import argparse

import glob

import json

import os

import re

import shutil

import stat

import sys

import random

from pathlib import Path


part_name = str(sys.argv[1])

domain_name = str(sys.argv[2])

batch_name = str(sys.argv[3]).zfill(5)

jsonfolder = r"/datablob/v-zhazhai/Basicdata"

output=r"/datablob/users/v-zhazhai/Language/en-US/display_data_prep_v3/output/long_form_fix/r12_merger_chunk/output_binary/"+ batch_name

registry = r"/datablob/users/v-zhazhai/Language/en-US/display_data_prep_v3/output/long_form_fix/r12_merger_chunk/merged_more_books_with_small_metadata_final/" + batch_name



#shared_name="en-us_youtube_realtext_" + part_name + "_" +  domain_name + "_" +  batch_name +  "_general"
shared_name="en-us_long_form_r12_textless_" + batch_name +  "_general"

commandline = "python torchtts/bin/train.py +experiment=fastspeech/unitts_v3 +dataset.lazy_decode=True dataset=unitts dataset.raw_data={} hydra.run.dir=. dataset.phone_set_path={}/phone_set.json dataset.speaker_set_path={}/speakers.json dataset.locale_set_path={}/locales.json dataset.style_set_path={}/styles.json dataset.add_locale_prefix=True dataset.shard_size=10000 +dataset.skip_training=True dataset.sample_rate=48000 trainer.device=cpu dataset.data_dir={} dataset.shard_name={} dataset.with_stat_data=true dataset.with_text_data=true dataset.with_context_info=true".format(registry, jsonfolder, jsonfolder, jsonfolder, jsonfolder, output, shared_name)

print(commandline)

os.system(commandline)

print('completed ~')
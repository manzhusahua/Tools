#!/bin/bash

python torchtts/bin/train.py \
  dataset=cifar10 \
  model=alexnet \
  trainer=basic_cv_trainer \
  hydra.run.dir=outputs/cifar10
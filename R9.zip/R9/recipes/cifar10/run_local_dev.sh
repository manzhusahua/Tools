#!/bin/bash

python torchtts/bin/train.py \
  dataset=cifar10 \
  dataset.split="train-dev" \
  model=alexnet \
  trainer=basic_cv_trainer \
  trainer.max_steps=10000 \
  trainer.log_interval=50 \
  trainer.save_interval=500 \
  hydra.run.dir=outputs/cifar10_dev
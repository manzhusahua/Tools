
#!/bin/bash

#set -euo pipefail

distributed="true"
# cluster="a100-scus"
# vc="speech-itp-tts"
# num_gpu=8
# cluster="a100-80gb-wus3"
# vc="speech-itp-tts-prod"
# num_gpu=8
#cluster="itp-v100-scus-2"
#vc="speech-itp-tts-prod"
#num_gpu=8
# cluster="v100-32gb-wus2-2"
# vc="speech-itp-tts"
# num_gpu=8
# cluster="itp-v100-scus"
# vc="speech-itp-tts-prod"
# num_gpu=8
cluster="itp-p100-wus2"
vc="speech-itp-default"
num_gpu=4



if [ $num_gpu -eq 1 ]; then
    distributed="false"
fi




preemptible="false"  

dist_config="ddp"
project_name="xx_streaming"
code_root=TorchTTS
extra_env_setup_cmd="pip install timm"


stage=3

#  source
if [ $stage -eq 1 ]; then
    extra_params="+experiment=conformer/conformer \
        trainer/dist_config=ddp trainer.dist_config.cluster_type=itp \
        model.enable_multi_speaker=True model.enable_multi_style=True \
        dataset=fastspeech \
        dataset.shard_size=1000 dataset.num_workers=1 \
        dataset.data_dir=/datablob/wujin/data/zhcn_v4/raw_gen/ \
        dataset.batch_size=6000 trainer.max_steps=600000 trainer.decay_rate=0.97 dataset.max_mel_len=1500 \
        dataset.with_speaker_id=True dataset.with_style_data=True dataset.with_locale_id=True \
        dataset.need_phone_pitch=True dataset.with_pitch_data=True dataset.pitch_norm.type=mean_var dataset.pitch_norm.f0_mean=215.4658 dataset.pitch_norm.f0_var=98.21176 \
        model.symbol_size=256 model.spk_size=128 +model.style_embedding_size=64 \
        +model.enable_ar_phn_pred=False \
        +model.enable_concat_lut=True \
        +dataset.bucket_step=2.0 \
        +model.embedding_activation=softsign \
        trainer.warm_start_from=/modelblob/wujin/xx_streaming/amlt-results/xx_source_from_0/7329682848.35232-7edecbfc-7cdc-456d-8449-d5680f0708ec/checkpoint-300000.pt" 


fi

# refine xx
if [ $stage -eq 2 ]; then
    extra_params="+experiment=conformer/conformer \
        trainer/dist_config=ddp trainer.dist_config.cluster_type=itp \
        model.enable_multi_speaker=True model.enable_multi_style=True \
        trainer.reset_trainer=True \
        +dataset.filter_speaker_id=1 \
        dataset=fastspeech \
        dataset.shard_size=1000 dataset.num_workers=1 \
        dataset.data_dir=/datablob/wujin/data/zhcn_v4/raw_gen/ \
        dataset.batch_size=4000 trainer.max_steps=600000 trainer.decay_rate=0.97 dataset.max_mel_len=1500 \
        dataset.with_speaker_id=True dataset.with_style_data=True dataset.with_locale_id=True \
        dataset.need_phone_pitch=True dataset.with_pitch_data=True dataset.pitch_norm.type=mean_var dataset.pitch_norm.f0_mean=215.4658 dataset.pitch_norm.f0_var=98.21176 \
        model.symbol_size=256 model.spk_size=128 +model.style_embedding_size=64 \
        +model.enable_ar_phn_pred=False \
        +model.enable_concat_lut=True \
        +dataset.bucket_step=2.0 \
        +model.embedding_activation=softsign \
        trainer.warm_start_from=/modelblob/zhihangxu/torchtts_unittsv4_zhcn_v5/gst_nonarpl16_pitch_hierarchical_softsign2/checkpoint-300000.pt" 


fi



# distil to 70mb
if [ $stage -eq 3 ]; then
    teacher_checkpoint=447000
    rnn_reduce=1
    dec_layers=2
    group=64
    batch=3000
    tgt_style=1
    # tgt_style=19-16-17-1-13-5-4-8-3-6-2-11-9
    exp_name="xx_streaming_70MB_from_${teacher_checkpoint}_tgt${tgt_style}_load_prod_goldenset_${rnn_reduce}_${dec_layers}_${group}_${cluster}_${num_gpu}gpu_batch${batch}"
    extra_params="+experiment=conformer/conformer \
                dataset=conformer dataset.batch_size=${batch} +dataset.bucket_step=1.5 \
                dataset.data_dir=/datablob/zhihangxu/data/zhcn/t2t_xiaoxiao_v5_adapt_selftraining/raw_gen_goldenset/ \
                dataset.enable_cross_lingual=True dataset.enable_multi_speaker=True +dataset.enable_multi_style=True \
                +dataset.load_fastspeech=True dataset.max_mel_len=1200 dataset.num_workers=2 dataset.odim=80 dataset.pin_memory=True \
                dataset.pitch_norm.f0_max=500 dataset.pitch_norm.f0_mean=215.4658 dataset.pitch_norm.f0_min=40 dataset.pitch_norm.f0_var=98.21176 dataset.pitch_norm.type=min_max \
                dataset.shard_format=tar dataset.shard_size=1000 dataset.split=train dataset.with_pitch_data=True \
                trainer/dist_config=ddp trainer.dist_config.cluster_type=itp trainer.dist_config.ddp.find_unused_parameters=True \
                trainer.decay_rate=0.95 \
                trainer.decay_steps=4000 +trainer.distil=full +trainer.distil_tgt_spk=1 +trainer.distil_tgt_style=${tgt_style} trainer.duration_loss_weight=0.1 trainer.enable_energy_loss=False trainer.enable_gst_loss=True trainer.enable_phone_emb_loss=True \
                trainer.enable_phone_kl_loss=False trainer.enable_pitch_loss=True \
                +trainer.fd_refine_from=/modelblob/wujin/xx_streaming/prod_70_checkpoint/checkpoint-200000.pt \
                +trainer.fd_refine_id=0_3 trainer.initial_lr=0.001 trainer.log_interval=100 trainer.max_steps=300000 trainer.mel2vec_pretrain=False trainer.ph_kl_loss_weight=0.0001 trainer.phoneme_bert_pretrain=False \
                trainer.reset_trainer=False trainer.save_interval=1000 \
                +trainer.teacher_config=/datablob/wujin/data/zhcn_v4/config_for_70.yaml \
                +trainer.teacher_model_path=/modelblob/zhihangxu/zhihangxu/amlt-results/xiaoxiao-gst_nonarpl16_pitch_hierarchical_softsign2-refinefrom-300000-selftraining_oldgoldenset600/checkpoint-447000.pt \
                +trainer.freeze_encoder=True \
                model.enable_multi_speaker=True model.enable_multi_style=True \
                model.symbol_size=256 model.spk_size=128 +model.style_embedding_size=64 \
                +model.enable_ar_phn_pred=False \
                +model.enable_concat_lut=True \
                +model.embedding_activation=softsign \
                +model.distil=full \
                +model.ffn_layer_type=single-sep-conv1d \
                model.enc_layers=6 model.dec_layers=${dec_layers} \
                +model.encoder_hidden_constraint=True +trainer.encoder_hidden_constraint=True \
                model.dec_use_highwayrnn=True \
                model.dec_rnn_bidirectional=False \
                model.dec_rnn_reduce=${rnn_reduce} \
                model.dec_hidden_dim=384 \
                model.dec_ffn_groups_batch_size=${group}"

fi

python third_party/Submitter/utils/amlt_submit.py \
    --service "amlk8s"  --cluster ${cluster} --virtual-cluster ${vc} \
    --gpu ${num_gpu} --distributed ${distributed} --preemptible ${preemptible} \
    --image-registry "docker.io" --image-repo "npuichigo" \
    --image-name "pytorch:pytorch1.8.1-py38-cuda11.1" \
    --data-container-name "philly-ipgsp" --model-container-name "philly-ipgsp" \
    --extra-env-setup-cmd "${extra_env_setup_cmd}" --local-code-dir "$(pwd)" \
    --amlt-project ${project_name} --exp-name ${exp_name} \
    --run-cmd "python torchtts/bin/train.py" --extra-params "${extra_params}" \
    --tool-type "TorchTTS"

#!/bin/bash

set -euo pipefail

cluster="a100-scus"
vc="speech-itp-tts"
num_gpu=8
preemptible="false"  # if ture, can access resources outside your quota
distributed="true"
dist_config="ddp"

project_name="torchtts-unitts_v3_sdtw"  # project name (e.g., tacotron/fastspeech)
# project_name="torchtts-unitts_v3"  # project name (e.g., tacotron/fastspeech)

exp_name="multi-spk-locale--soft_dtw--eva_from_scratch--a100"  # experimental name (e.g., Evan/Guy/Jessa)
# exp_name="multi-spk-locale-baseline-refine_audio_book_zhuang"  # experimental name (e.g., Evan/Guy/Jessa)

# if the packages not installed in the docker, you can install them here or set it as ""
extra_env_setup_cmd=""

# +experiment=fastspeech/base overrides the default config groups with
# the config file in torchtts/configs/experiment/fastspeech/base.yaml
# and is equal to dataset=fastspeech model=fastspeech trainer=fastspeech_trainer

extra_params="+experiment=fastspeech/unitts_v3_sdtw"
# extra_params="+experiment=fastspeech/unitts_v3"
extra_params=${extra_params}" dataset.data_dir=/datablob/yuanhyi/data/eva_v4_shard/"
# extra_params=${extra_params}" trainer.warm_start_from=/modelblob/yuanhyi/torchtts-unitts_v3_sdtw/multi-spk-locale-no_soft_decoder-refine_eva/pt-results/torchtts-unitts_v3_sdtw-c8bfb3ff-multi-spk-locale-no_soft_decoder-refine_eva-amlk8s-5eeec530/checkpoint-150000.pt"
# extra_params=${extra_params}" trainer.warm_start_from=/datablob/yuanhyi/checkpoint/torchtts-unitts_v3/multi-spk-locale-baseline/pt-results/torchtts-unitts_v3-c8bfb3ff-multi-spk-locale-baseline-amlk8s-eef20686/checkpoint-150000.pt"
# extra_params=${extra_params}" trainer.reset_trainer=False"
extra_params=${extra_params}" trainer.max_steps=300000"
extra_params=${extra_params}" dataset.batch_size=10000"
extra_params=${extra_params}" trainer/dist_config=${dist_config}"
extra_params=${extra_params}" trainer.dist_config.cluster_type=itp"

python third_party/Submitter/utils/amlt_submit.py \
    --service "amlk8s"  --cluster ${cluster} --virtual-cluster ${vc} \
    --gpu ${num_gpu} --distributed ${distributed} --preemptible ${preemptible} \
    --image-registry "azurecr.io" --image-repo "sramdevregistry" \
    --key-vault-name "exawatt-philly-ipgsp" --docker-username "tts-itp-user" \
    --image-name "torchtts:pytorch1.8.1-py38-cuda11.1" \
    --data-container-name "philly-ipgsp" --model-container-name "philly-ipgsp" \
    --extra-env-setup-cmd "${extra_env_setup_cmd}" --local-code-dir "$(pwd)" \
    --amlt-project ${project_name} --exp-name ${exp_name} \
    --run-cmd "python torchtts/bin/train.py" --extra-params "${extra_params}" \
    --tool-type "TorchTTS"

#!/bin/bash

set -euo pipefail

cluster="a100-80gb-wus3"
vc="speech-itp-tts-prod"
num_gpu=8
preemptible="false"  # if ture, can access resources outside your quota
distributed="true"
dist_config="ddp"

stage=1

project_name="foundationtts"  # project name (e.g., tacotron/fastspeech)
exp_name="codec_pretrain"  # experimental name (e.g., Evan/Guy/Jessa)

# if the packages not installed in the docker, you can install them here or set it as ""
extra_env_setup_cmd=""

data_dir="/datablob/yuczha/data/unified_datapipe/"

# 1. codec pretraining
# if you want to use istft upsampling layer, please
#    set use_istft to True and 
#    set up_ratios to [5, 5, 3] 
#    in "torchtts/configs/model/foundationtts/codec.yaml" codec_decoder

if [ $stage -eq 1 ]; then
  extra_params="+experiment=foundationtts/codec \
                dataset.data_dir=${data_dir} \
                dataset.batch_size=4500 \
                dataset.segment_length=24000 \
                trainer/dist_config=${dist_config} \
                trainer.dist_config.cluster_type=itp "
  extra_params=${extra_params}" trainer.warm_start_from=/datablob/yuanhyi/unittsv5/chp/codec/checkpoint-625000.pt"  # used by single voice refine from source model
fi

if [ $stage -eq 2 ]; then
  extra_params="+experiment=foundationtts/e2e \
                dataset.data_dir=${data_dir} \
                dataset.batch_size=6000 \
                +dataset.align_len=True \
                dataset.pitch_norm.type=mean_var \
                dataset.pitch_norm.f0_mean=196.07 \
                dataset.pitch_norm.f0_var=55.94 \
		model.acoustic_model.spk_size=3000 \
		model.acoustic_model.pitch_mean=196.07 \
		model.acoustic_model.pitch_var=55.94 \
		model.acoustic_model.enable_gst=True \
		model.acoustic_model.enable_phone_emb=False \
                trainer.disc_train_start_steps=0 \
                trainer.use_wave_pitch_std_loss=True \
                trainer/dist_config=${dist_config} \
                trainer.dist_config.cluster_type=itp \
                trainer.reset_trainer=False \
		model.acoustic_model.enable_multi_speaker=True  \
                model.acoustic_model.enable_multi_style=True  \
                model.acoustic_model.enable_cross_lingual=False  \
                model.acoustic_model.style_embedding_size=128"
fi

# 4. AM decoder distill for cpu setting.
if [ $stage -eq 3 ]; then
  extra_params="+experiment=foundationtts/distill \
               dataset.data_dir=${data_dir} \
               dataset.batch_size=4000 \
               trainer.warm_start_from=e2e.checkpoint \
               trainer/dist_config=${dist_config} \
               trainer.dist_config.cluster_type=itp \
			   +model.acoustic_model.enable_gst=False \
			   model.acoustic_model.enable_phone_emb=False"
fi

# 5. (On demand) AM full distill.
if [ $stage -eq 4 ]; then
  extra_params="+experiment=foundationtts/full_distill \
               dataset.data_dir=${data_dir} \
               dataset.batch_size=2000 \
               trainer.warm_start_from=e2e.checkpoint \
               trainer.target_spk_id=71 \
               trainer/dist_config=${dist_config} \
               trainer.dist_config.cluster_type=itp \
			   +model.acoustic_model.enable_gst=False \
			   model.acoustic_model.enable_phone_emb=False"
fi

# 6. (On demand) Vocoder distill.
if [ $stage -eq 5 ]; then
  extra_params="+experiment=foundationtts/voc_distill \
               dataset.data_dir=${data_dir} \
               dataset.batch_size=2000 \
               trainer.warm_start_from=e2e.checkpoint \
               trainer.target_spk_id=71 \
               trainer/dist_config=${dist_config} \
               trainer.dist_config.cluster_type=itp"
fi

# if phone embedding is added, fix pitch tuning.
if [ $stage -eq 6 ]; then
  extra_params="+experiment=foundationtts/postprocess \
               dataset.data_dir=${data_dir} \
               dataset.batch_size=1200 \
               trainer.warm_start_from=distill.checkpoint \
               trainer/dist_config=${dist_config} \
               trainer.dist_config.cluster_type=itp"
fi

python third_party/Submitter/utils/amlt_submit.py \
    --service "amlk8s"  --cluster ${cluster} --virtual-cluster ${vc} \
    --gpu ${num_gpu} --distributed ${distributed} --preemptible ${preemptible} \
    --image-registry "azurecr.io" --image-repo "sramdevregistry" \
    --key-vault-name "exawatt-philly-ipgsp" --docker-username "tts-itp-user" \
    --image-name "torchtts:pytorch1.8.1-py38-cuda11.1" \
    --data-container-name "philly-ipgsp" --model-container-name "philly-ipgsp" \
    --extra-env-setup-cmd "${extra_env_setup_cmd}" --local-code-dir "$(pwd)" \
    --amlt-project ${project_name} --exp-name ${exp_name} \
    --run-cmd "python torchtts/bin/train.py" --extra-params "${extra_params}" \
    --tool-type "TorchTTS"

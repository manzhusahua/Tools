#!/bin/bash

python torchtts/bin/train.py \
  +experiment=hifinet/base \
  dataset.raw_data=$(pwd)/raw_data \
  hydra.run.dir=outputs/hifinet \
  dataset.preprocess_workers=8

#!/bin/bash

# Copyright  2022  Microsoft (author: Ke Wang)

set -euo pipefail

region="southcentralus"        # eastus, southcentralus, westus2, westus3, rrlab
cluster="spch-sing-ttsprod-sc"     # spch-sing-tts-sc, spch-sing-ttsprod-sc, spch-singttsprod-wu3, spch-sing-tts-wu2, spch-singttsprod-wu2, cogsvc-sing-amd-vc01, spch-sing-wu3
num_nodes=2                    # 1 GPU node
gpus_per_node=8                # each node with 4 GPUs
memory_size=32                 # 16GB
gpu_type="V100"                # V100 GPU
interconnect_type="IB"         # "Empty", "IB", "NvLink", "xGMI", "IB-xGMI", "NvLink-xGMI"
sla_tier="Premium"            # Basic, Standard or Premium
distributed="true"             # enable distributed training or not
#dist_method="torch"            # torch or horovod

project_name="hifinet_singularity"    # project name (e.g., tacotron/fastspeech)
exp_name="univ2_24k"  # experimental name (e.g., Evan/Guy/Aria)

# if the packages not installed in the docker, you can install them here
extra_env_setup_cmd=" \
pip install -r requirements.txt \
" # or extra_env_setup_cmd=""

data_dir=""

extra_params=" \
+experiment=hifinet/universal_v2 \
dataset=hifinet_24k_100mel \
dataset.data_dir=${data_dir} \
dataset.batch_size=16 \
model.generator.in_channels=100 \
model.generator.ngf=64 \
model.spec_discriminator.channels=64 \
trainer.use_stft_loss=True \
trainer.lambda_feat_match_loss=2.0 \
trainer.use_feat_match_loss=True \
trainer/dist_config=ddp \
trainer.dist_config.cluster_type=itp \
"

# ============================================================================

python -u ./third_party/Submitter/utils/amlt_submit.py \
  --service "singularity" --region ${region} --cluster ${cluster} \
  --num-nodes ${num_nodes} --gpus-per-node ${gpus_per_node} \
  --memory-size ${memory_size} --gpu-type ${gpu_type} --sla-tier ${sla_tier} \
  --interconnect-type ${interconnect_type} --distributed ${distributed} \
  --key-vault-name "exawatt-philly-ipgsp" --docker-username "tts-itp-user" \
  --image-registry "azurecr.io" --image-repo "sramdevregistry" \
  --image-name "pytorch:1.13.0-py38-cuda11.6-cudnn8-ubuntu20.04" \
  --data-container-name "philly-ipgsp" --model-container-name "philly-ipgsp" \
  --extra-env-setup-cmd "${extra_env_setup_cmd}" --local-code-dir "$(pwd)" \
  --amlt-project ${project_name} --exp-name ${exp_name} \
  --run-cmd "python torchtts/bin/train.py" --extra-params "${extra_params}" \
  --tool-type "TorchTTS"

  # --image-registry "docker.io" --image-repo "npuichigo" \
  # --image-name "pytorch:pytorch1.8.1-py38-cuda11.1" \

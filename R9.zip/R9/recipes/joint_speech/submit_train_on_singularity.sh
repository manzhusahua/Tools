#!/bin/bash

set -euo pipefail

region="southcentralus"        # eastus, southcentralus, westus2
cluster="spch-sing-ttsprod-sc" # spch-sing-tts-sc, spch-sing-ttsprod-sc
num_nodes=1                    # 1 GPU node
gpus_per_node=4                # each node with 1 GPU
memory_size=16                 # 16GB
gpu_type="V100"                # V100 GPU
interconnect_type="IB"      # "Empty", "IB", "NvLink", "xGMI", "IB-xGMI", "NvLink-xGMI"
sla_tier="Premium"            # Basic, Standard or Premium
distributed="true"
dist_config="ddp"

project_name="v5"  # project name (e.g., tacotron/fastspeech)
exp_name="joint_speech_esmx_dalia"  # experimental name (e.g., Evan/Guy/Jessa)

# if the packages not installed in the docker, you can install them here or set it as ""
extra_env_setup_cmd="pip install -r requirements.txt"

data_dir="/datablob/v-litfen/unitts/unified_data/"

              #+dataset.shard_masks='[es-mx_TTS_*.tar]' \
              #+dataset.shard_masks='[zh-cn_TTS_ZhCNF128_General_General-*.tar]' \
extra_params="+experiment=joint_speech/base \
              dataset.data_dir=${data_dir} \
              +dataset.shard_masks='[es-mx_TTS_EsMXSDIAnaliz_*.tar]' \
              dataset.batch_size=6000 \
              dataset.num_workers=1 \
              trainer.save_interval=10000 \
              trainer.max_steps=1000000 \
              trainer/dist_config=${dist_config} \
              trainer.dist_config.cluster_type=itp"

python third_party/Submitter/utils/amlt_submit.py \
    --service "singularity" --region ${region}  --cluster ${cluster} \
    --num-nodes ${num_nodes} --gpus-per-node ${gpus_per_node} \
    --memory-size ${memory_size} --gpu-type ${gpu_type} --sla-tier ${sla_tier} \
    --interconnect-type ${interconnect_type} --distributed ${distributed} \
    --image-registry "azurecr.io" --image-repo "sramdevregistry" \
    --key-vault-name "exawatt-philly-ipgsp" --docker-username "tts-itp-user" \
    --image-name "pytorch:1.13.0-py38-cuda11.6-cudnn8-ubuntu20.04" \
    --data-container-name "philly-ipgsp" --model-container-name "philly-ipgsp" \
    --extra-env-setup-cmd "${extra_env_setup_cmd}" --local-code-dir "$(pwd)" \
    --amlt-project ${project_name} --exp-name ${exp_name} \
    --run-cmd "python torchtts/bin/train.py" --extra-params "${extra_params}" \
    --tool-type "TorchTTS"

#!/bin/bash

# We provide different pre-defined config files for experiment in torchtts/configs
# like base, pitch_contour to free you from having to specify all the parameters
# on command line, although you can still further modify them on cmd.

# +experiment=leanspeech/base overrides the default config groups with
# the config file in torchtts/configs/experiment/leanspeech/base.yaml
# and is equal to dataset=fastspeech model=leanspeech trainer=leanspeech_trainer
python torchtts/bin/train.py \
  +experiment=leanspeech/base \
  dataset.raw_data=$(pwd)/raw_data \
  hydra.run.dir=outputs/leanspeech

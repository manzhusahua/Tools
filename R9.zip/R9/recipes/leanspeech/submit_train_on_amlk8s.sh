#!/bin/bash

set -euo pipefail

cluster="$2"
vc="$3"
num_gpu=8
preemptible="false"  # if ture, can access resources outside your quota
distributed="true"
dist_config="ddp"

project_name="leanspeech"  # project name (e.g., tacotron/fastspeech)
datestr=$(date +'%Y-%m-%d-%H-%M-%S')
exp_name=$1"-"${datestr}  # experimental name (e.g., Evan/Guy/Jessa)

# if the packages not installed in the docker, you can install them here or set it as ""
extra_env_setup_cmd="pip install matplotlib"

extra_params="+experiment=leanspeech/base"
#extra_params=${extra_params}" dataset.data_dir=/datablob/jinzl/work/deviceNTTS/jessa/shard_data_style0 dataset.with_style_data=True model.use_style=False"
#extra_params=${extra_params}" dataset.data_dir=/datablob/jinzl/work/deviceNTTS/xx/v4-am/xx_student_20210225_shard/ dataset.with_style_data=True model.use_style=False"
#extra_params=${extra_params}" dataset.data_dir=/datablob/jinzl/work/deviceNTTS/NeerjaV3/stu_data/shard_data_small_phoneset/ dataset.with_style_data=True model.use_style=False"
#extra_params=${extra_params}" dataset.data_dir=/datablob/jinzl/work/deviceNTTS/bernice/v4_am/small_phoneset/shard_data/ dataset.with_style_data=True model.use_style=False"
extra_params=${extra_params}" dataset.data_dir=/datablob/jinzl/work/deviceNTTS/jenny/fs_stu_GD_shard_data/ dataset.with_style_data=True model.use_style=False"
extra_params=${extra_params}" trainer/dist_config=${dist_config}"
extra_params=${extra_params}" trainer.dist_config.cluster_type=itp"

# uncomment belows for pitch model training
#extra_params=${extra_params}" dataset.data_dir=/datablob/jinzl/work/deviceNTTS/jessa/shard_data_pitch dataset.with_pitch_data=True dataset.with_style_data=True model.use_style=True"
#extra_params=${extra_params}" model.enable_pitch_contour=True trainer.enable_pitch_loss=True trainer.warm_start_from=/datablob/jinzl/work/deviceNTTS/jessa/v5_am/convRnnHighwayDrop/checkpoint-400000.pt"
#extra_params=${extra_params}" trainer.max_steps=600000"

python third_party/Submitter/utils/amlt_submit.py \
    --service "amlk8s"  --cluster ${cluster} --virtual-cluster ${vc} \
    --gpu ${num_gpu} --distributed ${distributed} --preemptible ${preemptible} \
    --image-registry "azurecr.io" --image-repo "sramdevregistry" \
    --key-vault-name "exawatt-philly-ipgsp" --docker-username "tts-itp-user" \
    --image-name "torchtts:pytorch1.8.1-py38-cuda11.1" \
    --data-container-name "philly-ipgsp" --model-container-name "philly-ipgsp" \
    --extra-env-setup-cmd "${extra_env_setup_cmd}" --local-code-dir "$(pwd)" \
    --amlt-project ${project_name} --exp-name ${exp_name} \
    --run-cmd "python torchtts/bin/train.py" --extra-params "${extra_params}" \
    --tool-type "TorchTTS"

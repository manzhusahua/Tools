# Support new locales with low resource TTS

## Introduction

Low resource TTS means supporting a new locale with a few high quality TTS recording (even without pronunciation lexicon).
To achieve it, we will adapt from pre-trained models and use large SR low quality audio data set to help training.

This folder contains tools and documents for low resource TTS development.
[Related Onenote section](https://microsoft.sharepoint.com/teams/stca/ipe/_layouts/OneNote.aspx?id=%2Fteams%2Fstca%2Fipe%2FShared%20Documents%2FTTS%20Engineer%2FTTS%20Frontend%20innovation&wd=target%282020%20Low%20resource%20TTS.one%7C2052AA93-F5D4-478D-B578-890C6596B12D%2FProject%20description%7C0E283DC7-7BFF-4D00-A3F2-33CA9FA9B669%2F%29)

## Prerequisites

<details><summary>Click to expand</summary>

### Philly / ITP GPU cluster

For training jobs, You can submit it to [Philly](https://philly/) or [ITP](https://ml.azure.com/clusters?flight=itpmerge) GPU cluster.
Before starting using it, you need to join the `txt2spch` group on [idweb](https://idweb/) to get the permission.
We usually submit jobs to `tts-prod` queue of `ipgsp` virtual cluster in `sc1` region.

Here are some useful resources:

- [document entry](https://phillywiki.azurewebsites.net/articles/Getting_Started.html)
- [how to create a job](https://phillywiki.azurewebsites.net/articles/Philly_OnAzure_QuickStart.html)
- [job config file format](https://phillywiki.azurewebsites.net/articles/Environment.html#variables)

For specific samples, please refer to [low resource locale TTS recipe](https://microsoft.sharepoint.com/teams/stca/ipe/blue/_layouts/OneNote.aspx?id=%2Fteams%2Fstca%2Fipe%2Fblue%2FShared%20Documents%2FTTS%20GDI&wd=target%28Legacy%20Notes%202018%2FNeural%20TTS%20Expansion_2%2FFY21_H2.one%7CDA381662-4635-4FE2-A8EE-06441303AEF2%2FLow%20Resource%20TTS%20Recipe%20v3%5C%2Fv4%20%28support%20force%20alignment%7C7C5DD203-B683-4A6C-93F4-839F4DE930F1%2F%29)

### Personal Linux GPU dev machine

You may need a personal GPU dev machine for light weight jobs like debugging or inference without queueing on Philly.
Here are several choices:

1. [GCR](http://gcr-reservations/) Linux GPU sandbox: Follow the FAQ to reserve a machine. **Notice**: These machines are dedicated for short term use. Besides, TTS team has been reorganized into C+AI group, so you may be unable to get the access now.

2. Azure GPU VM: Create a GPU VM under `CIG-Speech` subscription. **Notice**: Azure GPU VM is expensive. K80 GPU should be enough for local works. Remember to set automatic shutdown in night.

3. Physical GPU workstation: Check [this page](https://microsoft.sharepoint.com/teams/stca/ipe/blue/_layouts/OneNote.aspx?id=%2Fteams%2Fstca%2Fipe%2Fblue%2FShared%20Documents%2FTTS%20GDI&wd=target%28Infrastructure.one%7C86BE1600-4A5E-4F49-A87D-C268DAF81C2C%2FGPU%20workstation%7C2C59B41C-99FD-4A95-992D-1B9A68E4E5DD%2F%29).

 **It's recommended to use Docker containers for environment setup.**

### Cloud storage

Our Philly jobs usually load data from a mounted Azure blob container.
After joining the `txt2spch` group, you can find premium blob containers in `Speech Infrastructure` subscription.
Then you can create a folder with your alias as name under the premium blob container in the region you need (usually `https://exawattaiprmbtts01scus.blob.core.windows.net/philly-ipgsp` because dedicated Philly queues for TTS team are in `sc1` region).

Download [azcopy](https://docs.microsoft.com/en-us/azure/storage/common/storage-use-azcopy-v10) for blob operations in command line, and [Azure Storage Explorer](https://azure.microsoft.com/en-us/features/storage-explorer/) for GUI.
[azcopy.py](backend/azcopy.py) can help you execute some common operations.

**Notice**: Premium blob storage is expensive, so remember to remove unnecessary files.
You can backup flies in `https://ttsdata.blob.core.windows.net/ttsdata/user` which is cheaper.
You need to contact Gang Wang (alias: gaw) to get the access permission first.

### Raw Data

You need to find raw data for low resource TTS before start working.

1. TTS recording: contact the PM owner for high quality TTS recording. For EU24 locales, You can contact Garfield He (alias: garhe).

2. SR data: contact the SR team for their data. For EU24 locales, there is a backup in `https://ttsdata.blob.core.windows.net/ttsdata/users/xianta/LowResourceRawData/`

</details>

## Recipe
The latest low resource locale TTS recipe can refer to [low resource locale TTS recipe](https://microsoft.sharepoint.com/teams/stca/ipe/blue/_layouts/OneNote.aspx?id=%2Fteams%2Fstca%2Fipe%2Fblue%2FShared%20Documents%2FTTS%20GDI&wd=target%28Legacy%20Notes%202018%2FNeural%20TTS%20Expansion_2%2FFY21_H2.one%7CDA381662-4635-4FE2-A8EE-06441303AEF2%2FLow%20Resource%20TTS%20Recipe%20v3%5C%2Fv4%20%28support%20force%20alignment%7C7C5DD203-B683-4A6C-93F4-839F4DE930F1%2F%29).

**Notice**: The following introduction is the first edition recipe (finished by Xianghao). Some information and links may be out of date. Please refer to the above low resource locale TTS recipe.


## Data processing

<details><summary>Example: `\\MININT-GEUQUDH\LowResourceTTS\Production\mt-MT`</summary>

### Text normalization

Text normlization rules can convert text from display form to spoken form (from "10" to "ten" for example) which is more friendly to our engine.
Nina Yang (alias: nayan) has developed a tool for converting SR TN rules to a format supported by TTS engine.

If text normalization rules are absent, training text containing non-spoken patterns like digits should be discarded or converted manually.

### General processing

<details><summary>Here are some general steps you can apply to all data sets.</summary>

#### Extract text

[proccess_text.py](data/process_text.py) can extract text and wave names from different data set layouts to a metadata file.
Non-spoken patterns can be detected in this step.
You can support new data set layouts in this script.

**Notice**: The string before the first underscore in a wave name will be recognized as the speaker name in following steps, so wave names should be carefully encoded.

#### Check character set

[get_char_set.py](data/get_char_set.py) can count character occurrences in data sets.
In this step we will usually run it without `--output_dir` option on text extracted by [proccess_text.py](data/process_text.py).
It's recommended to run on text merged by [merge_data.py](data/merge_data.py) to get a complete view.
Then you need to check the character set.

- Ensure no characters indicating non-spoken form (like digits and special symbols)

- Compare the letter set with Wikipedia. Usually we will assume native and English letters are legal because they are common-used.

- Determine the punctuation set.

It's recommended to remove all training cases containing rare characters from the metadata because these characters are unnecessary, hard to learn and might bring unstability.

#### Extract waves

[process_waves.py](data/process_wav.py) can extract waves from different data layouts.
Waves will be converted to mono channel and desired sample rates, then packaged to a ZIP file.
You may support new data set layouts in this script.

#### Filter bad training cases

You can check wave speed with [check_speaking_speed.py](data/check_speaking_speed.py) and remove those with outlier speed from metadata.

If there are a true phone set and a phone alignment model, [more tools](https://msasg.visualstudio.com/TextToSpeech/_git/SpeechAssess) can be used.

#### Merge metadata

Merge all metadata to a large training set with [merge_data.py](data/merge_data.py).

</details>

### TTS recording

TTS recordings are recorded in recording studio with professional voice talent. Her voice will be our target voice.
We usually expect:

- Audios are very clean (no noise).
- The speaker has standard pronunciations (no accent).
- The speaker controls her voice well. The prosody is consistent and stable.

Raw TTS recording scripts are usually saved in Excel spreadsheets.
They will be reviewed by native speakers.
Use the revised version if possible.

There might be some retaking due to quality issues.
Use the retaken version if possible.

### SR data

<details><summary>SR data are collected for speech recognition, so there are no audio quality guarantees.</summary>

There might be following issues:

- Environment noise
- Other speakers
- Unstable and diverse prosody
- Diverse accent

It's recommended to denoise these audios.
We use [PSNet](https://msasg.visualstudio.com/TextToSpeech/_git/Denoise?path=%2FPSNet%2Fsrc%2Fphilly_run.sh&version=GBxianta%2Fdaily&_a=contents) from MSRA to do it.
Waves are much cleaner after denoising.
This script will also extract Mel features of denoised waves after denoising.

#### Speech Ocean KingASR data

Speech Ocean KingASR data are recorded by phones when normal native speakers read prompted sentence aloud.
There are usually some background noise.

Audios are transcribed again later.
Transcription is preferred over prompt sentence as true text, but if transcription doesn't contain punctuations, we have to use prompt sentence to get basic breaking information.

Necessary processing:

- There are special symbols like `<TAG/>` or `**` in transcriptions representing disfluency or bad parts in audios. Check `TRANSCRIP.PDF` in data set document and remove these symbols. Sentences with such symbols should be discarded.

Optional processing:

- If a transcription is different from the prompt, it means the speaker read the prompt wrong, possibly indicating unstable speaking which is harmful to model training. Such cases can be discarded.

#### AppTek data

AppTek data consists of long waves of news broadcasts and some annotations.

Necessary processing:

- Split long waves into smaller pieces based on segmentation information in the data set.

- Handle sepcial symbols in transcriptions. Reference `https://ttsdata.blob.core.windows.net/ttsdata/users/xianta/LowResourceRawData/AppTek-news/tag_inventory.xlsx`. Usually we will discard cases with significant problem.

Optional processing:

- TODO: Each segmentation (average length 10 seconds) might contain several sentences. Try to find some ways to split them.

- To make speaker embedding training effective, we may only select those speakers with more than 5 or 10 minutes audio.

</details>

### Generate language data files

After data processing is completed, you can run [get_char_set.py](data/get_char_set.py) with `--output_dir` argument on merged metadata to generate some data files required by following work:

- `MSTTSLocXXXX.ini`: language INI containing a char-to-phone-id table required by character-based frontend
- `phone.txt`: a basic phone set file for dumping phone. It might be not suited for the final neural voice.
- `phone_set.json`: a phone set for acoustic model training, only containing new locale phones
- `phone_set.unitts.json`: a phone set for acoustic model adaptation, including source model phones and new locale phones
- `phone_set.xml`: a fake phone set used in raw frontend data

### Pronunciation module

Phonemes are more friendly than characters as input of acoustic models.
Traditionally, pronunciation lexicon and grapheme-to-phoneme models are responsible for pronouncing.

If pronunciation module is absent, we have to use characters as fake phonemes.

### Support a new locale in engine code

Reference [this commit](https://msasg.visualstudio.com/TextToSpeech/_git/TextToSpeechMain/commit/29218ce20700792a091030ddcdaa5aa396f4aa8c?refName=refs%2Fheads%2Ftts_dev) to create a pull request.
Related locale ID value can be found in [here](https://ss64.com/locale.html).

### Character-based frontend

#### Frontend data of new locale

Example: `TextToSpeechMain\private\dev\speech\tts\shenzhou\DataDrop\FrontendData\mt-MT`

1. Copy the example folder for the new locale
2. Replace `phoneset.xml` with the one generated by [get_char_set.py](data/get_char_set.py)
3. Update language name in files under the new locale folder
4. Check in the new locale data folder

#### Compile new langauge data and integrate it

[Example voice folder](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralTtsRelease?path=%2FAntonella)

1. Compile raw data into binary following [this](https://microsoft.sharepoint.com/teams/stca/ipe/_layouts/OneNote.aspx?id=%2Fteams%2Fstca%2Fipe%2FShared%20Documents%2FTTS%20Engineer%2FTTS%20Frontend%20Data%20Development&wd=target%28Quality%20Improvement.one%7C42AF8268-34E0-48B6-8DBD-0F9AA50B9FF4%2FLanguage%20Data%20Compiler%7C2FD20323-F41D-4C1E-B1F7-9DD5B8DE54B3%2F%29) (you may need to install `TextToSpeechMain\target\distrib\debug\amd64\dev\Server\bin\SpeechPlatformRuntime.msi` ahead)
2. Test it with `TextToSpeechMain\target\distrib\debug\amd64\dev\TTS\Server\bin\Offline\TtsDebugger.exe`
3. Copy `MSTTSLocXXXX.ini` generated by [get_char_set.py](data/get_char_set.py) and compiled `MSTTSLocXXXX.dat` to `Frontend` folder under the voice folder
4. Modify name and locale ID in `Tokens.xml`
5. Check in `MSTTSLocXXXX.ini` and `MSTTSLocXXXX.dat` to `TextToSpeechMain\private\dev\speech\tts\shenzhou\DataDrop\Dropfolder\lochand\XXXX`

### Dump phonemes with engine

To align data processing with engine runtime, we will use `ttsdumptool` in `NeuralTtsServer` to dump phonemes on Linux.
You can download compiled binary from [daily build](https://msasg.visualstudio.com/TextToSpeech/_build?definitionId=9868).
Check `phone` mode in [dump.py](backend/dump.py) for its usage.

There are several steps after you get phonemes:

1. Attach phonemes to metadata with [ensemble_phone.py](data/ensemble_phone.py)
2. Generate a speaker table from merged metadata with [get_speaker_set.py](data/get_speaker_set.py)
3. Convert the metadata to the format expected by training code with [convert_metadata.py](data/convert_metadata.py)

To avoid first word missing due to inconsistent beginning silence length in SR data, A BOS token is added at the beginning of each phone sequence.

</details>

## Acoustic model training

<details><summary>Acoustic model can predict spectrogram features for input sentence.</summary>

It's responsible for following problems:

- convert input phonemes to corresponding spectrum
- predict durations of input symbols
- predict prosody of the sentence

Related code are save in [NeuralVoiceModelling](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling).
Currently Low resource TTS recipe is still in developing, so check out the `xianta/daily` branch to start.

### Mel feature extraction

Mel features are usually used as output of acoustic models.
Here is a brief introduction of feature extraction:

1. Split each second to 80 frames
2. Perform short time Fourier transform on each frame to get spectrograms.
3. Extract 80-dimension Mel features from the spectrograms.

We usually run [this script](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FModelTrainerV1%2Fpreprocess.py) on 16k sample rate audios to extract Mel features into `.npy` files.

### Pretrained acoustic model

Uni-TTS source model is a Transformer-TTS model trained with multi-lingual multi-speaker data.
Usually we will adapt from it with new locale data.
There is a backup in https://exawattaiprmbtts01scus.blob.core.windows.net/philly-ipgsp/xianta/model/unitts_source_v2/

### Generate TFRecord binary

Small data files will be converted to structured binary TFRecord files to accelerate IO.
Check [this script](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FFastSpeech%2Fruns%2Flow_resource%2Fgen_low_resource.sh&version=GBxianta%2Fdaily&_a=contents) for how to do it.
`phone_set.unitts.json` generated by [get_char_set.py](data/get_char_set.py), converted metadata and mel features are required.

Given that we hope to get a clean voice, TTS recordings are upsampled by duplicating TFRecord files in the script.
Usually we adjust the upsample rate to make TTS recordings can account for 5%-10% of the training set.

### Adapt pretrained model

We will adapt the source model with new locale data.
Reference the [training script](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FFastSpeech%2Fruns%2Flow_resource%2Funitts_low_resource_adapt.sh&version=GBxianta%2Fdaily&_a=contents) and the [job config file](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FFastSpeech%2Fruns%2Flow_resource%2Funitts_low_resource_adapt.json&version=GBxianta%2Fdaily&_a=contents).
Reference [inference script](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FFastSpeech%2Fruns%2Flow_resource%2Funitts_low_resource_inference.sh&version=GBxianta%2Fdaily&_a=contents) for test.
You can use test sentences from [here](https://microsoftapc.sharepoint.com/:f:/t/TTSCompetitorMOSTest/Eg1KyNbyXj9NkC1GRfYzDa0BaYFPUdkpb5No8T9fZGtUTQ?e=uRDn1m).

There is an optional refine stage with only TTS recordings after the adaptation.
You can compare models before and after refinement and pick the better one.

### Knowledge distillation

The engine usually uses FastSpeech model in production for more robustness and smaller latency. Reference the [distillation script](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FFastSpeech%2Fruns%2Flow_resource%2Funitts_low_resource_distill.sh&version=GBxianta%2Fdaily&_a=contents) and the [job config file](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FFastSpeech%2Fruns%2Flow_resource%2Funitts_low_resource_distill.json&version=GBxianta%2Fdaily&_a=contents).

An important point is setting `--attn_constraint=True` in `hparams` of teacher inference command to make attention weights more diagonal, which is beneficial for FastSpeech student training.
Also, there several filters in generation of distillation data TFRecord files because the teacher sometimes has attention issues due to low quality SR data in training.

After the training is finished, you can integrate the model into engine following :

1. Dump a `.pb` model for engine by setting `--dump_model=True` in [student inference script](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2FFastSpeech%2Fruns%2Flow_resource%2Funitts_fs_inference.sh&version=GBxianta%2Fdaily&_a=contents)
2. Convert the `.pb` model to CUDA model following [this](https://microsoft.sharepoint.com/teams/stca/ipe/blue/_layouts/OneNote.aspx?id=%2Fteams%2Fstca%2Fipe%2Fblue%2FShared%20Documents%2FTTS%20GDI&wd=target%28Neural%20TTS%20Expansion.one%7C7CA520C6-A0B1-42E5-8B61-CE303519AD57%2FTransformer%20teacher%20data%20process%20and%20model%20train%5C%2Fdump%20recipe%7C2BC4952F-0B50-4F36-8C21-7DB45B6591E1%2F%29d)
3. Reference [example voice folder](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralTtsRelease?path=%2FAntonella) to integrate it into engine
4. Convert `phone_set.json` of student model to engine `phone.txt` format with [convert_phone_set.py](backend/convert_phone_set.py)

</details>

## Vocoder training

<details><summary>
Vocoder can recover the wave form from spectrogram features.
</summary>

We usually use audio with 24k sample rate to get high quality.

### MelGAN vocoder

Check [this](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralVoiceModelling?path=%2Fvocoders%2Fmelgan%2FREADME.md&version=GBmaster&_a=preview) for training, then reference [example voice folder](https://msasg.visualstudio.com/TextToSpeech/_git/NeuralTtsRelease?path=%2FAntonella) to integrate it into engine.

Then you can use `ttsdumptool` in `NeuralTtsServer` to call it. You can download compiled binary from [daily build](https://msasg.visualstudio.com/TextToSpeech/_build?definitionId=9868). Check `wave` mode in [dump.py](backend/dump.py) for its usage.

</details>

## Evaluation

<details><summary>Click to expand</summary>

You can submit tests on [UHRS](http://speechdx/firstparty/UHRSTest).
The task creation page will give an example for data folder layout.

For new locales, contact Kesheng Chen (alias: v-kesche) to add following test types:

- MOS test: an absolute score for each voice. Human recordings are usually tested together with synthesized audio to set a baseline.
- CMOS test: an relative score between two voices. It's usually used to compare two voices with a little difference.
- Pronunciation test: Test pronunciation accuracy.

### Basic goals

- MOS > 3.5
- Intelligible rate > 98%

### Advanced goals

- MOS gap with recording < 0.5
- Pronunciation accuracy > 95%

</details>

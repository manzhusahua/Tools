import sys
import os


def add_path():
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

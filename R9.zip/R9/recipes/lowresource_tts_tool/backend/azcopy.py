import argparse
import platform
import itertools
from pathlib import Path

import add_path
add_path.add_path()

from helper.func_helper import request_for_yes, runtime_check
from helper.io_helper import read_json
import lib.azcopy as azcopy
from lib.model_file import ModelDir, MODEL_DIR_FACTORY_DICT

# short names for config paths
CONFIG_PATH_DICT = {
    'main': Path.home() / 'azcopy_config.json',
    'backup': Path.home() / 'azcopy_backup_config.json',
    'ttsdata': Path.home() / 'azcopy_ttsdata_config.json',
    'user': Path.home() / 'azcopy_user_config.json',
}


def get_simple_mode_azcopy_task(mode: str) -> azcopy.Task:
    words = mode.split('_')
    if len(words) == 2:
        words = ['copy'] + words
    else:
        runtime_check(len(words) == 3, "Illegal number of words in mode")

    task = azcopy.Task(*words)
    return task


def main(args):

    config_path = CONFIG_PATH_DICT.get(args.config, Path(args.config))

    config = read_json(config_path)
    if 'mode_specific' in config:
        mode_specific_config = config['mode_specific'].get(args.mode, {})
        config.update(mode_specific_config)

    try:
        runner = azcopy.Runner(local_root=args.local_root, **config)
    except TypeError:
        print('ERROR: bad format of config file')
        raise

    def azcopy_multiple_run(paths, task):
        for path in paths:
            runner.run(path, task)

    if args.mode == 'sync_code':
        extra_args = ['--exclude-path', '.git', '--exclude-pattern', '*.pyc', '--delete-destination', 'true']
        task = azcopy.Task(command='sync', direction='up', item_type='dir', extra_args=extra_args)
        azcopy_multiple_run(args.code_dir, task)

    elif args.mode == 'down_ckpt':
        if args.local_path is not None:
            model_dirs = [ModelDir(local_path, args.model_type) for local_path in args.local_path]
        elif args.model_name is not None:
            model_dir_factory = MODEL_DIR_FACTORY_DICT[args.model_type]
            model_dirs = [model_dir_factory.get_model_dir(model_name) for model_name in args.model_name]
        else:
            raise RuntimeError('Do not know which checkpoint to download. Please specify local_path or model_type')

        task = azcopy.Task(command='copy', direction='down', item_type='file')
        for model_dir in model_dirs:
            azcopy_multiple_run(model_dir.get_ckpt_paths(args.step), task)

    else:
        task = get_simple_mode_azcopy_task(args.mode)
        azcopy_multiple_run(args.local_path, task)


if __name__ == '__main__':

    if platform.system() == 'Windows':
        request_for_yes("This program assumes delimiter in path is '/'.")

    special_modes = ['sync_code', 'down_ckpt']
    simple_modes = itertools.product(['', 'copy_', 'sync_'], ['down', 'up'], ['_'], ['file', 'dir'])
    simple_modes = map(lambda x: ''.join(x), simple_modes)
    simple_modes = list(simple_modes)

    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=special_modes + simple_modes)

    parser.add_argument('--local_root', type=Path, default=Path.home(),
                        help='the root directory of local working space, all transfer related paths should be under it')

    parser.add_argument('--config', default='main',
                        help='the path of config file (a short identifier can also be used)')

    parser.add_argument('--local_path', nargs='+', type=Path,
                        help='local paths to transfer')

    # for sync_code mode
    parser.add_argument('--code_dir', nargs='+', type=Path, default=[Path.home() / 'NeuralVoiceModelling'],
                        help='directories of code to sync (only for sync_code mode)')

    # for down_ckpt mode
    parser.add_argument('--step', type=int,
                        help='checkpoint step to download (only for down_ckpt mode)')

    # for pre-designed down ckpt modes
    parser.add_argument('--model_type', choices=MODEL_DIR_FACTORY_DICT.keys(), default='unitts',
                        help='model type of checkpoints to download (only for down_ckpt mode)')
    parser.add_argument('--model_name', nargs='+',
                        help='model names to download (only for down_ckpt mode)')

    args = parser.parse_args()

    main(args)

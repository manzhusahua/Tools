import argparse
import os
from pathlib import Path

import add_path
add_path.add_path()

import helper.io_helper as io_helper


def is_punc(phone: str) -> bool:
    return phone.startswith('punc')


def get_punc(punc_phone: str) -> str:
    return punc_phone[len('punc'):]


def is_letter(phone: str, locale: str) -> bool:
    return phone.startswith(locale)


def convert_letter_phone(phone: str, locale: str) -> str:
    token = phone

    # remove locale prefix
    token = token[len(locale + '_'):]

    # upper the letter for runtime compatibility
    if token.startswith('letter_'):
        token = token[:-1] + token[-1].upper()

    return token


RESERVED_TOKENS = ['<pad>', '~']


def is_special_phone(phone: str) -> bool:
    return phone.lower() in ['/', '-', '&', '<bos>'] + RESERVED_TOKENS


def main(args):
    phone_list = io_helper.read_json(args.input_path)

    locale = args.locale.lower()
    with open(args.output_path, 'w', encoding='utf-8') as phone_f, \
         open(args.punc_output_path, 'w', encoding='utf-8') as punc_f:
        for i, phone in enumerate(RESERVED_TOKENS + phone_list):
            if is_punc(phone) or is_letter(phone, locale) or is_special_phone(phone):
                token = phone
                if is_letter(token, locale):
                    token = convert_letter_phone(token, locale)
                phone_f.write(f'"{token}": {i}\n')

                if is_punc(phone):
                    punc = get_punc(phone)
                    punc_f.write(f'{punc}\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='convert a phone set with locale prefix to phone.txt')
    parser.add_argument('input_path', type=Path)
    parser.add_argument('output_path', type=Path)
    parser.add_argument('--locale', required=True)
    parser.add_argument('--punc_output_path', type=Path, default=os.path.devnull,
                        help='if this argument is passed, punctuations will be written in ttsserver punc.txt format')

    args = parser.parse_args()

    main(args)

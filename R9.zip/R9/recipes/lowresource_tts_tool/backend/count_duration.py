import argparse
from collections import defaultdict
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('phone_path')
parser.add_argument('--duration_path')
parser.add_argument('--attn_npz_path')

args = parser.parse_args()

with open(args.phone_path, 'r', encoding='utf-8') as f:
    seqs = [line.strip().split() for line in f.readlines()]

duration_count = defaultdict(int)

if args.duration_path is not None:
    with open(args.duration_path, 'r') as f:
        for line, seq in zip(f, seqs):
            durations = line.strip().split()[:-1]
            assert len(durations) == len(seq)
            for duration, phone in zip(durations, seq):
                duration_count[phone] += int(duration)

elif args.attn_npz_path is not None:
    attn_npz = np.load(args.attn_npz_path)
    for i, seq in enumerate(seqs):
        attn = attn_npz[str(i)]
        assert attn.shape[1] == len(seq)
        focus_points = attn.argmax(axis=-1)
        for focus_point in focus_points:
            duration_count[seq[focus_point]] += 1
else:
    raise AssertionError('no duration information')

print(sorted(duration_count.items(), key=lambda x: x[1], reverse=True))

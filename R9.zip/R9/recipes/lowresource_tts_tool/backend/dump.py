import os
import shutil
import argparse
from pathlib import Path
import tempfile

import add_path
add_path.add_path()

from helper.path_helper import ensure_dir
from helper.func_helper import runtime_check, run_subprocess, get_first_not_none
from lib.model_file import MODEL_DIR_FACTORY_DICT, ModelDir

SETTING_PATH_DICT = {
    'jessa': Path.home() / 'Jessa/setting.linux-gpu-fs-mv24k-cuda.json',
    'mia': Path.home() / 'Mia/setting.linux-gpu-fs-mv24k-cuda.json',
    'grace': Path.home() / 'Grace/setting.linux-gpu-fs-mv24k-cuda.json',
    'uni_melgan': Path.home() / 'Grace/setting.linux-gpu-fs-umv24k-cuda.json',
    'ona': Path.home() / 'Ona/setting.linux-gpu-fs-mv24k-cuda.json',
    'ona_cpu': Path.home() / 'Ona/setting.linux-cpu-fs-mv24k.json',
}


def main(args):

    def to_container_path(path: Path) -> Path:
        return args.container_home_dir / path.relative_to(args.home_dir)

    setting_path = SETTING_PATH_DICT.get(args.setting, args.setting)
    setting_path = Path(setting_path)
    runtime_check(setting_path.exists(), f'setting file {setting_path} does not exist')
    runtime_check(setting_path.suffix == '.json', f'extension of setting file {setting_path.name} is not json')
    runtime_check(setting_path.name.startswith('setting'),
                  f'setting file {setting_path.name} does not start with "setting"', action='request')

    common_dump_args = ['docker', 'run', '-it', '--rm', '--gpus', args.gpus, '--env', 'LD_LIBRARY_PATH=.',
                        '-v', f'{args.home_dir}:{args.container_home_dir}',
                        '-w', to_container_path(args.dump_tool_dir), args.image_name]
    common_dump_args += ['./ttsdumptool', '-s', to_container_path(setting_path)]

    def run_dump(dump_args: list) -> int:
        dump_args = common_dump_args + dump_args
        if args.show_output:
            return_code = run_subprocess(dump_args)
        else:
            with open(os.devnull, 'w') as fnull:
                return_code = run_subprocess(dump_args, stdout=fnull)
        return return_code

    if args.mode in ['phone', 'duration']:
        mode = 'Dump' + args.mode.title()
        runtime_check(args.text_path is not None, f'text_path is required for {mode} mode')
        runtime_check(args.text_path.suffix == '.txt',
                      f'The extension of text file {args.text_path.name} is not txt', action='request')

        dump_path = get_first_not_none(args.dump_path, args.text_path.with_suffix(f'.{args.mode}.txt'))

        run_dump(['-m', mode, '-l', '-i', to_container_path(args.text_path), '-o', to_container_path(dump_path)])

    elif args.mode == 'wave':
        runtime_check(args.mel_source is not None, f'mel_source {args.mel_source} is required for DumpWave mode')
        assert args.mel_source in MODEL_DIR_FACTORY_DICT, f'Illegal mel source {args.mel_source}'
        model_dir_factory = MODEL_DIR_FACTORY_DICT[args.mel_source]

        if args.setting in SETTING_PATH_DICT:
            wave_dir_name = args.setting
        else:
            # get the infix of 'setting.wave_dir_name.json'
            wave_dir_name = ''.join(setting_path.suffixes[:-1]).lstrip('.')
            runtime_check(wave_dir_name != '', f'no infix in {setting_path.name}')

        tmp_dir = Path(tempfile.mkdtemp(dir=args.home_dir))
        tmp_mel_path = tmp_dir / 'tmp_mel.txt'

        def convert_mels(model_dir: ModelDir):
            mels = model_dir.load_mels()
            with open(tmp_mel_path, 'w', encoding='utf-8') as f:
                for mel_data in mels:
                    mel = mel_data.reshape(-1)
                    if args.scale_mel:
                        mel = (mel + 4) / 8
                    mel_str = ' '.join(map(str, mel))
                    f.write(mel_str)
                    f.write('\n')

        try:
            for model_name in args.model_name:
                model_dir = model_dir_factory.get_model_dir(model_name)
                wave_dir = model_dir.path / wave_dir_name

                container_wave_dir = to_container_path(wave_dir)
                run_subprocess(['docker', 'run', '-it', '--rm', '-v', f'{args.home_dir}:{args.container_home_dir}',
                                args.image_name, 'rm', '-rf', container_wave_dir])
                ensure_dir(args.home_dir / wave_dir)

                convert_mels(model_dir)
                run_dump(['-m', 'DumpWave', '-i', to_container_path(tmp_mel_path), '-f', container_wave_dir])
        finally:
            shutil.rmtree(tmp_dir)

    else:
        raise AssertionError('Illegal mode')


def get_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['phone', 'wave', 'duration'])
    parser.add_argument('setting', help='TTS voice directory (a short identifier can also be used)')
    parser.add_argument('--home_dir', type=Path, default=Path.home(),
                        help='working directory (all related files should be under it)')
    parser.add_argument('--container_home_dir', type=Path, default='/blob',
                        help='working directory mapped in the container')
    parser.add_argument('--image_name', default='nvidia/cuda:10.1-cudnn7-devel-ubuntu18.04')
    parser.add_argument('--dump_tool_dir', type=Path, default=Path.home() / 'drop/ttsdumptool',
                        help='path of ttsdumptool')
    parser.add_argument('--gpus', default='1', help='ID of GPU to use')
    parser.add_argument('--show_output', action='store_true', help='whether show output of Docker container')

    # for DumpPhone & DumpDuration mode
    parser.add_argument('--text_path', type=Path, help='input text path (only for phone and duration mode)')
    parser.add_argument('--dump_path', type=Path, help='dump output path (only for phone and duration mode)')

    # for DumpWave mode
    parser.add_argument('--mel_source', choices=MODEL_DIR_FACTORY_DICT.keys(), default='unitts', help='model type')
    parser.add_argument('--scale_mel', type=bool, default=True, help='whether scale mel features to [-1, 1]')
    parser.add_argument('--model_name', nargs='+')

    return parser


if __name__ == '__main__':
    parser = get_parser()
    args = parser.parse_args()
    main(args)

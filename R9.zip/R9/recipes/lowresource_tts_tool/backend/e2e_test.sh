docker_home='/blob'
image='nvidia/cuda:10.1-cudnn7-devel-ubuntu18.04'
voice=$1
device=${2:-gpu}
lines=${3:-3}

if [ "$voice" = "Grace" ]; then
    rel_path='LowResourceProd/data/mtmt_old_mos/news_sample300.not_leaked.sample50.txt'
elif [ "$voice" = "Ona" ]; then
    #rel_path='LowResourceProd/data/ltlt_test/scripts.txt'
    rel_path='LowResourceProd/data/ltlt_dsat/scripts.txt'
else
    echo Unknown voice $voice
    exit 1
fi

if [ "$device" == "gpu" ]; then
    setting='setting.linux-gpu-fs-mv24k-cuda.json'
elif [ "$device" == "cpu" ]; then
    setting='setting.linux-cpu-fs-mv24k.json'
else
    echo Unknown device $device
    exit 1
fi

docker run -it --rm -v $HOME:$docker_home $image rm -rf "$docker_home/tmp/waves"

docker run -it --rm -v $HOME:$docker_home --env LD_LIBRARY_PATH=. -w $docker_home/drop/ttsserver --gpus 1 $image ./ttsserver Lines=$lines Voice=$docker_home/$voice:$setting OutputFormat='riff-24khz-16bit-mono-pcm' TestFile=$docker_home/$rel_path OutputDir=$docker_home/tmp/waves

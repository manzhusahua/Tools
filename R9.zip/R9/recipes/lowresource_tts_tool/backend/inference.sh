gpus='1'

model=$1
mel_source=${2:-'unitts'}
step=$3
spk_id=$4
vocoder_steps=${5:-50k}

case $model in
    "antonella")
        inference_script='Antonella/antonella_inference.sh'
        if [ "$mel_source" == "unitts" ]; then
            model_name='unitts_v2_mtmt_antonella_vol_normed'
            #model_name='unitts_v2_mtmt_antonella_denoised'
            #model_name='unitts_v2_mtmt_antonella_1m_steps'
            #step=1000000
        elif [ "$mel_source" == "fs" ]; then
            model_name='unitts_v2_mtmt_antonella_v2'
        fi
        setting='grace'
        ;;
    "grace")
        inference_script='Grace/grace_inference.sh'
        model_name='unitts_v2_mtmt_grace_v1.2'
        setting='grace'
        ;;
    "speaker")
        if [ "$spk_id" == "" ]; then
            echo please enter speaker id
            exit 1
        fi
        inference_script='Antonella/speaker_inference.sh'
        model_name="unitts_v2_mtmt_group_316D319D389D320D253D289D226D318D317D221D358D308D347D212D371D278D370D374D215D338"
        #model_name="unitts_v2_mtmt_speaker$spk_id"
        #model_name="unitts_v2_mtmt_no_upsample_speaker$spk_id"
        setting=~/Grace/setting.linux-gpu-fs-speaker${spk_id}-${vocoder_steps}_steps-mv24k-cuda.json
        ;;
    "ona")
        inference_script='Ona/ona_inference.sh'
        model_name='unitts_v2_ltlt_ona_v1'
        setting='ona'
        ;;
    "ona_phone")
        inference_script='Ona/ona_phone_inference.sh'
        model_name='unitts_v2_ltlt_ona_phone_v1'
        setting='ona'
        ;;
    *)
        echo error: unknown model
        exit 1
        ;;
esac

if [ "$model" == "speaker" ]; then
    extra_inference_env="env LOCAL_DEBUG=on"
fi

docker run -it --rm --gpus $gpus -v /home:/blob -e PHILLY_USER=$USER xianta/environments:fastspeech \
    $extra_inference_env bash /blob/$USER/NeuralVoiceModelling/FastSpeech/runs/low_resource/private/$inference_script $mel_source $step $spk_id \
|| exit 1

if [ "$model" == "speaker" ]; then
    extra_dump_args="--mel_dir_pattern=LowResourceProd/checkpoints/mtmt_speaker_refine/{}"
fi

python dump.py wave $setting --gpus $gpus --mel_source=$mel_source --model_name=$model_name $extra_dump_args

import argparse
import glob
import pdb
import os
import tensorflow as tf
import numpy as np
from tqdm import tqdm

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['get_fields', 'get_avg_mel', 'filter_avg_mel', 'get_mel_range',
                    'filter_max_mel', 'dump_attn', 'filter_spk_id'])
parser.add_argument('path_pattern')
parser.add_argument('--take', type=int, default=1000, help='how many examples to take in statistic mode (-1 means all)')

# for filter_avg_mel mode
parser.add_argument('--avg_mel_threshold', type=float, default=-0.6)

# for dump_attn mode
parser.add_argument('--dump_dir')

# for filter_spk_id mode
parser.add_argument('--spk_id', type=int)
parser.add_argument('--output_path')

args = parser.parse_args()


def iload(path_pattern, take=-1, mode='feature'):
    count = 0
    for path in glob.iglob(path_pattern):
        for raw_record in tf.python_io.tf_record_iterator(path):
            example = tf.train.Example.FromString(raw_record)
            if mode == 'feature':
                yield example.features.feature
            elif mode == 'example':
                yield example
            else:
                raise AssertionError('Illegal action')
            count += 1
            if count == take:
                return


def save(path, examples):
    with tf.python_io.TFRecordWriter(path) as f:
        for example in examples:
            f.write(example.SerializeToString())


def inspect_mel(path, func):
    mels = []
    for example in tqdm(iload(path, take=args.take)):
        mel_data = np.array(example['mel_data'].float_list.value)
        mels.append(mel_data)
    print(path)
    print(func(mels))


if args.mode == 'get_fields':
    for example in iload(args.path_pattern, take=1):
        pdb.set_trace()
        print(list(example.keys()))

elif args.mode == 'get_avg_mel':
    inspect_mel(args.path_pattern, lambda l: np.mean(map(np.mean, l)))

elif args.mode == 'filter_avg_mel':
    inspect_mel(args.path_pattern, lambda l: len([1 for ele in l if ele.mean() < args.avg_mel_threshold]))

elif args.mode == 'get_mel_range':
    def get_range(mels):
        ranges = [(mel.max(), mel.min()) for mel in mels]
        return np.max(ranges), np.min(ranges)
    inspect_mel(args.path_pattern, get_range)

elif args.mode == 'filter_max_mel':
    inspect_mel(args.path_pattern, lambda l: len([1 for ele in l if ele.max() < 3.99]))

elif args.mode == 'dump_attn':
    dump_dir = os.path.dirname(args.path_pattern)
    if args.dump_dir is not None:
        dump_dir = args.dump_dir
    dump_path = os.path.join(dump_dir, 'encdec_attn_weights.npz')

    data_dict = {}
    for example in tqdm(iload(args.path_pattern, take=args.take)):
        utt_id = list(example['utt_id'].int64_list.value)[0]
        phones = list(example['phones'].int64_list.value)
        encdec_attn = np.array(example['encdec_attn'].float_list.value).reshape((-1, len(phones)))
        data_dict[str(utt_id)] = encdec_attn
    np.savez(dump_path, **data_dict)

elif args.mode == 'filter_spk_id':
    assert args.spk_id is not None
    assert args.output_path is not None

    examples = iload(args.path_pattern, take=args.take, mode='example')
    examples = filter(lambda x: list(x.features.feature['spk_id'].int64_list.value)[0] == args.spk_id, examples)
    save(args.output_path, examples)

else:
    raise AssertionError('Illegal mode')

spk_id=$1
model_type=$2
vocoder_steps=${3:-50k}

if [ "$spk_id" == "" ]; then
    echo please enter speaker id
    exit 1
fi

model='speaker'
mel_source='unitts'

if [ "$model_type" == "no_upsample" ]; then
    model_name="unitts_v2_mtmt_no_upsample_speaker$spk_id"
elif [ "$model_type" == "group" ]; then
    model_name="unitts_v2_mtmt_group_316D319D389D320D253D289D226D318D317D221D358D308D347D212D371D278D370D374D215D338"
else
    model_name="unitts_v2_mtmt_speaker$spk_id"
fi

#setting='grace'
#wav_dir=$setting
#wav_prefix=$setting

wav_description="speaker${spk_id}-${vocoder_steps}_steps"
wav_dir="linux-gpu-fs-${wav_description}-mv24k-cuda"
setting=~/Grace/setting.${wav_dir}.json

model_dir=~/LowResourceProd/checkpoints/mtmt_speaker_refine/$model_name
mkdir -p $model_dir/waves

for step in $(seq 315001 5000 340001)
do
    bash inference.sh $model $mel_source $step $spk_id $vocoder_steps || exit 1
    mv $model_dir/$wav_dir $model_dir/waves/${step}_steps-${wav_description} || exit 1
done

import argparse
from pathlib import Path
from tqdm import tqdm

import add_path
add_path.add_path()

from helper.func_helper import run_subprocess
from helper.path_helper import ensure_dir


def main(args):
    ensure_dir(args.output_dir)
    for input_path in tqdm(args.input_dir.glob('*.wav')):
        output_path = args.output_dir / input_path.name
        run_subprocess([args.sox_command, input_path, output_path, 'norm', args.vol])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('input_dir', type=Path)
    parser.add_argument('output_dir', type=Path)
    parser.add_argument('--vol', type=float, default=-3)
    parser.add_argument('--sox_command', default='sox')

    args = parser.parse_args()
    main(args)

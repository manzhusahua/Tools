import re
import os
import shutil
from pathlib import Path
import librosa
import soundfile
from tqdm import tqdm

import add_path
add_path.add_path()

import helper.io_helper as io_utils


def get_language_list(languages_noformat):
    if isinstance(languages_noformat, str):
        return [languages_noformat]
    else:
        return languages_noformat


def normalize_wavename(no_ext_filename, speaker_id, segment_id):
    return (no_ext_filename + '=' + speaker_id).replace('_', '~') + '_' + segment_id


def denormalize_wavename(wavename):
    parts = wavename.split('_')
    assert len(parts) == 2
    speaker_name, segment_id = parts
    speaker_name = speaker_name.replace('~', '_')
    parts = speaker_name.split('=')
    filename_prefix, speaker_id = parts
    return filename_prefix, speaker_id, segment_id


def read_segments(annotation_path, return_annotation=False):
    annotation = io_utils.read_json(annotation_path)
    segments = annotation['value']['segments']

    wav_dir = annotation_path.parents[1] / 'waves'
    wav_name = annotation_path.name
    wav_path = (wav_dir / wav_name).with_suffix('.wav')
    if not os.path.exists(wav_path):
        print(f'ERROR: {wav_path} does not exist')
        return None, annotation
    wav_duration = librosa.get_duration(filename=wav_path)

    # Ensure no time-overflow speech
    final_start_time = None
    for i in range(len(segments)):
        if segments[- i - 1]['primaryType'] == 'Speech':
            final_start_time = segments[- i - 1]['start']
            break

    toleration = 1.0
    if final_start_time - wav_duration > toleration:
        print(f'ERROR: final segment time in {annotation_path} exceeds the duration of {wav_path}')
        print(f'    start time of final segment: {final_start_time}')
        print(f'    WAV duration: {wav_duration}')
        segments = None

    if return_annotation:
        return segments, annotation
    else:
        return segments


def read_cases(data_dir, illegal_pattern=r'\(\([^\)]*\)\)|\[[^\]]*\]', ignore_pattern=r'#|~|<[^>]+>'):
    def re_compile(pattern):
        return None if pattern is None or pattern == '' else re.compile(pattern)
    re_illegal_pattern = re_compile(illegal_pattern)
    re_ignore_pattern = re_compile(ignore_pattern)

    data_dir = Path(data_dir)
    annotation_paths = sorted(data_dir.glob('*.json'))
    cases = []
    for annotation_path in annotation_paths:
        annotation_filename = os.path.basename(annotation_path)
        no_ext_filename = os.path.splitext(annotation_filename)[0]
        segments, annotation = read_segments(annotation_path, return_annotation=True)
        if segments is None:
            continue
        primary_language_noformat = annotation['value'].get('languages')
        primary_language = get_language_list(primary_language_noformat)
        if len(primary_language) != 1:
            print('There are more than one languages in the file ' + annotation_filename)
            continue
        for segment in segments:
            segment_id = segment['segmentId']
            if segment['primaryType'] == 'Speech':
                languages_noformat = segment['language']
                languages = get_language_list(languages_noformat)
                if len(languages) != 1 or languages[0] != primary_language[0]:
                    continue
                transcription = segment['transcriptionData']['content']
                if re_illegal_pattern is None or re_illegal_pattern.search(transcription) is None:
                    if re_ignore_pattern is not None:
                        transcription = re_ignore_pattern.sub(' ', transcription)
                    transcription = re.sub(r'\s+', ' ', transcription.strip())
                    speaker_id = segment['speakerId']
                    if speaker_id.isspace():
                        speaker_id = 'tempSpeaker_001'
                    else:
                        print('There is the speaker_id.  ' + str(annotation_path))
                    duration = segment['end'] - segment['start']
                    cases.append({
                        'filename': no_ext_filename,
                        'segment_id': segment_id,
                        'speaker_id': speaker_id,
                        'transcription': transcription,
                        'duration': duration,
                        'wav': normalize_wavename(no_ext_filename, speaker_id, segment_id)
                    })
    return cases


def extract_segments(input_dir, output_dir, wavs):
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    last_filename = None
    segments = None
    last_segment_index = 0
    audio = None
    sample_rate = None
    for wav in tqdm(wavs):
        no_ext_filename, _, segment_id = denormalize_wavename(wav)
        if no_ext_filename != last_filename:
            last_filename = no_ext_filename
            no_ext_path = os.path.join(input_dir, no_ext_filename)
            json_path = (Path(input_dir).parent / 'scripts' / no_ext_filename).with_suffix('.json')
            segments = read_segments(json_path)
            last_segment_index = 0
            audio, sample_rate = soundfile.read(no_ext_path + '.wav')

        # border is not checked because segment ID can always be found
        while segments[last_segment_index]['segmentId'] != segment_id:
            last_segment_index += 1

        segment = segments[last_segment_index]
        start = int(segment['start'] * sample_rate)
        end = int(segment['end'] * sample_rate)

        output_path = os.path.join(output_dir, wav + '.wav')
        soundfile.write(output_path, audio[start:end], sample_rate)

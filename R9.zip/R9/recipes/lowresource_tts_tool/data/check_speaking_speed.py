import argparse
import os
import zipfile
import librosa
from tqdm import tqdm

import add_path
add_path.add_path()

import helper.io_helper as io_utils

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['describe', 'sample', 'split'])
parser.add_argument('data_dir')

# sample mode
parser.add_argument('--sample_count', type=int, default=20)

# split mode
parser.add_argument('--speed_lower_bound', type=float, default='0.02')
parser.add_argument('--speed_upper_bound', type=float, default='0.96')
parser.add_argument('--duration_lower_bound', type=float, default=1.0)

args = parser.parse_args()

metadata_path = os.path.join(args.data_dir, 'metadata.csv')
speed_metadata_path = os.path.join(args.data_dir, 'metadata_speed.csv')

if os.path.exists(speed_metadata_path):
    metadata = io_utils.read_metadata(speed_metadata_path)
    metadata['speed'] = metadata['speed'].astype('float')
    metadata['duration'] = metadata['duration'].astype('float')
else:
    metadata = io_utils.read_metadata(metadata_path)
    wave_path = os.path.join(args.data_dir, 'waves_16k.zip')
    speeds = []
    with zipfile.ZipFile(wave_path, 'r') as fzip:
        def get_duration(row):
            with fzip.open(row['wav'] + '.wav', 'r') as f:
                duration = librosa.get_duration(filename=f)
            return duration
        tqdm.pandas()
        metadata['length'] = metadata['text'].map(len)
        metadata['duration'] = metadata.progress_apply(get_duration, axis=1)
        metadata['speed'] = metadata['length'] / metadata['duration']

    io_utils.write_metadata(speed_metadata_path, metadata)

speeds = metadata['speed']


def get_in_bound_cases(speed_lower_bound, speed_upper_bound, duration_lower_bound=None):
    speed_lower_bound = speeds.quantile(speed_lower_bound)
    speed_upper_bound = speeds.quantile(speed_upper_bound)
    print(f'Filter metadata with speed bound [{speed_lower_bound}, {speed_upper_bound}]')
    cond = speeds.between(speed_lower_bound, speed_upper_bound)
    if duration_lower_bound is not None:
        print(f'And duration lower bound {duration_lower_bound} second')
        cond = cond | (metadata['duration'] > duration_lower_bound)
    filtered_metadata = metadata[cond]
    print(len(filtered_metadata), 'cases remain')
    return filtered_metadata, cond


def sample_cases(lower_bound, upper_bound):
    output_dir = os.path.join(args.data_dir, 'speed_check_samples', f'{lower_bound}-{upper_bound}')
    sampled_metadata_path = os.path.join(output_dir, 'metadata.csv')
    if os.path.exists(sampled_metadata_path):
        return

    os.makedirs(output_dir, exist_ok=True)

    filtered_metadata, _ = get_in_bound_cases(lower_bound, upper_bound)
    sampled_metadata = filtered_metadata.sample(min(args.sample_count, len(filtered_metadata)))
    sampled_metadata.sort_values(by=['wav'], inplace=True)
    io_utils.write_metadata(sampled_metadata_path, sampled_metadata)

    waves_path = os.path.join(args.data_dir, 'waves_16k.zip')
    with zipfile.ZipFile(waves_path, 'r') as fzip:
        for _, wav in sampled_metadata['wav'].iteritems():
            fzip.extract(wav + '.wav', path=output_dir)


if args.mode == 'describe':
    percentiles = [0.01, 0.02, 0.03, 0.05, 0.95, 0.97, 0.98, 0.99]
    description = speeds.describe(percentiles=percentiles)
    print(description)

elif args.mode == 'sample':
    for lower_bound in [0.0, 0.01, 0.02, 0.03, 0.04, 0.95, 0.96, 0.97, 0.98, 0.99]:
        sample_cases(lower_bound, lower_bound + 0.01)

elif args.mode == 'split':
    filtered_metadata, cond = get_in_bound_cases(args.speed_lower_bound, args.speed_upper_bound,
                                                 args.duration_lower_bound)

    backup_path = os.path.join(args.data_dir, 'metadata.before_speed_check.csv')
    filtered_metadata = filtered_metadata[['wav', 'text']]
    if not os.path.exists(backup_path):
        assert os.path.exists(metadata_path)
        os.rename(metadata_path, backup_path)
    io_utils.write_metadata(metadata_path, filtered_metadata)

    bad_metadata = metadata[~cond]
    bad_metadata_path = os.path.join(args.data_dir, 'metadata.bad_speed.csv')
    io_utils.write_metadata(bad_metadata_path, bad_metadata)

    for column in filtered_metadata.columns:
        output_path = os.path.join(args.data_dir, f'{column}.txt')
        io_utils.write_metadata(output_path, filtered_metadata[column], header=False)

    for suffix in ['phone', 'unitts']:
        update_path = os.path.join(args.data_dir, f'metadata_{suffix}.csv')
        backup_path = os.path.join(args.data_dir, f'metadata_{suffix}.before_speed_check.csv')

        if os.path.exists(backup_path):
            ext_metadata = io_utils.read_metadata(backup_path)
        elif os.path.exists(update_path):
            ext_metadata = io_utils.read_metadata(update_path)
            if len(ext_metadata) == len(filtered_metadata):
                continue
            os.rename(update_path, backup_path)
        else:
            continue

        assert len(ext_metadata) == len(cond)
        ext_metadata = ext_metadata[cond]
        io_utils.write_metadata(update_path, ext_metadata)

else:
    raise AssertionError('Illegal mode')

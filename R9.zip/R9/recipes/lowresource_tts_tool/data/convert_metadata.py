import argparse
from pathlib import Path
import json

import add_path
add_path.add_path()

from helper.io_helper import read_json, write_json, read_metadata, write_metadata
import data.data_helper as data_helper
from helper.func_helper import request_for_yes, runtime_check
from helper.path_helper import ensure_dir


def get_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description='convert metadata to the format expected by Uni-TTS code')
    parser.add_argument('work_dir', type=Path,
                        help='the directory to read and write metadata')
    parser.add_argument('--locale_id', type=int, default=99,
                        help='the locale ID of new locale to be used in AM training')
    parser.add_argument('--locale_prefix',
                        help='the locale prefix prepended to local phones')
    parser.add_argument('--speaker_set_path',
                        help='path of speaker set file')
    parser.add_argument('--speaker_id', type=int,
                        help='the speaker ID to add')
    parser.add_argument('--filename_prefix', nargs='+', default=[''],
                        help='prefix of input and output metadata file names')
    parser.add_argument('--no_bos', action='store_true')

    # phone set dumping options
    parser.add_argument('--phone_set_output_dir', type=Path,
                        help='if set, a phone set file will be saved in this directory')
    parser.add_argument('--unitts_phone_set_path', type=Path, help='phone set of the unitts base model. \
                        if set, a unitts phone set file will be saved in phone_set_output_dir')
    parser.add_argument('--phone_set_type', choices=['TFTTS', 'TorchTTS'], default='TFTTS',
                        help='format of phone set, with or without ID')

    return parser


def main(args: argparse.Namespace):
    if args.locale_prefix is None:
        request_for_yes('locale_prefix is not specified')
    else:
        print('convert phones with locale prefix', args.locale_prefix)

    runtime_check(args.speaker_id is not None or args.speaker_set_path is not None,
                  'One of --speaker_id or --speaker_set_path must be provided')
    runtime_check(args.speaker_id is None or args.speaker_set_path is None,
                  'Only one of --speaker_id or --speaker_set_path can be provided')

    speaker_dict = None
    if args.speaker_set_path is not None:
        speaker_dict = read_json(args.speaker_set_path)

    for filename_prefix in args.filename_prefix:
        input_metadata_path = args.work_dir / (filename_prefix + 'metadata_phone.csv')
        output_metadata_path = args.work_dir / (filename_prefix + 'metadata_unitts.csv')

        metadata = read_metadata(input_metadata_path)
        metadata.dropna(inplace=True)
        metadata['phone'] = metadata['phone'].map(
            lambda x: data_helper.to_training_pron(x, args.locale_prefix, not args.no_bos))
        metadata.dropna(inplace=True)
        metadata.insert(1, 'style_id', 0)
        metadata.insert(1, 'locale_id', args.locale_id)

        if args.speaker_id is not None:
            metadata.insert(1, 'speaker_id', args.speaker_id)
        elif args.speaker_set_path is not None:
            metadata.insert(1, 'speaker_id', metadata['wav'].map(lambda x: speaker_dict[data_helper.get_speaker(x)]))
        else:
            raise AssertionError('No speaker ID source')

        metadata = metadata.rename(columns={'text': 'txt2', 'phone': 'phone2'})

        write_metadata(output_metadata_path, metadata)

        if args.phone_set_output_dir is not None:
            prons = list(metadata['phone2'])
            phone_count = data_helper.count_token(prons)
            phone_set = list(phone_count.keys())
            print('phone count:')
            print(json.dumps(phone_count))

            ensure_dir(args.phone_set_output_dir)

            phone_set_output_path = args.phone_set_output_dir / 'phone_set.json'
            if args.phone_set_type == 'TorchTTS':
                phone_id = list(range(len(phone_set)))
                phoneid_set = dict(zip(phone_set, phone_id))
                write_json(phone_set_output_path, phoneid_set)
            else:
                write_json(phone_set_output_path, phone_set)

            if args.unitts_phone_set_path is not None:
                unitts_phone_set_output_path = args.phone_set_output_dir / 'phone_set.unitts.json'
                data_helper.append_phones_to_phone_set(args.unitts_phone_set_path,
                                                       unitts_phone_set_output_path, phone_set, args.phone_set_type)


if __name__ == '__main__':
    parser = get_parser()
    args = parser.parse_args()
    main(args)

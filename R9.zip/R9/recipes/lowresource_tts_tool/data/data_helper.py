from os import PathLike
from typing import Callable, Iterable, Optional
from collections import defaultdict

import add_path
add_path.add_path()

import helper.io_helper as io_utils


def get_speaker(wav: str) -> str:
    return wav.split('_')[0]


def count(items: Iterable):
    count = defaultdict(int)
    for item in items:
        count[item] += 1
    return count


def count_token(seqs: list, pred: Callable[[str], bool] = lambda x: True, split: bool = True):
    count = defaultdict(int)
    if len(seqs) > 0 and isinstance(seqs[0], str) and split:
        seqs = [seq.split() for seq in seqs]
    for seq in seqs:
        for token in seq:
            if pred(token):
                count[token] += 1
    return count


def append_phones_to_phone_set(input_path: PathLike, output_path: PathLike, phones: Iterable[str],
                               phone_set_type: str = 'TFTTS') -> None:
    unitts_phones = io_utils.read_json(input_path)
    if phone_set_type == 'TFTTS':
        for phone in phones:
            if phone not in unitts_phones:
                unitts_phones.append(phone)
    elif phone_set_type == 'TorchTTS':
        new_phone_id = 4701
        if max(map(int, unitts_phones.values())) >= new_phone_id:
            new_phone_id = max(map(int, unitts_phones.values())) + 1
        for phone in phones:
            if phone not in unitts_phones.keys():
                unitts_phones[phone] = new_phone_id
                new_phone_id += 1
    else:
        raise AssertionError('Illegal phone set type.')
    io_utils.write_json(output_path, unitts_phones)


def add_customized_letters(input_path: PathLike, letters: Iterable[str]):
    locale_phones = io_utils.read_json(input_path)
    for phone in locale_phones:
        if phone not in letters:
            letters.append(phone)
    return letters


def prepend_locale(pron: str, locale: str) -> str:
    locale = locale.lower()
    phones = pron.strip().split()
    for i in range(len(phones)):
        lower_phone = phones[i].lower()
        if (
            lower_phone not in ['symbol', '-', '&', '/', '<bos>'] and not
            lower_phone.startswith('punc') and not lower_phone.startswith(locale + '_')
        ):
            phones[i] = locale + '_' + phones[i]
    return ' '.join(phones)


def ensure_bos(phones_str: str) -> str:
    if phones_str.lower().startswith('<bos> / '):
        return phones_str
    return '<bos> / ' + phones_str


def to_training_pron(raw_pron: str, locale: Optional[str], add_bos: bool) -> str:
    pron = raw_pron
    # remove '~' because '<EOS>' is used in model training
    pron = pron.replace(' ~', '')
    # fastspeech training code will append a word boundary and a <EOS> at the end
    pron = pron.rstrip(' /')
    # add locale prefix
    if locale is not None:
        pron = prepend_locale(pron, locale)
    if add_bos:
        # add <bos> to handle various leading silence in low quality
        pron = ensure_bos(pron)
    return pron

import os
import argparse

import add_path
add_path.add_path()

import helper.io_helper as io_utils

parser = argparse.ArgumentParser('process dumped phones for low resource training')
parser.add_argument('work_dir', help='the directory to read and write metadata')
parser.add_argument('--filename_prefix', default='', help='prefix of input and output file names')

args = parser.parse_args()


def get_work_path(base_filename):
    return os.path.join(args.work_dir, args.filename_prefix + base_filename)


phone_path = get_work_path('text.phone.txt')
input_metadata_path = get_work_path('metadata.csv')
output_metadata_path = get_work_path('metadata_phone.csv')

prons = io_utils.readlines(phone_path, encoding='utf-8')
metadata = io_utils.read_metadata(input_metadata_path)
assert 'wav' in metadata.columns and 'text' in metadata.columns
assert len(prons) == metadata.shape[0]

metadata['phone'] = prons
io_utils.write_metadata(output_metadata_path, metadata)

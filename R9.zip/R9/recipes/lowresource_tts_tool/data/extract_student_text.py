import os
import argparse
import re
import subprocess

import add_path
add_path.add_path()

import helper.io_helper as io_utils
import data.data_helper as data_helper

parser = argparse.ArgumentParser(description='Process student model training scripts')
parser.add_argument('input_path')
parser.add_argument('output_path')
parser.add_argument('--mode', default='Metadata', choices=['PlainText', 'Metadata'], help='specify data source format')
parser.add_argument('--dump_tool_dir', help='the directory of dump phone tool')
parser.add_argument('--voice_setting', help='the path of voice setting')
parser.add_argument('--illegal_pattern_str', default='[0-9]', help='illegal pattern string')
parser.add_argument('--locale', help='locale name (like et-ee)')
parser.add_argument('--min_phone_count', type=int, default=0, help='min number of phone count')
parser.add_argument('--max_phone_count', type=int, default=1000, help='max number of phone count')

args = parser.parse_args()


def filter_text_with_char_num(texts, output_path):
    filtered_count = 0
    with open(output_path, 'w', encoding='utf-8') as f_out:
        for line in texts:
            length = len(line.strip().split())
            if length < args.min_phone_count or length > args.max_phone_count:
                filtered_count = filtered_count + 1
                continue
            f_out.write(line.strip() + '\n')

    print(str(filtered_count) + ' sentences are filtered.')
    print(str(len(texts) - filtered_count) + ' sentences are extracted.')


def filter_text_with_illegal_char(input_path, output_path):
    with open(input_path, 'r', encoding='utf-8') as f_in:
        lines = f_in.readlines()

    remaining_count = 0
    illegal_pattern = re.compile(args.illegal_pattern_str)
    with open(output_path, 'w', encoding='utf-8') as f_out:
        for line in lines:
            line = line.strip()
            if len(line) == 0:
                continue
            if re.findall(illegal_pattern, line):
                continue
            line = ' '.join(line.split()).strip()
            f_out.write(line + '\n')
            remaining_count = remaining_count + 1
    print('There are ' + str(len(lines)) + ' sentences in original file.')
    print(str(remaining_count) + ' sentences are remained in processed file.')


if args.mode == 'PlainText':
    # filter texts contains illegal charcter
    filter_illegal_text_file = args.input_path.split('.')[0] + '_filter.txt'
    filter_text_with_illegal_char(args.input_path, filter_illegal_text_file)

    # dump char sequence
    currect_work_dir = os.getcwd()
    os.chdir(args.dump_tool_dir)
    filter_illegal_char_file = args.input_path.split('.')[0] + '_phone.txt'
    common_dump = ['./ttsdumptool', '-m', 'DumpPhone', '-s', args.voice_setting,
                   '-l', '-i', filter_illegal_text_file, '-o', filter_illegal_char_file]
    result = subprocess.run(common_dump)
    if result.returncode != 0:
        print('ERROR: dump failed with args {common_dump}')
        exit(result.returncode)
    os.chdir(currect_work_dir)

    # filter texts with char number
    with open(filter_illegal_char_file, 'r', encoding='utf-8') as f_in:
        lines = f_in.readlines()
    texts = []
    for line in lines:
        text = data_helper.to_training_pron(line.strip(), args.locale, False)
        texts.append(text)
    filter_text_with_char_num(texts, args.output_path)

elif args.mode == 'Metadata':
    data_df = io_utils.read_metadata(args.input_path)
    texts = data_df['phone2']
    filter_text_with_char_num(texts, args.output_path)
else:
    raise AssertionError('Unknown mode')

import os
import html
import itertools
import xml.etree.ElementTree as ElementTree

import add_path
add_path.add_path()

from helper.func_helper import runtime_check

VOWELS = {
    'a', 'e', 'i', 'o', 'u', 'y',
    'aa', 'ee', 'ii', 'ii_bs', 'mm', 'oo', 'qq', 'uu', 'uu_bs', 'vv', 'yy',
    'schwa', 'schwa_bs', '_ae_', '_oee_',
    'one', 'two', 'three', 'three_bs', 'six', 'seven', 'eight', 'nine',
}
VOWELS.update(map(lambda x: x[0] + x[1], itertools.product(VOWELS, VOWELS.union(['j', 'w']))))


def xml_escape(s):
    return html.escape(s, quote=True)


def write_phone_set_xml(output_dir, actual_phones, locale):
    reserverd_phones = ['&', '-', '-sil-']
    reserverd_phones_feature = ['syllable', 'syllable', 'silence']
    assert len(reserverd_phones) == len(reserverd_phones_feature)
    phones = reserverd_phones + actual_phones

    def get_phone_feature(phone):
        if phone == '1':
            return 'mainstress'
        if phone in VOWELS:
            return 'vowel'
        return ''
    features = reserverd_phones_feature + [get_phone_feature(phone) for phone in actual_phones]

    frontend_phone_set_path = os.path.join(output_dir, 'phoneset.xml')
    with open(frontend_phone_set_path, 'w', encoding='utf-16') as f:
        f.write('<?xml version="1.0" encoding="utf-16"?>\n')
        f.write('\n')
        f.write(f'<phoneSet version="1.0" xmlns="http://schemas.microsoft.com/tts" lang="{locale}">\n')
        f.write('\n')
        for i, (phone, feature) in enumerate(zip(phones, features)):
            f.write(f'  <phone name="{html.escape(phone, quote=True)}" id="{i + 1}">\n')
            f.write(f'    <feature>{feature}</feature>\n')
            f.write('  </phone>\n')
            f.write('\n')
        f.write('</phoneSet>\n')

    phone_id_dict = {phone: i + 1 for i, phone in enumerate(phones)}
    return phone_id_dict


def write_lexicon_xml(output_dir, words, prons, locale):
    lexicon_path = os.path.join(output_dir, 'lexicon.xml')
    with open(lexicon_path, 'w', encoding='utf-16') as f:
        f.write('<?xml version="1.0" encoding="utf-16"?>\n')
        f.write(f'<lexiconWords xmlns="http://schemas.microsoft.com/tts" lang="{locale}">\n')
        handled_words = set()
        for word, phones in zip(words, prons):
            if word.lower() in handled_words:
                continue
            handled_words.add(word.lower())
            f.write(f'  <w v="{xml_escape(word)}">\n')
            pron = ' '.join(phones)
            pron = xml_escape(pron)
            f.write(f'    <p v="{pron}">\n')
            f.write('      <pr>\n')
            f.write('        <pos v="unknown"/>\n')
            f.write('      </pr>\n')
            f.write('    </p>\n')
            f.write('  </w>\n')
        f.write('</lexiconWords>\n')


def write_char_table_xml(output_dir, chars, prons, features, locale):
    char_table_path = os.path.join(output_dir, 'chartable.xml')
    with open(char_table_path, 'w', encoding='utf-16') as f:
        f.write('<?xml version="1.0" encoding="utf-16"?>\n')
        f.write(f'<chartable xmlns="http://schemas.microsoft.com/tts" lang="{locale}">\n')
        handled_chars = set()
        for ch, phones, feature in zip(chars, prons, features):
            if ch.lower() in handled_chars:
                continue
            handled_chars.add(ch.lower())
            pron = ' '.join(phones)
            pron = xml_escape(pron)
            f.write(f'  <char symbol="{ch.upper()}" pron="{pron}" feature="{feature}" type="UpperCase" />\n')
            f.write(f'  <char symbol="{ch.lower()}" pron="{pron}" feature="{feature}" type="LowerCase" />\n')
            f.write('\n')
        f.write('</chartable>\n')


def read_script_xml(path):
    def runtime_format_check(assertion):
        runtime_check(assertion, "Bad script XML format")

    with open(path, 'r', encoding='utf-16') as f:
        xml_string = f.read().replace(u" xmlns=\"http://schemas.microsoft.com/tts\"", "")

    root = ElementTree.fromstring(xml_string)
    cases = []
    for node_si in root:
        runtime_format_check(node_si.tag == "si")
        sid = node_si.attrib["id"]

        node_text = node_si[0]
        runtime_format_check(node_text.tag == "text")
        text = node_text.text

        word_prons = []
        for node_w in node_si.findall(u"./sent/words/w"):
            word = node_w.attrib["v"]
            pron = node_w.get("p", "punc" + word)
            word_prons.append(pron)
        pron = ' / '.join(word_prons)

        cases.append({
            'wav': sid,
            'text': text,
            'phone': pron,
        })
    return cases

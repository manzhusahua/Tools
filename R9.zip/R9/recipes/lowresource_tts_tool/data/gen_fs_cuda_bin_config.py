import os
import argparse
from pathlib import Path
import numpy as np

import add_path
add_path.add_path()

import helper.io_helper as io_utils

parser = argparse.ArgumentParser()
parser.add_argument('bin_dir')

args = parser.parse_args()

config = {
    'use_linguistic': 0
}


def add_shape_config(key, rel_path, mapping):
    data_path = os.path.join(Path(args.bin_dir), Path(rel_path))
    data = np.loadtxt(data_path)
    config[key] = mapping(data.shape)


add_shape_config('phoneme_list_size', 'na_speech_model/txt_modality/shared/weights', lambda x: x[0])
add_shape_config('decoder_embedding_size', 'na_speech_model/dec_txt_modality/shared/weights', lambda x: x[0])

config_path = os.path.join(args.bin_dir, 'config.json')
io_utils.write_json(config_path, config)

import os
import json
from pathlib import Path
import argparse
import subprocess


def read_json(path, allow_none=False):
    if allow_none and path is None:
        return None
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def write_json(path, obj):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=4)


def call_and_check(args, no_output=True):
    args = [str(arg) for arg in args]
    print(args)
    if no_output:
        with open(os.devnull, 'w') as fnull:
            retcode = subprocess.call(args, stdout=fnull)
    else:
        retcode = subprocess.call(args)
    if retcode != 0:
        raise RuntimeError(f'call failed: {args}')


BIN_CONFIG = {
    "upsampling_ratios": "3,4,5,5",
    "relu_after_mel_conv": True
}


def main(args):
    included_speakers = set()
    if args.include_speaker is not None:
        included_speakers.update(args.include_speaker)
    if args.include_speaker_range is not None:
        assert len(args.include_speaker_range) == 2
        included_speakers.update(range(*args.include_speaker_range))

    def speaker_cond(speaker_name, speaker_id):
        if not speaker_name.startswith('KingASR'):
            return False
        if args.exclude_speaker is not None and speaker_id in args.exclude_speaker:
            return False
        if len(included_speakers) != 0 and speaker_id not in included_speakers:
            return False
        return True

    speaker_dict = read_json(args.speaker_set)
    candidates_info = [speaker_info for speaker_info in speaker_dict.items() if speaker_cond(*speaker_info)]

    issues = []
    for speaker_name, speaker_id in candidates_info:
        print('start procssing', speaker_name, f'(ID {speaker_id})')

        work_dir = Path(Rf'D:\LowResourceTTS\Production\mt-MT\model\personal_vocoders\speaker{speaker_id}')
        bin_dir = work_dir / 'cuda_bin'
        bin_dir.mkdir(parents=True, exist_ok=True)

        # call_and_check([args.azcopy_path,
        # 'sync', f'https://ttsdata.blob.core.windows.net/ttsdata/users/xianta/LowResourceBackup
        # /denoise_data/mtmt_kingasr/clean_wav/wavs/{speaker_name}/melgan/cuda_bin/
        # ?sv=2019-02-02&st=2020-09-14T08%3A59%3A54Z&se=2020-12-31T08%3A59%3A00Z&sr=c&sp=racwl&sig
        # =JpSby2DSBCYXg08h%2BG8DKX3I4%2B5A5cTTu71vJ3s0ouM%3D', bin_dir])
        call_and_check([args.azcopy_path, 'sync', 'https://ttsdata.blob.core.windows.net/ttsdata/users', bin_dir])
        write_json(bin_dir / 'config.json', BIN_CONFIG)

        bin_path = work_dir / 'melgan_cuda.bin'
        call_and_check([args.pack_tool_path, bin_dir, bin_path])

        if bin_path.stat().st_size < 10 ** 6:
            print(f'Warning: small binary on {speaker_name} ({speaker_id})')
            issues.append((speaker_name, speaker_id))

    print('ISSUES:')
    for issue in issues:
        print(issue)


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('work_dir')
    parser.add_argument('--speaker_set', default=R"D:\LowResourceTTS\Production\mt-MT\data\langdata\speaker.json")
    parser.add_argument('--include_speaker', type=int, nargs='+')
    parser.add_argument('--exclude_speaker', type=int, nargs='+')
    parser.add_argument('--include_speaker_range', type=int, nargs=2)
    parser.add_argument('--azcopy_path', default=R"C:\Users\xianta\Downloads\azcopy.exe")
    parser.add_argument('--pack_tool_path',
                        default=R"C:\Users\xianta\OneDrive - Microsoft\useful\packTool\pack_runtime_model.exe")

    args = parser.parse_args()
    main(args)

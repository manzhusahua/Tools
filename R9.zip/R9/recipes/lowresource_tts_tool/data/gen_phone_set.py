import argparse

import add_path
add_path.add_path()

import helper.io_helper as io_utils
import data.data_helper as data_helper

parser = argparse.ArgumentParser()
parser.add_argument('input_path')
parser.add_argument('--mode', choices=['phone', 'metadata'], default='phone')
parser.add_argument('--output_path')
parser.add_argument('--unitts_phone_set_path', help='phone set of the unitts base model')
parser.add_argument('--phone_set_type', choices=['TFTTS', 'TorchTTS'], default='TFTTS',
                    help='format of phone set, with or without ID')

args = parser.parse_args()

if args.mode == 'phone':
    prons = io_utils.readlines(args.input_path)
elif args.mode == 'metadata':
    metadata = io_utils.read_metadata(args.input_path)
    prons = list(metadata['phone'])
else:
    raise AssertionError('Unknown mode')

phone_count = data_helper.count_token(prons)
phones = phone_count.keys()
print(phones)

if args.unitts_phone_set_path is not None or args.output_path is not None:
    assert args.unitts_phone_set_path is not None and args.output_path is not None
    data_helper.append_phones_to_phone_set(args.unitts_phone_set_path, args.output_path, phones, args.phone_set_type)

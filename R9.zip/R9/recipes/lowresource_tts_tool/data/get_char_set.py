import os
import json
import argparse
from collections import defaultdict
import pandas as pd

import add_path
add_path.add_path()

import helper.io_helper as io_utils
import data.data_helper as data_helper
import data.speech_ocean_data_helper as speech_ocean_data_helper
import data.frontend_data_helper as frontend_data_helper

# edit constants here according to target locale
possible_breaking_punctuations = ',.!?;:"'    # always a separate word
possible_non_breaking_punctuations = "'-_"    # maybe a part of the word, so included in the phone set

parser = argparse.ArgumentParser(description='get character statistics from text and generate related language data')
parser.add_argument('input_path')
parser.add_argument('--mode', default='PlainText',
                    choices=['PlainText', 'Metadata', 'KingASRContent', 'KingASRScript', 'Lexicon'],
                    help='specify data source format')
parser.add_argument('--output_dir', help='generate phone set and language INI')
parser.add_argument('--locale', help='locale name used in output (like en-US)')
parser.add_argument('--unitts_phone_set_path', help='phone set of the unitts base model')
parser.add_argument('--create_phone_for_non_breaking_punctuation', action='store_true',
                    help='add an isolated phone for ech each non-breaking punctuation')
parser.add_argument('--locale_phone_set_path', help='phone set of the locale being processed')
parser.add_argument('--phone_set_type', choices=['TFTTS', 'TorchTTS'], default='TFTTS',
                    help='format of phone set, with or without ID')

args = parser.parse_args()

# only count such characters
char_pred = lambda x: not x.isspace()    # noqa: E731

if args.mode == 'KingASRContent':
    content = pd.read_csv(args.input_path, sep='\t', encoding='utf-8')
    texts = content['TRS']
    previous_char_pred = char_pred
    char_pred = lambda x: previous_char_pred(x) and not speech_ocean_data_helper.is_special_marker(x)    # noqa: E731

elif args.mode == 'KingASRScript':
    scripts = speech_ocean_data_helper.load_scripts(args.input_path)
    texts = [pair[0] for pair in scripts.values()]    # prompts

elif args.mode == 'PlainText':
    script_format = 'plain text'
    texts = io_utils.readlines(args.input_path, encoding='utf-8')

elif args.mode == 'Metadata':
    metadata = io_utils.read_metadata(args.input_path)
    texts = metadata['text']

elif args.mode == 'Lexicon':
    assert args.input_path.endswith('.lex')
    lines = io_utils.readlines(args.input_path, encoding='utf-8')
    texts = [line.strip().split('\t')[1] for line in lines]

else:
    raise AssertionError('Unknown mode')

logging_path = args.input_path + '.charset.log'
logging_file = open(logging_path, 'w', encoding='utf-8')


def print_info(*args):
    print(*args)
    print(*args, file=logging_file)


def print_dict(d, **kwargs):
    print(d)
    s = json.dumps(d, indent=4, ensure_ascii=False, **kwargs)
    print(s, file=logging_file)


sentence_count = len(texts)
char_count = data_helper.count_token(texts, split=False, pred=char_pred)
print_info('total', len(texts), 'sentences')

texts_containing_digits = [text for text in texts if any([ch.isdigit() for ch in text])]
print_info(len(texts_containing_digits), 'sentences contain digits')

chars = sorted(char_count.keys())
filters = [
    ('lower letters', lambda ch: ch.islower()),
    ('upper letters', lambda ch: ch.isupper()),
    ('other alphas', lambda ch: ch.isalpha()),
    ('breaking punctuations', lambda ch: ch in possible_breaking_punctuations),
    ('non-breaking punctuations', lambda ch: ch in possible_non_breaking_punctuations),
    ('other characters', lambda ch: True)
]

filtered_chars = defaultdict(list)
for ch in sorted(char_count.keys()):
    for key, pred in filters:
        if pred(ch):
            filtered_chars[key].append(ch)
            break

for key, _ in filters:
    if len(filtered_chars[key]) > 0:
        print_info()
        print_info(len(filtered_chars[key]), key, ':', filtered_chars[key])
        print_info('counts:')
        print_dict({ch: char_count[ch] for ch in filtered_chars[key]})

letters = filtered_chars['other alphas'] + filtered_chars['lower letters'] + \
    [ch.lower() for ch in filtered_chars['upper letters']]
if args.locale_phone_set_path:
    letters = data_helper.add_customized_letters(args.locale_phone_set_path, letters)

if args.create_phone_for_non_breaking_punctuation:
    letters += filtered_chars['non-breaking punctuations']
letters = sorted(set(letters))
print_info()
print_info(f'current phone set contains {len(letters)} letters: {letters}')

logging_file.close()

if args.output_dir is not None:
    os.makedirs(args.output_dir, exist_ok=True)
    locale = args.locale
    assert locale is not None and locale[2] == '-'

    actual_phones = ['letter_' + ch for ch in letters] + ['symbol']
    phone_id_dict = frontend_data_helper.write_phone_set_xml(args.output_dir, actual_phones, locale)

    lang_ini_path = os.path.join(args.output_dir,
                                 f'MSTTSLoc{locale[0].upper()}{locale[1].lower()}{locale[3:].upper()}.ini')
    with open(lang_ini_path, 'w', encoding='utf-16') as f:
        f.write('[TN]\n')
        f.write('TNScope=FullContext\n')
        f.write('\n')
        f.write('[CharToPhoneIdMapping]\n')

        for i, letter in enumerate(letters):
            phone_id = phone_id_dict[actual_phones[i]]
            f.write(f'{letter}={phone_id}\n')
            if letter.upper() != letter:
                f.write(f'{letter.upper()}={phone_id}\n')

        if not args.create_phone_for_non_breaking_punctuation:
            symbol_phone_id = phone_id_dict['symbol']
            for ch in filtered_chars['non-breaking punctuations']:
                f.write(f'{ch}={symbol_phone_id}\n')

    punctuations = sorted(set(filtered_chars['non-breaking punctuations'] + filtered_chars['breaking punctuations']))
    reserved_tokens = ['<pad>', '~']
    actual_tokens = ['<bos>', '/'] + actual_phones + ['punc' + punctuation for punctuation in punctuations]
    tokens = reserved_tokens + actual_tokens

    backend_voice_phone_set_path = os.path.join(args.output_dir, 'phone.txt')
    with open(backend_voice_phone_set_path, 'w', encoding='utf-8') as f:
        for i, token in enumerate(tokens):
            f.write(f'"{token}": {i}\n')

    if args.unitts_phone_set_path is not None:
        new_unitts_tokens = [locale.lower() + '_' + token
                             if token.startswith('letter_') else token for token in actual_tokens]
        unitts_finetune_model_phone_set_path = os.path.join(args.output_dir, 'phone_set.json')
        data_helper.append_phones_to_phone_set(args.unitts_phone_set_path,
                                               unitts_finetune_model_phone_set_path, new_unitts_tokens,
                                               args.phone_set_type)

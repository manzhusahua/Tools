import argparse

import pandas as pd
import matplotlib.pyplot as plt

import helper.io_helper as io_utils
import data.data_helper as data_helper

parser = argparse.ArgumentParser(description='generate speaker and locale set from metadata')
parser.add_argument('metadata_path')
parser.add_argument('output_speaker_path')
parser.add_argument(
    '--mode', choices=['print_count', 'gen_for_training'], default='gen_for_training')

# for gen_for_training mode
parser.add_argument('--offset', default=201, type=int, help='the offset of new speaker id')
parser.add_argument('--base_speaker_set_path', help='the speaker set of base model')

parser.add_argument('--output_speaker_locale_path', default=None, help='the path of speaker and locale set')
parser.add_argument('--base_speaker_locale_set_path', help='the speaker and locale set of base model')
parser.add_argument('--output_locale_path', default=None, help='the path of locale set')
parser.add_argument('--base_locale_set_path', help='the locale set of base model')
parser.add_argument('--locale', default=None, help='locale name')
parser.add_argument('--locale_id', default=99, type=int, help='the locale id')

args = parser.parse_args()
assert args.metadata_path.endswith('.csv')
assert args.output_speaker_path.endswith('.json')
if args.output_speaker_locale_path is not None:
    assert args.output_speaker_locale_path.endswith('.json')
if args.output_locale_path is not None:
    assert args.output_locale_path.endswith('.json')

metadata = io_utils.read_metadata(args.metadata_path)

speaker_count = data_helper.count(metadata['wav'].map(data_helper.get_speaker))

if args.mode == 'print_count':
    io_utils.write_json(args.output_speaker_path, speaker_count)

    counts = pd.Series(list(speaker_count.values()))
    print(counts.describe())
    ax = counts.plot.hist(bins=200)
    ax.set_title('speaker count distribution')
    plt.show()

elif args.mode == 'gen_for_training':
    speaker_dict = {speaker: str(i + args.offset) for i, speaker in enumerate(speaker_count.keys())}
    speaker_dict_back = speaker_dict

    if args.base_speaker_set_path is not None:
        assert args.base_speaker_set_path.endswith('.json')
        base_speaker_dict = io_utils.read_json(args.base_speaker_set_path)
        assert isinstance(base_speaker_dict, dict)
        if max(map(int, base_speaker_dict.values())) >= args.offset:
            print('WARNING: the base speaker set contains index larger than the specified offset')
        base_speaker_dict.update(speaker_dict)
        speaker_dict = base_speaker_dict
    io_utils.write_json(args.output_speaker_path, speaker_dict)

    # Generate speaker_locale_set
    if args.output_speaker_locale_path is not None and args.locale is not None:
        speaker_locale_value_list = []
        speaker_locale_value_list += len(speaker_dict_back) * [args.locale]
        speaker_locale_dict = dict(zip(speaker_dict_back.keys(), speaker_locale_value_list))

        if args.base_speaker_locale_set_path is not None:
            assert args.base_speaker_locale_set_path.endswith('.json')
            base_speaker_locale_dict = io_utils.read_json(args.base_speaker_locale_set_path)
            assert isinstance(base_speaker_locale_dict, dict)
            base_speaker_locale_dict.update(speaker_locale_dict)
            speaker_locale_dict = base_speaker_locale_dict
        io_utils.write_json(args.output_speaker_locale_path, speaker_locale_dict)

    # Generate locale_set
    if args.output_locale_path is not None and args.locale is not None:
        locale_dict = {args.locale: args.locale_id}
        if args.base_locale_set_path is not None:
            assert args.base_locale_set_path.endswith('.json')
            base_locale_dict = io_utils.read_json(args.base_locale_set_path)
            assert isinstance(base_locale_dict, dict)
            if max(map(int, base_locale_dict.values())) >= args.locale_id:
                print('WARNING: the base locale set contains index larger than the specified locale id')
            base_locale_dict.update(locale_dict)
            locale_dict = base_locale_dict
        io_utils.write_json(args.output_locale_path, locale_dict)

else:
    raise AssertionError('unknown mode')

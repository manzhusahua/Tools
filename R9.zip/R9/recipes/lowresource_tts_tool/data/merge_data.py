import os
import argparse
import pandas as pd

import add_path
add_path.add_path()

import helper.io_helper as io_utils

parser = argparse.ArgumentParser(description='merge metadata of different parts')
parser.add_argument('root_dir', help='the specified file under each subfolder will be merged')
parser.add_argument('filenames', nargs='+', help='file names to merge')
parser.add_argument('--sub_dirs', nargs='+', help='sub folders to work on')
parser.add_argument('--output_dir')

args = parser.parse_args()

parts = os.listdir(args.root_dir)
if args.sub_dirs is not None:
    parts = [part for part in parts if part in args.sub_dirs]
parts = sorted(parts)
# Move TTS part to the first to make TTS speaker ID be the first
for i in range(len(parts)):
    if 'TTS' in parts[i]:
        parts.insert(0, parts.pop(i))
        break

output_dir = args.root_dir if args.output_dir is None else args.output_dir
if args.output_dir is not None:
    os.makedirs(args.output_dir, exist_ok=True)

for filename in args.filenames:
    paths = []
    for part in parts:
        part_dir = os.path.join(args.root_dir, part)
        if os.path.isdir(part_dir):
            path = os.path.join(part_dir, filename)
            assert os.path.exists(path), f'{filename} is not found in subfolder {part}'
            paths.append(path)

    output_path = os.path.join(output_dir, 'merged_' + filename)

    if filename.endswith('.csv'):
        df_parts = map(lambda path: io_utils.read_metadata(path), paths)
        merged_metadata = pd.concat(df_parts, ignore_index=True)
        io_utils.write_metadata(output_path, merged_metadata)
    elif filename.endswith('.txt'):
        with open(output_path, 'w', encoding='utf-8') as fout:
            for path in paths:
                with open(path, 'r', encoding='utf-8') as fin:
                    lines = fin.readlines()
                    if lines[-1][-1] != '\n':
                        lines[-1] += '\n'
                    fout.writelines(lines)
    else:
        raise AssertionError('Unknown extension')

$input_dir = "D:\LowResourceTTS\Production\mt-MT\waves\personal_refine\refine_speaker203\denoised_recording"
$output_dir = "D:\LowResourceTTS\Production\mt-MT\waves\personal_refine\refine_speaker203\denoised_recording\volume_normalized"

$files = Get-ChildItem "$input_dir\*.wav"
foreach ($file in $files)
{
    $output_path = Join-Path $output_dir $file.Name
    & "C:\Program Files (x86)\sox-14-4-2\sox.exe" $file.FullName $output_path norm -3
}
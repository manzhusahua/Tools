import os
import argparse
from pathlib import Path

import add_path
add_path.add_path()

import pandas as pd

import helper.io_helper as io_utils
import data.apptek_data_helper as apptek_data_helper
import data.speech_ocean_data_helper as speech_ocean_data_helper
import data.zen3_data_helper as zen3_data_helper
import data.frontend_data_helper as frontend_data_helper

# edit this pattern based on your data
# usually for detecting unsupported TN patterns and unexpected characters
illegal_pattern_dict = {
    'mt-MT': r'[0-9+#/\\\[\]\u2013\u0307\u0430@ˇÉÀÈáéèìíóöùúō]',
    'lt-LT': r'[0-9`àçëāēģīķļņóазку]',
    'et-EE': r'[0-9]',
    'ga-IE': r'\d|[+/\u0307]|\<|\>',
    'lv-LV': r'[0-9Бятсронмлкиедгба]'
}


def build_parser():
    parser = argparse.ArgumentParser(description='process text for low resource training')
    parser.add_argument('input_path')
    parser.add_argument('output_dir')
    parser.add_argument('--mode', required=True, choices=['TTS', 'XML', 'KingASR', 'AppTek_news', 'Zen3'],
                        help='specify data source layout')
    parser.add_argument('--locale', required=True)
    parser.add_argument('--ignore_wav', nargs='+', help='specify some wav to be ignored')

    # for TTS modes
    parser.add_argument('--tts_speaker_prefix', help='the prefix prepended to TTS wav name')

    # for TTS mode
    parser.add_argument('--tts_script_folder_name', default='feedback',
                        help='name of the folder containing script files under input_path')
    parser.add_argument('--tts_retake_folder_name', default='retakes',
                        help='name of the folder containing retaken waves under input_path')

    # for AppTek_news mode
    parser.add_argument('--AppTek_news_duration_threshold', type=int, default=300,
                        help='(in second) only keep speakers with audio length more than this threshold')

    # illegal pattern
    parser.add_argument('--illegal_pattern', help='illegal pattern')

    return parser


def split_df(df, mask):
    return df[mask], df[~mask]


def main(args):

    if args.illegal_pattern is not None:
        illegal_pattern_dict[args.locale] = args.illegal_pattern

    final_kept_columns = ['wav', 'text']

    if args.mode == 'TTS':
        assert args.tts_speaker_prefix is not None
        wav_name_pattern = args.tts_speaker_prefix + '_' + '{:010}'

        script_dir = os.path.join(args.input_path, args.tts_script_folder_name)
        assert os.path.isdir(script_dir)

        sub_data_dfs = []
        for filename in os.listdir(script_dir):
            if filename[0] != '$' and filename.endswith('.xlsx'):
                path = os.path.join(script_dir, filename)
                sub_data_dfs += pd.read_excel(path, sheet_name=None, keep_default_na=False).values()
        data_df = pd.concat(sub_data_dfs, ignore_index=True, sort=False)

        if 'Revised script' in data_df.columns:
            revise_mask = ~ data_df['Revised script'].map(lambda x: x is None or x == '' or x.isspace())
            data_df.loc[revise_mask, 'Script'] = data_df.loc[revise_mask, 'Revised script']

        if 'Accept (Y/N)' in data_df.columns:
            retake_dir = os.path.join(args.input_path, args.tts_retake_folder_name)
            assert os.path.isdir(retake_dir)

            retake_wavs = set()
            for _root, _dirs, files in os.walk(retake_dir):
                for filename in files:
                    retake_wavs.add(filename.lower())

            accept_mask = (data_df['Accept (Y/N)'] == 'Y') | data_df['ID'].map(lambda x: f'{x:010}.wav' in retake_wavs)
            data_df, rejected_cases = split_df(data_df, accept_mask)

            print(len(rejected_cases), 'cases are rejected becaues no retaken audio is found:',
                  list(rejected_cases['ID']))

        data_df['wav'] = data_df['ID'].map(wav_name_pattern.format)

        excel_border_chars = '\'"'    # some character hidden in Excel cells
        data_df['text'] = data_df['Script'].map(lambda x: x.strip(excel_border_chars).strip().strip(excel_border_chars))

    elif args.mode == 'XML':
        # Standard TTS XML script format
        input_dir = Path(args.input_path)
        cases = []
        for script_path in input_dir.rglob('*.xml'):
            cases += frontend_data_helper.read_script_xml(script_path)
        data_df = pd.DataFrame(cases)
        final_kept_columns += ['phone']

    elif args.mode == 'KingASR':
        scripts = speech_ocean_data_helper.load_scripts(args.input_path)
        data_df = pd.DataFrame(map(lambda x: (x[0],) + x[1], scripts.items()), columns=['ID', 'text', 'transcript'])

        data_df['wav'] = data_df['ID'].map(speech_ocean_data_helper.normalize_wavename)

    elif args.mode == 'AppTek_news':
        cases = apptek_data_helper.read_cases(args.input_path)
        data_df = pd.DataFrame(cases)

        data_df['speaker_name'] = data_df['wav'].map(lambda x: x.split('_')[0])
        duration_info = data_df[['speaker_name', 'duration']].groupby('speaker_name').sum()
        duration_info = duration_info[duration_info['duration'] > args.AppTek_news_duration_threshold]
        candidate_set = set(duration_info.index)
        data_df = data_df[data_df['speaker_name'].map(lambda x: x in candidate_set)]

        data_df.rename(columns={'transcription': 'text'}, inplace=True)

        print('time threshold per speaker is', args.AppTek_news_duration_threshold, 'seconds')
        print('total time', data_df['duration'].sum() / 3600, 'hours')
        print('total speaker', len(candidate_set))

    elif args.mode == 'Zen3':
        data_df = zen3_data_helper.load_scripts_csv(args.input_path)
        illegal_pattern = illegal_pattern_dict.get(args.locale)
        if illegal_pattern is not None:
            data_df = data_df[~ data_df['Transcripts'].str.contains(illegal_pattern)]
        data_df['wav'] = data_df['Recorder_ID'].map(str) + '_' + data_df['Audio_FileName'].map(str)
        data_df['text'] = data_df['Sentence_Prompt']
        if illegal_pattern is not None:
            mask = data_df['text'].str.contains(illegal_pattern)
            data_df.loc[mask, 'text'] = data_df.loc[mask, 'Transcripts']

    else:
        raise AssertionError('Unknown mode')

    os.makedirs(args.output_dir, exist_ok=True)
    metadata_path = os.path.join(args.output_dir, 'metadata.csv')

    illegal_pattern = illegal_pattern_dict.get(args.locale)
    if illegal_pattern is not None:
        data_df = data_df[~ data_df['text'].str.contains(illegal_pattern)]

    data_df = data_df[final_kept_columns]
    if args.ignore_wav is not None:
        ignore_mask = data_df['wav'].map(lambda x: x in args.ignore_wav)
        ignored_cases, data_df = split_df(data_df, ignore_mask)
        print(len(ignored_cases), 'cases are ignored due to --ignore_wav', args.ignore_wav)

    io_utils.write_metadata(metadata_path, data_df)
    print(len(data_df), 'cases have been extracted')

    for column in data_df.columns:
        output_path = os.path.join(args.output_dir, f'{column}.txt')
        io_utils.write_metadata(output_path, data_df[column], header=False, check_ext=False)


if __name__ == '__main__':
    parser = build_parser()
    args = parser.parse_args()
    main(args)

import os
import glob
import zipfile
import argparse
import tempfile
import shutil
import subprocess
import numpy as np
import librosa
import librosa.effects
import soundfile
from tqdm import tqdm

import add_path
add_path.add_path()

import helper.io_helper as io_utils
import data.apptek_data_helper as apptek_data_helper
import data.speech_ocean_data_helper as speech_ocean_data_helper
import data.zen3_data_helper as zen3_data_helper

parser = argparse.ArgumentParser(description='process wave for low resource training')
parser.add_argument('input_dir')
parser.add_argument('output_dir')
parser.add_argument('--metadata_path', help='metadata CSV containing wave names to process')
parser.add_argument('--mode', required=True,
                    choices=['TTS', 'KingASR', 'AppTek_news', 'Zen3'], help='specify source data type')
parser.add_argument('--tts_output_sample_rates',
                    default='16k,24k', help='output sample rates for TTS data, separated by comma')
parser.add_argument('--no_zip', action='store_true')

args = parser.parse_args()


def get_sample_rates(arg_str):
    target_sample_rates = arg_str.split(',')
    assert all([
               sample_rate[-1].lower() == 'k' for sample_rate in target_sample_rates]
               ), 'only integer khz are supported'
    target_sample_rates = [int(sample_rate[:-1]) for sample_rate in target_sample_rates]
    assert len(set(target_sample_rates)) == len(target_sample_rates), 'duplicate target sample rates'
    return target_sample_rates


def process_waves(wave_index, input_dir, output_dir, target_sample_rates_khz, output_zip, normalize_silence_ms=None):
    os.makedirs(output_dir, exist_ok=True)

    wave_paths = {}
    for rel_path in glob.iglob(os.path.join(input_dir, '**', '*.*'), recursive=True):
        basename_parts = os.path.splitext(os.path.basename(rel_path))
        if basename_parts[1].lower() == '.wav' and basename_parts[0] in wav_index:
            target_wav = wav_index[basename_parts[0]]
            wave_paths[target_wav] = os.path.join(args.input_dir, rel_path)

    # unify waves format with sox
    for _target_wav, target_wav_path in wave_paths.items():
        target_wav_path_new = target_wav_path.split('.WAV')[0] + 'new.WAV'
        common_sox = ['sox', target_wav_path, target_wav_path_new]
        result = subprocess.run(common_sox)
        if result.returncode != 0:
            print('ERROR: sox failed with args {common_sox}')
            exit(result.returncode)
        shutil.move(target_wav_path_new, target_wav_path)

    expected_wav_set = set(wav_index.values())
    not_found_count = len(expected_wav_set) - len(wave_paths)
    assert not_found_count == 0, f'{not_found_count} target waves not found: \
    {expected_wav_set - set(wave_paths.keys())}'

    output_zips = {}
    if output_zip:
        for sample_rate_khz in target_sample_rates_khz:
            output_path = os.path.join(output_dir, f'waves_{sample_rate_khz}k.zip')
            output_zips[sample_rate_khz] = zipfile.ZipFile(output_path, 'w')

    for target_wav, src_path in tqdm(wave_paths.items(), total=len(wave_paths)):
        audio, original_sample_rate = librosa.load(src_path, sr=None)
        is_modified = False

        origin_is_mono = len(audio.shape) == 1
        if not origin_is_mono:
            audio = librosa.to_mono(audio)
            is_modified = True

        if normalize_silence_ms is not None:
            trimmed_audio, _ = librosa.effects.trim(audio)
            head_silence = [0.0] * (original_sample_rate // 1000 * normalize_silence_ms[0])
            tail_silence = [0.0] * (original_sample_rate // 1000 * normalize_silence_ms[1])
            audio = np.concatenate((head_silence, trimmed_audio, tail_silence))
            is_modified = True

        for target_sample_rate_khz in target_sample_rates_khz:
            target_sample_rate = target_sample_rate_khz * 1000
            need_resample = original_sample_rate != target_sample_rate
            if need_resample:
                if original_sample_rate < target_sample_rate:
                    print(f'WARNING: {target_wav} has a low sample rate')
                resampled_audio = librosa.resample(audio, original_sample_rate, target_sample_rate)
            else:
                resampled_audio = audio

            tgt_path = os.path.join(output_dir, target_wav + '.wav')
            if is_modified or need_resample:
                if output_zip:
                    tmp_file = tempfile.SpooledTemporaryFile(max_size=999_000_000)
                    soundfile.write(tmp_file, resampled_audio, target_sample_rate, format='WAV')
                    output_zips[target_sample_rate_khz].writestr(target_wav + '.wav', tmp_file._file.getvalue())
                else:
                    soundfile.write(tgt_path, resampled_audio, target_sample_rate)
            else:
                if output_zip:
                    output_zips[target_sample_rate_khz].write(src_path, arcname=target_wav + '.wav')
                else:
                    shutil.copy(src_path, tgt_path)


metadata_path = args.metadata_path
if metadata_path is None:
    metadata_path = os.path.join(args.output_dir, 'metadata.csv')

metadata = io_utils.read_metadata(metadata_path)
target_wavs = metadata['wav']
wav_index = {}    # map source filename to target filename

normalize_silence_ms = None
target_sample_rates_khz = [16]

input_dir = args.input_dir

if args.mode == 'TTS':
    target_sample_rates_khz = get_sample_rates(args.tts_output_sample_rates)
    wav_index = {target_wav: target_wav for target_wav in target_wavs}

    # source file names without speaker name prefix are also acceptable
    wav_index.update({target_wav.split('_')[1]: target_wav for target_wav in target_wavs if '_' in target_wav})

    normalize_silence_ms = (50, 100)    # ms

elif args.mode == 'KingASR':
    wav_index = {speech_ocean_data_helper.denormalize_wavename(target_wav): target_wav for target_wav in target_wavs}

elif args.mode == 'AppTek_news':
    segments_dir = os.path.join(args.output_dir, 'raw_segments')
    if os.path.exists(segments_dir):
        print('WARNING: Segment folder already exists. Reuse it without extracting again.')
    else:
        wav_index = apptek_data_helper.extract_segments(args.input_dir, segments_dir, target_wavs)

    wav_index = {target_wav: target_wav for target_wav in target_wavs}
    input_dir = segments_dir

elif args.mode == 'Zen3':
    wav_index = {zen3_data_helper.denormalize_wavename(target_wav): target_wav for target_wav in target_wavs}

else:
    raise AssertionError('Unknown mode')

process_waves(wav_index, input_dir, args.output_dir, target_sample_rates_khz, not args.no_zip, normalize_silence_ms)

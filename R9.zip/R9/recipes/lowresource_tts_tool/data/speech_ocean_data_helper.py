import os


def is_special_marker(token):
    return token[0] == '<' and token.endswith('/>') or token == '**'


def is_corrupted_case(prompt, transcript):
    def normalize_text(text):
        # lower case and remove punctuations
        # keep stars which means corrupted part in transcription
        normalized_text = [ch.lower() for ch in text if ch.isalpha() or ch == '*']
        return normalized_text

    normalized_prompt = normalize_text(prompt)
    normalized_transcript = normalize_text(transcript)
    return normalized_prompt != normalized_transcript


def load_scripts(script_dir):
    scripts = {}
    for filename in os.listdir(script_dir):
        path = os.path.join(script_dir, filename)
        with open(path, 'r', encoding='utf-8-sig') as f:
            num = None
            prompt = ''
            transcript = ''
            for i, line in enumerate(f):
                if i % 2 == 0:
                    columns = line.rstrip().split('\t')
                    num = columns[0]
                    prompt = columns[1]
                elif i % 2 == 1:
                    transcript = line.strip()
                    if not is_corrupted_case(prompt, transcript):
                        scripts[num] = (prompt, transcript)
    return scripts


def normalize_wavename(name):
    wave_id = name[:-4] if name.endswith('.wav') else name
    assert len(wave_id) == 9 and wave_id.isdigit()
    # wave_id[0]: channel number
    # wave_id[1:5]: speaker number
    # wave_id[5:9]: utterance number
    return f'KingASRCHANNEL{wave_id[0]}Speaker{wave_id[1:5]}_{wave_id[5:]}'


def denormalize_wavename(name):
    wave_id = ''.join(filter(lambda x: x.isdigit(), name))
    return wave_id

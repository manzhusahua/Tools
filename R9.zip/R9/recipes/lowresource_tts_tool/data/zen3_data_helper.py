import os
import pandas as pd

import add_path
add_path.add_path()

import helper.io_helper as io_utils


def load_scripts_csv(csv_dir):
    data_df = pd.DataFrame(columns=('Recorder_ID', 'Audio_FileName', 'Sentence_Prompt', 'Transcripts'))
    for filename in os.listdir(csv_dir):
        path = os.path.join(csv_dir, filename)
        data_df_temp = io_utils.read_metadata(path)
        data_df = data_df.append(data_df_temp, sort=False)

    data_df.dropna(axis=0, how='any', inplace=True)
    return data_df


def denormalize_wavename(name):
    wave_id = name.split('_')[1]
    return wave_id

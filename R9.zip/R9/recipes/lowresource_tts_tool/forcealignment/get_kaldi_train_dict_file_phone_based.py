import csv
import pandas as pd
import argparse
import os
import re


# Prepare text file
def get_text_file(inputcsv, output, prefix):
    data = pd.read_csv(inputcsv, sep='|', encoding='utf-8', quoting=csv.QUOTE_NONE, dtype={'wav': str})
    f_out = open(output, 'w', encoding='utf-8')
    txt_new = []
    index = list(range(data.shape[0]))
    for i in index:
        item = data.iloc[i]
        line = item['phone2']
        wav = item['wav']
        new_line = ""
        phone_list = line.strip().split(' ')
        word = ""
        for phone in phone_list:
            if phone == '<bos>' or phone == '<BOS>':
                new_line = new_line + word + ' ' + phone + ' '
                word = ""
            elif phone.startswith('punc'):
                new_line = new_line + word + ' ' + phone.replace('punc', '') + ' '
                word = ""
            elif phone.startswith('br'):
                new_line = new_line + word + ' ' + phone + ' '
                word = ""
            else:
                word = word + phone.replace(prefix, '')
        if word != "":
            new_line = new_line + ' ' + word + ' '

        new_line = new_line.replace('  ', ' ').strip()
        f_out.write(wav + ' ' + new_line.strip() + '\n')
        txt_new.append(new_line.strip())

    f_out.close()
    print('Prepare text file done.')
    data['txt_new'] = txt_new
    print('Get text file successfully.')
    return data


# Prepare lexicon.txt file
def get_lexicon(data, output):
    dictionary = {}
    f_out = open(output, 'w', encoding='utf-8')
    f_out.write('<UNK> sil\n')
    f_out.write('<bos> sil\n')
    index = list(range(data.shape[0]))
    for i in index:
        line = data.iloc[i]
        phones = line['phone2']
        text = line['txt_new']

        phone_list = re.split('(<bos>|br0|br1|br2|br3|br4)', phones)
        phone_list = [phone for phone in phone_list if phone.strip() != '']
        text_list = text.strip().split()
        if len(phone_list) != len(text_list):
            print(str(line['wav']) + 'The length of phone sequence is not equal with the length of word sequence')
            continue
        for key, value in zip(text_list, phone_list):
            key = key.strip()
            value = value.strip()
            if key in dictionary.keys():
                if dictionary[key] != value:
                    if value.startswith('punc') and dictionary[key] == 'sil':
                        pass
                    else:
                        print('Error lexicon: ' + str(key))
                        continue
            elif key == '<UNK>' or key == '<bos>':
                continue
            elif value.startswith('punc'):
                dictionary[key] = 'sil'
            else:
                dictionary[key] = value

    for key, value in dictionary.items():
        f_out.write(key.strip() + ' ' + value.strip() + '\n')
    f_out.close()
    print('Prepare lexicon.txt file done.')


# Prepare nonsilence_phones.txt file
def get_phone_set(input, output):
    with open(input, 'r', encoding='utf-8') as f_in:
        lines = f_in.readlines()
    phones = set()
    for line in lines[1:]:
        phone_list = line.strip().split(' ')[1:]
        for phone in phone_list:
            if phone != '<bos>' and phone != '<BOS>' and phone != 'br0' and phone != 'br1' \
               and phone != 'br2' and phone != 'br3' and phone != 'br4' and phone != 'sil':
                phones.add(phone)
    f_out = open(output, 'w', encoding='utf-8')
    for phone in phones:
        f_out.write(phone + '\n')
    f_out.close()
    print('Prepare nonsilence_phones.txt file done.')


# Prepare wav.scp and utt2spk file
def get_wav_utt2spk_path(data, output_waves_folder, waves_folder, output, output_utt2spk):
    f_out = open(output, 'w', encoding='utf-8')
    f_out_utt2spk = open(output_utt2spk, 'w', encoding='utf-8')
    index = list(range(data.shape[0]))
    for i in index:
        item = data.iloc[i]
        wav = item['wav']
        spk = wav.strip().split('_')[0] + '_'
        waves_path = os.path.join(output_waves_folder, waves_folder, wav + '.wav')
        f_out.write(wav + ' ' + waves_path + '\n')
        f_out_utt2spk.write(wav + ' ' + spk + '\n')
    f_out.close()
    f_out_utt2spk.close()
    print('Prepare wav.scp and utt2spk files done.')


# Prepare empty and silence files on dict folder
def get_other_dict_files(output_extra_questions, output_optional_silence, output_silence_phones):
    command = "touch " + output_extra_questions
    os.system(command)
    print('Prepare extra_questions.txt file done.')

    command = "echo sil > " + output_optional_silence
    os.system(command)
    print('Prepare optional_silence.txt file done.')

    command = "echo sil > " + output_silence_phones
    os.system(command)
    command = "echo br0 >> " + output_silence_phones
    os.system(command)
    command = "echo br1 >> " + output_silence_phones
    os.system(command)
    command = "echo br2 >> " + output_silence_phones
    os.system(command)
    command = "echo br3 >> " + output_silence_phones
    os.system(command)
    command = "echo br4 >> " + output_silence_phones
    os.system(command)
    print('Prepare silence_phones.txt file done.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Get some lexicon and text files to force aligm with kaldi')
    parser.add_argument('--inputcsv_dir', default=None, required=True, help='input metadata_phone.csv file path')
    parser.add_argument('--output_dir', default='data', help='output folder path')
    parser.add_argument('--prefix', default='et-ee_letter_', help='prefix of char need to be removed')
    parser.add_argument('--output_waves_folder', default='output_waves_folder', help='the output folder of wave folder')
    parser.add_argument('--waves_folder', default='waves', help='the folder of wave files')
    args = parser.parse_args()

    output_data_dir = os.path.join(args.output_dir, 'data')
    output_train_dir = os.path.join(output_data_dir, 'train')
    output_dict_dir = os.path.join(output_data_dir, 'dict')
    if not os.path.exists(output_data_dir):
        os.makedirs(output_data_dir)
    if not os.path.exists(output_train_dir):
        os.makedirs(output_train_dir)
    if not os.path.exists(output_dict_dir):
        os.makedirs(output_dict_dir)

    output_text = os.path.join(output_train_dir, 'text')
    output_wav = os.path.join(output_train_dir, 'wav.scp')
    output_utt2spk = os.path.join(output_train_dir, 'utt2spk')
    output_lexicon = os.path.join(output_dict_dir, 'lexicon.txt')
    output_phone_set = os.path.join(output_dict_dir, 'nonsilence_phones.txt')
    output_extra_questions = os.path.join(output_dict_dir, 'extra_questions.txt')
    output_optional_silence = os.path.join(output_dict_dir, 'optional_silence.txt')
    output_silence_phones = os.path.join(output_dict_dir, 'silence_phones.txt')

    inputcsv = os.path.join(args.inputcsv_dir, 'metadata_phone.csv')
    data = get_text_file(inputcsv, output_text, args.prefix)
    get_lexicon(data, output_lexicon)
    get_phone_set(output_lexicon, output_phone_set)
    get_wav_utt2spk_path(data, args.output_waves_folder, args.waves_folder, output_wav, output_utt2spk)
    get_other_dict_files(output_extra_questions, output_optional_silence, output_silence_phones)

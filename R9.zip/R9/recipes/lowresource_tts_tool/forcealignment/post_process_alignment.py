import os
import sys
import csv
import pandas as pd
import argparse
import wave
from typing import Union
from pathlib import Path
import zipfile


# Unzip
def unzip_file(zip_name, unzip_dir):
    r = zipfile.is_zipfile(zip_name)
    if r:
        os.makedirs(unzip_dir, exist_ok=True)
        fz = zipfile.ZipFile(zip_name, 'r')
        for file in fz.namelist():
            fz.extract(file, unzip_dir)
    else:
        print('This is not zip')


# Deal duration no combine and add punctuation
def deal_duration(lines):
    result_list = []
    previous_key = lines[0].strip().split()[0]

    for line in lines:
        key = line.strip().split()[0]
        if key != previous_key:
            print('Error: The key is not same ' + str(key))
        dur = float(line.strip().split()[3])

        result_list.append(int(dur * 100))
    return result_list


def deal_total_sentence(input_file):
    with open(input_file, 'r', encoding='utf-8') as f_in:
        lines = f_in.readlines()
    result_dict = {}
    sentence_dict = {}
    for line in lines:
        key = line.strip().split()[0].replace('.wav', '')
        if key not in sentence_dict.keys():
            sentence_dict[key] = []
            sentence_dict[key].append(line)
        else:
            sentence_dict[key].append(line)

    for key, values in sentence_dict.items():
        line_result = deal_duration(values)
        result_dict[key] = line_result

    print('There are ' + str(len(result_dict)) + ' sentences')
    return result_dict


def dealfun(sr_duration_str):
    newdur = ""
    remian = 0.0
    durlist = sr_duration_str.strip().split()
    for dur in durlist:
        phonelength = int(dur) * 10
        frame_count = int(phonelength / 12.5)
        remian = remian + (phonelength - frame_count * 12.5)
        if remian >= 12.5:
            frame_count = frame_count + 1
            remian = remian - 12.5
        newdur = newdur + str(frame_count) + ' '
    return newdur.strip()


def get_audio_length(filename: Union[str, Path]):
    # wave module only support str filename
    if isinstance(filename, Path):
        filename = str(filename)
    with wave.open(filename) as f:
        return f.getnframes() / f.getframerate()


def get_dur_metadata(input_metadata, output_metadata, duration_dict,
                     is_add_punc_dur, duration_convert, metadata_type, locale,
                     waves_dict, waves_zip_file, waves_dict_path, keep_speaker_id):
    data_df = pd.read_csv(input_metadata, sep='|', encoding='utf-8', quoting=csv.QUOTE_NONE,
                          error_bad_lines=False, dtype={'wav': str})
    if metadata_type == 'TFTTS':
        data = pd.DataFrame(columns=['', 'Unnamed: 0', 'style_id', 'wav', 'locale_id', 'speaker_id',
                                     'txt2', 'phone', 'phone2', 'phone_dur'])
    elif metadata_type == 'TorchTTS':
        if keep_speaker_id:
            data = pd.DataFrame(columns=['sid', 'locale', 'speaker', 'speaker_id', 'style',
                                         'text', 'phones', 'durations', 'speech_length_in_s', 'speech_path'])
        else:
            data = pd.DataFrame(columns=['sid', 'locale', 'speaker', 'style',
                                         'text', 'phones', 'durations', 'speech_length_in_s', 'speech_path'])
        waves_zip_path = os.path.join(waves_dict, waves_zip_file)
        if os.path.isfile(waves_zip_path):
            unzip_file(waves_zip_path, waves_dict)
    else:
        print("Please input correct metadata file type. Such as: TFTTS/TorchTTS")
        sys.exit()
    index = list(range(data_df.shape[0]))
    count = 0
    for i in index:
        line = data_df.iloc[i]
        wav = line['wav']
        speaker_id = line['speaker_id']
        if wav not in duration_dict.keys():
            print(str(wav) + ' not in dictionary.')
            continue
        if is_add_punc_dur == 'Yes':
            temp = duration_dict[wav]
            temp.insert(0, 0)
            phone_list = line['phone2'].strip().split()
            if len(phone_list) >= 3 and phone_list[-1].startswith('punc') and phone_list[-3].startswith('punc'):
                temp.append(0)
            duration_list = []
            phone_index = list(range(len(phone_list)))
            punc_count = 0
            for pi in phone_index:
                phone = phone_list[pi]
                if phone.startswith('punc') and pi != len(phone_list) - 1:
                    duration_list.append(0)
                    punc_count = punc_count + 1
                elif phone.startswith('punc') and pi == len(phone_list) - 1 and (pi - punc_count == len(temp)):
                    duration_list.append(0)
                    punc_count = punc_count + 1
                else:
                    try:
                        duration_list.append(temp[pi - punc_count])
                    except BaseException:
                        print(wav + ' has bad force alignment.')
                        break
        else:
            duration_list = duration_dict[wav]

        if len(duration_list) != len(line['phone2'].strip().split()):
            print('Error: Phone sequence length is not as same as the length of duration' + str(i) + ' ' + line['wav'])
            continue
        duration_seq_sr = ' '.join('%s' % id for id in duration_list).strip()
        if duration_convert == 'Yes':
            duration_seq = dealfun(duration_seq_sr)
        else:
            duration_seq = duration_seq_sr

        if metadata_type == 'TFTTS':
            sample = pd.Series([count, count, line['style_id'], wav, line['locale_id'], line['speaker_id'],
                               line['txt2'], line['phone2'].strip(), line['phone2'].strip(), duration_seq],
                               index=data.columns)
        elif metadata_type == 'TorchTTS':
            wave_path = os.path.join(waves_dict, wav + '.wav')
            wave_path_blob = os.path.join(waves_dict_path, wav + '.wav')
            speech_length = get_audio_length(wave_path)
            phones_new = line['phone2'].strip().replace(locale + '_', '').replace('<bos>', '<s>') + ' </s>'
            duration_seq_new = duration_seq + ' 0'
            line_data = ["placeholder", locale, 'Xcustom_', 'General', line['txt2'],
                         phones_new, duration_seq_new, speech_length, wave_path_blob]
            if len(wav.strip().split('_')) != 2:
                line_data[0] = wav.strip()
                if keep_speaker_id:
                    line_data.insert(3, speaker_id)
                sample = pd.Series(line_data, index=data.columns)
            else:
                line_data[0] = wav.strip().split('_')[1]
                sample = pd.Series(line_data, index=data.columns)

        data = data.append(sample, ignore_index=True)
        count = count + 1

    data.to_csv(output_metadata, sep='|', encoding='utf-8', index=False, quoting=csv.QUOTE_NONE)


def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_align_dir',
        dest='inputaligndir',
        default=None)
    parser.add_argument(
        '--input_metadata_dir',
        dest='inputmetadatadir',
        default=None)
    parser.add_argument(
        '--metadata_phone_name',
        dest='metadataphonename',
        default='metadata_phone.csv')
    parser.add_argument(
        '--align_data_name',
        dest='aligndataname',
        default='data.ctm')
    parser.add_argument(
        '--add_punc_dur',
        choices=['Yes', 'False'],
        default='False',
        help='add punction duration')
    parser.add_argument(
        '--duration_convert',
        choices=['Yes', 'False'],
        default='Yes',
        help='convert SR duration to TTS duration')
    parser.add_argument(
        '--keep_speaker_id',
        choices=['Yes', 'False'],
        default='False',
        help='Keep speaker id in metadata')
    parser.add_argument(
        '--output_dir',
        dest='outputdir',
        default=None)
    parser.add_argument(
        '--locale',
        dest='locale',
        default=None)
    parser.add_argument(
        '--metadata_type',
        dest='metadatatype',
        default='TFTTS',
        help='TFTTS: metadata type for tensorflow binary formats, TorchTTS: metadata type for torchTTS formats')
    parser.add_argument(
        '--waves_dict',
        dest='wavesdict',
        default=None)
    parser.add_argument(
        '--waves_zip_file',
        dest='waveszipfile',
        default='waves_processed_16k.zip')
    parser.add_argument(
        '--waves_dict_path',
        dest='wavesdictpath',
        default=None)

    args, _ = parser.parse_known_args()

    args.keep_speaker_id = True if args.keep_speaker_id == "Yes" else False
    return args


if __name__ == "__main__":
    args = get_arguments()
    input_metadata = os.path.join(args.inputmetadatadir, args.metadataphonename)
    input_alignment = os.path.join(args.inputaligndir, args.aligndataname)
    if not os.path.isdir(args.outputdir):
        os.makedirs(args.outputdir, exist_ok=True)

    output_metadata = os.path.join(args.outputdir, 'metadata_phone.csv')
    duration_convert = args.duration_convert
    add_punc_dur = args.add_punc_dur
    metadata_type = args.metadatatype
    locale = args.locale
    waves_dict = args.wavesdict
    waves_zip_file = args.waveszipfile
    waves_dict_path = args.wavesdictpath
    if metadata_type == 'TorchTTS':
        if locale is None:
            print('Please input locale when choose TorchTTS metadata format, such as et-ee')
            sys.exit()
        if waves_dict is None:
            print('Please input waves dictionary path when choose TorchTTS metadata format')
            sys.exit()
        if waves_dict_path is None:
            print('Please input waves blob dictionary path when choose TorchTTS metadata format')
            sys.exit()
    duration_dict = deal_total_sentence(input_alignment)
    get_dur_metadata(input_metadata, output_metadata, duration_dict,
                     add_punc_dur, duration_convert, metadata_type, locale,
                     waves_dict, waves_zip_file, waves_dict_path, args.keep_speaker_id)

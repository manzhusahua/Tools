import subprocess
from typing import Optional


def request_for_yes(prompt: str, exit_code: Optional[int] = 0) -> bool:
    if prompt[-1] != '.':
        prompt += '.'
    response = input(prompt + ' Continue? (y/N)')
    is_yes = response.lower() in ['y', 'yes']
    if exit_code is not None and not is_yes:
        exit(exit_code)
    return is_yes


def runtime_check(assertion: bool, message: str, action: str = 'raise') -> None:
    if not assertion:
        if action == 'raise':
            raise RuntimeError(message)
        elif action == 'request':
            request_for_yes(message)
        else:
            raise AssertionError('Illegal action')


def run_subprocess(args: list, print_call: bool = True, check_return_code: bool = True, **kwargs) -> int:
    str_args = [str(arg) for arg in args]
    if print_call:
        print(f'run subprocess {str_args}')
    return_code = subprocess.call(str_args, **kwargs)
    if check_return_code and return_code != 0:
        raise RuntimeError(f'non-zero returned code {return_code} when calling {str_args}')
    return return_code


def get_first_not_none(*objs):
    for obj in objs:
        if obj is not None:
            return obj
    raise RuntimeError('all candidates are none')

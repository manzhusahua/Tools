from os import PathLike
import json
import csv
from typing import List, Iterable
import pandas as pd
from helper.path_helper import check_extension


def readlines(path: PathLike, *args, **kwargs) -> List[str]:
    with open(path, 'r', *args, **kwargs) as f:
        return [line.rstrip('\n') for line in f]


def writelines(path: PathLike, lines: Iterable[str], *args, **kwargs):
    with open(path, 'w', *args, **kwargs) as f:
        f.writelines([line + '\n' for line in lines])


def read_json(path: PathLike, **kwargs):
    check_extension(path, 'json')
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f, **kwargs)


def write_json(path: PathLike, obj, ensure_ascii: bool = False, **kwargs):
    check_extension(path, 'json')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=4, ensure_ascii=ensure_ascii, **kwargs)


def read_metadata(path: PathLike, check_ext=True, **kwargs) -> pd.DataFrame:
    if check_ext:
        check_extension(path, 'csv')
    return pd.read_csv(path, sep='|', encoding='utf-8', quoting=csv.QUOTE_NONE, dtype=str, **kwargs)


def write_metadata(path: PathLike, metadata: pd.DataFrame, check_ext=True, **kwargs) -> None:
    if check_ext:
        check_extension(path, 'csv')
    metadata.to_csv(path, sep='|', encoding='utf-8', index=False, quoting=csv.QUOTE_NONE, **kwargs)

from os import PathLike
from pathlib import Path
from helper.func_helper import runtime_check


def ensure_dir(directory: PathLike):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)


def check_extension(path: PathLike, extension: str) -> None:
    path = Path(path)
    extension = extension.lower()
    if extension[0] != '.':
        extension = '.' + extension
    runtime_check(path.suffix.lower() == extension, f'the extension of {path} is not {extension}', action='request')

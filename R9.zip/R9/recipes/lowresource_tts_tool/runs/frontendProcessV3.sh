#!/bin/bash

func() 
{
    echo "Usage:"
    echo "  frontendProcessV3.sh [-i TTS_work_dir] [-I merged_work_dir] [-v voice_setting] [-s pretrained_speaker_set] [-m pretrained_speaker_locale_set] [-a pretrained_locale_set] [-d langdata_dir] [-l locale] [-h locale_id] [-t dump_tool_dir]"
    echo "Description:"
    echo "  TTS_work_dir, the path of TTS data."
    echo "  merged_work_dir, the path of merged data."
    echo "  voice_setting, voice setting of locale."
    echo "  pretrained_speaker_set, the path of the unitts base model speaker set."
    echo "  pretrained_speaker_locale_set, the path of the unitts base model speaker and locale matching set."
    echo "  pretrained_locale_set, the path of the unitts base model locale set."
    echo "  langdata_dir, the path of langdata."
    echo "  locale, data locale."
    echo "  locale_id, data locale id."
    echo "  dump_tool_dir, the path of dump tool."
    exit -1
}

# Get paraments
while getopts 'i:I:v:s:m:a:d:l:h:t:' OPT;
do
    case $OPT in
        i) tts_work_dir=$OPTARG;;
        I) merged_work_dir=$OPTARG;;
        v) voice_setting=$OPTARG;;
        s) pretrained_speaker_set=$OPTARG;;
        m) pretrained_speaker_locale_set=$OPTARG;;
        a) pretrained_locale_set=$OPTARG;;
        d) langdata_dir=$OPTARG;;
        l) locale=$OPTARG;;
        h) locale_id=$OPTARG;;
        t) dump_tool_dir=$OPTARG;;
        ?) func;;
    esac
done

if [ ! -n "$tts_work_dir" ] && [ ! -n "$merged_work_dir" ]; then
    echo "Please input at least one work folder."
    exit 1
fi
if [ ! -n "$voice_setting" ]; then
    echo "Please input voice setting."
    exit 1
fi
if [ ! -n "$langdata_dir" ]; then
    echo "Please input langdata folder."
    exit 1
fi
if [ ! -n "$locale" ]; then
    echo "Please input data locale."
    exit 1
fi
if [ ! -n "$locale_id" ]; then
    echo "Please input data locale id."
    exit 1
fi
if [ ! -n "$dump_tool_dir" ]; then
    dump_tool_dir="/blob/code/drop/ttsdumptool"
fi

shell_folder=$(cd "$(dirname "$0")";pwd)
if [ -n "$merged_work_dir" ]; then
    # Dump phone
    cd $dump_tool_dir
    merged_script=$merged_work_dir/merged_text.txt
    merged_script_phone=$merged_work_dir/merged_text.phone.txt
    ./ttsdumptool -m DumpPhone -s $voice_setting -l -i $merged_script -o $merged_script_phone
    cd $shell_folder
    cd ../

    # Attach phonemes to metadata
    filename_prefix=${merged_work_dir##*/}_
    python data/ensemble_phone.py $merged_work_dir --filename_prefix $filename_prefix

    # Generate a speaker table
    merged_metadata_phone=$merged_work_dir/${filename_prefix}metadata_phone.csv 
    total_speaker_set=$langdata_dir/speakers.json
    total_speaker_locale_set=$langdata_dir/speaker_locale.json
    total_locale_set=$langdata_dir/locales.json
    command_line="python data/get_speaker_locale_set.py $merged_metadata_phone $total_speaker_set --offset 500 --output_speaker_locale_path $total_speaker_locale_set --output_locale_path $total_locale_set --locale $locale --locale_id $locale_id"
    if [ -n "$pretrained_speaker_set" ]; then
        command_line="$command_line --base_speaker_set_path $pretrained_speaker_set"
    fi
    if [ -n "$pretrained_speaker_locale_set" ]; then
        command_line="$command_line  --base_speaker_locale_set_path $pretrained_speaker_locale_set"
    fi
    if [ -n "$pretrained_locale_set" ]; then
        command_line="$command_line  --base_locale_set_path $pretrained_locale_set"
    fi
    $command_line

    # Convert the metadata
    python data/convert_metadata.py $merged_work_dir --locale_id $locale_id --locale_prefix $locale --speaker_set_path $total_speaker_set --filename_prefix $filename_prefix
    
    echo "***********Merged data process successful.**********"
fi
if [ -n "$tts_work_dir" ]; then
    # Dump phone
    cd $dump_tool_dir
    tts_script=$tts_work_dir/text.txt
    tts_script_phone=$tts_work_dir/text.phone.txt
    ./ttsdumptool -m DumpPhone -s $voice_setting -l -i $tts_script -o $tts_script_phone
    cd $shell_folder
    cd ../

    # Attach phonemes to metadata
    filename_prefix=${tts_work_dir##*/}_
    mv $tts_work_dir/metadata.csv $tts_work_dir/${filename_prefix}metadata.csv
    mv $tts_script_phone $tts_work_dir/${filename_prefix}text.phone.txt
    python data/ensemble_phone.py $tts_work_dir --filename_prefix $filename_prefix

   # Generate a speaker table
    if [ ! -n "$merged_work_dir" ]; then
        tts_metadata_phone=$tts_work_dir/${filename_prefix}metadata_phone.csv
        total_speaker_set=$langdata_dir/speakers.json
        total_speaker_locale_set=$langdata_dir/speaker_locale.json
        total_locale_set=$langdata_dir/locales.json
        command_line="python data/get_speaker_set.py $tts_metadata_phone $total_speaker_set --offset 500 --output_speaker_locale_path $total_speaker_locale_set --output_locale_path $total_locale_set --locale $locale --locale_id $locale_id"
        if [ -n "$pretrained_speaker_set" ]; then
            command_line="$command_line --base_speaker_set_path $pretrained_speaker_set"
        fi
        if [ -n "$pretrained_speaker_locale_set" ]; then
            command_line="$command_line  --base_speaker_locale_set_path $pretrained_speaker_set"
        fi
        if [ -n "$pretrained_locale_set" ]; then
            command_line="$command_line  --base_locale_set_path $pretrained_locale_set"
        fi
        $command_line
    fi

   # Convert the metadata
    python data/convert_metadata.py $tts_work_dir --locale_id $locale_id --locale_prefix $locale --speaker_set_path $total_speaker_set --filename_prefix $filename_prefix

    echo "***********TTS data process successful.**********"
fi

#!/bin/bash

func() 
{
    echo "Usage:"
    echo "  genPhoneSet.sh [-i work_dir] [-o output_dir] [-d langdata_dir] [-m mode] [-l locale] [-s pretrained_phone_set] [-S locale_phone_set] [-t phone_set_type]"
    echo "Description:"
    echo "  work_dir,the path of data."
    echo "  output_dir, the path of output."
    echo "  langdata_dir, the path of langdata."
    echo "  mode, the source format of data."
    echo "  locale, data locale."
    echo "  pretrained_phone_set, the path of the unitts base model phone set."
    echo "  locale_phone_set, the path of the locale customized phone set."
    echo "  phone_set_type, the phone set type, such as TFTTS or TorchTTS."
    exit -1
}

# Get paraments
while getopts 'i:o:d:m:l:s:S:t:' OPT;
do
    case $OPT in
        i) work_dir=$OPTARG;;
        o) output_dir=$OPTARG;;
        d) langdata_dir=$OPTARG;;
        m) mode=$OPTARG;;
        l) locale=$OPTARG;;
        s) pretrained_phone_set=$OPTARG;;
        S) locale_phone_set=$OPTARG;;
        t) phone_set_type=$OPTARG;;
        ?) func;;
    esac
done

if [ ! -n "$work_dir" ]; then
    echo "Please input work folder."
    exit 1
fi
if [ ! -n "$langdata_dir" ]; then
    echo "Please input langdata folder."
    exit 1
fi
if [ ! -n "$mode" ]; then
    echo "Please input data mode."
    exit 1
fi
if [ ! -n "$locale" ]; then
    echo "Please input data locale."
    exit 1
fi

cd ../
command_merge_data="python data/merge_data.py $work_dir metadata.csv text.txt"
metadata_path=$work_dir/merged_metadata.csv

if [ -n "$output_dir" ]; then
    command_merge_data="$command_merge_data --output_dir $output_dir"
    metadata_path=$output_dir/merged_metadata.csv
fi

command_get_char_set="python data/get_char_set.py $metadata_path --mode $mode --output_dir $langdata_dir --locale $locale"
if [ -n "$pretrained_phone_set" ]; then
    command_get_char_set="$command_get_char_set --unitts_phone_set_path $pretrained_phone_set"
fi
if [ -n "$locale_phone_set" ]; then
    command_get_char_set="$command_get_char_set --locale_phone_set_path $locale_phone_set"
fi
if [ -n "$phone_set_type" ]; then
    command_get_char_set="$command_get_char_set --phone_set_type $phone_set_type"
fi
$command_merge_data
$command_get_char_set

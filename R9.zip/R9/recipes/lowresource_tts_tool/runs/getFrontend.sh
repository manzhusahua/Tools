#!/bin/bash

func() 
{
    echo "Usage:"
    echo "  getFrontend.sh [-i TTS_work_dir] [-I SR_work_dir] [-m TTS_mode] [-M SR_mode] [-l locale] [-n voice_name] [-o output_dir] [-d langdata_dir] [-s pretrained_phone_set] [-S locale_phone_set] [-t phone_set_type]"
    echo "Description:"
    echo "  TTS_work_dir, the path of TTS data."
    echo "  SR_work_dir, the path of SR data."
    echo "  TTS_mode, the mode of TTS data."
    echo "  SR_mode, the mode of SR data."
    echo "  locale, data locale."
    echo "  voice_name, voice name of locale."
    echo "  output_dir, the path of output."
    echo "  langdata_dir, the path of langdata."
    echo "  pretrained_phone_set, the path of the unitts base model phone set."
    echo "  locale_phone_set, the path of the locale customized phone set."
    echo "  phone_set_type, the phone set type, such as TFTTS or TorchTTS."
    exit -1
}

# Get paraments
while getopts 'i:I:m:M:l:n:o:d:s:S:t:' OPT;
do
    case $OPT in
        i) tts_work_dir=$OPTARG;;
        I) sr_work_dir=$OPTARG;;
        m) tts_mode=$OPTARG;;
        M) sr_mode=$OPTARG;;
        l) locale=$OPTARG;;
        n) voice_name=$OPTARG;;
        o) output_dir=$OPTARG;;
        d) langdata_dir=$OPTARG;;
        s) pretrained_phone_set=$OPTARG;;
        S) locale_phone_set=$OPTARG;;
        t) phone_set_type=$OPTARG;;
        ?) func;;
    esac
done

echo "tts_work_dir:" $tts_work_dir
echo "sr_work_dir:" $sr_work_dir
echo "tts_mode:" $tts_mode
echo "sr_mode:" $sr_mode
echo "locale:" $locale
echo "voice_name:" $voice_name
echo "output_dir:" $output_dir
echo "langdata_dir:" $langdata_dir
echo "pretrained_phone_set:" $pretrained_phone_set
echo "locale_phone_set:" $locale_phone_set
echo "phone_set_type": $phone_set_type

if [ ! -n "$tts_work_dir" ] && [ ! -n "$sr_work_dir" ]; then
    echo "Please input at least one work folder."
    exit 1
fi
if [ -n "$sr_work_dir" ] && [ ! -n "$sr_mode" ]; then
    echo "Please input SR data mode."
    exit 1
fi
if [ ! -n "$langdata_dir" ]; then
    echo "Please input langdata folder."
    exit 1
fi
if [ ! -n "$locale" ]; then
    echo "Please input data locale."
    exit 1
fi

if [ -n "$tts_work_dir" ] && [ ! -n "$tts_mode" ]; then
    tts_mode="TTS"
fi
if [ -n "$tts_work_dir" ] && [ -n "$tts_mode" ]; then
    echo "Process TTS recordings."
    output_pre=$tts_work_dir/.. 
    tts_output=$output_pre/deal_data
    command_line="bash textWaveProcess.sh -i $tts_work_dir -o $tts_output -m $tts_mode -l $locale"
    if [ -n "$voice_name" ]; then
        command_line="$command_line -n $voice_name"
    fi
    $command_line
fi
if [ -n "$sr_work_dir" ] && [ -n "$sr_mode" ]; then
    echo "Process SR data."
    #output_pre=${sr_work_dir%/*}
    output_pre=$sr_work_dir/..
    sr_output=$output_pre/deal_data
    bash textWaveProcess.sh -i $sr_work_dir -o $sr_output -m $sr_mode -l $locale
fi
echo "***********Process data successful.**********"

if [ -n "$tts_work_dir" ] && [ -n "$sr_work_dir" ]; then
    output_pre=${tts_work_dir%/*}
    tts_output_temp=$output_pre/deal_data
    output_pre=${sr_work_dir%/*}
    sr_output_temp=$output_pre/deal_data
    if [ "$tts_output_temp" != "$sr_output_temp" ]; then
        echo "Please put TTS deal data and SR deal data in the same folder."
        exit 1
    fi
fi

echo "Generate phone or char set."
if [ -n "$tts_work_dir" ]; then
    total_input=$tts_work_dir/../deal_data
else
    total_input=$sr_work_dir/../deal_data
fi
command_line="bash genPhoneSet.sh -i $total_input -d $langdata_dir -m Metadata -l $locale"
if [ -n "$output_dir" ]; then
    command_line="$command_line -o $output_dir"
fi
if [ -n "$pretrained_phone_set" ]; then
    command_line="$command_line -s $pretrained_phone_set"
fi
if [ -n "$locale_phone_set" ]; then
    command_line="$command_line -S $locale_phone_set"
fi
if [ -n "$phone_set_type" ]; then
    command_line="$command_line -t $phone_set_type"
fi
$command_line
echo "***********Generate phone or char set successful.**********"


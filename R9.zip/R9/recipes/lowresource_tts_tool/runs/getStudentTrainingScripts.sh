#!/bin/bash

func()
{
    echo "Usage:"
    echo "  getStudentTrainingScripts.sh [-i input_file] [-o output_file] [-m mode] [-t dump_tool_dir] [-v voice_setting] [-p illegal_pattern] [-l locale] [-c min_phone_count] [-C max_phone_count]"
    echo "Description:"
    echo "  input_file, the path of input csv file."
    echo "  output_file, the path of output file."
    echo "  mode, the mode of data."
    echo "  dump_tool_dir, the path of dump tool."
    echo "  voice_setting, voice setting of locale."
    echo "  illegal pattern, the pattern that want to delete from the data."
    echo "  locale, data locale."
    echo "  min_phone_count, the min number of phone count."
    echo "  max_phone_count, the max number of phone count."
    exit -1
}

while getopts 'i:o:m:t:v:p:l:c:C:' OPT;
do
    case $OPT in
        i) input_file=$OPTARG;;
        o) output_file=$OPTARG;;
        m) mode=$OPTARG;;
        t) dump_tool_dir=$OPTARG;;
        v) voice_setting=$OPTARG;;
        p) illegal_pattern=$OPTARG;;
        l) locale=$OPTARG;;
        c) min_phone_count=$OPTARG;;
        C) max_phone_count=$OPTARG;;
        ?) func;;
    esac
done

if [ ! -n "$input_file" ]; then
    echo "Please input the input file."
    exit 1
fi
if [ ! -n "$output_file" ]; then
    echo "Please input the output file."
    exit 1
fi
if [ "$mode" == "PlainText" ]; then
    if [ ! -n "$dump_tool_dir" ]; then
        echo "Please input the directory of dump tool."
        exit 1
    fi
    if [ ! -n "$voice_setting" ]; then
        echo "Please input the path of voice setting file."
        exit 1
    fi
    if [ ! -n "$locale" ]; then
        echo "Please input the locale name, like et-ee."
        exit 1
    fi
fi

cd ../
command_line="python data/extract_student_text.py $input_file $output_file "

if [ -n "$min_phone_count" ]; then
    command_line="$command_line --min_phone_count $min_phone_count"
fi
if [ -n "$max_phone_count" ]; then
    command_line="$command_line --max_phone_count $max_phone_count"
fi
if [ -n "$mode" ]; then
    command_line="$command_line --mode $mode"
fi
if [ -n "$dump_tool_dir" ]; then
    command_line="$command_line --dump_tool_dir $dump_tool_dir"
fi
if [ -n "$voice_setting" ]; then
    command_line="$command_line --voice_setting $voice_setting"
fi
if [ -n "$illegal_pattern" ]; then
    command_line="$command_line --illegal_pattern $illegal_pattern"
fi
if [ -n "$locale" ]; then
    command_line="$command_line --locale $locale"
fi
echo "&command_line"

$command_line

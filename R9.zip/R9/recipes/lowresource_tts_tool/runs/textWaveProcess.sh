#!/bin/bash

func() 
{
    echo "Usage:"
    echo "  textWaveProcess.sh [-i work_dir] [-o output_dir] [-m mode] [-l locale] [-n voice_name] [-p illegal_pattern]"
    echo "Description:"
    echo "  work_dir, the path of data."
    echo "  output_dir, the path of output."
    echo "  mode, the mode of data."
    echo "  locale, data locale."
    echo "  voice_name, voice name of locale."
    echo "  illegal pattern, the pattern that want to delete from the data."
    exit -1
}

# Get paraments
while getopts 'i:o:m:l:n:p:' OPT;
do
    case $OPT in
        i) work_dir=$OPTARG;;
        o) output_dir=$OPTARG;;
        m) mode=$OPTARG;;
        l) locale=$OPTARG;;
        n) voice_name=$OPTARG;;
        p) illegal_pattern=$OPTARG;;
        ?) func;;
    esac
done

if [ ! -n "$work_dir" ]; then
    echo "Please input work folder."
    exit 1
fi
if [ ! -n "$output_dir" ]; then
    echo "Please input output folder."
    exit 1
fi
if [ ! -n "$mode" ]; then
    echo "Please input data mode."
    exit 1
fi
if [ ! -n "$locale" ]; then
    echo "Please input data locale."
    exit 1
fi

raw_scripts_dir=$work_dir/scripts
raw_waves_dir=$work_dir/waves
deal_dir=$output_dir/$mode

cd ../
#Extract text and delete illegal items.
command_line="python data/process_text.py $raw_scripts_dir $deal_dir --mode $mode --locale $locale"
if [ -n "$voice_name" ] && [ -n "$illegal_pattern" ]; then
    command_line="$command_line --tts_speaker_prefix $voice_name --illegal_pattern $illegal_pattern"
elif [ -n "$voice_name" ]; then
    command_line="$command_line --tts_speaker_prefix $voice_name"
elif [ -n "$illegal_pattern" ]; then
    command_line="$command_line --illegal_pattern $illegal_pattern"
fi
$command_line

#Extract waves
metadata_path=$deal_dir/metadata.csv
python data/process_wav.py $raw_waves_dir $deal_dir --metadata_path $metadata_path --mode $mode
#Check wave speed
if [ "$mode" != "TTS" ]; then
    python data/check_speaking_speed.py split $deal_dir
fi


import csv
import pandas as pd
import argparse


# Check if all vowels, all consonants or vowels and consonants
def check_vowel_consonant(string, vowel_list, consonant_list):
    vowel_letter_count = 0
    consonant_letter_count = 0
    for char in string:
        if char.lower() in vowel_list:
            vowel_letter_count += 1
        elif char.lower() in consonant_list:
            consonant_letter_count += 1
    if len(string) == vowel_letter_count:
        return "ALL_VOWEL"
    elif len(string) == consonant_letter_count:
        return "ALL_CONSONANT"
    else:
        return "VOWEL_CONSONANT"


# Check if capital letters of length 4 match the spelling word pattern
def check_spelling_pattern(string, vowel_list, consonant_list):
    spelling_word_pattern = ["VVVV", "CVVV", "VCVV", "CCVV", "VVCV", "CCCV", "VVVC", "VVCC", "VCCC", "CCCC"]
    word_pattern = ""
    for char in string:
        if char.lower() in vowel_list:
            word_pattern = word_pattern + "V"
        elif char.lower() in consonant_list:
            word_pattern = word_pattern + "C"
        else:
            word_pattern = word_pattern + "N"
    if word_pattern in spelling_word_pattern:
        return "SPELLABLE"
    else:
        return "UNSPELLABLE"


# Check is word is spellable
def check_word_spellable(word, vowel_list, consonant_list):
    if not word.isalpha():
        return "UNSPELLABLE"
    if word.isupper() and len(word) <= 3:
        return "SPELLABLE"
    elif word.isupper() and len(word) == 4:
        return check_spelling_pattern(word, vowel_list, consonant_list)
    else:
        if (check_vowel_consonant(word, vowel_list, consonant_list) == "ALL_VOWEL"
                or check_vowel_consonant(word, vowel_list, consonant_list) == "ALL_CONSONANT"):
            return "SPELLABLE"
        else:
            return "UNSPELLABLE"


# Count word number info and check if word is spellable
def get_word_spellable_number_info(input_metadata, vowel_list, consonant_list, text_column_name, output_spelling_file):
    data_df = pd.read_csv(input_metadata, sep='|', encoding='utf-8', quoting=csv.QUOTE_NONE, error_bad_lines=False)
    word_dictionary = {}
    for line in data_df[text_column_name]:
        words = line.strip().split()
        for word in words:
            if word in word_dictionary.keys():
                word_dictionary[word] = word_dictionary[word] + 1
            else:
                word_dictionary[word] = 1
    f_out = open(output_spelling_file, 'w', encoding='utf-8')
    for word, count in word_dictionary.items():
        if check_word_spellable(word, vowel_list, consonant_list) == "SPELLABLE":
            print("Spellable word: " + str(word) + "\tcount: " + str(count))
            f_out.write("Spellable word: " + str(word) + "\tcount: " + str(count) + "\n")
    f_out.close()


def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--input_metadata',
        dest='inputmetadata',
        required=True)
    parser.add_argument(
        '--input_vowel_list',
        dest='inputvowellist',
        nargs='+',
        required=True)
    parser.add_argument(
        '--input_consonant_list',
        dest='inputconsonantlist',
        nargs='+',
        required=True)
    parser.add_argument(
        '--output_spelling_file',
        dest='outputspellingfile',
        required=True)
    parser.add_argument(
        '--text_column_name',
        dest='textcolumnname',
        default='txt2')

    args, _ = parser.parse_known_args()
    return args


if __name__ == "__main__":
    args = get_arguments()
    metadata = args.inputmetadata
    input_vowel_list = args.inputvowellist
    vowel_list = list(map(lambda x: x.lower(), input_vowel_list))
    input_consonant_list = args.inputconsonantlist
    consonant_list = list(map(lambda x: x.lower(), input_consonant_list))
    spelling_file = args.outputspellingfile
    text_column_name = args.textcolumnname

    get_word_spellable_number_info(metadata, vowel_list, consonant_list, text_column_name, spelling_file)

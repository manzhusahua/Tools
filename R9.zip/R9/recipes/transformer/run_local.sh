#!/bin/bash

# We provide different pre-defined config files for experiment in torchtts/configs
# like base, pitch_contour to free you from having to specify all the parameters
# on command line, although you can still further modify them on cmd.

# +experiment=transformer/base overrides the default config groups with
# the config file in torchtts/configs/experiment/transformer/base.yaml
# and is equal to dataset=transformer model=transformer trainer=transformer_trainer
# for training:
python torchtts/bin/train.py \
  +experiment=transformer/base \
  dataset.raw_data=$(pwd)/raw_data \
  hydra.run.dir=outputs/transformer
# for inference:
python torchtts/bin/transformer/inference_transformer.py \
  model=transformer \
  hydra.run.dir=$(pwd)/outputs

#!/bin/bash

set -euo pipefail

cluster="v100-32gb-wus2-2"
vc="speech-itp-tts-prod"
num_gpu=8
preemptible="false"  # if ture, can access resources outside your quota
distributed="true"
dist_config="ddp"

project_name="torchtts-transformer"  # project name (e.g., tacotron/transformer)
exp_name="jessa_baseline"  # experimental name (e.g., Evan/Guy/Jessa)

# if the packages not installed in the docker, you can install them here or set it as ""
extra_env_setup_cmd=""

# +experiment=transformer/base overrides the default config groups with
# the config file in torchtts/configs/experiment/transformer/base.yaml
# and is equal to dataset=transformer model=transformer trainer=transformer_trainer
extra_params="+experiment=transformer/base"
extra_params=${extra_params}" dataset.data_dir=/datablob/yuanhyi/data/jessa_shard/shard_data/"
extra_params=${extra_params}" trainer/dist_config=${dist_config}"
extra_params=${extra_params}" trainer.dist_config.cluster_type=itp"

python third_party/Submitter/utils/amlt_submit.py \
    --service "amlk8s"  --cluster ${cluster} --virtual-cluster ${vc} \
    --gpu ${num_gpu} --distributed ${distributed} --preemptible ${preemptible} \
    --image-registry "azurecr.io" --image-repo "sramdevregistry" \
    --key-vault-name "exawatt-philly-ipgsp" --docker-username "tts-itp-user" \
    --image-name "torchtts:pytorch1.8.1-py38-cuda11.1" \
    --data-container-name "philly-ipgsp" --model-container-name "philly-ipgsp" \
    --extra-env-setup-cmd "${extra_env_setup_cmd}" --local-code-dir "$(pwd)" \
    --amlt-project ${project_name} --exp-name ${exp_name} \
    --run-cmd "python torchtts/bin/train.py" --extra-params "${extra_params}" \
    --tool-type "TorchTTS"

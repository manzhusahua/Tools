import argparse
import glob
import json
import os
import re
import shutil
import stat
import json
import re

class LazyDecoder(json.JSONDecoder):
    def decode(self, s, **kwargs):
        regex_replacements = [
            (re.compile(r'([^\\])\\([^\\])'), r'\1\\\\\2'),
            (re.compile(r',(\s*])'), r'\1'),
        ]
        for regex, replacement in regex_replacements:
            s = regex.sub(replacement, s)
        return super().decode(s, **kwargs)


def Process(args):
    settingfile = args.multispeakerdatasetting
    if not os.path.isfile(settingfile):
        raise Exception("setting %s does not exist!" % settingfile)
    else:
        with open(settingfile) as f:
            sf = f.read()
        setting =json.loads(sf.replace('\\', '\\\\'))
        speakers = setting['speakers']
    print("Total: " + str(len(speakers)) + " Voices")
    speaker_list = ["NlNLMaarten"]
    for i in range(0, len(speakers)):
        speaker = setting['speakers'][i]['speaker']
        #if not speaker in speaker_list:
        #    continue
        locale = speaker[0:2].lower() + "-" + speaker[2:4].lower()
        forcealign = setting['speakers'][i]['forcealign']
        xmlscripts = setting['speakers'][i]['xmlscripts']
        wave24k = setting['speakers'][i]['wave24knorm']
        keep_testset = True
        if "keep_testset" in setting['speakers'][i]:
            keep_testset = setting['speakers'][i]['keep_testset']
        commandline = "preprocess.sh " + forcealign + " " + xmlscripts + " " + wave24k + " " + locale + " " + speaker + " " + args.output
        output_metadata = os.path.join(args.output, locale, speaker, "stage_5", "metadata.csv")
        if not os.path.isfile(output_metadata):
            print(commandline)
            print("\t" + locale + " " + speaker + " Start")
            os.system(commandline)
            print("\t" + locale + " " + speaker + " Finished")
        else:
            print("\t" + locale + " " + speaker + " Skipped")

def main():
    def _str_to_bool(s):
        """Convert string to bool (in argparse context)."""
        if s.lower() not in ['true', 'false']:
            raise ValueError('Argument needs to be a '
                             'boolean, got {}'.format(s))
        return {'true': True, 'false': False}[s.lower()]
    parser = argparse.ArgumentParser()
    parser.add_argument("--multispeakerdatasetting", type=str, default=None, dest="multispeakerdatasetting")
    parser.add_argument("--skip_finished", type=_str_to_bool, default=True, dest="skip_finished")
    parser.add_argument("--output", type=str, default=None, dest="output")
    args= parser.parse_args()
    
    Process(args)

if __name__== "__main__":
    main()
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_zhcn.json  --output /d/Work/universal/universal_metadata/Tier1
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_Tier1_jajp.json --output /d/Work/universal/universal_metadata/Tier1
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_itit_xia.json --output /d/Work/universal/universal_metadata/Tier1
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_weiwei_48k.json --output /d/Work/universal/universal_metadata/Tier1
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_Tier1.json --output /d/Work/universal/universal_metadata/Tier1
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_Tier2.json --output /d/Work/universal/universal_metadata/Tier2
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_Tier3.json --output /d/Work/universal/universal_metadata/Tier3
#python MultipleSpeakerDataprocess.py --multispeakerdatasetting data_48k.json --output /d/Work/universal/universal_metadata/Tier1_48k

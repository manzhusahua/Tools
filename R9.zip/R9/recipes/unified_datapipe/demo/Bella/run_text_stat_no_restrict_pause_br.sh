#!/usr/bin/env bash

set -eou pipefail
unified_datapipe_dir=$(cd "$(dirname $0)/../.."; pwd)
torchtts_dir=$(cd "$unified_datapipe_dir/../.."; pwd)

# Please copy the Emina data to $voice_dir in advance
voice_dir=unified_datapipe/testdata
voice_config_dir=unified_datapipe/testdata/voiceconfig

preprocess_data=unified_datapipe/testdata/output/preprocess_data/Bella
raw_data=unified_datapipe/testdata/output/raw_data
shard_data=unified_datapipe/testdata/output/shard_data

# 1. Preprocess data
cd $unified_datapipe_dir
(set -x;
bash preprocess.sh \
    --alignment_dir $voice_dir/Alignment \
    --speech_dir $voice_dir/Wave24k16bNormalized \
    --xml_script_dir $voice_dir/XmlScript \
    --voice_name EnUSBella \
    --speech_length_tolerance_in_s 3 \
    --sil_tolerance_in_ms 100 \
    --extract_statistics true \
    --restrict_pause false \
    --use_br false \
    --out_dir $preprocess_data)

# 2. Raw data collection
[ -d $raw_data ] || mkdir -p $raw_data
[ -d $raw_data/Bella ] && rm -r $raw_data/Bella
mv $preprocess_data/final $raw_data/Bella
(set -x;
python steps/merge_voice.py \
    --root_dir $raw_data \
    --registry_output $raw_data/registry.csv)

# 3. Convert to TorchTTS shards for training
cp $voice_config_dir/* $raw_data/ # prepare the mapping files
raw_data=$(realpath $raw_data)
shard_data=$(realpath $shard_data)

cd $torchtts_dir
(set -x;
python torchtts/bin/train.py \
    +experiment=fastspeech/base \
    dataset=unitts \
    dataset.raw_data=$raw_data \
    dataset.data_dir=$shard_data \
    dataset.phone_set_path=$raw_data/phone_set.json \
    dataset.locale_set_path=$raw_data/locales.json \
    dataset.speaker_set_path=$raw_data/speakers.json \
    dataset.style_set_path=$raw_data/styles.json \
    dataset.add_locale_prefix=true \
    dataset.shard_size=500 \
    dataset.with_stat_data=true \
    dataset.with_text_data=true \
    trainer.max_steps=1)
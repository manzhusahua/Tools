#!/usr/bin/env bash

set -eou pipefail
unified_datapipe_dir=$(cd "$(dirname $0)/../.."; pwd)
torchtts_dir=$(cd "$unified_datapipe_dir/../.."; pwd)

# Please copy the Emina data to $voice_dir in advance
voice_dir=~/data/ttsdata/en-us/Voices/Emina
style_config_dir=demo/Emina/style_config
voice_config_dir=demo/Emina/voice_config
preprocess_data=outputs/demo/preprocess_data/Emina
raw_data=outputs/demo/raw_data
shard_data=outputs/demo/shard_data

# 1. Preprocess data
cd $unified_datapipe_dir
(set -x;
bash preprocess.sh \
    --alignment_dir $voice_dir/Alignment/ForcedAlignment.Phone.WithSR \
    --speech_dir $voice_dir/Speech/Wave16kNormalized \
    --xml_script_dir $voice_dir/XmlScripts \
    --style_mapping_config $style_config_dir/style_mapping.yaml \
    --style_sampling_config $style_config_dir/style_sampling.yaml \
    --voice_name EnUSEmina \
    --out_dir $preprocess_data)

# 2. Raw data collection
[ -d $raw_data] || mkdir -p $raw_data
[ -d $raw_data/Emina ] && rm -r $raw_data/Emina
mv $preprocess_data/final $raw_data/Emina
(set -x;
python steps/merge_voice.py \
    --root_dir $raw_data \
    --registry_output $raw_data/registry.csv)

# 3. Convert to TorchTTS shards for training
cp $voice_config_dir/* $raw_data/ # prepare the mapping files
raw_data=$(realpath $raw_data)
shard_data=$(realpath $shard_data)

cd $torchtts_dir
(set -x;
python torchtts/bin/train.py \
    +experiment=fastspeech/base \
    dataset=unitts \
    dataset.raw_data=$raw_data \
    dataset.data_dir=$shard_data \
    dataset.phone_set_path=$raw_data/phone_set.json \
    dataset.locale_set_path=$raw_data/locales.json \
    dataset.speaker_set_path=$raw_data/speakers.json \
    dataset.style_set_path=$raw_data/styles.json \
    dataset.add_locale_prefix=true \
    dataset.shard_size=500 \
    trainer.max_steps=1)

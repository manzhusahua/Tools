#!/usr/bin/env bash

set -eou pipefail
unified_datapipe_dir=$(cd "$(dirname $0)/.."; pwd)

# Make sure the run.sh scripts in demo/Brandy and demo/Emina have been run
cd $unified_datapipe_dir
(set -x;
python steps/calc_f0_auto_scale.py \
    --style_trans_config demo/style_trans_config_Emina-to-Brandy.json \
    --f0_scale_output outputs/demo/preprocess_data/f0_auto_scale_param.csv)

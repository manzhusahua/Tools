#!/usr/bin/env bash

set -eou pipefail

# Start and stop stages
start_stage=0
stop_stage=10

# Dry run and only list stages
dry_run=false

# Data collection root dir
root_dir=/path/to/root

. utils/parse_options.sh || exit 1

log() {
  local fname=${BASH_SOURCE[1]##*/}
  echo -e "$(date '+%Y-%m-%d %H:%M:%S') (${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]}) $*"
}

if [ $start_stage -le 0 ] && [ $stop_stage -ge 0 ]; then
  log "stage 0: Merge data"
  if [ $dry_run == false ]; then
    python steps/merge_voice.py --root_dir="$root_dir" --registry_output="$root_dir"/registry.csv
  fi
fi

import argparse
import csv
import logging
import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Dict

import numpy as np
from tqdm import tqdm

from torchtts.data.core.audio import load_wav
from torchtts.data.core.audio import save_wav
from utils import load_metadata
from utils import stringify_metadata


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--metadata",
        type=Path,
        help="Metadata file extracted from previous step",
    )
    parser.add_argument(
        "--frame_shift_in_ms",
        type=float,
        default=12.5,
        help="Frame shift in ms used to determine phone duration",
    )
    parser.add_argument(
        "--leading_sil_in_frame",
        type=int,
        default=4,
        help="Leading silence in frame after adjustment",
    )
    parser.add_argument(
        "--trailing_sil_in_frame",
        type=int,
        default=8,
        help="Trailing silence in frame after adjustment",
    )
    parser.add_argument(
        "--metadata_output",
        type=Path,
        default="metadata.csv",
        help="Update metadata output file",
    )
    parser.add_argument(
        "--speech_output",
        type=Path,
        default="speech",
        help="Output folder for adjusted speech",
    )
    parser.add_argument(
        "--max_workers",
        type=int,
        default=8,
        help="Max workers to use for feature extraction",
    )

    return parser.parse_args()


def main(args):
    os.makedirs(args.speech_output, exist_ok=True)

    futures = []
    with ProcessPoolExecutor(max_workers=args.max_workers) as executor:
        # Submit parallel feature extraction tasks
        for metadata_item in load_metadata(args.metadata):
            futures.append(executor.submit(adjust_silence, metadata_item,
                                           args.leading_sil_in_frame,
                                           args.trailing_sil_in_frame,
                                           args.frame_shift_in_ms,
                                           args.speech_output))
        # Collect parallel execution results
        with open(args.metadata_output, 'w', newline='', encoding='utf-8') as f:
            metadata_writer = csv.writer(f, delimiter='|')
            header_written = False
            # Collect updated metadata items
            for future in tqdm(futures):
                updated_metadata_item = future.result()
                # Stringify items in metadata (for example, list)
                metadata_item = stringify_metadata(updated_metadata_item)
                # Write csv header first if not written before
                if not header_written:
                    metadata_writer.writerow(metadata_item.keys())
                    header_written = True
                # Write real data
                metadata_writer.writerow(metadata_item.values())


def adjust_silence(metadata: Dict,
                   leading_sil_in_frame: int,
                   trailing_sil_in_frame: int,
                   frame_shift_in_ms: float,
                   speech_output: Path):
    speech, sr = load_wav(metadata['speech_path'])
    samples_per_frame = int(sr * frame_shift_in_ms / 1000)
    # Handle leading silence
    # TODO: Use seeding silence as padding values
    leading_sil_diff = (metadata['durations'][0] - leading_sil_in_frame) * samples_per_frame
    if leading_sil_diff > 0:
        speech = speech[leading_sil_diff:]
    else:
        speech = np.pad(speech, (-leading_sil_diff, 0), constant_values=0.0)
    metadata['durations'][0] = leading_sil_in_frame
    # Handle trailing silence
    trailing_sil_idx = len(metadata['phones']) - 1
    while trailing_sil_idx >= 0:
        phone = metadata['phones'][trailing_sil_idx]
        if phone == 'sil' or 'punc' in phone:
            break
        trailing_sil_idx -= 1
    trailing_sil_diff = (metadata['durations'][trailing_sil_idx] - trailing_sil_in_frame) * samples_per_frame
    if trailing_sil_diff > 0:
        speech = speech[:-trailing_sil_diff]
    else:
        speech = np.pad(speech, (0, -trailing_sil_diff), constant_values=0.0)
    metadata['durations'][trailing_sil_idx] = trailing_sil_in_frame
    # Save adjusted speech
    metadata['speech_length_in_s'] = len(speech) / sr
    metadata['speech_path'] = speech_output / f"{metadata['sid']}.wav"
    save_wav(metadata['speech_path'], data=speech, sample_rate=sr)
    return metadata


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

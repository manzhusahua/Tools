import argparse
import csv
import logging
from pathlib import Path
import json


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--style_trans_config",
        required=True,
        type=Path,
        help="styel tansfer configuration file",
    )
    parser.add_argument(
        "--energy_scale_output",
        type=Path,
        required=True,
        help="Output energy scale parameter csv file",
    )
    parser.add_argument(
        "--energy_preset_scale",
        type=Path,
        help="energy preset scale file",
    )
    parser.add_argument(
        "--f0_scale_param",
        type=Path,
        help="f0 scale file, used for energy compensation for f0 scale",
    )
    parser.add_argument(
        "--energy_compensation_for_f0_scale",
        type=Path,
        help="energy compensation for f0 scale",
    )

    return parser.parse_args()


def auto_scale_offset(args, target_spk_energy, src_style_energy_list,
                      energy_preset_scale, energy_compensation):
    with open(args.energy_scale_output, 'w', newline='', encoding='utf-8') as f:

        energy_scale_writer = csv.writer(f, delimiter=',', skipinitialspace=False)
        energy_scale_writer.writerow(['style', 'b'])
        energy_scale_param = {}
        for i in range(len(src_style_energy_list)):
            b = target_spk_energy["general"][3] - src_style_energy_list[i]["src_general"][3]

            style_name = src_style_energy_list[i]["style_name"]
            if energy_preset_scale:
                if style_name in energy_preset_scale.keys():
                    b += energy_preset_scale[style_name]

            if energy_compensation:
                if style_name in energy_compensation.keys():
                    b += energy_compensation[style_name]

            energy_scale_param[style_name] = b
            energy_scale_writer.writerow([style_name, f"{b:.3f}"])

    return energy_scale_param


# target_spk_energy: {"general": [energy_min, energy_max, energy_range, energy_mean],
#                     "overall": [energy_min, energy_max, energy_range, energy_mean]}
# src_style_energy_list: [
#   {
#       "style_name": "Angry",
#       "src_general": [energy_min, energy_max, energy_range, energy_mean]
#       "src_style": [energy_min, energy_max, energy_range, energy_mean]
#   }
#   ......
# ]
def load_energy_stat(style_trans_config_dict):
    target_spk_energy = {}
    with open(style_trans_config_dict["target_speaker"]["f0_stats"], 'r', newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter=',')
        for data in reader:
            if data["style"].lower() in ["general", "default"]:
                target_spk_energy["general"] = [float(data["energy_min"]), float(data["energy_max"]),
                                                float(data["energy_range"]), float(data["energy_mean"])]
            if data["style"] == "Overall":
                target_spk_energy["overall"] = [float(data["energy_min"]), float(data["energy_max"]),
                                                float(data["energy_range"]), float(data["energy_mean"])]

    src_style_energy_list = []
    for src_style in style_trans_config_dict["src_speaker"]:
        src_style_energy = {}
        src_style_energy["style_name"] = src_style["style_name"]
        with open(src_style["f0_stats"], 'r', newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f, delimiter=',')
            for data in reader:
                if data["style"].lower() in ["general", "default"]:
                    src_style_energy["src_general"] = [float(data["energy_min"]), float(data["energy_max"]),
                                                       float(data["energy_range"]), float(data["energy_mean"])]
                if data["style"] == src_style["style_name"]:
                    src_style_energy["src_style"] = [float(data["energy_min"]), float(data["energy_max"]),
                                                     float(data["energy_range"]), float(data["energy_mean"])]
        src_style_energy_list.append(src_style_energy)

    return target_spk_energy, src_style_energy_list


def load_energy_preset_scale(style_trans_config_dict, energy_preset_scale_file):
    energy_preset_scale = {}
    with open(energy_preset_scale_file, 'r', encoding='utf-8') as f:
        energy_preset_scale_dict = json.load(f)

    for src_style in style_trans_config_dict["src_speaker"]:
        style_name = src_style["style_name"]
        speaker_name = src_style["speaker_name"]
        if style_name in energy_preset_scale_dict.keys():
            if speaker_name in energy_preset_scale_dict[style_name].keys():
                energy_preset_scale[style_name] = energy_preset_scale_dict[style_name][speaker_name]

    return energy_preset_scale


def get_energy_compensation(style_trans_config_dict, f0_scale_param, energy_compensation_for_f0_scale):
    energy_compensation = {}
    f0_scale = {}
    with open(f0_scale_param, 'r', newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter=',')
        for data in reader:
            f0_scale[data["style"]] = float(data["k"])

    with open(energy_compensation_for_f0_scale, 'r', encoding='utf-8') as f:
        energy_comp_for_f0_scale = json.load(f)

    for src_style in style_trans_config_dict["src_speaker"]:
        style_name = src_style["style_name"]
        speaker_name = src_style["speaker_name"]
        if style_name in energy_comp_for_f0_scale.keys():
            if speaker_name in energy_comp_for_f0_scale[style_name].keys():
                [threshold, k] = [float(x) for x in energy_comp_for_f0_scale[style_name][speaker_name]]
                delta = (1 - f0_scale[style_name])
                delta = threshold if (1 - f0_scale[style_name]) > threshold else delta
                comp = delta * k
                energy_compensation[style_name] = comp

    return energy_compensation


def main(args):
    with open(args.style_trans_config, 'r', encoding='utf-8') as f:
        style_trans_config_dict = json.load(f)
    keys = style_trans_config_dict.keys()
    if "src_speaker" not in keys or "target_speaker" not in keys:
        Exception("styel tansfer configuration file format error: {}".format(args.style_trans_config))

    energy_preset_scale = {}
    if str(args.energy_preset_scale) != 'None':
        energy_preset_scale = load_energy_preset_scale(style_trans_config_dict, args.energy_preset_scale)

    energy_compensation = {}
    if str(args.f0_scale_param) != 'None' and str(args.energy_compensation_for_f0_scale) != 'None':
        energy_compensation = get_energy_compensation(style_trans_config_dict, args.f0_scale_param,
                                                      args.energy_compensation_for_f0_scale)

    target_spk_energy, src_style_energy_list = load_energy_stat(style_trans_config_dict)

    return auto_scale_offset(args, target_spk_energy, src_style_energy_list,
                             energy_preset_scale, energy_compensation)


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

import argparse
import csv
import logging
from pathlib import Path
import json


def str_to_bool(str):
    return True if str.lower() == 'true' else False


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--style_trans_config",
        required=True,
        type=Path,
        help="styel tansfer configuration file",
    )
    parser.add_argument(
        "--f0_scale_output",
        type=Path,
        required=True,
        help="Output f0 scale parameter csv file",
    )
    parser.add_argument(
        "--f0_min_pre_scale",
        type=float,
        default=1.1,
        help="f0 min pre-scale cosidering the modelling loss",
    )
    parser.add_argument(
        "--f0_lower_limit",
        type=float,
        default=70.0,
        help="f0 lower limit provided by source model",
    )
    parser.add_argument(
        "--f0_max_scale",
        type=Path,
        help="f0 max scale setting file, use the seeting in this file if it's provided, \
              otherwise, use ",
    )
    parser.add_argument(
        "--target_spk_f0Max_scale",
        type=float,
        default=1.1,
        help="f0 scale for target speaker's general style max f0 \
              considering the empowering by multi speaker src model",
    )
    parser.add_argument(
        "--srcStyle_f0Max_prescale",
        type=float,
        default=1.0,
        help="prescale for src style max f0 cosidering the modelling loss",
    )
    parser.add_argument(
        "--f0_preset_scale",
        type=Path,
        help="f0 preset scale file",
    )

    return parser.parse_args()


def auto_scale_offset(args, target_spk_f0, src_style_f0_list, f0_max_scale, f0_preset_scale=None):
    with open(args.f0_scale_output, 'w', newline='', encoding='utf-8') as f:
        f0_scale_writer = csv.writer(f, delimiter=',', skipinitialspace=False)
        f0_scale_writer.writerow(['style', 'k', 'b'])
        f0_scale_param = {}
        for i in range(len(src_style_f0_list)):
            delta1 = src_style_f0_list[i]["src_style"][3] - src_style_f0_list[i]["src_general"][3]
            delta3 = src_style_f0_list[i]["src_style"][3] - target_spk_f0["general"][3]

            # if diff(src_general, src_style) > 50Hz, it's strong intensity
            #   if (src_style-src_general) * (src_style-target_general) > 0: just keep src_style pitch
            #   else: need to maintain the polarity,
            # elseif diff(src_general, src_style) in range (30, 50)
            #   if (src_style-src_general) * (src_style-target_general) > 0: just keep src_style pitch
            #   else: need to maintain the polarity,
            # elseif diff(src_general, src_style) in range (0, 30), it's weak intensity
            #           just keep the src_style pitch
            #
            # for strong intensity style
            k1 = 1.0
            if (delta1 > 50.0 or delta1 < -50.0):
                if delta1 * delta3 > 0.0:
                    b1 = 0.0
                else:
                    if delta1 > 0.0:
                        b1 = -delta3 + 20.0
                    else:
                        b1 = -delta3 - 10.0
            # for middle intensity style
            elif (delta1 <= 50.0 and delta1 > 30.0) or (delta1 >= -50.0 and delta1 < -30.0):
                if delta1 * delta3 > 0.0:
                    b1 = 0.0
                else:
                    if delta1 > 0.0:
                        b1 = -delta3 + 10.0
                    else:
                        b1 = -delta3 - 10.0
            # for low intensity style
            else:
                b1 = 0.0

            if f0_preset_scale:
                style_name = src_style_f0_list[i]["style_name"]
                if style_name in f0_preset_scale.keys():
                    k1 = f0_preset_scale[style_name][0]
                    b1 += f0_preset_scale[style_name][1]

            # step 2: scale to upper limit if the scaled pitch maximum surpass the upper limit
            k2 = 1.0
            f0_upper_limit = target_spk_f0["overall"][1] * f0_max_scale[0]
            scaled_max = src_style_f0_list[i]["src_style"][1] * f0_max_scale[1] * k1 + b1
            if scaled_max > f0_upper_limit:
                k2 = f0_upper_limit / scaled_max

            # step 3: shif up if scaled pitch minimum lower than the bottom
            b3 = 0.0
            f0_lower_limit = target_spk_f0["overall"][0] if target_spk_f0["overall"][0] < args.f0_lower_limit \
                else args.f0_lower_limit
            scaled_min = k2 * (src_style_f0_list[i]["src_style"][0] * args.f0_min_pre_scale * k1 + b1)
            if scaled_min < f0_lower_limit:
                b3 = f0_lower_limit - scaled_min

            # step 4: combe together
            k = k2 * k1
            b = k2 * b1 + b3

            style_name = src_style_f0_list[i]["style_name"]
            f0_scale_param[style_name] = [k, b]
            f0_scale_writer.writerow([style_name, f"{k:.3f}", f"{b:.3f}"])

    return f0_scale_param


# target_spk_f0: {"general": [f0_min, f0_max, f0_range], "overall": [f0_min, f0_max, f0_range]}
# src_style_f0_list: [
#   {
#       "style_name": "Angry",
#       "src_general": [f0_min, f0_max, f0_range]
#       "src_style": [f0_min, f0_max, f0_range]
#   }
#   ......
# ]
def load_f0_min_max_range(style_trans_config_dict):
    target_spk_f0 = {}
    with open(style_trans_config_dict["target_speaker"]["f0_stats"], 'r', newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter=',')
        for data in reader:
            if data["style"].lower() in ["general", "default"]:
                target_spk_f0["general"] = [float(data["f0_min_mean"]), float(data["f0_max_mean"]),
                                            float(data["f0_range_mean"]), float(data["f0_mean_mean"])]
            if data["style"] == "Overall":
                target_spk_f0["overall"] = [float(data["f0_min_mean"]), float(data["f0_max_mean"]),
                                            float(data["f0_range_mean"]), float(data["f0_mean_mean"])]

    src_style_f0_list = []
    for src_style in style_trans_config_dict["src_speaker"]:
        src_style_f0 = {}
        src_style_f0["style_name"] = src_style["style_name"]
        with open(src_style["f0_stats"], 'r', newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f, delimiter=',')
            for data in reader:
                if data["style"].lower() in ["general", "default"]:
                    src_style_f0["src_general"] = [float(data["f0_min_mean"]), float(data["f0_max_mean"]),
                                                   float(data["f0_range_mean"]), float(data["f0_mean_mean"])]
                if data["style"] == src_style["style_name"]:
                    src_style_f0["src_style"] = [float(data["f0_min_mean"]), float(data["f0_max_mean"]),
                                                 float(data["f0_range_mean"]), float(data["f0_mean_mean"])]
        src_style_f0_list.append(src_style_f0)

    return target_spk_f0, src_style_f0_list


def load_f0_preset_scale(style_trans_config_dict, f0_preset_scale_file):
    f0_preset_scale = {}
    with open(f0_preset_scale_file, 'r', encoding='utf-8') as f:
        f0_preset_scale_dict = json.load(f)

    for src_style in style_trans_config_dict["src_speaker"]:
        style_name = src_style["style_name"]
        speaker_name = src_style["speaker_name"]
        if style_name in f0_preset_scale_dict.keys():
            if speaker_name in f0_preset_scale_dict[style_name].keys():
                f0_preset_scale[style_name] = f0_preset_scale_dict[style_name][speaker_name]

    return f0_preset_scale


def main(args):
    with open(args.style_trans_config, 'r', encoding='utf-8') as f:
        style_trans_config_dict = json.load(f)
    keys = style_trans_config_dict.keys()
    if "src_speaker" not in keys or "target_speaker" not in keys:
        Exception("styel tansfer configuration file format error: {}".format(args.style_trans_config))

    f0_preset_scale = {}
    if str(args.f0_preset_scale) != 'None':
        f0_preset_scale = load_f0_preset_scale(style_trans_config_dict, args.f0_preset_scale)

    f0_max_scale_factor = [args.target_spk_f0Max_scale, args.srcStyle_f0Max_prescale]
    if str(args.f0_max_scale) != 'None':
        with open(args.f0_max_scale, 'r', encoding='utf-8') as f:
            f0_max_scale = json.load(f)
            f0_max_scale_factor[0] = float(f0_max_scale['targetSpk_f0Max_scale'])
            f0_max_scale_factor[1] = float(f0_max_scale['srcStyle_f0Max_prescale'])

    target_spk_f0, src_style_f0_list = load_f0_min_max_range(style_trans_config_dict)

    return auto_scale_offset(args, target_spk_f0, src_style_f0_list, f0_max_scale_factor, f0_preset_scale)


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

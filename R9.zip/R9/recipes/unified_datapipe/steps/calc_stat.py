import argparse
import csv
import logging
from pathlib import Path
from typing import List

import numpy as np

from utils import load_metadata


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--metadata",
        type=Path,
        help="Metadata file extracted from previous step",
    )
    parser.add_argument(
        "--stat_out",
        type=Path,
        required=True,
        help="Output file for statistics about duration and f0 distribution",
    )
    parser.add_argument(
        "--min_f0",
        type=float,
        default=50,
        help="The lower bound of f0 used in statistics",
    )
    parser.add_argument(
        "--max_f0",
        type=float,
        default=800,
        help="The upper limit of f0 used in statistics",
    )

    return parser.parse_args()


def main(args):
    style_metadata_dict = split_style(args.metadata)
    metadata_root = args.metadata.parent
    with open(args.stat_out, 'w', newline='', encoding='utf-8') as f:
        stat_writer = csv.writer(f, delimiter=',', skipinitialspace=False)
        header_written = False
        style_metadata_all = []
        overall_min = float(args.max_f0)
        overall_max = float(args.min_f0)
        for style in sorted(style_metadata_dict):
            style_metadata = style_metadata_dict[style]
            style_metadata_all += style_metadata
            speaker = style_metadata[0]['speaker']
            locale = style_metadata[0]['locale']
            stat_item = {'locale': locale, 'speaker': speaker, 'style': style.lower()}
            stat_item.update(calc_stat(style_metadata, metadata_root, args.min_f0, args.max_f0))

            # For general style, use mean + 3*std for f0_max_mean, because this should be more robust
            if style.lower() in ["general", "default"]:
                f0_max_mean = float(stat_item["f0_mean_mean"]) + 3.0 * float(stat_item["f0_std_mean"])
                f0_range_mean = f0_max_mean - float(stat_item["f0_min_mean"])
                stat_item["f0_max_mean"] = f"{f0_max_mean:.3f}"
                stat_item["f0_range_mean"] = f"{f0_range_mean:.3f}"

            # overall min and max will be asigned as the minimum and maximum across all styles, respectively
            overall_min = stat_item['f0_min_mean'] if float(overall_min) > float(stat_item['f0_min_mean']) \
                else overall_min
            overall_max = stat_item['f0_max_mean'] if float(overall_max) < float(stat_item['f0_max_mean']) \
                else overall_max

            # Write csv header first if not written before
            if not header_written:
                stat_writer.writerow(stat_item.keys())
                header_written = True
            # Write real data
            stat_writer.writerow(stat_item.values())
        stat_item = {'locale': ' ', 'speaker': ' ', 'style': 'Overall'}
        stat_item.update(calc_stat(style_metadata_all, metadata_root, args.min_f0, args.max_f0))
        stat_item['f0_min_mean'] = overall_min
        stat_item['f0_max_mean'] = overall_max
        stat_item['f0_range_mean'] = f"{(float(overall_max) - float(overall_min)):.3f}"
        stat_writer.writerow(stat_item.values())


def split_style(metadata: Path):
    style_metadata_dict = {}
    for data in load_metadata(metadata):
        if data["style"] not in style_metadata_dict:
            style_metadata_dict[data["style"]] = []
        style_metadata_dict[data["style"]].append(data)
    return style_metadata_dict


def calc_stat(style_metadata: List, metadata_root: Path, min_f0: int, max_f0: int):
    total_duration = 0
    sf_file_list, uv_file_list, mel_file_list = [], [], []
    for metadata_item in style_metadata:
        total_duration += float(metadata_item['speech_length_in_s'])
        sf_file_list.append(metadata_root / 'sf' / metadata_item['sf_path'].name)
        uv_file_list.append(metadata_root / 'uv' / metadata_item['uv_path'].name)
        mel_file_list.append(metadata_root / 'mel' / metadata_item['mel_path'].name)
    (f0_mean_mean, f0_std_mean, f0_range_mean, f0_min_mean, f0_max_mean) = calc_f0_stat_v2(
        sf_file_list, uv_file_list, min_f0, max_f0)
    (energy_mean, energy_std, energy_range, energy_min, energy_max) = calc_energy_stat(
        mel_file_list, uv_file_list)
    stat_item = {"count": len(style_metadata),
                 "duration(h)": f"{total_duration / 3600:.3f}",
                 "f0_mean_mean": f"{f0_mean_mean:.3f}",
                 "f0_std_mean": f"{f0_std_mean:.3f}",
                 "f0_range_mean": f"{f0_range_mean:.3f}",
                 "f0_min_mean": f"{f0_min_mean:.3f}",
                 "f0_max_mean": f"{f0_max_mean:.3f}",
                 "energy_mean": f"{energy_mean:.3f}",
                 "energy_std": f"{energy_std:.3f}",
                 "energy_range": f"{energy_range:.3f}",
                 "energy_min": f"{energy_min:.3f}",
                 "energy_max": f"{energy_max:.3f}"}
    return stat_item


def calc_f0_stat(sf_file_list: List, uv_file_list: List, min_f0: int, max_f0: int):
    f0_means, f0_stds, f0_ranges, f0_min, f0_max = [], [], [], [], []
    for sf_file, uv_file in zip(sf_file_list, uv_file_list):
        f0 = np.load(sf_file)
        uv = np.load(uv_file)
        f0_nonzero = f0[np.where((uv == 1) & (f0 >= min_f0) & (f0 <= max_f0))]
        if len(f0_nonzero) == 0:
            logging.error(f'{sf_file} is empty or illegal!')
            continue
        f0_mean = np.mean(f0_nonzero)
        f0_std = np.std(f0_nonzero, ddof=1)
        f0_means.append(f0_mean)
        f0_stds.append(f0_std)
        f0_nonzero_sorted = np.sort(f0_nonzero)
        percentile_point1 = f0_nonzero_sorted[int(len(f0_nonzero_sorted) * 0.01)]
        percentile_point99 = f0_nonzero_sorted[int(len(f0_nonzero_sorted) * 0.99)]
        f0_range = percentile_point99 - percentile_point1
        f0_ranges.append(f0_range)
        f0_min.append(percentile_point1)
        f0_max.append(percentile_point99)
    f0_mean_mean = np.mean(f0_means)
    f0_std_mean = np.mean(f0_stds)
    f0_range_mean = np.mean(f0_ranges)
    f0_min_mean = np.mean(f0_min)
    f0_max_mean = np.mean(f0_max)
    return f0_mean_mean, f0_std_mean, f0_range_mean, f0_min_mean, f0_max_mean


def calc_f0_stat_v2(sf_file_list: List, uv_file_list: List, min_f0: int = 60, max_f0: int = 500):
    f0s = []
    for sf_file, uv_file in zip(sf_file_list, uv_file_list):
        f0 = np.load(sf_file)
        uv = np.load(uv_file)
        f0_nonzero = f0[np.where((uv == 1) & (f0 >= min_f0) & (f0 <= max_f0))]
        if len(f0_nonzero) == 0:
            logging.error(f'{sf_file} is empty or illegal!')
            continue
        for i in range(len(f0_nonzero)):
            f0s.append(f0_nonzero[i])
    f0_mean_mean = np.mean(f0s)
    f0_std_mean = np.std(f0s)
    f0s_sorted = np.sort(f0s)
    f0_min_mean = f0s_sorted[int(len(f0s_sorted) * 0.01)]
    f0_max_mean = f0s_sorted[int(len(f0s_sorted) * 0.99)]
    f0_range_mean = f0_max_mean - f0_min_mean

    return f0_mean_mean, f0_std_mean, f0_range_mean, f0_min_mean, f0_max_mean


def calc_energy_stat(mel_file_list: List, uv_file_list: List):
    energys = []
    for mel_file, uv_file in zip(mel_file_list, uv_file_list):
        mel = np.load(mel_file)
        uv = np.load(uv_file)
        uv = np.pad(uv, (0, len(mel) - len(uv))) if len(mel) > len(uv) else uv
        energy = np.mean(mel, 1)
        energy_nonsilence = energy[np.where(uv == 1)]
        for i in range(len(energy_nonsilence)):
            energys.append(energy_nonsilence[i])
    energy_mean = np.mean(energys)
    energy_std = np.std(energys)
    energys_sorted = np.sort(energys)
    energy_min = energys_sorted[int(len(energys_sorted) * 0.01)]
    energy_max = energys_sorted[int(len(energys_sorted) * 0.99)]
    energy_range = energy_max - energy_min

    return energy_mean, energy_std, energy_range, energy_min, energy_max


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

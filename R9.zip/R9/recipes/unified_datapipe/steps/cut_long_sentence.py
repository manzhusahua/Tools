import argparse
import csv
import logging
import math
import os
from copy import deepcopy
from pathlib import Path
from typing import Dict, List
import re

from torchtts.data.core.audio import load_wav
from torchtts.data.core.audio import save_wav
from utils import stringify_metadata
from utils import load_metadata


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--metadata",
        type=Path,
        help="Metadata file extracted from previous step",
    )
    parser.add_argument(
        "--frame_shift_in_ms",
        type=float,
        default=12.5,
        help="Frame shift in ms used to determine phone duration",
    )
    parser.add_argument(
        "--speech_length_tolerance_in_s",
        type=float,
        default=15,
        help="Sentence should be further cut if longer than tolerance",
    )
    parser.add_argument(
        "--sil_tolerance_in_ms",
        type=float,
        default=500,
        help="Silence tolerance determines cutting point of long sentence",
    )
    parser.add_argument(
        "--metadata_output",
        type=Path,
        default="metadata.csv",
        help="Metadata output file",
    )
    parser.add_argument(
        "--speech_output",
        type=Path,
        default="speech",
        help="Output folder for cut speech",
    )

    return parser.parse_args()


def main(args):
    with open(args.metadata_output, 'w', newline='', encoding='utf-8') as f:
        metadata_writer = csv.writer(f, delimiter='|')
        header_written = False
        for metadata_item in load_metadata(args.metadata):
            for cut_metadata_item in try_cut_long_sentence(metadata_item,
                                                           args.speech_length_tolerance_in_s,
                                                           args.sil_tolerance_in_ms,
                                                           args.frame_shift_in_ms,
                                                           args.speech_output):
                # Stringify items in metadata (for example, list)
                metadata_item = stringify_metadata(cut_metadata_item)
                # Write csv header first if not written before
                if not header_written:
                    metadata_writer.writerow(metadata_item.keys())
                    header_written = True
                # Write real data
                metadata_writer.writerow(metadata_item.values())


def try_cut_long_sentence(metadata: Dict,
                          speech_length_tolerance_in_s: float,
                          sil_tolerance_in_ms: float,
                          frame_shift_in_ms: float,
                          speech_output: Path):
    if metadata['speech_length_in_s'] <= speech_length_tolerance_in_s:
        metadata['sid'] = f"{metadata['sid']}_0"
        yield metadata
    else:
        sil_tolerance_in_frame = int(sil_tolerance_in_ms / frame_shift_in_ms)
        cutting_points = find_cutting_points(metadata['phones'],
                                             metadata['durations'],
                                             sil_tolerance_in_frame)
        if len(cutting_points) == 0:
            metadata['sid'] = f"{metadata['sid']}_0"
            yield metadata
        else:
            # Store newly cut speech output
            os.makedirs(speech_output, exist_ok=True)
            # Cut metadata and corresponding speech to short clips
            segment_start = 0
            prev_cutting_point = prev_left_sil = 0
            prev_word_cutting_point = 0
            for i, cutting_point in enumerate(cutting_points + [len(metadata['phones']) - 1]):
                # Skip br and punc after sil if possible
                next_start = cutting_point + 1
                while (next_start < len(metadata['phones'])
                       and ('br' in metadata['phones'][next_start] or 'punc' in metadata['phones'][next_start])):
                    next_start += 1

                cut_phones = metadata['phones'][prev_cutting_point: next_start]
                cut_durations = metadata['durations'][prev_cutting_point: next_start]

                # Handle trailing silence
                if not cut_phones[-1].startswith('</s>'):
                    cut_phones.append('</s>')
                    cut_durations.append(0)
                # Half the silence
                sil_duration = metadata['durations'][cutting_point]
                cut_durations[cutting_point - prev_cutting_point] = math.floor(sil_duration / 2)

                # Handle leading silence
                if not cut_phones[0].startswith('<s>'):
                    bos_phones = ['<s>']
                    bos_durations = [prev_left_sil]
                    if not cut_phones[0].startswith('br0'):
                        bos_phones.append('br0')
                        bos_durations.append(0)
                    cut_phones = bos_phones + cut_phones
                    cut_durations = bos_durations + cut_durations

                cut_words_num = len([w_p for w_p in re.split(r"br\d", " ".join(cut_phones)) if w_p.strip() not
                                     in ["<s>", "</s>", "sil"]])
                cut_words = metadata["text"].split(' ')[prev_word_cutting_point:prev_word_cutting_point + cut_words_num]
                prev_word_cutting_point += cut_words_num
                prev_left_sil = math.ceil(sil_duration / 2)
                prev_cutting_point = next_start

                # Assemble new cut metadata
                cut_metadata = deepcopy(metadata)
                cut_metadata['sid'] = f"{metadata['sid']}_{i}"
                cut_metadata['phones'] = cut_phones
                cut_metadata['durations'] = cut_durations
                cut_metadata['text'] = " ".join(cut_words)
                # Process real wave data clipping
                segment_frames = sum(cut_durations)
                speech, sr = load_wav(cut_metadata['speech_path'],
                                      offset=segment_start * frame_shift_in_ms / 1000,
                                      duration=segment_frames * frame_shift_in_ms / 1000)
                cut_metadata['speech_length_in_s'] = len(speech) / sr
                cut_metadata['speech_path'] = speech_output / f"{cut_metadata['sid']}.wav"
                save_wav(filename=cut_metadata['speech_path'], data=speech, sample_rate=sr)
                segment_start += segment_frames
                yield cut_metadata


def find_cutting_points(phones: List[str], durations: List[int], sil_tolerance_in_frame: int):
    assert len(phones) == len(durations)
    cutting_points = []
    for i in range(len(phones)):
        if phones[i] == 'sil' and durations[i] > sil_tolerance_in_frame:
            cutting_points.append(i)
    return cutting_points


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

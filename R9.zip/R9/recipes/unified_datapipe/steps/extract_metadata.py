import argparse
import csv
import logging
import os
import re
import string
import yaml
import xml.etree.ElementTree as ET  # noqa: N817
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Union, Optional, Tuple, Iterator
from glob import glob
from torchtts.data.core import audio
from torchtts.data.core.audio import load_wav
from utils import stringify_metadata
import get_f0
import numpy as np


def get_args():
    def non_empty_string(s):
        if not s:
            raise ValueError("Must not be empty string")
        return s

    def _str_to_bool(s):
        """Convert string to bool (in argparse context)."""
        if s.lower() not in ['true', 'false']:
            raise ValueError('Argument needs to be a '
                             'boolean, got {}'.format(s))
        return {'true': True, 'false': False}[s.lower()]

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--alignment_dir",
        type=Path,
        required=True,
        help="Directory of alignments",
    )
    parser.add_argument(
        "--speech_dir",
        type=Path,
        required=True,
        help="Directory of speech",
    )
    parser.add_argument(
        "--xml_script_dir",
        type=Path,
        required=True,
        help="Directory of XML scripts",
    )
    parser.add_argument(
        "--voice_name",
        type=non_empty_string,
        required=True,
        help="The name of the voice",
    )
    parser.add_argument(
        "--voice_style",
        type=non_empty_string,
        required=True,
        help="The style of the voice",
    )
    parser.add_argument(
        "--style_mapping_config",
        type=Path,
        default="None",
        help="The style mapping config of the voice",
    )
    parser.add_argument(
        "--metadata_output",
        type=Path,
        default="metadata.csv",
        help="Metadata output file",
    )
    parser.add_argument(
        "--frame_shift_in_ms",
        type=float,
        default=12.5,
        help="Frame shift in ms used to determine phone duration",
    )
    parser.add_argument(
        "--br1_in_frame",
        type=int,
        default=1,
        help="Upper bound of frames reserved for br1",
    )
    parser.add_argument(
        "--br2_in_frame",
        type=int,
        default=4,
        help="Upper bound of frames reserved for br2",
    )
    parser.add_argument(
        "--br3_in_frame",
        type=int,
        default=12,
        help="Upper bound of frames reserved for br3",
    )
    parser.add_argument(
        "--punc_in_frame",
        type=int,
        default=20,
        help="Upper bound of frames reserved for punc",
    )

    parser.add_argument(
        "--question_tone",
        type=_str_to_bool,
        default=True,
        help="Support question falling tone with punc?_l",
    )

    parser.add_argument(
        "--question_tone_from_f0",
        type=_str_to_bool,
        default=True,
        help="Support get question tone from wave pitch",
    )

    parser.add_argument(
        "--question_tone_duration",
        type=float,
        default=10.0,
        help="question tone duration",
    )

    parser.add_argument(
        "--question_tone_min_variation",
        type=float,
        default=5.0,
        help="question tone min variation",
    )

    parser.add_argument(
        "--question_tone_frame_time",
        type=float,
        default=0.005,
        help="question tone frame time",
    )

    parser.add_argument(
        "--question_tone_min_phone_num",
        type=int,
        default=3,
        help="question tone min phone number",
    )

    parser.add_argument(
        "--question_tone_min_half_distance",
        type=int,
        default=5,
        help="question tone min half distance",
    )
    return parser.parse_args()


BREAK_LIST = ['br0', 'br1', 'br2', 'br3', 'br4']
TONE_LIST = ['1', '2', '3', '4']
T_TONE_LIST = ['t1', 't2', 't3', 't4', 't5', 't6']


class StyleMapping:
    def __init__(self, voice_style="General", style_mapping_config: Path = "None"):
        self.voice_style = voice_style
        self.style_mapping_config = style_mapping_config
        self.build_style_mapping()

    def build_style_mapping(self):
        style_mapping_dict = {}
        if self.style_mapping_config.is_file():
            with open(self.style_mapping_config) as f:
                mapping_config = yaml.load(f, Loader=yaml.FullLoader)
                logging.info(f"mapping_config = {mapping_config}")
            # using limits
            for style in mapping_config.get('limits', {}):
                for sid_limits in mapping_config['limits'][style]:
                    start_id, end_id = sid_limits.split('-')
                    assert len(start_id.strip()) == len(end_id.strip())
                    sid_length = len(start_id.strip())
                    for sid in range(int(start_id), int(end_id) + 1):
                        style_mapping_dict[f"{sid:0{sid_length}}"] = style
            # using single
            for style in mapping_config.get('single', {}):
                for sid in mapping_config['single'][style]:
                    assert isinstance(sid, str)
                    style_mapping_dict[sid] = style
        # logging.debug(f"style_mapping_dict = {style_mapping_dict}")
        self.style_mapping_dict = style_mapping_dict

    def get_style(self, sid: str) -> str:
        if self.style_mapping_dict and sid not in self.style_mapping_dict:
            logging.warning(f"sid={sid} not in {self.style_mapping_config}, using {self.voice_style} style")
        return self.style_mapping_dict.get(sid, self.voice_style)


def main(args):
    with open(args.metadata_output, 'w', newline='', encoding='utf-8') as f:
        metadata_writer = csv.writer(f, delimiter='|')
        header_written = False
        for metadata_item in extract_metadata(alignment_dir=args.alignment_dir,
                                              speech_dir=args.speech_dir,
                                              xml_script_dir=args.xml_script_dir,
                                              voice_name=args.voice_name,
                                              voice_style=args.voice_style,
                                              style_mapping_config=args.style_mapping_config,
                                              frame_shift_in_ms=args.frame_shift_in_ms,
                                              br1_in_frame=args.br1_in_frame,
                                              br2_in_frame=args.br2_in_frame,
                                              br3_in_frame=args.br3_in_frame,
                                              punc_in_frame=args.punc_in_frame,
                                              question_tone=args.question_tone,
                                              question_tone_from_f0=args.question_tone_from_f0,
                                              question_tone_duration=args.question_tone_duration,
                                              question_tone_min_variation=args.question_tone_min_variation,
                                              question_tone_frame_time=args.question_tone_frame_time,
                                              question_tone_min_phone_num=args.question_tone_min_phone_num,
                                              question_tone_min_half_distance=args.question_tone_min_half_distance):
            # Stringify items in metadata (for example, list)
            metadata_item = stringify_metadata(metadata_item)
            # Write csv header first if not written before
            if not header_written:
                metadata_writer.writerow(metadata_item.keys())
                header_written = True
            # Write real data
            metadata_writer.writerow(metadata_item.values())


def extract_metadata(alignment_dir: Path,
                     speech_dir: Path,
                     xml_script_dir: Path,
                     voice_name: str,
                     voice_style: str,
                     style_mapping_config: Path,
                     frame_shift_in_ms: float,
                     br1_in_frame: int,
                     br2_in_frame: int,
                     br3_in_frame: int,
                     punc_in_frame: int,
                     question_tone: bool,
                     question_tone_from_f0: bool,
                     question_tone_duration: float,
                     question_tone_min_variation: float,
                     question_tone_frame_time: float,
                     question_tone_min_phone_num: int,
                     question_tone_min_half_distance: int) -> Iterator[Dict]:
    """Extract metadata from alignment, speech and xml script.

    Args:
        alignment_dir: Directory of alignments which contain lines of phone and timestamp.
        speech_dir: Directory of speech waveforms corresponding to the alignments.
        xml_script_dir: Directory of xml scripts which contain text information.
        voice_name: The name of voice to be added to metadata
        voice_style: The style of voice to be added to metadata
        style_mapping_config: Yaml file which contains style information for each sentence
        frame_shift_in_ms: Frame shift in millisecond used to determine frame numbers.
        br1_in_frame: Upper bound of frame number of br1.
        br2_in_frame: Upper bound of frame number of br2.
        br3_in_frame: Upper bound of frame number of br3.
        punc_in_frame: Upper bound of frame number of punc.
        question_tone： Support question falling tone with punc?_l
        question_tone_from_f0： Support get question tone from wave pitch

    Returns:
        Generator of metadata items (sid, phones, durations, speech).
    """
    style_map = StyleMapping(voice_style, style_mapping_config)
    # get all wave files {wave_id: filename}
    wave_files = {}
    for f in glob(os.path.join(speech_dir, "**", "*.wav"), recursive=True):
        wave_id = os.path.basename(f)[:-4]
        if wave_id not in wave_files:
            wave_files[wave_id] = Path(f)
        else:
            print("warnning dumplicate wave id{}".format(wave_id))
    print("len(wave_files)", len(wave_files))

    # get all aligment files
    align_files = {}  # {align_id: filename}
    suffix = "*.txt"
    for f in glob(os.path.join(alignment_dir, "**", suffix), recursive=True):
        align_id = os.path.basename(f)[:-4]
        if align_id not in align_files:
            align_files[align_id] = Path(f)
        else:
            print("warnning dumplicate align id{}".format(align_id))
    print("len(align_files)", len(align_files))
    for xml_filename in xml_script_dir.glob("*.xml"):
        xml_info = extract_info_from_xml(xml_filename)
        for sent_info in xml_info:
            try:
                # Corresponding alignment
                alignment_filename = align_files[sent_info['sid']]
                if not alignment_filename.exists():
                    logging.debug(f"{alignment_filename} doesn't exist, skip")
                    continue
                alignment = read_alignment(alignment_filename)
                # Corresponding speech audio
                speech_filename = wave_files[sent_info['sid']]
                if not speech_filename.exists():
                    logging.debug(f"{speech_filename} doesn't exist, skip")
                    continue
                speech_length = audio.get_audio_length(speech_filename)
                # Convert alignment timestamps to frame numbers
                durations = _alignment_to_frames(alignment, speech_length, frame_shift_in_ms)
                # Extract phone sequence with break from sent_info
                phones = _extract_phone_seq(sent_info,
                                            speech_filename,
                                            alignment_filename,
                                            question_tone,
                                            question_tone_from_f0,
                                            question_tone_duration,
                                            question_tone_min_variation,
                                            question_tone_frame_time,
                                            question_tone_min_phone_num,
                                            question_tone_min_half_distance)
                # Fill duration according to duration and break level
                phones, durations = _fill_phone_seq_with_duration(phones, durations,
                                                                  br1_in_frame, br2_in_frame, br3_in_frame,
                                                                  punc_in_frame)
                yield {
                    'sid': sent_info['sid'],
                    'locale': sent_info['locale'],
                    'speaker': voice_name,
                    'style': style_map.get_style(sent_info['sid']),
                    'text': sent_info['text'],
                    'phones': phones,
                    'durations': durations,
                    'speech_length_in_s': speech_length,
                    'speech_path': speech_filename,
                }
            except Exception as ex:
                logging.debug(f"Skip {sent_info['sid']} since unexpected error encountered: {ex}")
                continue


def extract_info_from_xml(xml_filename: Path) -> Iterator[Dict]:
    """Extract needed structured info from xml script

    Args:
        xml_filename: Filename of xml script.

    Returns:
        Generator of dict contains xml info (sid, text, words).
    """
    # Don't eat namespace here
    ns = {'tts': 'http://schemas.microsoft.com/tts'}
    tree = ET.parse(xml_filename)
    locale = tree.getroot().attrib['language'].lower()
    for si_node in tree.getroot():
        sid = si_node.get("id")
        if sid is None:
            continue
        words = []
        for w_node in si_node.findall('./tts:sent/tts:words/tts:w', ns):
            # Extract word value, phones, type and break info
            words.append({
                'value': w_node.get('v'),
                'phones': w_node.get('p'),
                'type': w_node.get('type'),
                'break': w_node.get('br'),
                'tobifbt': w_node.get('tobifbt')
            })

        text = " ".join([word['value'] for word in words]).strip()
        yield {'sid': sid, 'locale': locale, 'text': text, 'words': words}


# TODO: Support MGE alignment
def read_alignment(alignment_filename: Path) -> List[Tuple]:
    """Read alignments from alignment file.

    Args:
        alignment_filename: Filename of alignment file

    Returns:
        List of tuple (timestamp, phones).
    """
    alignment = []
    with open(alignment_filename, "r", encoding="utf-8") as f_in:
        for line in f_in:
            parts = line.strip('\r\n').split(' ')
            # Convert to htk format time alignments (100ns)
            alignment.append((_s_to_100ns(float(parts[0])), parts[1]))
    return alignment


def _s_to_100ns(second: float) -> int:
    """Convert second to 100 nanosecond (htk format)

    Args:
        second: Number of seconds.

    Returns:
        Number of nanoseconds.
    """
    return int(Decimal(second) * Decimal(1e7))


def _ms_to_100ns(millisecond: float) -> int:
    """Convert millisecond to 100 nanosecond (htk format)

    Args:
        millisecond: Number of milliseconds.

    Returns:
        Number of nanoseconds.
    """
    return int(Decimal(millisecond) * Decimal(1e4))


def _alignment_to_frames(alignment: List[Tuple[int, str]],
                         audio_length: float,
                         frame_shift_in_ms: float) -> List[Tuple[str, float]]:
    """Convert timestamp of alignments to frame numbers

    Args:
        alignment: Alignment, list of (timestamp, phone) tuple.
        audio_length: Audio length in second used to determine the duration of last phone.
        frame_shift_in_ms: Frame shift in millisecond used to determine the number of frames.

    Returns:
        List of tuple (phones, durations in frame)
    """
    # Calculate actual duration from alignment
    durations, phones = [], []
    prev_timestamp = 0.
    for i, (timestamp, phone) in enumerate(alignment):
        phones.append(phone)
        if i != 0:
            durations.append(timestamp - prev_timestamp)
        prev_timestamp = timestamp
    durations.append(_s_to_100ns(audio_length) - prev_timestamp)
    # Duration -> frames
    durations = [dur / _ms_to_100ns(frame_shift_in_ms) for dur in durations]
    # Return a list of (phone, duration) tuple
    return list(zip(phones, durations))


def _convert_to_phones(word_phones_str: str) -> List[str]:
    """Convert <p> tag in XML to sequence of phone.

    Args:
        word_phones_str: word phone string from <p> tag in XML.

    Returns:
       List of phones.
    """
    word_phones = []
    for syllable in word_phones_str.split(' - '):
        for phone in syllable.split(' . '):
            phone = phone.split()
            # Special tone as separate phone
            if phone[-1] in T_TONE_LIST:
                word_phones.extend(phone)
            # Tone not as separate phone
            elif phone[-1] in TONE_LIST:
                word_phones.append(''.join(phone))
            else:
                word_phones.extend(phone)
        word_phones.append('-')

    return word_phones[:-1]


def compare_half_sum(array, min_distance=5):
    length = len(array)
    mid = int(length / 2)
    mid_next = mid if length % 2 == 0 else mid + 1
    average_dist = (np.sum(array[mid_next:length]) - np.sum(array[:mid])) / mid
    if average_dist > min_distance:
        return True
    else:
        return False


def get_boundary_tone(f0_sample, question_tone_duration, question_tone_min_variation, question_tone_min_half_distance):
    if f0_sample is None:
        return "L-L%"
    boundary_tone = []
    length = f0_sample.shape[0]
    if length < 3:
        return "L-L%"
    pre_index = 0
    for i in range(1, length - 1):
        if f0_sample[i - 1] == f0_sample[i]:
            continue
        if f0_sample[i] > f0_sample[i - 1] and f0_sample[i] > f0_sample[i + 1]:
            if (i - pre_index + 1 >= question_tone_duration
                    and abs(f0_sample[i] - f0_sample[pre_index]) >= question_tone_min_variation):
                boundary_tone.append(["H", i - pre_index + 1])
            pre_index = i + 1
        elif f0_sample[i] < f0_sample[i - 1] and f0_sample[i] < f0_sample[i + 1]:
            if (i - pre_index + 1 >= question_tone_duration
                    and abs(f0_sample[i] - f0_sample[pre_index]) >= question_tone_min_variation):
                boundary_tone.append(["L", i - pre_index + 1])
            pre_index = i + 1

    if len(boundary_tone) == 0:
        if (compare_half_sum(f0_sample, min_distance=question_tone_min_half_distance)
                and max(f0_sample) - min(f0_sample) >= question_tone_min_variation):
            return "H-H%"
        else:
            return "L-L%"

    if (length - pre_index + 1 >= question_tone_duration
            and abs(f0_sample[length - 1] - f0_sample[pre_index]) >= question_tone_min_variation):
        if f0_sample[pre_index] < f0_sample[length - 1]:
            boundary_tone.append(["H", length - pre_index + 1])
        else:
            boundary_tone.append(["L", length - pre_index + 1])
    final_boundary_tone = ''
    longest_duration = 0
    for tone, cur_duration in boundary_tone:
        if cur_duration > longest_duration:
            longest_duration = cur_duration
            final_boundary_tone = tone

    return final_boundary_tone + "-" + final_boundary_tone + "%"


def get_last_syllable(sentence_words, at_least):

    words = []
    for sentence_word in sentence_words:
        words.append((sentence_word["type"], sentence_word["phones"]))

    for i in range(len(words) - 1, -1, -1):
        (word_type, words_syllables) = words[i]
        if word_type == "punc" or words_syllables is None:
            continue
        else:
            last_syllable = words_syllables.split("-")[-1]
            phones_split = re.split(r'[\.\-]', words_syllables)
            break

    phones_split = [ele.strip().split(' ')[0] for ele in phones_split]

    last_syllable = last_syllable.strip().split('.')

    for i, _syl in enumerate(last_syllable):
        last_syllable[i] = last_syllable[i].strip().split(" ")[0]

    if len(last_syllable) < at_least:
        last_syllable = phones_split[-at_least:]

    return last_syllable


def get_timestamp_syllable(file_name, syllable):
    with open(file_name, "r") as f:
        time_stamps_list = []
        lines = f.readlines()
        j = len(syllable) - 1
        for i in range(len(lines) - 1, -1, -1):
            phone = lines[i].strip('\n').split(' ')
            if "sil" == phone[1] or "SIL" == phone[1]:
                continue
            elif syllable[j] == phone[1]:
                j -= 1
                time_stamps_list.append(phone[0])
            if j == -1:
                time_stamps_list.reverse()
                time_stamps_list.append(lines[-1].strip('\n').split(' ')[0])
                break
        if len(time_stamps_list) == 0:
            return None
        return time_stamps_list


def longest_nonzero_substring(f0_list):
    longest_sublist = []
    current_sublist = []
    for f0 in f0_list:
        if f0 != 0.0:
            current_sublist.append(f0)
        else:
            if len(current_sublist) > len(longest_sublist):
                longest_sublist = current_sublist
                current_sublist = []
            else:
                current_sublist = []
    if len(current_sublist) > len(longest_sublist):
        longest_sublist = current_sublist
        current_sublist = []
    else:
        current_sublist = []
    return longest_sublist


def get_f0_sample(wave_f0_input, question_tone_frame_time, time_stamps=None):
    wave_f0 = list(wave_f0_input)
    f0_sample = []
    if time_stamps is None:
        return None

    effect_partitions = []
    current_partition = []

    # get sub partitions which zero value smaller than half
    for i in range(len(time_stamps) - 1):
        partition_start_index = int(float(time_stamps[i]) / question_tone_frame_time) - 1
        partition_end_index = int(float(time_stamps[i + 1]) / question_tone_frame_time) - 1
        partition_f0 = wave_f0[partition_start_index: partition_end_index]

        partition_length = len(partition_f0)
        zero_f0_count = partition_f0.count(0.0)

        if zero_f0_count > partition_length * 0.5:
            if len(current_partition) > 0:
                effect_partitions.append(current_partition)
                current_partition = []
            continue
        else:
            current_partition += partition_f0

    if len(current_partition) > 0:
        effect_partitions.append(current_partition)
        current_partition = []

    # if no effective partition return []
    if len(effect_partitions) == 0:
        return None

    # in left partitions, find longest non-zero sub string
    global_longest_sublist = []
    for effect_partition in effect_partitions:
        longest_sublist = longest_nonzero_substring(effect_partition)
        if len(longest_sublist) > len(global_longest_sublist):
            global_longest_sublist = longest_sublist
            longest_sublist = []
        else:
            longest_sublist = []
    f0_sample = np.asarray(global_longest_sublist, dtype=float)
    return f0_sample


def _extract_phone_seq(sent_info: Dict,
                       speech_filename: str,
                       alignment_file: str,
                       question_tone: bool,
                       question_tone_from_f0: bool,
                       question_tone_duration: float,
                       question_tone_min_variation: float,
                       question_tone_frame_time: float,
                       question_tone_min_phone_num: int,
                       question_tone_min_half_distance: int) -> List[str]:
    """Extract phone sequence with break from information extracted from XML script.

    Args:
        sent_info: Dict which contains information of one sentence.

    Returns:
        Phone sequence with break info.
    """
    phones = []
    for word in sent_info['words']:
        # Filter and split to get word phone sequence, also inserting break info
        if word['type'] == 'normal':
            # Handle missing phone cases
            if word['phones'] is None:
                # Amend that punctuation may have normal type
                if word['value'] in string.punctuation:
                    word['phones'] = f"punc{word['value']}"
                    word['type'] = 'punc'
                else:
                    raise ValueError(f"Normal word {word['value']} has no phones")
            word_phones = _convert_to_phones(word['phones'])
            phones.extend(word_phones)
            if word['break'] is None:
                phones.append('br1')
            else:
                phones.append(f"br{word['break']}")
        elif word['type'] == 'punc':
            phones.extend([f"punc{word['value']}", 'br1'])
        else:
            raise ValueError(f"{word['value']} has unrecognized type {word['type']}")
    # Pop final br1 after punc
    if phones[-1] == 'br1':
        phones.pop()
    # Assign missing punc after phone sequence
    if 'punc' not in phones[-1]:
        if sent_info['locale'] == 'zh-cn':
            phones.append('punc。')
            sent_info['text'] += " 。"
        else:
            phones.append('punc.')
            sent_info['text'] += " ."

    if question_tone and '?' in sent_info['text']:
        if question_tone_from_f0:
            speech, sr = load_wav(speech_filename)
            last_syllable = get_last_syllable(sent_info['words'], at_least=question_tone_min_phone_num)
            time_stamps = get_timestamp_syllable(alignment_file, last_syllable)
            f0 = get_f0.extract_pitch(speech, sr,
                                      50, 800,
                                      frame_duration=question_tone_frame_time)
            f0_sample = get_f0_sample(f0, question_tone_frame_time, time_stamps)
            tobifbt = get_boundary_tone(f0_sample,
                                        question_tone_duration,
                                        question_tone_min_variation,
                                        question_tone_min_half_distance)
            if tobifbt == "L-L%" or tobifbt == "H-L%":
                for i, p in enumerate(phones):
                    if p == 'punc?':
                        phones[i] = 'punc?_l'
            if tobifbt == "L-H%" or tobifbt == "H-H%":
                for i, p in enumerate(phones):
                    if p == 'punc?_l':
                        phones[i] = 'punc?'
        else:
            tobifbt = []
            for word in sent_info['words']:
                if word['tobifbt'] is not None:
                    tobifbt.append(word['tobifbt'])
            if tobifbt[-1] == "L-L%" or tobifbt[-1] == "H-L%":
                for i, p in enumerate(phones):
                    if p == 'punc?':
                        phones[i] = 'punc?_l'

    return phones


def _round_with_remaining(duration: float, remaining: float):
    duration += remaining
    rounded_duration = round(duration)
    return rounded_duration, duration - rounded_duration


def _fill_phone_seq_with_duration(phones: List[str],
                                  durations: List[Tuple[str, float]],
                                  br1_in_frame: int,
                                  br2_in_frame: int,
                                  br3_in_frame: int,
                                  punc_in_frame: int) -> Tuple[List[Union[str, Any]], List[Union[Optional[int], Any]]]:
    """Calculate duration through joint decision of break info and alignment.

    Args:
        phones: Phone sequence.
        durations: Corresponding durations of phones.
        br1_in_frame: Upper bound of frame number of br1.
        br2_in_frame: Upper bound of frame number of br2.
        br3_in_frame: Upper bound of frame number of br3.

    Returns:
        Tuple of updated phones and durations.
    """
    new_phones = []
    new_durations = []

    # Remaining duration in frame after rounding
    remaining = 0.

    phone_idx = dur_idx = 0
    while phone_idx < len(phones):
        if phone_idx == 0 and dur_idx == 0:
            # Add BOS tag and br0 for each sentence, dispatch duration of silence
            if durations[dur_idx][0] != 'sil':
                raise ValueError(f'Expect durations to start with sil, but got {durations[dur_idx][0]}')
            new_phones.extend(['<s>', 'br0'])
            duration, remaining = _round_with_remaining(durations[0][1], remaining)
            new_durations.extend([duration, 0])
            dur_idx += 1
        elif phones[phone_idx] in ['-']:
            new_phones.append(phones[phone_idx])
            new_durations.append(0)
            phone_idx += 1
        elif phones[phone_idx] in BREAK_LIST:
            if dur_idx >= len(durations) or durations[dur_idx][0] != 'sil':
                new_phones.append(phones[phone_idx])
                if phones[phone_idx] == 'br0':
                    new_durations.append(0)
                else:
                    # Delay the decision after one-pass since it may steal duration from adjacent phones
                    new_durations.append(None)
                phone_idx += 1
            else:
                if phones[phone_idx] == 'br4':
                    if not (phone_idx + 1 < len(phones) and 'punc' in phones[phone_idx + 1]):
                        raise ValueError('Missing punc in end of sentence')
                    new_phones.extend([phones[phone_idx], phones[phone_idx + 1]])
                    duration, remaining = _round_with_remaining(durations[dur_idx][1], remaining)
                    punc_duration = duration - 1 if duration > 1 else 0
                    new_durations.extend([1, punc_duration])
                    phone_idx += 1
                else:
                    # Override the xml break if silence duration falls in another interval.
                    duration, remaining = _round_with_remaining(durations[dur_idx][1], remaining)
                    if duration <= br1_in_frame:
                        new_phones.append('br1')
                        new_durations.append(duration)
                    elif br1_in_frame < duration <= br2_in_frame:
                        new_phones.append('br2')
                        new_durations.append(duration)
                    elif br2_in_frame < duration <= br3_in_frame:
                        new_phones.append('br3')
                        new_durations.append(duration)
                    else:
                        aver_br3_in_frame = (br3_in_frame + br2_in_frame) // 2
                        # Punctuation may have duration if sil exists
                        if phone_idx + 1 < len(phones) and 'punc' in phones[phone_idx + 1]:
                            remaining_sil = duration - aver_br3_in_frame
                            new_phones.append('br3')
                            new_durations.append(aver_br3_in_frame)
                            if remaining_sil < punc_in_frame:
                                new_phones.append(phones[phone_idx + 1])
                                new_durations.append(remaining_sil)
                                phone_idx += 1
                            else:
                                new_phones.extend([phones[phone_idx + 1], 'br1', 'sil', 'br0'])
                                new_durations.extend([punc_in_frame - 1, 1, remaining_sil - punc_in_frame, 0])
                                phone_idx += 2
                        else:
                            new_phones.extend(['br3', 'sil', 'br0'])
                            new_durations.extend([aver_br3_in_frame, duration - aver_br3_in_frame, 0])
                phone_idx += 1
                dur_idx += 1
        elif 'punc' in phones[phone_idx]:
            new_phones.append(phones[phone_idx])
            new_durations.append(0)
            phone_idx += 1
        elif phones[phone_idx] in T_TONE_LIST:
            # Special tone with duration 0
            new_phones.append(phones[phone_idx])
            new_durations.append(0)
            phone_idx += 1
        else:
            # XML phone matches the alignment one, directly fill the duration
            if phones[phone_idx].rstrip(''.join(TONE_LIST)) != durations[dur_idx][0]:
                raise ValueError(f"Expect the {dur_idx} element of alignment to be {phones[phone_idx]}, "
                                 f"but got {durations[dur_idx][0]}")
            new_phones.append(phones[phone_idx])
            duration, remaining = _round_with_remaining(durations[dur_idx][1], remaining)
            new_durations.append(duration)
            phone_idx += 1
            dur_idx += 1

    # Second pass to determine unknown durations
    for phone_idx in range(len(new_phones)):
        if new_durations[phone_idx] is None:
            # Downgrade to br1 and try to steal duration from previous phones
            for dur_idx in reversed(range(phone_idx)):
                if new_durations[dur_idx] > br1_in_frame:
                    new_durations[dur_idx] -= br1_in_frame
                    new_durations[phone_idx] = br1_in_frame
                    new_phones[phone_idx] = 'br1'
                    break
            if new_durations[phone_idx] is None:
                raise ValueError('Failed to steal duration from previous phones')

    # Add EOS
    new_phones.append('</s>')
    new_durations.append(0)

    return new_phones, new_durations


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.DEBUG)

    main(get_args())

import argparse
import logging
import collections
import pandas as pd
import re
import csv
from tqdm import tqdm
from pathlib import Path
import os
import numpy as np

from utils import load_metadata
from utils import stringify_metadata


def get_args():
    def _str_to_bool(s):
        """Convert string to bool (in argparse context)."""
        if s.lower() not in ['true', 'false']:
            raise ValueError('Argument needs to be a '
                             'boolean, got {}'.format(s))
        return {'true': True, 'false': False}[s.lower()]

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--metadata",
        type=Path,
        help="Metadata file extracted from previous step",
    )
    parser.add_argument(
        "--para_pos_start",
        type=int,
        default=0,
        dest="para_pos_start",
        help="start position of paragraph id in sentence id.")
    parser.add_argument(
        "--para_pos_len",
        type=int,
        default=5,
        dest="para_pos_len",
        help="paragraph id length in sentence id")
    parser.add_argument(
        "--use_br",
        type=_str_to_bool,
        default=True,
        help="whether to use br phones, if not, just use word boundary /",
    )
    parser.add_argument(
        "--metadata_output",
        type=Path,
        default="metadata.csv",
        help="Updated metadata output file",
    )
    parser.add_argument(
        "--stat_output",
        type=Path,
        default="stat",
        help="Output folder for statistic feature",
    )
    return parser.parse_args()


def parse_paraid(sid, para_pos_start, para_pos_len):
    sid_split = sid.rsplit('_', 2)
    if len(sid_split) == 2:
        return sid_split[0][para_pos_start:para_pos_start + para_pos_len]
    else:
        return "%s_%s" % (sid_split[0], sid_split[1][para_pos_start:para_pos_start + para_pos_len])


def extract_global_stat(metadata_path, para_pos_start, para_pos_len, use_br):
    metadata = pd.read_csv(metadata_path, dtype=str, sep='|', quoting=3)
    phone_dict = collections.OrderedDict()
    for _, row in tqdm(metadata.iterrows()):
        sid = row["sid"].strip()
        phone_dict[sid] = row["phones"].strip()

    max_sent_num_para, max_sent_num_para_id, max_syl_num_para, max_syl_num_para_id = 0, 0, 0, 0
    max_syl_num_sent, max_syl_num_sent_id = 0, 0

    para_info = collections.OrderedDict()
    para_sent_id_map = collections.OrderedDict()
    for k, _ in phone_dict.items():
        sid = k.split('.')[0].strip()
        cur_pid = parse_paraid(sid, para_pos_start, para_pos_len)
        if cur_pid not in para_sent_id_map:
            para_sent_id_map[cur_pid] = [sid]
        else:
            para_sent_id_map[cur_pid].append(sid)

    for k, v in para_sent_id_map.items():
        sent_num_para = 0
        syl_num_para = 0
        for sid in v:
            phone = phone_dict[sid]
            syl_phone_list = []
            word_phone_list = re.split(r'br\d', phone) if use_br else phone.split(' / ')
            [syl_phone_list.extend(word_phone.strip().split(' - ')) for word_phone in word_phone_list]
            syl_num = len(syl_phone_list)
            if syl_num > max_syl_num_sent:
                max_syl_num_sent = syl_num
                max_syl_num_sent_id = sid

            sent_num_para += 1
            syl_num_para += syl_num

        if sent_num_para > max_sent_num_para:
            max_sent_num_para = sent_num_para
            max_sent_num_para_id = k

        if syl_num_para > max_syl_num_para:
            max_syl_num_para = syl_num_para
            max_syl_num_para_id = k

        para_info[k] = "%s_%s" % (sent_num_para - 1, syl_num_para - 1)

    para_info["max_sent_para"] = "%s_%s" % (max_sent_num_para_id, max_sent_num_para - 1)
    para_info["max_syl_para"] = "%s_%s" % (max_syl_num_para_id, max_syl_num_para - 1)
    para_info["max_syl_sent"] = "%s_%s" % (max_syl_num_sent_id, max_syl_num_sent - 1)

    return para_info


def extract_stat(syl_phone_list, global_info, cum_syl_num, cum_sent_num, pid):
    phone_stat = []
    max_syl_sent = float(global_info["max_syl_sent"].split('_')[-1])
    sent_syl_size_norm = (len(syl_phone_list) - 1) / max_syl_sent if max_syl_sent > 0 else 1.0

    max_syl_para = float(global_info["max_syl_para"].split('_')[-1])
    para_syl_size_norm = float(global_info[pid].split('_')[-1]) / max_syl_para if max_syl_para > 0 else 1.0

    para_sent_num = float(global_info[pid].split('_')[0])
    sid_norm = cum_sent_num / para_sent_num if para_sent_num > 0 else 1.0

    max_sent_para = float(global_info["max_sent_para"].split('_')[-1])
    para_sent_size_norm = float(global_info[pid].split('_')[0]) / max_sent_para if max_sent_para > 0 else 1.0

    for sylid, syl in enumerate(syl_phone_list):
        sylid_norm = sylid / (len(syl_phone_list) - 1) if (len(syl_phone_list) - 1) > 0 else 1.0
        para_syl_num = float(global_info[pid].split('_')[-1])
        cum_sylid_norm = (sylid + cum_syl_num) / para_syl_num if para_syl_num > 0 else 1.0
        phone_num = len(syl.strip().split()) if sylid == len(syl_phone_list) - 1 else len(syl.strip().split()) + 1
        phone_stat += [[sylid_norm, sent_syl_size_norm, cum_sylid_norm, para_syl_size_norm, sid_norm,
                        para_sent_size_norm]] * phone_num

    return np.array(phone_stat, dtype='float32')


def main(args):
    os.makedirs(args.stat_output, exist_ok=True)
    global_info = extract_global_stat(args.metadata, args.para_pos_start, args.para_pos_len, args.use_br)
    with open(args.metadata_output, 'w', newline='', encoding='utf-8') as f:
        metadata_writer = csv.writer(f, delimiter='|')
        header_written = False
        cum_syl_num, cum_sent_num, pre_pid = 0, 0, "-1"
        for metadata_item in tqdm(load_metadata(args.metadata)):
            sid = metadata_item['sid']
            pid = parse_paraid(sid, args.para_pos_start, args.para_pos_len)
            phones = " ".join(metadata_item['phones'])
            syl_phone_list = []
            word_phone_list = re.split(r'br\d', phones) if args.use_br else phones.split(' / ')
            [syl_phone_list.extend(word_phone.strip().split(' - ')) for word_phone in word_phone_list]
            if pid != pre_pid and pre_pid != "-1":
                cum_syl_num = 0
                cum_sent_num = 0
            phone_stat = extract_stat(syl_phone_list, global_info, cum_syl_num, cum_sent_num, pid)
            assert phone_stat.shape[0] == len(metadata_item['phones'])
            cum_syl_num += len(syl_phone_list)
            cum_sent_num += 1
            pre_pid = pid

            basename = metadata_item['speech_path'].stem
            metadata_item['stat_path'] = args.stat_output / f"{basename}.npy"
            np.save(metadata_item['stat_path'], phone_stat)

            syl_phone_num = [len(syl_phone.strip().split(' ')) if idx == len(syl_phone_list) - 1 else
                             len(syl_phone.strip().split(' ')) + 1 for idx, syl_phone in enumerate(syl_phone_list)]
            metadata_item['syl_phone_num'] = ' '.join(map(str, syl_phone_num))

            # Stringify items in metadata (for example, list)
            metadata_item = stringify_metadata(metadata_item)
            # Write csv header first if not written before
            if not header_written:
                metadata_writer.writerow(metadata_item.keys())
                header_written = True
            # Write real data
            metadata_writer.writerow(metadata_item.values())


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

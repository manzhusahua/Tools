import argparse
import csv
import logging
import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Dict
import shutil
from tqdm import tqdm

from utils import load_metadata
from utils import stringify_metadata


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--metadata",
        type=Path,
        help="Metadata file extracted from previous step",
    )
    parser.add_argument(
        "--speech_output",
        type=Path,
        default="speech",
        help="Output folder for speech",
    )
    parser.add_argument(
        "--mel_output",
        type=Path,
        default="mel",
        help="Output folder for Mel spectrogram",
    )
    parser.add_argument(
        "--sf_output",
        type=Path,
        default="sf",
        help="Output folder for interpolated f0",
    )
    parser.add_argument(
        "--uv_output",
        type=Path,
        default="uv",
        help="Output folder for uv",
    )
    parser.add_argument(
        "--stat_output",
        type=Path,
        default="stat",
        help="Output folder for statistic feature",
    )
    parser.add_argument(
        "--metadata_output",
        type=Path,
        default="metadata.csv",
        help="Updated metadata output file",
    )
    parser.add_argument(
        "--max_workers",
        type=int,
        default=8,
        help="Max workers to use for feature extraction",
    )

    return parser.parse_args()


def main(args):
    os.makedirs(args.speech_output, exist_ok=True)
    os.makedirs(args.mel_output, exist_ok=True)
    os.makedirs(args.sf_output, exist_ok=True)
    os.makedirs(args.uv_output, exist_ok=True)
    os.makedirs(args.stat_output, exist_ok=True)

    futures = []
    with ProcessPoolExecutor(max_workers=args.max_workers) as executor:
        # Submit parallel feature extraction tasks
        for metadata_item in load_metadata(args.metadata):
            futures.append(executor.submit(finalize_and_relocate, metadata_item,
                                           args.metadata_output.parent,
                                           args.speech_output, args.mel_output,
                                           args.sf_output, args.uv_output, args.stat_output))

        # Collect parallel execution results
        with open(args.metadata_output, 'w', newline='', encoding='utf-8') as f:
            metadata_writer = csv.writer(f, delimiter='|')
            header_written = False
            # Collect updated metadata items
            for future in tqdm(futures):
                updated_metadata_item = future.result()
                # Stringify items in metadata (for example, list)
                metadata_item = stringify_metadata(updated_metadata_item, absolute_path=False)
                # Write csv header first if not written before
                if not header_written:
                    metadata_writer.writerow(metadata_item.keys())
                    header_written = True
                # Write real data
                metadata_writer.writerow(metadata_item.values())


def finalize_and_relocate(metadata: Dict,
                          relocate_dir: Path,
                          speech_output: Path,
                          mel_output: Path,
                          sf_output: Path,
                          uv_output: Path,
                          stat_output: Path):
    """Finalize pre-processing output and relocate absolute path in metadata"""
    # Finalize and locale speech
    speech_path = metadata['speech_path']
    speech_name = metadata['sid'] + os.path.splitext(speech_path.name)[-1]
    shutil.copy(speech_path, speech_output / speech_name)
    relocated_speech_output = speech_output.relative_to(relocate_dir)
    metadata['speech_path'] = relocated_speech_output / speech_name

    # Finalize and locale mel
    mel_path = metadata['mel_path']
    mel_name = metadata['sid'] + os.path.splitext(mel_path.name)[-1]
    shutil.copy(mel_path, mel_output / mel_name)
    relocated_mel_output = mel_output.relative_to(relocate_dir)
    metadata['mel_path'] = relocated_mel_output / mel_name

    # Finalize and locale sf
    sf_path = metadata['sf_path']
    sf_name = metadata['sid'] + os.path.splitext(sf_path.name)[-1]
    shutil.copy(sf_path, sf_output / sf_name)
    relocated_sf_output = sf_output.relative_to(relocate_dir)
    metadata['sf_path'] = relocated_sf_output / sf_name

    # Finalize and locale uv
    uv_path = metadata['uv_path']
    uv_name = metadata['sid'] + os.path.splitext(uv_path.name)[-1]
    shutil.copy(uv_path, uv_output / uv_name)
    relocated_uv_output = uv_output.relative_to(relocate_dir)
    metadata['uv_path'] = relocated_uv_output / uv_name

    # Finalize and locale stat
    if 'stat_path' in metadata:
        stat_path = metadata['stat_path']
        stat_name = metadata['sid'] + os.path.splitext(stat_path.name)[-1]
        shutil.copy(stat_path, stat_output / stat_name)
        relocated_stat_output = stat_output.relative_to(relocate_dir)
        metadata['stat_path'] = relocated_stat_output / stat_name

    return metadata


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

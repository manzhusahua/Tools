import argparse
import csv
import logging
from pathlib import Path

from utils import load_metadata


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root_dir",
        type=Path,
        required=True,
        help="Root directory of single voice collections",
    )
    parser.add_argument(
        "--registry_output",
        type=Path,
        default="registry.csv",
        help="Output registry file of found voices",
    )

    return parser.parse_args()


def main(args):
    with open(args.registry_output, 'w', newline='', encoding='utf-8') as f:
        registry_writer = csv.writer(f, delimiter='|')
        header_written = False
        for metadata_filename in args.root_dir.glob("**/metadata_*.csv"):
            speaker_set, locale_set, style_set = (set() for _ in range(3))
            for metadata_item in load_metadata(metadata_filename):
                speaker_set.add(metadata_item['speaker'])
                locale_set.add(metadata_item['locale'])
                style_set.add(metadata_item['style'])
            # In common case, we process voices one-by-one for each speaker/locale/style
            assert len(locale_set) == 1 and len(style_set) == 1
            locale, style = locale_set.pop(), style_set.pop()
            if len(speaker_set) > 1:
                speaker = 'Multiple'
                logging.warning("You have multiple speakers in one metadata, considered as low resource case")
            else:
                speaker = speaker_set.pop()
            # Construct registry item
            registry_item = {'speaker': speaker, 'locale': locale, 'style': style,
                             'metadata_path': str(metadata_filename.relative_to(args.root_dir))}
            # Write csv header first if not written before
            if not header_written:
                registry_writer.writerow(registry_item.keys())
                header_written = True
            # Write real data
            registry_writer.writerow(registry_item.values())


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

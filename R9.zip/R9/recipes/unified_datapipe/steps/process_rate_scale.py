import argparse
import csv
import logging
from pathlib import Path
import json


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--style_trans_config",
        required=True,
        type=Path,
        help="styel tansfer configuration file",
    )
    parser.add_argument(
        "--rate_preset_scale",
        type=Path,
        help="rate preset scale file",
    )
    parser.add_argument(
        "--rate_scale_output",
        type=Path,
        required=True,
        help="Output rate scale parameter csv file",
    )

    return parser.parse_args()


def load_rate_scale(style_trans_config_dict, rate_preset_scale_file):
    f0_preset_scale = {}
    with open(rate_preset_scale_file, 'r', encoding='utf-8') as f:
        rate_preset_scale_dict = json.load(f)

    for src_style in style_trans_config_dict["src_speaker"]:
        style_name = src_style["style_name"]
        speaker_name = src_style["speaker_name"]
        if style_name in rate_preset_scale_dict.keys():
            if speaker_name in rate_preset_scale_dict[style_name].keys():
                f0_preset_scale[style_name] = rate_preset_scale_dict[style_name][speaker_name]

    return f0_preset_scale


def main(args):
    with open(args.style_trans_config, 'r', encoding='utf-8') as f:
        style_trans_config_dict = json.load(f)
    keys = style_trans_config_dict.keys()
    if "src_speaker" not in keys or "target_speaker" not in keys:
        Exception("styel tansfer configuration file format error: {}".format(args.style_trans_config))

    rate_scale_param = {}
    if args.rate_preset_scale:
        rate_scale_param = load_rate_scale(style_trans_config_dict, args.rate_preset_scale)

    with open(args.rate_scale_output, 'w', newline='', encoding='utf-8') as f:
        rate_scale_writer = csv.writer(f, delimiter=',', skipinitialspace=False)
        rate_scale_writer.writerow(['style', 'rate'])

        for style_name in rate_scale_param.keys():
            rate_scale_writer.writerow([style_name, f"{rate_scale_param[style_name]:.3f}"])

    return rate_scale_param


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

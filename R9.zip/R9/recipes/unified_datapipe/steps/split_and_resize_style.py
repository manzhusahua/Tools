import argparse
import copy
import csv
import logging
import random
from pathlib import Path
from typing import List

import yaml

from utils import load_metadata, stringify_metadata


def get_args():
    def _str_to_bool(s):
        """Convert string to bool (in argparse context)."""
        if s.lower() not in ['true', 'false']:
            raise ValueError('Argument needs to be a '
                             'boolean, got {}'.format(s))
        return {'true': True, 'false': False}[s.lower()]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--metadata",
        type=Path,
        help="Metadata file extracted from previous step",
    )
    parser.add_argument(
        "--out_dir",
        type=Path,
        required=True,
        help="Output folder for updated metadata",
    )
    parser.add_argument(
        "--style_sampling_config",
        type=Path,
        default="registry.csv",
        help="The style sampling config of the voice",
    )
    parser.add_argument(
        "--allow_downsampling",
        type=_str_to_bool,
        default=True,
        help="Whether to allow downsampling",
    )

    return parser.parse_args()


def main(args):
    if args.style_sampling_config.is_file():
        with open(args.style_sampling_config) as fi:
            sampling_config = yaml.load(fi, Loader=yaml.FullLoader)
        logging.info(f"sampling_config = {sampling_config}")
    else:
        sampling_config = {}
        logging.info("only split style metadata, no resize")
    style_metadata_dict = split_style(args.metadata)
    sum_raw_size, sum_resample_size = 0, 0
    with open(args.out_dir / "style_sampling.csv", 'w') as fo:
        fo.write("style,raw_size,resample_size\n")
        for style in sorted(style_metadata_dict):
            style_metadata = style_metadata_dict[style]
            metadata_output = args.out_dir / f"metadata_{style}.csv"
            if args.style_sampling_config.is_file() and style not in sampling_config:
                logging.warning(f"style={style} not in {args.style_sampling_config}, no resize")
            raw_size = len(style_metadata)
            resample_size = raw_size \
                if sampling_config.get(style, -1) == -1 else sampling_config[style]
            if resample_size < raw_size:
                logging.warning(f"for style={style}, resample_size={resample_size} is lower than raw_size={raw_size}")
                if not args.allow_downsampling:
                    resample_size = raw_size
            fo.write(f"{style},{raw_size},{resample_size}\n")
            logging.info(f"style={style}, raw_size={raw_size}, resample_size={resample_size}")
            resample_style(style_metadata, metadata_output, resample_size)
            sum_raw_size += raw_size
            sum_resample_size += resample_size
        fo.write(f"SUM,{sum_raw_size},{sum_resample_size}")


def split_style(metadata: Path):
    style_metadata_dict = {}
    for data in load_metadata(metadata):
        if data["style"] not in style_metadata_dict:
            style_metadata_dict[data["style"]] = []
        style_metadata_dict[data["style"]].append(data)
    return style_metadata_dict


def resample_style(style_metadata: List, metadata_output: Path, resample_size: int):
    raw_size = len(style_metadata)
    if resample_size <= raw_size:
        style_metadata_resample = sorted(
            random.sample(style_metadata, resample_size),
            key=lambda metadata_item: metadata_item['sid'])
    else:
        style_metadata_resample = style_metadata
        for i in range(raw_size, resample_size):
            metadata_item = copy.deepcopy(style_metadata[i % raw_size])
            metadata_item['sid'] = f"{metadata_item['sid']}-{i // raw_size}"
            style_metadata_resample.append(metadata_item)

    with open(metadata_output, 'w', newline='', encoding='utf-8') as f:
        metadata_writer = csv.writer(f, delimiter='|')
        header_written = False
        # Collect updated metadata items
        for metadata_item in style_metadata_resample:
            # Stringify items in metadata (for example, list)
            metadata_item = stringify_metadata(metadata_item, absolute_path=False)
            # Write csv header first if not written before
            if not header_written:
                metadata_writer.writerow(metadata_item.keys())
                header_written = True
            # Write real data
            metadata_writer.writerow(metadata_item.values())


if __name__ == "__main__":
    formatter = (
        "%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s"
    )

    logging.basicConfig(format=formatter, level=logging.INFO)

    main(get_args())

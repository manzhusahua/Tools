import csv
from pathlib import Path
from typing import Dict


def load_metadata(filename: Path):
    with open(filename, 'r', newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter='|')
        for row in reader:
            yield unstringify_metadata(row)


def stringify_metadata(data: Dict, absolute_path: bool = True):
    """Stringify items before write to csv in place.

    Args:
        data: dict of items to stringify
        absolute_path: whether to stringify path to absolute path
    """
    data['phones'] = ' '.join(data['phones'])
    data['durations'] = ' '.join(map(str, data['durations']))
    data['speech_length_in_s'] = str(data['speech_length_in_s'])

    for key in data.keys():
        if key.endswith('path'):
            if absolute_path:
                data[key] = str(data[key].absolute())
            else:
                data[key] = str(data[key])

    return data


def unstringify_metadata(data: Dict):
    """Unstringify items after reading from csv in place.

    Args:
        data: dict of items to unstringify
    """
    data['phones'] = data['phones'].split()
    data['durations'] = list(map(int, data['durations'].split()))
    data['speech_length_in_s'] = float(data['speech_length_in_s'])

    # For Path object like speech_path
    for key in data.keys():
        if key.endswith('path'):
            data[key] = Path(data[key])

    return data

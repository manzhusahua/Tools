#!/bin/bash

for i in {0..18..1}
do
    part_name="FY22Q3"
    domain_name="Howto_Style"
    ./submit_zetta.sh $part_name $domain_name $i
done

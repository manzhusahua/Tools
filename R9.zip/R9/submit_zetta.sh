#!/bin/bash


workspace_name="zetta-prod-ws02-eus2"
compute_target="ZettA-AML-E8v3"

part_name=$1
domain_name=$2
each_part=$3

command="export HYDRA_FULL_ERROR=1 && pip install hydra-core==1.1.0dev5 filelock gdown einops PyWavelets timm --upgrade --pre; pip install pandas; pip install backoff; pip install more_itertools; pip install transformers; pip install numpy==1.20; pip install -e .; python generate_binary.py "$part_name" "$domain_name" "$each_part

experiment_name="en-us_long_form_r12"
display_name="binary_"$each_part

"C:\Users\v-zhazhai\Toosl\miniconda3\envs\use\python.exe" -u submit/zetta_submit.py \
  --workspace-name "${workspace_name}" \
  --compute-target "${compute_target}" \
  --experiment-name "${experiment_name}" \
  --display-name "${display_name}" \
  --key-vault-name "exawatt-philly-ipgsp" \
  --docker-address "docker.io" \
  --docker-name "npuichigo/pytorch:pytorch1.8.1-py38-cuda11.1"\
  --local-code-dir "$(pwd)" \
  --cmd "${command}"

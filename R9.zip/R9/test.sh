#!/bin/bash

for i in {00000..00000..1}
do
    part_name="en-US"
    domain_name="long_form_r12"
    ./submit_zetta.sh $part_name $domain_name $i
done
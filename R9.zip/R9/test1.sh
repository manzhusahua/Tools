#!/bin/bash

for i in {00001..00001..1}
do
    part_name="LibriTTS_R"
    domain_name="Education"
    ./submit_zetta.sh $part_name $domain_name $i
done
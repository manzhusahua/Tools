from abc import ABC
from abc import abstractmethod


class ClusterEnvironment(ABC):
    @property
    @abstractmethod
    def master_address(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @property
    @abstractmethod
    def master_port(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @property
    @abstractmethod
    def world_size(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @property
    @abstractmethod
    def rank(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @property
    @abstractmethod
    def local_rank(self):
        raise NotImplementedError("Must be implemented in subclasses.")

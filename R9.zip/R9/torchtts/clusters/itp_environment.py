import logging
import os
import re

from torchtts.clusters.local_environment import LocalEnvironment

logger = logging.getLogger(__name__)


class ITPEnvironment(LocalEnvironment):
    """Integrated training platform (aka AzureML K8S) environment."""

    INIT_ENV_FILE = "/dlts-runtime/env/init.env"

    def __init__(self):
        if not os.path.isfile(self.INIT_ENV_FILE):
            logger.warning(
                "ITP cannot be initialized due to the missing file: "
                f"{self.INIT_ENV_FILE}. Init as local environment."
            )
            self.use_local_init = True
        else:
            regexp = r"[\s\S]*export[\s]*DLTS_SD_worker0_IP=([0-9.]+)[\s|s]*"
            with open(self.INIT_ENV_FILE, "r") as f:
                line = f.read()
            match = re.match(regexp, line)
            if match:
                self._master_address = str(match.group(1))
                self._master_port = 6000
                self.use_local_init = False
            else:
                logger.warning(f"Did not find master node ip in {self.INIT_ENV_FILE}")
                self.use_local_init = True

    @property
    def master_address(self):
        if self.use_local_init:
            return super(ITPEnvironment, self).master_address
        else:
            return self._master_address

    @property
    def master_port(self):
        if self.use_local_init:
            return super(ITPEnvironment, self).master_port
        else:
            return self._master_port

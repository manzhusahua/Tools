import logging
import os

from torchtts.clusters.cluster_environment import ClusterEnvironment

logger = logging.getLogger(__name__)


class LocalEnvironment(ClusterEnvironment):
    @property
    def master_address(self):
        if "MASTER_ADDR" not in os.environ:
            logger.warning("MASTER_ADDR environment variable is not defined. Set as 127.0.1.1")
            os.environ["MASTER_ADDR"] = "127.0.1.1"
        logger.debug(f"MASTER_ADDR: {os.environ['MASTER_ADDR']}")
        master_address = os.environ.get("MASTER_ADDR")
        return master_address

    @property
    def master_port(self):
        if "MASTER_PORT" not in os.environ:
            logger.warning("MASTER_PORT environment variable is not defined. Set as 50065")
            os.environ["MASTER_PORT"] = "50065"
        logger.debug(f"MASTER_PORT: {os.environ['MASTER_PORT']}")
        port = os.environ.get("MASTER_PORT")
        return port

    @property
    def world_size(self):
        """Find OMPI world size without calling mpi functions"""
        return int(os.environ.get("OMPI_COMM_WORLD_SIZE") or 1)

    @property
    def rank(self):
        """Find OMPI world rank without calling mpi functions"""
        return int(os.environ.get("OMPI_COMM_WORLD_RANK") or 0)

    @property
    def local_rank(self):
        """Find OMPI local rank without calling mpi functions"""
        return int(os.environ.get("OMPI_COMM_WORLD_LOCAL_RANK") or 0)

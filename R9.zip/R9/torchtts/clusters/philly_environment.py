import logging
import os

from torchtts.clusters.local_environment import LocalEnvironment

logger = logging.getLogger(__name__)


class PhillyEnvironment(LocalEnvironment):
    """Philly cluster environment for distributed training."""

    def __init__(self):
        if "PHILLY_RUNTIME_CONFIG" not in os.environ:
            logger.warning("PHILLY_RUNTIME_CONFIG environment variable is not defined. " "Init as local environment.")
            self.use_local_init = True
        else:
            from mpi4py import MPI

            self.comm = MPI.COMM_WORLD
            self.use_local_init = False

    @property
    def master_address(self):
        if self.use_local_init:
            return super(PhillyEnvironment, self).master_address
        else:
            my_rank = self.comm.Get_rank()
            master_ip = None
            if my_rank == 0:
                hostname_cmd = ["hostname -I"]
                import subprocess

                result = subprocess.check_output(hostname_cmd, shell=True)
                master_ip = result.decode("utf-8").split()[0]
            master_ip = self.comm.bcast(master_ip, root=0)
            return master_ip

    @property
    def master_port(self):
        if self.use_local_init:
            return super(PhillyEnvironment, self).master_port
        else:
            start_port_range = int(os.environ["PHILLY_CONTAINER_PORT_RANGE_START"])
            end_port_range = int(os.environ["PHILLY_CONTAINER_PORT_RANGE_END"])
            torch_port = start_port_range + (end_port_range - start_port_range) // 2
            master_port = self.comm.bcast(torch_port, root=0)
            return master_port

import logging
import os
import os.path
import numpy as np
import pickle

from torchvision.datasets.utils import check_integrity
from torchvision.datasets.utils import download_and_extract_archive

from torchtts.data.core import features
from torchtts.data.core.dataset_info import DatasetInfo
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder

logger = logging.getLogger(__name__)


class CIFAR10Dataset(GeneratorBasedBuilder):
    BASE_FOLDER = "cifar-10-batches-py"
    URL = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
    FILENAME = "cifar-10-python.tar.gz"
    TGZ_MD5 = "c58f30108f718f92721af3b95e74349a"
    TRAIN_LIST = [
        ["data_batch_1", "c99cafc152244af753f735de768cd75f"],
        ["data_batch_2", "d4bba439e000b95fd0a9bffe97cbabec"],
        ["data_batch_3", "54ebc095f3ab1f0389bbae665268c751"],
        ["data_batch_4", "634d18415352ddfa80567beed471001a"],
        ["data_batch_5", "482c414d41f54cd18b22e5b47cb7c3cb"],
    ]

    TEST_LIST = [
        ["test_batch", "40351d587109b95175f43aff81a1287e"],
    ]
    META = {
        "filename": "batches.meta",
        "key": "label_names",
        "md5": "5ff9c542aee3614f3951f8cda6e48888",
    }

    def _info(self):
        return DatasetInfo(
            builder=self,
            description="CIFAR10 dataset builder",
            features=features.FeaturesDict(
                {
                    "img": features.Tensor(shape=(3, 32, 32), dtype=np.float32),
                    "label": features.Tensor(shape=(), dtype=np.int64),
                }
            ),
        )

    def _split_generators(self):
        return {k: self._raw_data_generator(split=v) for k, v in self.split_type.items()}

    def _raw_data_generator(self, split):
        self._download()

        if not self._check_integrity():
            raise RuntimeError("Dataset not found or corrupted.")

        if split == "train":
            downloaded_list = self.TRAIN_LIST
        else:
            downloaded_list = self.TEST_LIST

        data = []
        targets = []

        # now load the picked numpy arrays
        for file_name, _ in downloaded_list:
            file_path = os.path.join(os.path.join(self.data_dir, "download"), self.BASE_FOLDER, file_name)
            with open(file_path, "rb") as f:
                entry = pickle.load(f, encoding="latin1")
                data.append(entry["data"])
                if "labels" in entry:
                    targets.extend(entry["labels"])
                else:
                    targets.extend(entry["fine_labels"])

        data = np.vstack(data).reshape(-1, 3, 32, 32)
        mean = np.array([0.5, 0.5, 0.5], dtype=np.float32).reshape(-1, 1, 1)
        std = np.array([0.5, 0.5, 0.5], dtype=np.float32).reshape(-1, 1, 1)
        data = (data.astype(np.float32) / 255 - mean) / std

        for index in range(len(data)):
            key = f"{index:05}"
            img, label = data[index], targets[index]
            yield key, {"img": img, "label": label}

    def _data_pipeline(self, datapipe, shuffle=True):
        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=100)
        datapipe = datapipe.batch(64)
        datapipe = datapipe.collate()
        return datapipe

    def _check_integrity(self) -> bool:
        root = os.path.join(self.data_dir, "download")
        for entry in self.TRAIN_LIST + self.TEST_LIST:
            filename, md5 = entry[0], entry[1]
            path = os.path.join(root, self.BASE_FOLDER, filename)
            if not check_integrity(path, md5):
                return False
        return True

    def _download(self):
        if self._check_integrity():
            logger.info("Files already downloaded and verified")
            return
        download_and_extract_archive(
            self.URL, os.path.join(self.data_dir, "download"), filename=self.FILENAME, md5=self.TGZ_MD5
        )

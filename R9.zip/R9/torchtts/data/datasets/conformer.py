import io
import json
import os
import zipfile

import numpy as np

from torchtts.data.core import features
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder
from torchtts.data.core.dataset_info import DatasetInfo
from torchtts.utils.data_utils import get_bucket_scheme

import random
import logging

logger = logging.getLogger(__name__)


class ConformerDataset(GeneratorBasedBuilder):
    def _info(self):
        odim = self._config.get("odim", 80)
        feature_dict = {
            "phone_id": features.Tensor(shape=(None,), dtype=np.int64),
            "phone_id_length": features.Tensor(shape=(), dtype=np.int64),
            "duration": features.Tensor(shape=(None,), dtype=np.int64),
            "mel": features.Tensor(shape=(None, odim), dtype=np.float32),
            "mel_length": features.Tensor(shape=(), dtype=np.int64),
        }

        if self._config.get('multilingual_data', False):
            feature_dict.update({
                'speaker_id': features.Tensor(shape=(), dtype=np.int64),
                'locale_id': features.Tensor(shape=(), dtype=np.int64),
                'style_id': features.Tensor(shape=(), dtype=np.int64),
                'f0': features.Tensor(shape=(None,), dtype=np.float32),
                'uv': features.Tensor(shape=(None,), dtype=np.float32)
            })
        elif self._config.get("voice_attribute_data", False):
            feature_dict.update(
                {
                    "speaker_id": features.Tensor(shape=(), dtype=np.int64),
                    "locale_id": features.Tensor(shape=(), dtype=np.int64),
                    "style_id": features.Tensor(shape=(), dtype=np.int64),
                    "f0": features.Tensor(shape=(None,), dtype=np.float32),
                    "uv": features.Tensor(shape=(None,), dtype=np.float32),
                    "attributes": features.Tensor(shape=(None,), dtype=np.float32),
                }
            )
            if self._config.get('semi_supervised_training', False):
                feature_dict.update({
                    'with_attri_label': features.Tensor(shape=(), dtype=np.float32)
                })
            if self._config.get("old_data_format", False):
                feature_dict.update({"spkemb": features.Tensor(shape=(None,), dtype=np.float32)})
        elif self._config.get('new_voice_data', False):
            feature_dict.update({
                'speaker_id': features.Tensor(shape=(), dtype=np.int64),
                'locale_id': features.Tensor(shape=(), dtype=np.int64),
                'style_id': features.Tensor(shape=(), dtype=np.int64),
                'phone_f0': features.Tensor(shape=(None,), dtype=np.float32),
                'phone_e': features.Tensor(shape=(None,), dtype=np.float32),
            })
        elif self._config.get("load_fastspeech", False):
            if self._config.get("enable_multi_speaker", False):
                feature_dict.update({"speaker_id": features.Tensor(shape=(), dtype=np.int64)})

            if self._config.get("enable_cross_lingual", False):
                feature_dict.update({"locale_id": features.Tensor(shape=(), dtype=np.int64)})

            if self._config.get("enable_multi_style", False):
                feature_dict.update({"style_id": features.Tensor(shape=(), dtype=np.int64)})

            if self._config.get("with_pitch_data", False):
                feature_dict.update(
                    {
                        "f0": features.Tensor(shape=(None,), dtype=np.float32),
                        "uv": features.Tensor(shape=(None,), dtype=np.float32),
                    }
                )
        else:
            if self._config.get("enable_multi_speaker", False):
                feature_dict.update({"speaker_id": features.Tensor(shape=(None,), dtype=np.int64)})

            if self._config.get("enable_cross_lingual", False):
                feature_dict.update({"locale_id": features.Tensor(shape=(None,), dtype=np.int64)})

            if self._config.get("enable_multi_style", False):
                feature_dict.update({"style_id": features.Tensor(shape=(None,), dtype=np.int64)})

            if self._config.get("with_pitch_data", False):
                feature_dict.update({"phone_f0": features.Tensor(shape=(None,), dtype=np.float32)})

            if self._config.get("with_singing_data", False):
                feature_dict.update(
                    {
                        "syllable_duration": features.Tensor(shape=(None,), dtype=np.int64),
                        "note_duration": features.Tensor(shape=(None,), dtype=np.int64),
                        "note_pitch": features.Tensor(shape=(None,), dtype=np.int64),
                        "f0": features.Tensor(shape=(None,), dtype=np.float32),
                        "uv": features.Tensor(shape=(None,), dtype=np.float32),
                    }
                )

            if self._config.get("with_power_data", False):
                feature_dict.update(
                    {
                        "power": features.Tensor(shape=(None,), dtype=np.float32),
                        "phone_power": features.Tensor(shape=(None,), dtype=np.float32)
                    }
                )

            if self._config.get("with_tilt_data", False):
                feature_dict.update(
                    {
                        "tilt": features.Tensor(shape=(None,), dtype=np.float32),
                        "phone_tilt": features.Tensor(shape=(None,), dtype=np.float32)
                    }
                )

            if self._config.get("with_quantized_pitch_data", False):
                feature_dict.update(
                    {
                        "quantized_f0": features.Tensor(shape=(None, 256), dtype=np.float32),
                        "f0": features.Tensor(shape=(None,), dtype=np.float32),
                        "uv": features.Tensor(shape=(None,), dtype=np.float32),
                    }
                )

        return DatasetInfo(
            builder=self, description="Conformer dataset builder", features=features.FeaturesDict(feature_dict)
        )

    def _split_generators(self):
        path = self._config.get("raw_data", None)
        if path is None:
            raise ValueError("You should specify raw_data in dataset builder")
        if self._config.get("with_singing_data", False):
            logger.info("singing data preparation")
            return {k: self._raw_data_generator_singing(split=v, path=path) for k, v in self.split_type.items()}
        else:
            return {k: self._raw_data_generator(split=v, path=path) for k, v in self.split_type.items()}

    def _get_path(self, data_dir, name):
        if name is None:
            raise ValueError(f"{name} is empty for conformer.")
        data_path = os.path.join(data_dir, name)
        if not os.path.exists(data_path):
            raise ValueError(f"Cannot find {data_path}.")
        return data_path

    def _load_spec_data(self, meta_path, metadata, specs):
        if self._config.get("load_fastspeech", False):
            for item in metadata:
                try:
                    npy_path = os.path.join(meta_path, item[0])
                    target = np.load(npy_path)
                    specs[item[0]] = target
                except Exception:
                    logger.info("missing npy in mel zip: " + str(item[0]))
                    continue

            return specs
        else:
            zfile = zipfile.ZipFile(meta_path)
            for item in metadata:
                try:
                    zip_npy = zfile.open(item[0], "r")
                except Exception:
                    logger.info("missing npy in mel zip: " + str(item[0]))
                    continue
                raw_npy = io.BytesIO(zip_npy.read())
                target = np.load(raw_npy)
                specs[item[0]] = target
            zfile.close()
            return specs

    def _load_metadata(self, metadata_path, _metadata):
        new_meta_ = []
        with open(metadata_path, encoding="utf-16") as f:
            for line in f:
                pas = line.strip().split("|")
                _metadata.append(pas)
                new_meta_.append(pas)
        return _metadata, new_meta_

    def _load_voice_attri_meta(self, metadata_path, _metadata):
        new_meta_ = []
        with open(metadata_path, encoding="utf-8") as f:
            lines = f.readlines()
            head = lines[0].strip().split("|")  # format:'wav|locale_id|speaker_id|style_id|txt|phone|phone_dur'
            for line in lines[1:]:
                pas = line.strip().split("|")
                if pas[0][-4:] != ".npy":
                    pas[0] += ".npy"
                _metadata.append(pas)
                new_meta_.append(pas)
        return _metadata, new_meta_, head

    def _load_phone_set(self, path, phone2idx):
        with open(path, encoding="utf-8") as json_file:
            data = json.load(json_file)
            idx = len(phone2idx)
            for item in data:
                if item not in phone2idx:
                    phone2idx[item] = idx
                    idx += 1
        return phone2idx

    def _load_speaker_set(self, path, speaker2idx):
        with open(path, encoding="utf-8-sig") as json_file:
            data = json.load(json_file)
            if isinstance(data, dict):
                speaker2idx = data
            else:
                idx = len(speaker2idx)
                for item in data:
                    if item not in speaker2idx:
                        speaker2idx[item] = idx
                        idx += 1
        return speaker2idx

    def _load_lang_set(self, path, lang2idx):
        with open(path, encoding="utf-8-sig") as json_file:
            data = json.load(json_file)
            if isinstance(data, dict):
                lang2idx = data
            else:
                idx = len(lang2idx)
                for item in data:
                    if item not in lang2idx:
                        lang2idx[item] = idx
                        idx += 1
        return lang2idx

    def _load_style_set(self, path, style2idx):
        with open(path, encoding="utf-8-sig") as json_file:
            data = json.load(json_file)
            if isinstance(data, dict):
                style2idx = data
            else:
                idx = len(style2idx)
                for item in data:
                    if item not in style2idx:
                        style2idx[item] = idx
        return style2idx

    def _load_f0(self, path, f0s):
        with np.load(path) as data:
            for key in data.files:
                if key not in f0s:
                    f0s[key] = data[key].astype(np.float32)
                else:
                    raise Exception(f"The same item name {key} in f0 file: {path} .")
        return f0s

    def _load_uv(self, path, uvs):
        with np.load(path) as data:
            for key in data.files:
                if key not in uvs:
                    uvs[key] = data[key].astype(np.float32)
                else:
                    raise Exception(f"The same item name {key} in uv file: {path} .")
        return uvs

    def _hierarchical_onehot(self, mu_law_encode_f0, quantization_channels, f0_mean=250.0, f0_max=800.0):
        temp_one_hot = np.zeros((len(mu_law_encode_f0), quantization_channels - 1), dtype=np.float32)
        mu_law_encode_f0 = np.concatenate((np.expand_dims(mu_law_encode_f0, -1), temp_one_hot), axis=-1)
        for i in range(len(mu_law_encode_f0)):
            if mu_law_encode_f0[i, 0] == 0:
                mu_law_encode_f0[i, 0] = 1.0
            else:
                index = self._mu_law_encode(
                    (mu_law_encode_f0[i, 0] - f0_mean) / (f0_max - f0_mean), quantization_channels - 1
                )
                mu_law_encode_f0[i, 0] = 0
                mu_law_encode_f0[i, index + 1] = 1.0
        return mu_law_encode_f0

    def _load_attributes(self, path, attributes):
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
            # line:speaker|gender|age|pitch_level|speaking_rate|soft|sweet|resonant|clear|husky|upbeat|deep|authority|comfort|warm
            field_lst = lines[0].strip().split("|")
            # the order of the attributes is given in config 'attribute_names'.
            attri_lst = self._config.get("attribute_names", None)
            logger.info(f"Attributes: {attri_lst}")
            for line in lines[1:]:
                lst = line.strip().split("|")
                spk = lst[field_lst.index("speaker")]
                if spk not in attributes:
                    score_lst = []
                    for attri_name in attri_lst:
                        score_lst.append(lst[field_lst.index(attri_name)])
                    attributes[spk] = np.array(score_lst, dtype=np.float32)
                    logger.info(f"{spk}: {score_lst}")
        return attributes

    def _load_spec_data_from_folder(self, mel_path, metadata, specs):
        for item in metadata:
            try:
                target = np.load(os.path.join(mel_path, item[0] + ".npy"))
            except Exception:
                logger.info("missing npy in mel zip: " + str(item[0]))
                continue
            specs[item[0]] = target
        return specs

    def _load_pitch_data(self, pitch_path, metadata, f0s, uvs):
        if os.path.exists(os.path.join(pitch_path, "sf.npz")) and os.path.exists(os.path.join(pitch_path, "uv.npz")):
            sffiles = np.load(os.path.join(pitch_path, "sf.npz"))
            uvfiles = np.load(os.path.join(pitch_path, "uv.npz"))
        for item in metadata:
            try:
                f0 = sffiles[item[0]]
                uv = uvfiles[item[0]]
            except Exception:
                logger.info("missing npy in pitch data: " + str(item[0]))
                continue
            f0s[item[0]] = f0
            uvs[item[0]] = uv
        return f0s, uvs

    def _load_power_data(self, power_path, metadata):
        powers = {}
        if os.path.exists(os.path.join(power_path, "power.npz")):
            powerfiles = np.load(os.path.join(power_path, "power.npz"))
        for item in metadata:
            try:
                power = powerfiles[item[0]]
            except Exception:
                logger.info('missing npy in pitch data: ' + str(item[0]))
                continue
            powers[item[0]] = power
        return powers

    def _load_tilt_data(self, tilt_path, metadata):
        tilts = {}
        if os.path.exists(os.path.join(tilt_path, "tilt.npz")):
            tiltfiles = np.load(os.path.join(tilt_path, "tilt.npz"))
        for item in metadata:
            try:
                tilt = tiltfiles[item[0]]
            except Exception:
                logger.info('missing npy in pitch data: ' + str(item[0]))
                continue
            tilts[item[0]] = tilt
        return tilts

    def _load_metadata_utf8(self, metadata_path, _metadata):
        new_meta_ = []
        with open(metadata_path, encoding="utf-8") as f:
            for line in f:
                pas = line.strip().split("|")
                _metadata.append(pas)
                new_meta_.append(pas)
        return _metadata, new_meta_

    def _handle_length_mismatch(self, mutable, target_length, tolerance):
        mismatch = target_length - len(mutable)
        if mismatch != 0:
            if abs(mismatch) > tolerance:
                return None
            else:
                if mismatch > 0:
                    pad_width = ((0, mismatch), *((0, 0) for _ in range(mutable.ndim - 1)))
                    mutable = np.pad(mutable, pad_width, mode="edge")
                else:
                    mutable = mutable[:mismatch]
        return mutable

    def _raw_data_generator_singing(self, split, path):
        data_partition = []
        if "-" not in path:
            data_partition.append(path)
        else:
            pars = path.strip().split("--")
            for par in pars:
                data_partition.append(par)

        logger.info("data partitions: " + str(data_partition))

        phone2idx = {}
        phone2idx["padding"] = 0
        metadata = []
        specs = {}
        sfs = {}
        uvs = {}

        logger.info("enable multi speaker: " + str(self._config.get("enable_multi_speaker", False)))
        logger.info("enable cross lingual: " + str(self._config.get("enable_cross_lingual", False)))
        logger.info("with pitch data: " + str(self._config.get("with_pitch_data", False)))

        phone_set_path = self._config.get("phone_set", None)
        meta_path = self._config.get("metadata", None)
        mel_path = self._config.get("spec_data", None)

        for path in data_partition:
            logger.info("loading partition: " + path)
            phone2idx = self._load_phone_set(self._get_path(path, phone_set_path), phone2idx)
            logger.info("sub phone2idx size: " + str(len(phone2idx)))
            metadata, new_meta_ = self._load_metadata_utf8(self._get_path(path, meta_path), metadata)
            logger.info("sub metadata size: " + str(len(metadata)))
            specs = self._load_spec_data_from_folder(self._get_path(path, mel_path), new_meta_, specs)
            logger.info("sub specs size: " + str(len(specs)))
            if self._config.get("with_pitch_data", False) or self._config.get("with_quantized_pitch_data", False):
                sfs, uvs = self._load_pitch_data(path, new_meta_, sfs, uvs)
            if self._config.get("with_power_data", False):
                powers = self._load_power_data(path, new_meta_)
            if self._config.get("with_tilt_data", False):
                tilts = self._load_tilt_data(path, new_meta_)
        num_examples = len(metadata)

        logger.info("total mel num: " + str(num_examples))
        logger.info("phone2idx: " + str(phone2idx))

        max_mel_len = self._config.get("max_mel_len", 1350)

        filter_out_mels = 0

        for i in range(num_examples):
            example = metadata[i]
            id = example[0]

            if id not in specs.keys():
                logger.info("missing mel for: " + id)
                continue

            mel = specs[id]
            if len(mel) > max_mel_len:
                filter_out_mels += 1
                continue

            phones = example[1].strip().split(" ")
            durs = example[4].strip().split(" ")

            num_phones = len(phones)
            phone_ids = []
            for j in range(num_phones):
                ph = phones[j].strip()
                if ph != "." and ph != "":
                    if ph in phone2idx.keys():
                        ph_id = phone2idx[ph]
                    else:
                        raise ValueError(f"{ph} is missing in phone_set.")
                    phone_ids.append(ph_id)
            xs = np.array(phone_ids, dtype=np.int64)
            ilens = len(phone_ids)

            num_durs = len(durs)
            assert num_durs == num_phones

            ph_durs = []
            for j in range(num_durs):
                dur = durs[j]
                ph_durs.append((int)(dur))
            total_frames = sum(ph_durs)
            durs = np.array(ph_durs, dtype=np.int64)
            frame_tolerance = self._config.get("frame_tolerance", 5)
            mel = self._handle_length_mismatch(mel, total_frames, frame_tolerance)
            if mel is None:
                continue
            olens = len(mel)
            example_dict = {
                "phone_id": xs,
                "phone_id_length": ilens,
                "duration": durs,
                "mel": mel,
                "mel_length": olens,
            }

            if self._config.get("with_pitch_data", False):
                f0 = sfs[id]
                uv = uvs[id]
                f0 = self._handle_length_mismatch(f0, olens, frame_tolerance)
                uv = self._handle_length_mismatch(uv, olens, frame_tolerance)
                if f0 is None or uv is None:
                    continue

                pitch_norm = self._config["pitch_norm"]
                if pitch_norm["type"] == "min_max":
                    f0_new = (f0 - pitch_norm["f0_min"]) / (pitch_norm["f0_max"] - pitch_norm["f0_min"])

                elif pitch_norm["type"] == "mean_var":
                    f0_new = (f0 - pitch_norm["f0_mean"]) / pitch_norm["f0_var"]

                phone_boundary = np.cumsum(np.pad(durs, (1, 0)))
                # Padding because the last phone has duration 0
                phone_f0 = np.add.reduceat(np.pad(f0_new, (0, 1)), phone_boundary[:-1])
                phone_f0[durs == 0] = np.min(f0_new)
                phone_f0 /= np.where(durs == 0, 1, durs)
                example_dict.update({"phone_f0": phone_f0.astype(np.float32)})
                if self._config.get("with_singing_data", False):
                    example_dict.update({"f0": f0.astype(np.float32)})
                    example_dict.update({"uv": uv.astype(np.float32)})

            if self._config.get("with_power_data", False):
                power = powers[id]
                power = self._handle_length_mismatch(power, olens, frame_tolerance)
                if power is None:
                    continue
                example_dict.update({"power": power.astype(np.float32)})
                phone_boundary = np.cumsum(np.pad(durs, (1, 0)))
                # Padding because the last phone has duration 0
                phone_power = np.add.reduceat(np.pad(power, (0, 1)),
                                              phone_boundary[:-1])
                phone_power[durs == 0] = np.min(power)
                phone_power /= np.where(durs == 0, 1, durs)
                example_dict.update({"phone_power": phone_power.astype(np.float32)})
            if self._config.get("with_tilt_data", False):
                tilt = tilts[id]
                tilt = self._handle_length_mismatch(tilt, olens, frame_tolerance)
                if tilt is None:
                    continue
                example_dict.update({"tilt": tilt.astype(np.float32)})
                phone_boundary = np.cumsum(np.pad(durs, (1, 0)))
                # Padding because the last phone has duration 0
                phone_tilt = np.add.reduceat(np.pad(tilt, (0, 1)),
                                             phone_boundary[:-1])
                phone_tilt[durs == 0] = np.min(tilt)
                phone_tilt /= np.where(durs == 0, 1, durs)
                example_dict.update({"phone_tilt": phone_tilt.astype(np.float32)})
            if self._config.get("enable_multi_speaker", False):
                speaker_ids = []
                speaker_ids.append(int(example[5]))
                speaker_ids = np.array(speaker_ids, dtype=np.int64)
                example_dict.update({"speaker_id": speaker_ids})

            syllable_durations = example[6].strip().split(" ")
            if num_phones != len(syllable_durations):
                continue
            syllable_duration_list = []
            for k in range(len(syllable_durations)):
                syllable_duration_list.append((int)(syllable_durations[k]))
            syllable_duration = np.array(syllable_duration_list, dtype=np.int64)
            example_dict.update({"syllable_duration": syllable_duration})

            note_durations = example[3].strip().split(" ")
            if num_phones != len(note_durations):
                continue
            note_duration_list = []
            for k in range(len(note_durations)):
                note_duration_list.append((int)(note_durations[k]))
            note_duration = np.array(note_duration_list, dtype=np.int64)
            example_dict.update({"note_duration": note_duration})

            note_pitchs = example[2].strip().split(" ")
            if num_phones != len(note_pitchs):
                continue
            note_pitch_list = []
            for k in range(len(note_pitchs)):
                note_pitch_list.append((int)(note_pitchs[k]))
            note_pitch = np.array(note_pitch_list, dtype=np.int64)
            example_dict.update({"note_pitch": note_pitch})

            yield f"{i:010}", example_dict

        logger.info("filter out long mel cnt: " + str(filter_out_mels))

    def _raw_data_generator(self, split, path):
        logger.info("full data path: " + str(path))

        data_partition = []
        if self._config.get('multilingual_data', False) or self._config.get('voice_attribute_data', False) or self._config.get('new_voice_data', False):
            if "*" not in path:
                if self._config.get("raw_data_root", None) is not None:
                    data_partition.append(os.path.join(self._config.get("raw_data_root"), path))
                else:
                    data_partition.append(path)
            else:
                pars = path.strip().split("*")
                for par in pars:
                    if self._config.get("raw_data_root", None) is not None:
                        data_partition.append(os.path.join(self._config.get("raw_data_root"), par))
                    else:
                        data_partition.append(par)
        else:
            if "-" not in path:
                data_partition.append(path)
            else:
                pars = path.strip().split("-")
                for par in pars:
                    data_partition.append(par)

        # add adaptation data
        if self._config.get("adaptation_data", None) is not None:
            if "*" not in self._config["adaptation_data"]:
                data_partition.append(self._config["adaptation_data"])
            else:
                pars = self._config["adaptation_data"].strip().split("*")
                for par in pars:
                    data_partition.append(par)

        logger.info("data partitions: " + str(data_partition))

        phone2idx = {}
        phone2idx["padding"] = 0
        metadata = []
        specs = {}
        speaker2idx = {}
        lang2idx = {}
        style2idx = {}
        f0s = {}
        uvs = {}
        attributes = {}
        phone_f0s = {}
        phone_es = {}

        logger.info("enable multi speaker: " + str(self._config.get("enable_multi_speaker", False)))
        logger.info("enable cross lingual: " + str(self._config.get("enable_cross_lingual", False)))
        logger.info("enable multi style: " + str(self._config.get("enable_multi_style", False)))
        logger.info("with pitch data: " + str(self._config.get("with_pitch_data", False)))
        logger.info("voice attribute data: " + str(self._config.get("voice_attribute_data", False)))
        logger.info("multilingual data: " + str(self._config.get('multilingual_data', False)))
        logger.info("use generated new voice data: " + str(self._config.get('new_voice_data', False)))

        phone_set_path = self._config.get("phone_set", None)
        meta_path = self._config.get("metadata", None)
        mel_path = self._config.get("spec_data", None)
        spkset_path = self._config.get("speaker_set", None)
        lang_path = self._config.get("lang_set", None)
        style_path = self._config.get("style_set", None)
        f0_file = self._config.get("f0_data", None)
        uv_file = self._config.get("uv_data", None)
        attribute_file = self._config.get("attribute_data", None)
        phone_f0_file = self._config.get('phone_f0_data', None)
        phone_energy_file = self._config.get('phone_energy_data', None)

        for path in data_partition:
            logger.info("loading partition: " + path)
            if os.path.exists(os.path.join(path, phone_set_path)):
                phone2idx = self._load_phone_set(self._get_path(path, phone_set_path), phone2idx)
            logger.info("cumulative phone2idx size: " + str(len(phone2idx)))
            if self._config.get('multilingual_data', False) or self._config.get('voice_attribute_data', False) or self._config.get('new_voice_data', False):
                # head format: 'wav|locale_id|speaker_id|style_id|txt|phone|phone_dur'
                metadata, new_meta_, head = self._load_voice_attri_meta(self._get_path(path, meta_path), metadata)
            else:
                metadata, new_meta_ = self._load_metadata(self._get_path(path, meta_path), metadata)
            logger.info("sub metadata size: " + str(len(new_meta_)))
            specs = self._load_spec_data(self._get_path(path, mel_path), new_meta_, specs)
            logger.info("cumulative specs size: " + str(len(specs)))

            if self._config.get('multilingual_data', False):
                f0s = self._load_f0(self._get_path(path, f0_file), f0s)
                uvs = self._load_uv(self._get_path(path, uv_file), uvs)
            elif self._config.get("voice_attribute_data", False):
                f0s = self._load_f0(self._get_path(path, f0_file), f0s)
                uvs = self._load_uv(self._get_path(path, uv_file), uvs)
                attributes = self._load_attributes(self._get_path(path, attribute_file), attributes)
            elif self._config.get('new_voice_data', False):
                phone_f0s = self._load_f0(self._get_path(path, phone_f0_file), phone_f0s)
                if phone_energy_file is not None:
                    phone_es = self._load_uv(self._get_path(path, phone_energy_file), phone_es)
                else:
                    phone_es = None
            else:
                if self._config.get("enable_multi_speaker", False):
                    speaker2idx = self._load_speaker_set(self._get_path(path, spkset_path), speaker2idx)
                    logger.info("sub speaker2idx size: " + str(len(speaker2idx)))

                if self._config.get("enable_cross_lingual", False):
                    lang2idx = self._load_lang_set(self._get_path(path, lang_path), lang2idx)
                    logger.info("sub lang2id size: " + str(len(lang2idx)))

                if self._config.get("enable_multi_style", False):
                    style2idx = self._load_style_set(self._get_path(path, style_path), style2idx)
                    logger.info("sub style2id size: " + str(len(style2idx)))

                if self._config.get("with_quantized_pitch_data", False):
                    f0s = self._load_f0(self._get_path(path, f0_file), f0s)
                    uvs = self._load_uv(self._get_path(path, uv_file), uvs)

        num_examples = len(metadata)

        if self._config.get('multilingual_data', False) or self._config.get('voice_attribute_data', False) or self._config.get('new_voice_data', False):
            logger.info("total mel num: " + str(num_examples))
            logger.info("phone2idx: " + str(phone2idx))
            logger.info("shuffle metadata for binary generation ... ...")
            random.shuffle(metadata)
        else:
            logger.info("total mel num: " + str(num_examples))
            logger.info("phone2idx: " + str(phone2idx))
            logger.info("speaker2idx: " + str(speaker2idx))
            logger.info("lang2idx: " + str(lang2idx))
            logger.info("style2idx: " + str(style2idx))

        filter_out_mels = 0
        unlabelled_spk = []

        if self._config.get('multilingual_data', False) or self._config.get('voice_attribute_data', False) or self._config.get('new_voice_data', False):
            max_mel_len = self._config.get("max_mel_len", 1200)
            for i in range(num_examples):
                example = metadata[i]
                fn = example[head.index("wav")]
                if fn[-4:] == ".npy":
                    mel_fn = fn
                    fn = os.path.splitext(fn)[0]
                else:
                    mel_fn = fn + ".npy"

                if mel_fn not in specs.keys():
                    logger.info("missing mel: " + mel_fn)
                    continue
                if not self._config.get('new_voice_data', False):
                    if fn not in f0s.keys():
                        logger.info('missing f0: ' + fn)
                        continue
                    if fn not in uvs.keys():
                        logger.info('missing uv: ' + fn)
                        continue

                mel = specs[mel_fn]
                if len(mel) > max_mel_len:
                    filter_out_mels += 1
                    continue

                olens = len(mel)

                phones = example[head.index("phone")].strip().split()
                durs = example[head.index("phone_dur")].strip().split()

                num_phones = len(phones)
                phone_ids = []
                skip = False
                for j in range(num_phones):
                    ph = phones[j].strip()
                    if ph != "." and ph != "":
                        if ph in phone2idx.keys():
                            ph_id = phone2idx[ph]
                            phone_ids.append(ph_id)
                        else:
                            # raise Exception(f"{ph} in {fn} is missing in the phone set.")
                            logger.warning(f"{ph} in {fn} is missing in the phone set.")
                            skip = True
                            break
                if skip:
                    continue

                xs = np.array(phone_ids, dtype=np.int64)
                ilens = len(phone_ids)

                num_durs = len(durs)
                if num_durs != num_phones:
                    raise Exception(f"Phone and duration length mismatch: {fn}.")

                ph_durs = []
                for j in range(num_durs):
                    dur = durs[j]
                    ph_durs.append((int)(dur))
                durs = np.array(ph_durs, dtype=np.int64)

                # process length mismath
                len_diff = olens - sum(durs)
                if abs(len_diff) > 2:
                    logger.info(
                        f"Skip the data {fn} with duration and mel length difference greater than 2: \
                                {sum(durs)} vs. {olens}"
                    )
                    continue
                else:
                    if len_diff > 0:
                        olens = sum(durs)
                        mel = mel[:olens]
                    elif len_diff < 0:
                        if durs[-1] > abs(len_diff):
                            durs[-1] -= abs(len_diff)
                        elif durs[-1] == 0 and durs[-2] >= abs(len_diff):
                            durs[-2] -= abs(len_diff)
                        elif durs[-1] == 0 and durs[-2] == 0 and durs[-3] >= abs(len_diff):
                            durs[-3] -= abs(len_diff)
                        else:
                            logger.info(
                                f"Skip the data {fn} with different duration and mel length: \
                                        {sum(durs)} vs. {olens}"
                            )
                            continue

                example_dict = {
                    "phone_id": xs,
                    "phone_id_length": ilens,
                    "duration": durs,
                    "mel": mel,
                    "mel_length": olens,
                }

                if example_dict['mel_length'] != sum(example_dict['duration']):
                    logger.warning(
                        f'Different mel and duration length for {fn}: \
                            {example_dict["mel_length"]} vs. {sum(example_dict["duration"])}'
                    )

                if self._config.get('new_voice_data', False):
                    example_dict.update({'phone_f0': phone_f0s[fn]})
                    example_dict.update({'phone_e': phone_es[fn]})
                    assert len(example_dict['phone_f0']) == len(example_dict['phone_e'])
                    assert len(example_dict['duration']) == len(example_dict['phone_e'])
                else:
                    example_dict.update({"f0": f0s[fn]})
                    example_dict.update({"uv": uvs[fn]})
                    # process length mismatch
                    assert len(example_dict["f0"]) == len(example_dict["uv"])
                    if example_dict["mel_length"] != len(example_dict["f0"]):
                        len_diff = example_dict["mel_length"] - len(example_dict["f0"])
                        for _tmp in range(len_diff):
                            example_dict["f0"] = np.append(example_dict["f0"], example_dict["f0"][-1])
                            example_dict["uv"] = np.append(example_dict["uv"], example_dict["uv"][-1])
                        if len_diff < 0:
                            example_dict["f0"] = example_dict["f0"][:olens]
                            example_dict["uv"] = example_dict["uv"][:olens]
                    if example_dict["mel_length"] != len(example_dict["f0"]):
                        logger.warning(
                            f'Different mel and f0 length for {fn}: \
                                       {example_dict["mel_length"]} vs. {len(example_dict["f0"])}'
                        )
                    # attributes default order:
                    # gender|age|pitch_level|speaking_rate|soft|sweet|resonant|clear|husky|upbeat|deep|authority|comfort|warm
                    if self._config.get('voice_attribute_data', False):
                        spk_name = fn.split('_')[0]
                        if self._config.get('semi_supervised_training', False):
                            if spk_name in attributes:
                                example_dict.update({'attributes': attributes[spk_name]})
                                example_dict.update({'with_attri_label': np.float32(1)})
                            else:
                                if spk_name not in unlabelled_spk:
                                    unlabelled_spk.append(spk_name)
                                    logger.warning(f'Attribute-unlabelled speaker: {spk_name}.')
                                example_dict.update({'attributes': np.ones(len(list(attributes.values())[0]), dtype=np.float32)})
                                # attributes will be rescale to zeros in _data_pipeline().
                                example_dict.update({'with_attri_label': np.float32(0)})
                        else:
                            example_dict.update({'attributes': attributes[spk_name]})

                example_dict.update({"speaker_id": np.int64(example[head.index("speaker_id")])})
                example_dict.update({"locale_id": np.int64(example[head.index("locale_id")])})
                example_dict.update({"style_id": np.int64(example[head.index("style_id")])})

                yield f"{i:010}", example_dict
        else:
            idx = -1
            frame_tolerance = self._config.get("frame_tolerance", 5)
            for i in range(num_examples):
                idx += 1
                if idx % 5000 == 0:
                    logger.info("processing: " + str(idx))

                example = metadata[i]
                id = example[0]

                if id not in specs.keys():
                    logger.info("missing mel for: " + id)
                    continue

                mel = specs[id]

                phones = example[3].strip().split(" ")
                durs = example[4].strip().split(" ")

                num_phones = len(phones)
                phone_ids = []
                for j in range(num_phones):
                    ph = phones[j].strip()
                    if ph != "." and ph != "":
                        if ph in phone2idx.keys():
                            ph_id = phone2idx[ph]
                        else:
                            raise ValueError(f"{ph} is missing in phone_set.")
                        phone_ids.append(ph_id)
                xs = np.array(phone_ids, dtype=np.int64)
                ilens = len(phone_ids)

                num_durs = len(durs)
                assert num_durs == num_phones

                ph_durs = []
                for j in range(num_durs):
                    dur = durs[j]
                    ph_durs.append((int)(dur))
                durs = np.array(ph_durs, dtype=np.int64)

                total_frames = sum(ph_durs)
                mel = self._handle_length_mismatch(mel, total_frames, frame_tolerance)
                if mel is None:
                    continue
                olens = len(mel)
                example_dict = {
                    "phone_id": xs,
                    "phone_id_length": ilens,
                    "duration": durs,
                    "mel": mel,
                    "mel_length": olens,
                }
                if self._config.get("with_quantized_pitch_data", False):
                    f0s_id = self._handle_length_mismatch(f0s[id], total_frames, frame_tolerance)
                    uvs_id = self._handle_length_mismatch(uvs[id], total_frames, frame_tolerance)
                    if f0s_id is None or uvs_id is None:
                        continue
                    quantized_f0 = self._hierarchical_onehot(
                        f0s_id * uvs_id, quantization_channels=256, f0_mean=self._config["pitch_norm"]["f0_mean"]
                    )
                    example_dict.update({"quantized_f0": quantized_f0})

                    pitch_norm = self._config["pitch_norm"]
                    if pitch_norm["type"] == "min_max":
                        f0s_id = (f0s_id - pitch_norm["f0_min"]) / (pitch_norm["f0_max"] - pitch_norm["f0_min"])

                    elif pitch_norm["type"] == "mean_var":
                        f0s_id = (f0s_id - pitch_norm["f0_mean"]) / pitch_norm["f0_var"]
                    example_dict.update({"f0": f0s_id})
                    example_dict.update({"uv": uvs_id})

                if self._config.get("with_pitch_data", False):
                    f0s = example[5].strip().split(" ")
                    f0_list = []
                    for k in range(len(f0s)):
                        f0_list.append((float)(f0s[k]))
                    f0 = np.array(f0_list, dtype=np.float32)
                    if self._config.get("load_fastspeech", False):
                        example_dict.update({"f0": f0})
                        example_dict.update({"uv": f0})
                    else:
                        example_dict.update({"phone_f0": f0})

                if self._config.get("enable_multi_speaker", False):
                    speaker_ids = []
                    if id.split("_")[0] in speaker2idx.keys():
                        speaker_ids.append(speaker2idx[id.split("_")[0]])
                    else:
                        speaker_ids.append(speaker2idx["_".join(id.split("_")[:-1])])
                    speaker_ids = np.array(speaker_ids, dtype=np.int64)
                    if self._config.get("load_fastspeech", False):
                        speaker_ids = speaker_ids.squeeze(-1)
                    example_dict.update({"speaker_id": speaker_ids})

                if self._config.get("enable_cross_lingual", False):
                    lang_ids = []
                    lang_ids.append(lang2idx[example[1]])
                    lang_ids = np.array(lang_ids, dtype=np.int64)
                    if self._config.get("load_fastspeech", False):
                        lang_ids = lang_ids.squeeze(-1)
                    example_dict.update({"locale_id": lang_ids})

                if self._config.get("enable_multi_style", False):
                    style_ids = []
                    style_ids.append(style2idx[example[2]])
                    style_ids = np.array(style_ids, dtype=np.int64)
                    if self._config.get("load_fastspeech", False):
                        style_ids = style_ids.squeeze(-1)
                    example_dict.update({"style_id": style_ids})

                yield f"{i:010}", example_dict

        logger.info("filter out long mel cnt: " + str(filter_out_mels))

    def _data_pipeline(self, data_pipe, shuffle=True):
        max_mel_len = self._config.get("max_mel_len", None)
        if max_mel_len is not None:
            data_pipe = data_pipe.filter(self._filter_mel_len, fn_kwargs={"max_mel_len": max_mel_len})

        # filter the data with only zero pitch
        if self._config.get("filter_zero_pitch_data", False):
            data_pipe = data_pipe.filter(self._filter_zero_pitch)

        # filter by locale IDs
        filter_locale_id = self._config.get('filter_locale_id', None)
        if filter_locale_id is not None:
            locale_id_list = list(map(int, str(filter_locale_id).split('-')))
            data_pipe = data_pipe.filter(self._filter_locale_id, fn_kwargs={'locale_id_list': locale_id_list})

        # balance training
        if self._config.get('balanced_training', False):
            stats = self.balanced_training_stats(
                self._config.get('stats_file', ''),
                self._config.get('loc_scale_ratio', 0.6),
                self._config.get('spk_scale_ratio', 0.6),
                self._config.get('change_spk_prob', False),
                self._config.get('tgt_spk_ids', '-1'),
                self._config.get('tgt_spk_probs', '0.25'),
                self._config.get('change_locale_prob', False),
                self._config.get('tgt_loc_ids', '-1'),
                self._config.get('tgt_loc_probs', '0.25'),
            )
            data_pipe = data_pipe.filter(self.filter_fn_balanced_training, fn_kwargs={'stats': stats})

        # using objective attributes
        if self._config.get("use_obj_attri", False):
            if self._config.get("phone_set_path", None) is not None:
                # to be consistant with binary data generation
                self.phone2idx = self._load_phone_set(self._config.get("phone_set_path", None), dict({"padding": 0}))
            else:
                raise Exception("Please specify the phone set path.")
            # silence phone index
            sil_phone_lst = ["br0", "br1", "br2", "br3", "br4", "-BOS-", "-sil-", "<bos>", "<eos>", "-", "/"]
            sil_lst = sil_phone_lst.copy()
            sil_lst += [ph for ph in self.phone2idx.keys() if "punc" in ph and ph not in sil_lst]
            sil_ids = [self.phone2idx[ph] for ph in sil_lst]
            logger.info(f"{sil_lst}, {sil_ids}")
            self.idx2phone = {v: k for k, v in self.phone2idx.items()}
            # utterance-level speaking rate
            data_pipe = data_pipe.map(
                self._add_spk_rate_and_energy_level,
                fn_kwargs={
                    "sil_ids": sil_ids,
                    "idx2phone": self.idx2phone if self._config.get("debug_mode", False) else None,
                },
            )
            # utterance-level frame pitch level (pitch average over frames)
            if not self._config.get("use_phone_pitch_level", False):
                data_pipe = data_pipe.map(
                    self._add_frame_pitch_level, fn_kwargs={"debug_mode": self._config.get("debug_mode", False)}
                )

        if self._config.get('multilingual_data', False) or self._config.get('voice_attribute_data', False):
            # normalize pitch data
            pitch_norm = self._config["pitch_norm"]
            if pitch_norm["type"] == "min_max":
                data_pipe = data_pipe.map(
                    self._min_max_normalize,
                    fn_kwargs={"f0_min": pitch_norm["f0_min"], "f0_max": pitch_norm["f0_max"]}
                )
            elif pitch_norm["type"] == "mean_var":
                data_pipe = data_pipe.map(
                    self._mean_var_normalize,
                    fn_kwargs={"f0_mean": pitch_norm["f0_mean"], "f0_var": pitch_norm["f0_var"]},
                )
            else:
                raise ValueError("'pitch_norm' type should be 'min_max' or 'mean_var'!")

            # phone pitch
            data_pipe = data_pipe.map(self._add_phone_pitch)
            if self._config.get('voice_attribute_data', False) and self._config.get('use_obj_attri', False) and self._config.get('use_phone_pitch_level', False):
                # pitch average over phones
                data_pipe = data_pipe.map(
                    self._add_phone_pitch_level,
                    fn_kwargs={
                        "f0_mean": pitch_norm["f0_mean"],
                        "f0_var": pitch_norm["f0_var"],
                        "sil_ids": sil_ids,
                        "debug_mode": self._config.get("debug_mode", False),
                    },
                )

            data_pipe = data_pipe.map(self._add_phone_energy)
            # rescale the attributes scores [0, 2] -> [-1, 1]
            if self._config.get('voice_attribute_data', False):
                data_pipe = data_pipe.map(self._rescale_attri_value)
        elif self._config.get('new_voice_data', False):
            if self._config.get('use_inferred_energy', False):
                data_pipe = data_pipe.map(self._use_inferred_phone_energy)
            else:
                data_pipe = data_pipe.map(self._add_phone_energy)

        if self._config.get("speech_inpainting", False):
            if self._config.get("phone_set_path", None) is not None:
                self.phone2idx = self._load_phone_set(self._config.get("phone_set_path", None), dict({"padding": 0}))
            else:
                raise Exception("Please specify the phone set path.")
            self.idx2phone = {v: k for k, v in self.phone2idx.items()}
            data_pipe = data_pipe.map(self._get_training_pair_inpainting, fn_kwargs={"idx2phone": self.idx2phone})

        if shuffle:
            data_pipe = data_pipe.shuffle(buffer_size=100)

        # filter by speaker id
        filter_speaker_id = self._config.get("filter_speaker_id", None)
        if filter_speaker_id is not None:
            speaker_id_list = list(map(int, str(filter_speaker_id).split("-")))
            data_pipe = data_pipe.filter(self._filter_speaker_id, fn_kwargs={"speaker_id_list": speaker_id_list})

        filter_style_id = self._config.get("filter_style_id", None)
        if filter_style_id is not None:
            style_id_list = list(map(int, str(filter_style_id).split("-")))
            data_pipe = data_pipe.filter(self._filter_style_id, fn_kwargs={"style_id_list": style_id_list})

        if self._config.get("load_fastspeech", False):
            pitch_norm = self._config["pitch_norm"]
            data_pipe = data_pipe.map(
                self._mean_var_normalize, fn_kwargs={"f0_mean": pitch_norm["f0_mean"], "f0_var": pitch_norm["f0_var"]}
            )

        if self._config.get("load_fastspeech", False):
            data_pipe = data_pipe.map(self._add_phone_pitch)

        batch_size = self._config.get("batch_size", 6000)
        bucket_step = self._config.get("bucket_step", 1.1)
        bucket_scheme = get_bucket_scheme(batch_size, 8, bucket_step)
        data_pipe = data_pipe.dynamic_batch(
            group_key_fn=self.get_frames,
            bucket_boundaries=bucket_scheme["boundaries"],
            batch_sizes=bucket_scheme["batch_sizes"],
        )

        if shuffle:
            data_pipe = data_pipe.shuffle(buffer_size=32)

        if self._config.get('multilingual_data', False) or self._config.get('voice_attribute_data', False):
            data_pipe = data_pipe.collate(
                fn_kwargs={
                    "padding_axes": {
                        "phone_id": -1,
                        "duration": -1,
                        "mel": 0,
                        "f0": 0,
                        "uv": 0,
                        "phone_f0": 0,
                        "phone_energy": 0,
                    },
                    "padding_values": {
                        "phone_id": 0,
                        "duration": 0,
                        "mel": -4.0,
                        "f0": 0.0,
                        "uv": 0.0,
                        "phone_f0": 0.0,
                        "phone_energy": 0.0,
                    },
                }
            )
        elif self._config.get('new_voice_data', False):
            data_pipe = data_pipe.collate(
                fn_kwargs={
                    'padding_axes': {
                        'phone_id': -1,
                        'duration': -1,
                        'mel': 0,
                        'phone_f0': 0,
                        'phone_e': 0,
                        'phone_energy': 0,
                    },
                    'padding_values': {
                        'phone_id': 0,
                        'duration': 0,
                        'mel': -4.0,
                        'phone_f0': 0.0,
                        'phone_e': 0.0,
                        'phone_energy': 0.0,
                    },
                }
            )
        elif self._config.get("load_fastspeech", False):
            data_pipe = data_pipe.collate(
                fn_kwargs={
                    "padding_axes": {
                        "phone_id": -1,
                        "duration": -1,
                        "mel": 0,
                        "f0": 0,
                        "uv": 0,
                        "phone_f0": 0,
                    },
                    "padding_values": {
                        "phone_id": 0,
                        "duration": 0,
                        "mel": -4.0,
                        "f0": 0,
                        "uv": 0.0,
                        "phone_f0": 0,
                    },
                }
            )
        elif self._config.get("speech_inpainting", False):
            data_pipe = data_pipe.collate(
                fn_kwargs={
                    "padding_axes": {"phone_id": -1, "duration": -1, "phone_f0": 0, "mel": 0, "ref": 0},
                    "padding_values": {"phone_id": 0, "duration": 0, "phone_f0": 0, "mel": -4.0, "ref": -4.0},
                }
            )
        elif self._config.get("with_singing_data", False):
            data_pipe = data_pipe.collate(
                fn_kwargs={
                    "padding_axes": {
                        "phone_id": -1,
                        "duration": -1,
                        "phone_f0": 0,
                        "f0": 0,
                        "quantized_f0": 0,
                        "uv": 0,
                        "power": 0,
                        "tilt": 0,
                        "phone_power": 0,
                        "phone_tilt": 0,
                        "mel": 0,
                        "syllable_duration": -1,
                        "note_duration": -1,
                        "note_pitch": -1,
                    },
                    "padding_values": {
                        "phone_id": 0,
                        "duration": 0,
                        "phone_f0": 0,
                        "f0": 0.0,
                        "quantized_f0": 0,
                        "uv": 0.0,
                        "power": 0.0,
                        "tilt": 0.0,
                        "phone_power": 0.0,
                        "mel": -4.0,
                    },
                }
            )
        else:
            data_pipe = data_pipe.collate(
                fn_kwargs={
                    "padding_axes": {"phone_id": -1, "duration": -1, "phone_f0": 0, "mel": 0},
                    "padding_values": {"phone_id": 0, "duration": 0, "phone_f0": 0, "mel": -4.0},
                }
            )
        return data_pipe

    @staticmethod
    def _add_phone_pitch(data):
        if data["f0"].shape[0] == data["duration"].shape[0]:
            data["phone_f0"] = data["f0"].astype(np.float32)
        else:
            duration = data["duration"]
            phone_boundary = np.cumsum(np.pad(duration, (1, 0)))
            # Padding because the last phone has duration 0
            phone_f0 = np.add.reduceat(np.pad(data["f0"], (0, 1)), phone_boundary[:-1])
            phone_f0[duration == 0] = np.min(data["f0"])
            phone_f0 /= np.where(duration == 0, 1, duration)
            data["phone_f0"] = phone_f0.astype(np.float32)
        return data

    @staticmethod
    def _filter_mel_len(data, max_mel_len):
        return bool(data["mel_length"] < max_mel_len)

    @staticmethod
    def _filter_speaker_id(data, speaker_id_list):
        return int(data["speaker_id"]) in speaker_id_list

    @staticmethod
    def _filter_locale_id(data, locale_id_list):
        return int(data['locale_id']) in locale_id_list

    @staticmethod
    def _min_max_normalize(data, f0_min, f0_max):
        data["f0"] = (data["f0"] - f0_min) / (f0_max - f0_min)
        return data

    @staticmethod
    def _mean_var_normalize(data, f0_mean, f0_var):
        if data["f0"].shape[0] != data["duration"].shape[0]:
            data["f0"] = (data["f0"] - f0_mean) / f0_var
        return data

    @staticmethod
    def get_frames(x):
        return x["mel_length"]

    @staticmethod
    def _filter_style_id(data, style_id_list):
        return int(data["style_id"]) in style_id_list

    @staticmethod
    def _filter_zero_pitch(data):
        return bool(data["uv"].sum() > 0)

    @staticmethod
    def _get_training_pair_inpainting(data, idx2phone):
        def check_phone_locale(phone):
            if len(phone) > len("en-us_") and phone[2] == "-" and phone[5] == "_":
                return phone[:5]
            else:
                return None

        x = data["phone_id"]
        xlen = data["phone_id_length"]
        y = data["mel"]
        d = data["duration"]
        words = []
        sid = -1
        eid = -1
        for i, ix in enumerate(x):
            ix = int(ix)
            if idx2phone[ix] == "-" or check_phone_locale(idx2phone[ix]) is not None:
                if sid < 0:
                    sid = i
                    eid = i
                else:
                    eid = i
            else:
                if sid >= 0 and eid >= 0 and eid >= sid:
                    words.append([sid, eid])
                    sid = -1
                    eid = -1
        if len(words) == 0:
            print("len(words) should not be 0, pls check:", [idx2phone[ix] for ix in x])
            tgtxseq = [1, xlen - 2]
        else:
            i = random.sample(range(len(words)), 1)[0]
            # br1 first
            word = words[i]
            sid = word[0]
            eid = word[1]
            tgtxseq = [sid, eid]
        cumd = np.cumsum(d, axis=-1)
        sid = cumd[tgtxseq[0] - 1]
        eid = cumd[tgtxseq[1]]
        short_y = np.concatenate((y[:sid, :], y[eid + 1 :, :]))
        sylen = np.shape(short_y)[0]
        tgtyseq = [sid, eid]

        data["tgtyseq"] = np.array(tgtyseq)
        data["tgtxseq"] = np.array(tgtxseq)
        data["ref"] = short_y
        data["ref_olen"] = sylen
        data["duration"][tgtxseq[1]] += 1
        data["duration"][tgtxseq[1] + 1] -= 1
        return data

    def balanced_training_stats(self, stats_fn, loc_scale_ratio, spk_scale_ratio, change_spk_prob=False, tgt_spk_ids='-1',
                                tgt_spk_probs='0.25', change_locale_prob=False, tgt_loc_ids='-1', tgt_loc_probs='0.25'):
        if not os.path.isfile(stats_fn):
            raise Exception(f'Cannot find the data statistics file for data balanced training: {stats_fn}')
        with open(stats_fn, 'r') as pf:
            stats_dic = json.load(pf)
        # stats_dic format:
        # {
        #     loc_id: {
        #         'spk_id_list': [],
        #         'spk_utt_num': [],    ### not used
        #         'spk_prob': []
        #     },
        #     'loc_id_list': [],
        #     'loc_utt_num': [],        ### not used
        #     'loc_prob': []
        # }

        # speaker-balanced training
        cur_loc_prob = np.array(stats_dic['loc_prob']) / sum(stats_dic['loc_prob'])
        for loc_ in stats_dic['loc_id_list']:
            loc = str(loc_)
            stats_dic[loc]['spk_prob'] = np.array(stats_dic[loc]['spk_prob']) / sum(stats_dic[loc]['spk_prob'])
            stats_dic[loc]['spk_prob_new'] = stats_dic[loc]['spk_prob']**spk_scale_ratio \
                / sum(stats_dic[loc]['spk_prob']**spk_scale_ratio)

            # change prob for target speakers
            if change_spk_prob:
                tgt_spk_id_lst = [int(i) for i in tgt_spk_ids.split('*')]
                tgt_spk_prob_lst = [float(i) for i in tgt_spk_probs.split('*')]

                spk_lst = [spk for spk in tgt_spk_id_lst if spk in stats_dic[loc]['spk_id_list']]
                if len(spk_lst) > 0:
                    cur_loc_spk_probs = stats_dic[loc]['spk_prob_new']
                    cur_loc_spk_ids = stats_dic[loc]['spk_id_list']
                    sum_cur_prob = sum([cur_loc_spk_probs[cur_loc_spk_ids.index(spk)] for spk in spk_lst])
                    sum_tgt_prob = sum([tgt_spk_prob_lst[tgt_spk_id_lst.index(spk)] for spk in spk_lst])
                    stats_dic[loc]['spk_prob_new'] = stats_dic[loc]['spk_prob_new'] * (1.0 - sum_tgt_prob) / (1.0 - sum_cur_prob)
                    for spk in spk_lst:
                        prob = tgt_spk_prob_lst[tgt_spk_id_lst.index(spk)]
                        stats_dic[loc]['spk_prob_new'][stats_dic[loc]['spk_id_list'].index(spk)] = prob

            stats_dic[loc]['spk_sample_ratio'] = stats_dic[loc]['spk_prob_new'] / stats_dic[loc]['spk_prob']
            stats_dic[loc]['spk_sample_ratio'] /= max(stats_dic[loc]['spk_sample_ratio'])
            logger.info(f'Speaker IDs: {stats_dic[loc]["spk_id_list"]}')
            logger.info(f'Scaled speaker prob: {stats_dic[loc]["spk_prob_new"]}')
            logger.info(f'Speaker sampling ratio: {stats_dic[loc]["spk_sample_ratio"]}')

            loc_idx = stats_dic['loc_id_list'].index(loc_)
            cur_loc_prob[loc_idx] *= sum(stats_dic[loc]['spk_prob'] * stats_dic[loc]['spk_sample_ratio'])
        # locale-balanced training
        stats_dic['loc_prob'] = np.array(stats_dic['loc_prob']) / sum(stats_dic['loc_prob'])
        stats_dic['loc_prob_new'] = stats_dic['loc_prob']**loc_scale_ratio / sum(stats_dic['loc_prob']**loc_scale_ratio)

        # change prob for locale
        if change_locale_prob:
            tgt_loc_id_lst = [int(i) for i in tgt_loc_ids.split('*')]
            tgt_loc_prob_lst = [float(i) for i in tgt_loc_probs.split('*')]
            sum_tgt_prob = sum(tgt_loc_prob_lst)
            sum_cur_prob = sum([stats_dic['loc_prob_new'][stats_dic['loc_id_list'].index(i)] for i in tgt_loc_id_lst])
            stats_dic['loc_prob_new'] = stats_dic['loc_prob_new'] * (1.0 - sum_tgt_prob) / (1.0 - sum_cur_prob)
            for i in range(len(tgt_loc_id_lst)):
                stats_dic['loc_prob_new'][stats_dic['loc_id_list'].index(tgt_loc_id_lst[i])] = tgt_loc_prob_lst[i]

        # as the speaker sampling change the overall local probabilties, the new local prob (cur_loc_prob) is used.
        stats_dic['loc_sample_ratio'] = stats_dic['loc_prob_new'] / cur_loc_prob
        stats_dic['loc_sample_ratio'] /= max(stats_dic['loc_sample_ratio'])
        logger.info(f'Locale IDs: {stats_dic["loc_id_list"]}')
        logger.info(f'Scaled locale prob: {stats_dic["loc_prob_new"]}')
        logger.info(f'Locale sampling ratio: {stats_dic["loc_sample_ratio"]}')
        # get stats
        stats = {}
        stats['loc_dic'] = dict(zip(stats_dic['loc_id_list'], stats_dic['loc_sample_ratio']))
        for loc_ in stats_dic['loc_id_list']:
            loc = str(loc_)
            stats[loc_] = dict(zip(stats_dic[loc]['spk_id_list'], stats_dic[loc]['spk_sample_ratio']))
        return stats

    @staticmethod
    def filter_fn_balanced_training(data, stats):
        loc = data["locale_id"]
        spk = data["speaker_id"]
        random_loc = np.random.uniform(0.0, 1.0)
        random_spk = np.random.uniform(0.0, 1.0)
        loc_ratio = stats["loc_dic"][int(loc)]
        spk_ratio = stats[int(loc)][int(spk)]
        res = bool(bool(random_loc < loc_ratio) and bool(random_spk < spk_ratio))
        return res

    @staticmethod
    def _add_spk_rate_and_energy_level(data, sil_ids, idx2phone):
        phones = data["phone_id"]
        pho_len = len(phones)
        data["spk_rate"] = np.array(
            [(1.0 / np.mean([data["duration"][i] for i in range(pho_len) if phones[i] not in sil_ids]) - 0.16) / 0.094],
            dtype=np.float32,
        )  # normalized
        # energy level
        a = [True if ph not in sil_ids else False for ph in phones]  # non silence phones
        b = data["duration"]
        nonsil = [a[i] for i in range(pho_len) for j in range(b[i])]  # non silence frames
        nonsil_mel = data["mel"][nonsil]
        data["energy_level"] = np.array([(nonsil_mel.mean() - 0.6) / 0.9], dtype=np.float32)  # normalized
        if idx2phone is not None:
            logger.info(f'speaker_id: {data["speaker_id"]}')
            logger.info(f"phones: {[idx2phone[ph] for ph in phones]}")
            logger.info(f"silence phones: {[idx2phone[phones[i]] for i in range(pho_len) if phones[i] in sil_ids]}")
            logger.info(f'spk_rate:, {data["spk_rate"]}, energy_level:, {data["energy_level"]}')
        return data

    @staticmethod
    def _add_frame_pitch_level(data, debug_mode=False):
        data["pitch_level"] = np.array(
            [(np.mean(data["f0"][np.nonzero(data["uv"])]) - 225) / 148], dtype=np.float32
        )  # normalized
        if debug_mode:
            logger.info(f'frame pitch level: {data["pitch_level"]}')
        return data

    @staticmethod
    def _add_phone_pitch_level(data, f0_mean, f0_var, sil_ids, debug_mode=False):
        phones = data["phone_id"]
        nonsil = [True if ph not in sil_ids else False for ph in phones]
        data["pitch_level"] = np.array(
            [(data["phone_f0"][nonsil].mean() * f0_var + f0_mean - 225) / 148], dtype=np.float32
        )  # re-normalize
        if debug_mode:
            logger.info(f'phone pitch level: {data["pitch_level"]}, {data["pitch_level"]*148 + 225}')
            frame_pitch_level = np.array(
                [np.mean(data["f0"][np.nonzero(data["uv"])]) * f0_var + f0_mean], dtype=np.float32
            )
            logger.info(f"frame pitch level: {frame_pitch_level}")
        return data

    @staticmethod
    def _add_phone_energy(data):
        duration = data["duration"]
        phone_boundary = np.cumsum(np.pad(duration, (1, 0)))
        # Padding because the last phone has duration 0
        pmel = data["mel"].mean(-1)
        phone_energy = np.add.reduceat(np.pad(pmel, (0, 1)), phone_boundary[:-1])
        phone_energy[duration == 0] = np.min(pmel)
        phone_energy /= np.where(duration == 0, 1, duration)
        data["phone_energy"] = phone_energy.astype(np.float32)
        return data

    @staticmethod
    def _use_inferred_phone_energy(data):
        data["phone_energy"] = data["phone_e"]
        return data

    @staticmethod
    def _rescale_attri_value(data):
        data["attributes"] -= 1.0
        return data

    @staticmethod
    def _mu_law_encode(audio, quantization_channels, shifted=True):
        """Quantizes waveform amplitudes."""
        mu = quantization_channels - 1
        # Perform mu-law companding transformation (ITU-T, 1988).
        magnitude = np.log(1 + mu * np.absolute(audio)) / np.log(1.0 + mu)
        signal = np.sign(audio) * magnitude
        # Quantize signal to the specified number of levels.
        if shifted:
            return np.int32((signal + 1) / 2 * mu + 0.5)
        else:
            return np.int32(signal * mu + 0.5)

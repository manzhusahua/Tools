import csv
import os
import json
import re

import numpy as np
import logging
from pathlib import Path

from torchtts.data.core import features
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder
from torchtts.data.core.dataset_info import DatasetInfo
from torchtts.utils.data_utils import get_bucket_scheme


logger = logging.getLogger(__name__)


class DistilPhoneDataset(GeneratorBasedBuilder):
    LOCALE_PREFIX_WHITELIST = re.compile(r"^(<s>|</s>|-|sil|br[0-4]|t[1-6])$|^punc")

    def _info(self):
        feature_dict = {
            "phone_id": features.Tensor(shape=(None,), dtype=np.int64),
            "speaker_id": features.Tensor(shape=(), dtype=np.int64),
            "locale_id": features.Tensor(shape=(), dtype=np.int64),
            "style_id": features.Tensor(shape=(), dtype=np.int64),
        }

        return DatasetInfo(
            builder=self, description="FastSpeech dataset builder", features=features.FeaturesDict(feature_dict)
        )

    def _split_generators(self):
        path = self._config.get("raw_data", None)
        if path is None:
            raise ValueError("You should specify raw_data in dataset builder")
        return {k: self._raw_data_generator(split=v, path=Path(path)) for k, v in self.split_type.items()}

    def _raw_data_generator(self, split, path: Path):
        # Map to id for training example:
        # {
        # "<pad>":0,
        # "~":1,
        # "en-cn_k":2,
        # ...}
        with open(os.path.join(path, "phone_tf.json"), "r", encoding="utf-8") as f:
            phone_set = json.load(f)
        max_phone_id = max(phone_set.values())

        add_locale_prefix = self._config.get("add_locale_prefix", False)

        # metadata format example:
        # speaker_id|locale_id|style_id|phone
        # 283|5|0|-bos- br0 en-us_ih1 en-us_t en-us_s en-us_br4 en-us_punc. ~
        metadata_file = os.path.join(path, "metadata_phone.csv")
        sid = 0
        with open(metadata_file, "r", newline="", encoding="utf-8") as meta_f:
            metadata_reader = csv.DictReader(meta_f, delimiter="|")
            for metadata in metadata_reader:
                phone_id = []
                for p in metadata["phone"].split():
                    if add_locale_prefix:
                        if self.LOCALE_PREFIX_WHITELIST.match(p):
                            phone = p
                        else:
                            phone = f"{metadata['locale']}_{p}"
                    else:
                        phone = p
                    # Automatically insert incremental phone id to phone set
                    p_id = phone_set.get(phone, None)
                    if p_id is None:
                        max_phone_id += 1
                        p_id = max_phone_id
                        phone_set[phone] = p_id
                        logger.warning(f"Missing phone {phone} in phone set, set that to {p_id} automatically")
                    phone_id.append(p_id)

                sid += 1
                speaker_id = metadata["speaker_id"]
                locale_id = metadata["locale_id"]
                style_id = metadata["style_id"]

                # Generate a unique sid
                example_id = f"{locale_id}_{speaker_id}_{style_id}_{sid}"
                yield example_id, {
                    "phone_id": phone_id,
                    "speaker_id": speaker_id,
                    "locale_id": locale_id,
                    "style_id": style_id,
                }

    def _data_pipeline(self, datapipe, shuffle=True):
        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=100)

        # filter by locale id
        if self._config.get("filter_locale_id", None):
            locale_str = self._config["filtered_locale"]
            locale_id_list = list(map(int, str(locale_str).split("-")))
            datapipe = datapipe.filter(self._filter_locale_id, fn_kwargs={"locale_id_list": locale_id_list})

        # filter by speaker id
        filter_speaker_id = self._config.get("filter_speaker_id", None)
        if filter_speaker_id is not None:
            speaker_id_list = list(map(int, str(filter_speaker_id).split("-")))
            datapipe = datapipe.filter(self._filter_speaker_id, fn_kwargs={"speaker_id_list": speaker_id_list})

        # filter by style id
        filter_style_id = self._config.get("filter_style_id", None)
        if filter_style_id is not None:
            style_id_list = list(map(int, str(filter_style_id).split("-")))
            logger.info(f"This run will only train style id in {style_id_list}")
            datapipe = datapipe.filter(self._filter_style_id, fn_kwargs={"style_id_list": style_id_list})

        # Data balance
        if self._config.get("balance_training", None):
            speaker_str = self._config["filtered_speaker"]
            balance_ratio = self._config["balance_ratio"]
            datapipe = datapipe.filter(
                self._balance_training, fn_kwargs={"speaker_id": speaker_str, "balance_ratio": balance_ratio}
            )

        # Add length info before batch and padding
        datapipe = datapipe.map(self._add_length)

        # Dynamic batching with bucket
        batch_size = self._config.get("batch_size", 6000)
        bucket_step = self._config.get("bucket_step", 1.1)
        bucket_scheme = get_bucket_scheme(batch_size, 8, bucket_step)
        datapipe = datapipe.dynamic_batch(
            group_key_fn=self.get_phn_length,
            bucket_boundaries=bucket_scheme["boundaries"],
            batch_sizes=bucket_scheme["batch_sizes"],
        )

        # Shuffle on batch
        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=32)

        # Apply padding and then convert to pytorch tensor
        datapipe = datapipe.collate(fn_kwargs={"padding_axes": {"phone_id": -1}, "padding_values": {"phone_id": 0}})
        return datapipe

    @staticmethod
    def _filter_speaker_id(data, speaker_id_list):
        return int(data["speaker_id"]) in speaker_id_list

    @staticmethod
    def _filter_style_id(data, style_id_list):
        return int(data["style_id"]) in style_id_list

    @staticmethod
    def _balance_training(data, speaker_id, balance_ratio):
        rand = np.random.random_sample()

        if int(data["speaker_id"]) != speaker_id:
            if rand <= balance_ratio:
                return False
        return True

    @staticmethod
    def _filter_locale_id(data, locale_id_list):
        return int(data["locale_id"]) in locale_id_list

    @staticmethod
    def _add_length(data):
        data["phone_id_length"] = len(data["phone_id"])
        return data

    @staticmethod
    def get_phn_length(data):
        return data["phone_id_length"]

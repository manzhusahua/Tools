import os
import itertools
import numpy as np
import librosa
import logging

from torchtts.data.core import features
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder
from torchtts.data.core.dataset_info import DatasetInfo
from torchtts.utils.data_utils import get_bucket_scheme
from torchtts.utils.data_zeroshot_utils import shuffle_mel_by_frame
from torchtts.utils.import_utils import _TENSORFLOW_AVAILABLE


logger = logging.getLogger(__name__)


if _TENSORFLOW_AVAILABLE:
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
    import tensorflow as tf


class FastSpeechDataset(GeneratorBasedBuilder):
    DEFAULT_TFRECORD_PATTERN = "unified_speech_problem-train-*"

    def _info(self):
        feature_dict = {
            "phone_id": features.Tensor(shape=(None,), dtype=np.int64),
            "phone_id_length": features.Tensor(shape=(), dtype=np.int64),
            "duration": features.Tensor(shape=(None,), dtype=np.int64),
            "mel": features.Tensor(shape=(None, 80), dtype=np.float32),
            "mel_length": features.Tensor(shape=(), dtype=np.int64),
        }

        if self._config.get("with_speaker_id", False):
            feature_dict.update({"speaker_id": features.Tensor(shape=(), dtype=np.int64)})

        if self._config.get("with_locale_id", False):
            feature_dict.update({"locale_id": features.Tensor(shape=(), dtype=np.int64)})

        if self._config.get("with_style_data", False):
            feature_dict.update({"style_id": features.Tensor(shape=(), dtype=np.int64)})

        if self._config.get("with_pitch_data", False):
            feature_dict.update(
                {
                    "f0": features.Tensor(shape=(None,), dtype=np.float32),
                    "uv": features.Tensor(shape=(None,), dtype=np.float32),
                }
            )

        if self._config.get("with_phone_pitch_data", False):
            feature_dict.update({"f0": features.Tensor(shape=(None,), dtype=np.float32)})

        if self._config.get("with_singing_data", False):
            feature_dict.update(
                {
                    "note_duration": features.Tensor(shape=(None,), dtype=np.int64),
                    "note_pitch": features.Tensor(shape=(None,), dtype=np.int64),
                }
            )

        if self._config.get("with_context_data", False):
            phone_dim = self._config["context_dim"]["phone"]
            seq_dim = self._config["context_dim"]["seq"]
            feature_dict.update(
                {
                    "context_phone_emb": features.Tensor(shape=(None, phone_dim), dtype=np.float32),
                    "context_seq_emb": features.Tensor(shape=(None, seq_dim), dtype=np.float32),
                }
            )

        if self._config.get("with_pretrain_speaker_embedding", False):
            feature_dict.update(
                {
                    "pretrain_speaker_embedding": features.Tensor(shape=(None,), dtype=np.float32),
                }
            )

        return DatasetInfo(
            builder=self, description="FastSpeech dataset builder", features=features.FeaturesDict(feature_dict)
        )

    def _split_generators(self):
        path = self._config.get("raw_data", None)
        if path is None:
            raise ValueError("You should specify raw_data in dataset builder")
        return {k: self._raw_data_generator(split=v, path=path) for k, v in self.split_type.items()}

    def _raw_data_generator(self, split, path):
        # Transfer tfrecord to chunk dataset
        tfrecord_pattern = self._config.get("tfrecord_pattern", self.DEFAULT_TFRECORD_PATTERN)
        style_filter = self._config.get("style_filter", None)
        tfrecord_pattern = tfrecord_pattern.split("+")
        tfrecord_path = []
        for pattern in tfrecord_pattern:
            tfrecord_path.append(os.path.join(path, pattern))
        # Read tfrecord with tf.data APIs.
        tfrecord_files = tf.data.Dataset.list_files(tfrecord_path)
        dataset = tf.data.TFRecordDataset(tfrecord_files)
        dataset = dataset.map(tf.autograph.experimental.do_not_convert(self._read_and_decode))

        # Allow frame mismatch to be less than frame_tolerance
        frame_tolerance = self._config.get("frame_tolerance", 5)

        mel_scaler = lambda x: x  # noqa: E731
        mel_stat_num = 100
        ex_min, ex_max = 0.0, 0.0
        for example in itertools.islice(dataset, mel_stat_num):
            ex_min += example["mel"].numpy().min()
            ex_max += example["mel"].numpy().max()
        ex_min /= mel_stat_num
        ex_max /= mel_stat_num

        # process raw data scaling issue.
        # [0, 1]
        if ex_min > -1 and ex_min < 1 and ex_max > 0 and ex_max < 2:
            mel_scaler = lambda x: x * 8.0 - 4.0  # noqa: E731
        # [-1.6, -0.6]
        elif ex_min > -2 and ex_min < -1 and ex_max > -1 and ex_max < 0:
            mel_scaler = lambda x: (x + 1.6) * 8.0 - 4.0  # noqa: E731
        # [-5.6, 2.4]
        elif ex_min > -6 and ex_min < -5 and ex_max > 2 and ex_max < 3:
            mel_scaler = lambda x: x + 1.6  # noqa: E731

        for example_index, example in enumerate(dataset):
            phone_id = example["phone_id"].numpy()

            # Handle t2t's breaking change of saving duration in tfrecord
            duration = example["duration_v1"].numpy()
            if sum(duration) == 0:
                duration = example["duration_v2"].numpy()

            # Discard data with inconsistency
            if len(phone_id) != len(duration):
                continue

            mel = example["mel"].numpy()
            mel = mel_scaler(mel)

            total_frames = sum(duration)

            mel = self._handle_length_mismatch(mel, total_frames, frame_tolerance)
            if mel is None:
                continue

            example_dict = {
                "phone_id": phone_id,
                "phone_id_length": len(phone_id),
                "duration": duration,
                "mel": mel,
                "mel_length": len(mel),
            }

            if self._config.get("with_speaker_id", False):
                speaker_id = example["speaker_id"].numpy().squeeze()
                override_spk_id = self._config.get("override_speaker_id")
                if override_spk_id is not None:
                    speaker_id = override_spk_id
                example_dict.update({"speaker_id": speaker_id})

            if self._config.get("with_locale_id", False):
                locale_id = example["locale_id"].numpy().squeeze()
                example_dict.update({"locale_id": locale_id})

            if self._config.get("with_pitch_data", False):
                f0, uv = example["f0"].numpy(), example["uv"].numpy()
                f0 = self._handle_length_mismatch(f0, total_frames, frame_tolerance)
                uv = self._handle_length_mismatch(uv, total_frames, frame_tolerance)
                if f0 is None or uv is None:
                    continue
                example_dict.update({"f0": f0, "uv": uv})

            if self._config.get("with_phone_pitch_data", False):
                f0 = example["f0"].numpy()
                f0 = self._handle_length_mismatch(f0, total_frames, frame_tolerance)
                if f0 is None:
                    continue
                example_dict.update({"f0": f0})

            if self._config.get("with_style_data", False):
                style_id = example["style_id"].numpy().squeeze()
                if style_filter is not None and style_id != style_filter:
                    continue
                example_dict.update({"style_id": style_id})

            if self._config.get("with_singing_data", False):
                note_duration = example["note_duration"].numpy()
                if len(phone_id) != len(note_duration):
                    continue
                example_dict.update({"note_duration": note_duration})
                note_pitch = example["note_pitch"].numpy()
                if len(phone_id) != len(note_pitch):
                    continue
                example_dict.update({"note_pitch": note_pitch})

            if self._config.get("with_context_data", False):
                context_dim = self._config["context_dim"]

                context_phone_emb = example["context_phone_emb"].numpy().reshape((-1, context_dim["phone"]))
                example_dict.update({"context_phone_emb": context_phone_emb})
                if len(phone_id) != len(context_phone_emb):
                    logger.info("phone_id size %s != context_phone_emb %s" % (len(phone_id), len(context_phone_emb)))
                    continue

                context_seq_emb = example["context_seq_emb"].numpy().reshape((-1, context_dim["seq"]))
                example_dict.update({"context_seq_emb": context_seq_emb})

            if self._config.get("with_pretrain_speaker_embedding", False):
                pretrain_speaker_embedding = example["pretrain_speaker_embedding"].numpy()
                example_dict.update({"pretrain_speaker_embedding": pretrain_speaker_embedding})

            yield f"{example_index:010}", example_dict

    def _data_pipeline(self, datapipe, shuffle=True):
        max_mel_len = self._config.get("max_mel_len", None)
        if max_mel_len is not None:
            datapipe = datapipe.filter(self._filter_mel_len, fn_kwargs={"max_mel_len": max_mel_len})

        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=100)

        if self._config.get("filter_locale_id", None):
            locale_str = self._config["filtered_locale"]
            locale_id_list = list(map(int, str(locale_str).split("-")))
            datapipe = datapipe.filter(self._filter_locale_id, fn_kwargs={"locale_id_list": locale_id_list})

        if self._config.get("balance_training", None):
            speaker_str = self._config["filtered_speaker"]
            balance_ratio = self._config["balance_ratio"]
            datapipe = datapipe.filter(
                self._balance_training, fn_kwargs={"speaker_id": speaker_str, "balance_ratio": balance_ratio}
            )

        # filter by speaker id
        filter_speaker_id = self._config.get("filter_speaker_id", None)
        if filter_speaker_id is not None:
            speaker_id_list = list(map(int, str(filter_speaker_id).split("-")))
            datapipe = datapipe.filter(self._filter_speaker_id, fn_kwargs={"speaker_id_list": speaker_id_list})

        # filter by style id
        filter_style_id = self._config.get("filter_style_id", None)
        if filter_style_id is not None:
            style_id_list = list(map(int, str(filter_style_id).split("-")))
            logger.info(f"This run will only train style id in {style_id_list}")
            datapipe = datapipe.filter(self._filter_style_id, fn_kwargs={"style_id_list": style_id_list})

        if self._config.get("with_pitch_data", False):
            pitch_norm = self._config["pitch_norm"]
            if pitch_norm["type"] == "min_max":
                datapipe = datapipe.map(
                    self._min_max_normalize, fn_kwargs={"f0_min": pitch_norm["f0_min"], "f0_max": pitch_norm["f0_max"]}
                )
            elif pitch_norm["type"] == "mean_var":
                datapipe = datapipe.map(
                    self._mean_var_normalize,
                    fn_kwargs={"f0_mean": pitch_norm["f0_mean"], "f0_var": pitch_norm["f0_var"]},
                )
            else:
                raise ValueError("pitch_norm type should be one of min_max or mean_var")

        if self._config.get("with_phone_pitch_data", False):
            pitch_norm = self._config["pitch_norm"]
            if pitch_norm["type"] == "min_max":
                datapipe = datapipe.map(
                    self._min_max_normalize, fn_kwargs={"f0_min": pitch_norm["f0_min"], "f0_max": pitch_norm["f0_max"]}
                )
            elif pitch_norm["type"] == "mean_var":
                datapipe = datapipe.map(
                    self._mean_var_normalize,
                    fn_kwargs={"f0_mean": pitch_norm["f0_mean"], "f0_var": pitch_norm["f0_var"]},
                )
            else:
                raise ValueError("pitch_norm type should be one of min_max or mean_var")

        if self._config.get("need_phone_pitch", False):
            datapipe = datapipe.map(self._add_phone_pitch)
            datapipe = datapipe.map(self._add_phone_energy)

        if self._config.get("need_global_prosodic_feature", False):
            datapipe = datapipe.map(
                self._add_prosodic_feature,
                fn_kwargs={
                    "f0_mean": self._config["pitch_norm"]["f0_mean"],
                    "f0_var": self._config["pitch_norm"]["f0_var"],
                    "brphones": self._config.get("brphones", None),
                    "silphones": self._config.get("silphones", None),
                },
            )

        # Dynamic batching with bucket
        batch_size = self._config.get("batch_size", 6000)
        bucket_step = self._config.get("bucket_step", 1.1)
        bucket_scheme = get_bucket_scheme(batch_size, 8, bucket_step)
        datapipe = datapipe.dynamic_batch(
            group_key_fn=self.get_frames,
            bucket_boundaries=bucket_scheme["boundaries"],
            batch_sizes=bucket_scheme["batch_sizes"],
        )

        # Shuffle on batch
        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=32)

        # Apply padding and then convert to pytorch tensor
        datapipe = datapipe.collate(
            fn_kwargs={
                "padding_axes": {
                    "phone_id": -1,
                    "duration": -1,
                    "mel": 0,
                    "f0": 0,
                    "uv": 0,
                    "phone_f0": 0,
                    "note_duration": -1,
                    "note_pitch": -1,
                    "phone_energy": 0,
                    "context_phone_emb": 0,
                    'mel_shuffle': 0,
                },
                "padding_values": {"phone_id": 0, "duration": 0, "mel": -4.0, "uv": 0.0, "context_phone_emb": 0.0, 'mel_shuffle': -4.0},
            }
        )
        return datapipe

    @staticmethod
    def _read_and_decode(serialized_example):
        parsed_data = tf.io.parse_single_example(
            serialized_example,
            features={
                "encdec_attn": tf.io.VarLenFeature(tf.float32),
                "inputs": tf.io.VarLenFeature(tf.int64),
                "linguisticfeature": tf.io.VarLenFeature(tf.float32),
                "locale_id": tf.io.VarLenFeature(tf.int64),
                "mel_data": tf.io.VarLenFeature(tf.float32),
                "mel_lens": tf.io.VarLenFeature(tf.float32),
                "phone_dur": tf.io.VarLenFeature(tf.float32),
                "phones": tf.io.VarLenFeature(tf.int64),
                "sf": tf.io.VarLenFeature(tf.float32),
                "spk_id": tf.io.VarLenFeature(tf.int64),
                "spkemb": tf.io.VarLenFeature(tf.float32),
                "style_id": tf.io.VarLenFeature(tf.int64),
                "utt_id": tf.io.VarLenFeature(tf.int64),
                "uv": tf.io.VarLenFeature(tf.float32),
                "noteDur": tf.io.VarLenFeature(tf.int64),
                "pitch": tf.io.VarLenFeature(tf.int64),
                "pretrain_speaker_embedding": tf.io.VarLenFeature(tf.float32),
                "raw_transcript": tf.io.FixedLenFeature([], tf.string),
                "context_phone_emb": tf.io.VarLenFeature(tf.float32),
                "context_seq_emb": tf.io.VarLenFeature(tf.float32),
            },
        )
        return {
            "phone_id": tf.sparse.to_dense(parsed_data["phones"]),
            "speaker_id": tf.sparse.to_dense(parsed_data["spk_id"]),
            "locale_id": tf.sparse.to_dense(parsed_data["locale_id"]),
            "style_id": tf.sparse.to_dense(parsed_data["style_id"]),
            "duration_v1": tf.cast(tf.sparse.to_dense(parsed_data["mel_lens"]), tf.int64),
            "duration_v2": tf.cast(tf.sparse.to_dense(parsed_data["phone_dur"]), tf.int64),
            "mel": tf.reshape(tf.sparse.to_dense(parsed_data["mel_data"]), (-1, 80)),
            "f0": tf.sparse.to_dense(parsed_data["sf"]),
            "uv": tf.sparse.to_dense(parsed_data["uv"]),
            "note_duration": tf.sparse.to_dense(parsed_data["noteDur"]),
            "note_pitch": tf.sparse.to_dense(parsed_data["pitch"]),
            "pretrain_speaker_embedding": tf.sparse.to_dense(parsed_data["pretrain_speaker_embedding"]),
            "context_phone_emb": tf.sparse.to_dense(parsed_data["context_phone_emb"]),
            "context_seq_emb": tf.sparse.to_dense(parsed_data["context_seq_emb"]),
        }

    @staticmethod
    def _handle_length_mismatch(mutable, target_length, tolerance):
        mismatch = target_length - len(mutable)
        if mismatch != 0:
            if abs(mismatch) > tolerance:
                return None
            else:
                if mismatch > 0:
                    pad_width = ((0, mismatch), *((0, 0) for _ in range(mutable.ndim - 1)))
                    mutable = np.pad(mutable, pad_width, mode="edge")
                else:
                    mutable = mutable[:mismatch]
        return mutable

    @staticmethod
    def _filter_mel_len(data, max_mel_len):
        return bool(data["mel_length"] < max_mel_len)

    @staticmethod
    def _filter_speaker_id(data, speaker_id_list):
        return int(data["speaker_id"]) in speaker_id_list

    @staticmethod
    def _filter_style_id(data, style_id_list):
        return int(data["style_id"]) in style_id_list

    @staticmethod
    def _balance_training(data, speaker_id, balance_ratio):
        rand = np.random.random_sample()

        if int(data["speaker_id"]) != speaker_id:
            if rand <= balance_ratio:
                return False
        return True

    @staticmethod
    def _filter_locale_id(data, locale_id_list):
        return int(data["locale_id"]) in locale_id_list

    @staticmethod
    def _min_max_normalize(data, f0_min, f0_max):
        data["f0"] = (data["f0"] - f0_min) / (f0_max - f0_min)
        return data

    @staticmethod
    def _mean_var_normalize(data, f0_mean, f0_var):
        data["f0"] = (data["f0"] - f0_mean) / f0_var
        return data

    @staticmethod
    def _add_phone_energy(data):
        duration = data["duration"]
        phone_boundary = np.cumsum(np.pad(duration, (1, 0)))
        # Padding because the last phone has duration 0

        pmel = data["mel"].mean(-1)

        phone_energy = np.add.reduceat(np.pad(pmel, (0, 1)), phone_boundary[:-1])
        phone_energy[duration == 0] = np.min(pmel)
        phone_energy /= np.where(duration == 0, 1, duration)
        data["phone_energy"] = phone_energy.astype(np.float32)

        return data

    @staticmethod
    def _add_phone_pitch(data):
        duration = data["duration"]
        phone_boundary = np.cumsum(np.pad(duration, (1, 0)))
        # Padding because the last phone has duration 0
        phone_f0 = np.add.reduceat(np.pad(data["f0"], (0, 1)), phone_boundary[:-1])
        phone_f0[duration == 0] = np.min(data["f0"])
        phone_f0 /= np.where(duration == 0, 1, duration)
        data["phone_f0"] = phone_f0.astype(np.float32)
        return data

    @staticmethod
    def _add_prosodic_feature(data, f0_mean, f0_var, brphones, silphones):
        def _global_zerocrossrate(mel):
            melm = np.mean(mel - 0.5, -1)
            tempo = np.array(librosa.zero_crossings(melm), dtype=np.float32)
            # norm to 0-200
            tempo = int(np.sum(tempo) / (len(tempo) * 12.5 / 1000.0) * 10.0)
            return tempo

        def _global_pitch(data, f0_mean, f0_var):
            leng = np.maximum(np.sum(data["uv"]), 1.0)
            data["global_f0"] = np.sum((data["f0"] * f0_var + f0_mean) * data["uv"]) / leng
            # norm to 0-200
            data["global_f0"] = int(data["global_f0"] / 5.0)
            return data

        def _global_energy(data):
            leng = np.maximum(np.sum(data["uv"]), 1.0)
            data["global_energy"] = np.sum(data["mel"].mean(-1) * data["uv"]) / leng
            # norm to 0-100
            data["global_energy"] = int((data["global_energy"] + 4.0) / 8.0 * 100.0)
            return data

        data["global_zero_cross_rate"] = _global_zerocrossrate(data["mel"])
        data = _global_pitch(data, f0_mean, f0_var)
        data = _global_energy(data)
        data['mel_shuffle'] = shuffle_mel_by_frame(data['mel'], data['phone_id'], data['duration'], brphones, silphones)
        return data

    @staticmethod
    def get_frames(data):
        return len(data["mel"])

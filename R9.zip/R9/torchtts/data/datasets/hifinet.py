import logging
import multiprocessing as mp
import os
import random
from functools import partial

import numpy as np
from threadpoolctl import threadpool_limits

from torchtts.data.core import audio
from torchtts.data.core import features
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder
from torchtts.data.core.dataset_info import DatasetInfo

logger = logging.getLogger(__name__)


class HiFiNetDataset(GeneratorBasedBuilder):
    def _info(self):
        return DatasetInfo(
            builder=self,
            description="HiFiNet dataset builder",
            features=features.FeaturesDict(
                {
                    "audio": features.Audio(),
                    "mel": features.Tensor(shape=(None, 80), dtype=np.float32),
                }
            ),
        )

    def _split_generators(self):
        path = self._config.get("raw_data", None)
        if path is None:
            raise ValueError("You should specify raw_data in dataset builder")
        return {"train": self._raw_data_generator(split="train", path=path)}

    def _raw_data_generator(self, split, path):
        example_index = 0
        num_workers = self._config.get("preprocess_workers", os.cpu_count())
        if num_workers > 1:
            with mp.Pool(num_workers) as pool:
                for root, _, files in os.walk(path):
                    extract_fn = partial(self._extract_feature, wav_dir=root, audio_config=self._config["audio_config"])
                    for result in pool.imap_unordered(extract_fn, files):
                        if result is not None:
                            yield f"{example_index:010}", result
                            example_index += 1
        else:
            for root, _, files in os.walk(path):
                for wav_file in files:
                    result = self._extract_feature(
                        wav_file=wav_file, wav_dir=root, audio_config=self._config["audio_config"]
                    )
                    if result is not None:
                        yield f"{example_index:010}", result
                        example_index += 1

    def _data_pipeline(self, datapipe, shuffle):
        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=100)
        # Random clip (audio, mel) pairs for training
        audio_config = self._config["audio_config"]
        hop_length = int(audio_config["frame_shift_ms"] / 1000 * audio_config["target_sample_rate"])
        segment_length = self._config["segment_length"]
        datapipe = datapipe.map(
            self._random_clip, fn_kwargs={"hop_length": hop_length, "segment_length": segment_length}
        )
        # Scale mel range to [-1, 1]
        datapipe = datapipe.map(self._scale_and_transpose_mel)
        # Batch and collate
        datapipe = datapipe.batch(self._config["batch_size"])
        datapipe = datapipe.collate()
        return datapipe

    @staticmethod
    def _extract_feature(wav_file, wav_dir, audio_config):
        # We need this to limit the threads of common native libraries used by numpy for scientific
        # computing and data science (e.g. BLAS and OpenMP). Otherwise, each worker may have risk
        # of draining system resources.
        with threadpool_limits(limits=1, user_api="blas"):
            if os.path.splitext(wav_file)[1] != ".wav":
                return None
            res_type = audio_config.get("res_type", "soxr_hq")
            wav_path = os.path.join(wav_dir, wav_file)
            # Vocoder target synthesis sample rate
            target_wav_data, _ = audio.load_wav(wav_path, audio_config["target_sample_rate"], res_type=res_type)
            # Maybe down-sampled audio data for mel extraction
            feats_wav_data, _ = audio.load_wav(wav_path, audio_config["sample_rate"], res_type=res_type)
            mel_spec = audio.mel_spectrogram(feats_wav_data, **audio_config)
            return {"audio": target_wav_data, "mel": mel_spec}

    @staticmethod
    def _random_clip(x, hop_length, segment_length):
        if segment_length <= len(x["audio"]):
            max_wav_start = len(x["audio"]) - segment_length
            wav_start = random.randint(0, max_wav_start)
            wav_start = wav_start // hop_length * hop_length
            x["audio"] = x["audio"][wav_start : wav_start + segment_length]
            start_frame = wav_start // hop_length
            x["mel"] = x["mel"][start_frame : start_frame + segment_length // hop_length, :]
        else:
            x["audio"] = np.pad(x["audio"], [0, segment_length - len(x["audio"])], mode="constant", constant_values=0.0)
            x["mel"] = np.pad(
                x["mel"],
                ((0, int(segment_length // hop_length - len(x["mel"]))), (0, 0)),
                mode="constant",
                constant_values=-4.0,
            )
        return x

    @staticmethod
    def _scale_and_transpose_mel(x):
        x["mel"] = x["mel"].T / 4.0
        return x

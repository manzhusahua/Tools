import json
import logging
import os
import codecs
import numpy as np

import torch

from torchtts.data.core import features
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder
from torchtts.data.core.dataset_info import DatasetInfo
from torchtts.utils.data_utils import get_bucket_scheme

logger = logging.getLogger(__name__)


class PhonemeBERTDataset(GeneratorBasedBuilder):
    def _info(self):
        feature_dict = {
            "phoneme": features.Tensor(shape=(None,), dtype=np.int64),
            "phone_id_length": features.Tensor(shape=(), dtype=np.int64),
        }

        return DatasetInfo(
            builder=self, description="Phoneme BERT dataset builder", features=features.FeaturesDict(feature_dict)
        )

    def _split_generators(self):
        path = self._config.get("raw_data", None)
        if path is None:
            raise ValueError("You should specify raw_data in dataset builder")
        return {k: self._raw_data_generator(split=v, path=path) for k, v in self.split_type.items()}

    def _get_path(self, data_dir, name):
        if name is None:
            raise ValueError(f"{name} is empty for conformer.")
        data_path = os.path.join(data_dir, name)
        if not os.path.exists(data_path):
            raise ValueError(f"Cannot find {data_path}.")
        return data_path

    def _load_phone_set(self, path, phone2idx):
        with open(path, encoding="utf-8") as json_file:
            data = json.load(json_file)
            idx = len(phone2idx)
            for item in data:
                if item not in phone2idx:
                    phone2idx[item] = idx
                    idx += 1
        return phone2idx

    def _raw_data_generator(self, split, path):
        phone2idx = {}
        phone2idx = self._load_phone_set(os.path.join(path, self._config.get("phoneme_dict", None)), phone2idx)
        phone2idx["<mask>"] = len(phone2idx)
        logger.info("phone2idx size: " + str(len(phone2idx)))
        logger.info("mask id: " + str(phone2idx["<mask>"]))

        total_idx = -1
        phnm_data_dir = os.path.join(path, self._config.get("phoneme_data", None))

        for f in os.listdir(phnm_data_dir):
            for phoneme_line in codecs.open(os.path.join(phnm_data_dir, f), encoding="utf-8"):
                phoneme_seq = phoneme_line.strip()
                if phoneme_seq == "":
                    continue

                total_idx += 1
                phoneme_parts = phoneme_seq.split(" ")
                phone_ids = []

                for j in range(len(phoneme_parts)):
                    ph = phoneme_parts[j].strip()
                    if ph != "." and ph != "":
                        if ph in phone2idx.keys():
                            ph_id = phone2idx[ph]
                            phone_ids.append(ph_id)
                        else:
                            raise ValueError(f"{ph} is missing in phone_set.")

                phoneme_ids = np.array(phone_ids, dtype=np.int64)
                ilens = len(phone_ids)

                example_dict = {
                    "phoneme": phoneme_ids,
                    "phone_id_length": ilens,
                }

                yield f"{total_idx:010}", example_dict

        logger.info("finished data loading, total: " + str(total_idx))

    def _data_pipeline(self, data_pipe, shuffle=True):
        if shuffle:
            data_pipe = data_pipe.shuffle(buffer_size=100)

        data_pipe = data_pipe.map(
            _mask_tokens,
            fn_kwargs={
                "phoneme_mask_idx": self._config.get("phoneme_mask_idx", 3),
                "phoneme_pad_idx": self._config.get("phoneme_pad_idx", 0),
                "special_end": self._config.get("special_end", 7),
                "mask_prob": self._config.get("mask_prob", 0.12),
                "leave_unmasked_prob": self._config.get("leave_unmasked_prob", 0.12),
                "random_token_prob": self._config.get("random_token_prob", 0.12),
            },
        )

        batch_size = self._config.get("batch_size", 6000)
        bucket_scheme = get_bucket_scheme(batch_size, 8, 1.1)
        data_pipe = data_pipe.dynamic_batch(
            group_key_fn=get_phonemes,
            bucket_boundaries=bucket_scheme["boundaries"],
            batch_sizes=bucket_scheme["batch_sizes"],
        )

        if shuffle:
            data_pipe = data_pipe.shuffle(buffer_size=32)

        data_pipe = data_pipe.collate(
            fn_kwargs={
                "padding_axes": {"phoneme": -1, "phoneme_target": -1},
                "padding_values": {"phoneme": 0, "phoneme_target": 0},
            }
        )
        return data_pipe


def get_phonemes(x):
    return len(x["phoneme"])


def _mask_tokens(
    item, phoneme_mask_idx, phoneme_pad_idx, special_end, mask_prob, leave_unmasked_prob, random_token_prob=0.015
):
    phoneme = item["phoneme"]

    ph_len = len(phoneme)

    mask = np.full(ph_len, False)
    non_special_indices = np.argwhere(phoneme > special_end)
    num_mask = int(
        # add a random number for probabilistic rounding
        mask_prob * len(non_special_indices)
        + np.random.rand()
    )
    selected_indices = non_special_indices[np.random.choice(len(non_special_indices), num_mask, replace=False)]
    mask[selected_indices] = True

    phoneme_target = np.full(len(mask), phoneme_pad_idx)
    phoneme_target[mask] = phoneme[torch.from_numpy(mask.astype(np.uint8)) == 1]
    item["phoneme_target"] = phoneme_target

    # decide unmasking and random replacement
    rand_or_unmask_prob = random_token_prob + leave_unmasked_prob
    if rand_or_unmask_prob > 0.0:
        rand_or_unmask = mask & (np.random.rand(ph_len) < rand_or_unmask_prob)
        if random_token_prob == 0.0:
            unmask = rand_or_unmask
        elif leave_unmasked_prob == 0.0:
            unmask = None
        else:
            unmask_prob = leave_unmasked_prob / rand_or_unmask_prob
            decision = np.random.rand(ph_len) < unmask_prob
            unmask = rand_or_unmask & decision
    else:
        unmask = None

    if unmask is not None:
        mask = mask ^ unmask

    phoneme_target = np.copy(phoneme)
    phoneme_target[mask] = phoneme_mask_idx
    item["phoneme"] = phoneme_target

    return item

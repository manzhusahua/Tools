import os

import numpy as np

from torchtts.data.core import features
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder
from torchtts.data.core.dataset_info import DatasetInfo
from torchtts.utils.data_utils import get_bucket_scheme
from torchtts.utils.import_utils import _TENSORFLOW_AVAILABLE

if _TENSORFLOW_AVAILABLE:
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
    import tensorflow as tf


class TransformerDataset(GeneratorBasedBuilder):
    DEFAULT_TFRECORD_PATTERN = "unified_speech_problem-train-*"

    def _info(self):
        return DatasetInfo(
            builder=self,
            description="Transformer dataset builder",
            features=features.FeaturesDict(
                {
                    "phone_id": features.Tensor(shape=(None,), dtype=np.int64),
                    "phone_id_length": features.Tensor(shape=(), dtype=np.int64),
                    "duration": features.Tensor(shape=(None,), dtype=np.int64),
                    "mel": features.Tensor(shape=(None, 80), dtype=np.float32),
                    "mel_length": features.Tensor(shape=(), dtype=np.int64),
                }
            ),
        )

    def _split_generators(self):
        path = self._config.pop("raw_data", None)
        if path is None:
            raise ValueError("You should specify raw_data in dataset builder")
        return {k: self._raw_data_generator(split=v, path=path) for k, v in self.split_type.items()}

    def _raw_data_generator(self, split, path):
        # Transfer tfrecord to chunk dataset
        tfrecord_pattern = self._config.get("tfrecord_pattern", self.DEFAULT_TFRECORD_PATTERN)
        tfrecord_path = os.path.join(path, tfrecord_pattern)
        # Read tfrecords with tf.data APIs.
        tfrecord_files = tf.data.Dataset.list_files(tfrecord_path)
        dataset = tf.data.TFRecordDataset(tfrecord_files)
        dataset = dataset.map(tf.autograph.experimental.do_not_convert(_read_and_decode))

        for example_index, example in enumerate(dataset):
            phone_id = example["phone_id"].numpy()
            duration = example["duration"].numpy()
            mel = example["mel"].numpy()

            assert len(mel) == sum(duration)
            assert len(phone_id) == len(duration)

            yield f"{example_index:010}", {
                "phone_id": phone_id,
                "phone_id_length": len(phone_id),
                "duration": duration,
                "mel": mel,
                "mel_length": len(mel),
            }

    def _data_pipeline(self, datapipe, shuffle=True):
        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=100)

        def get_frames(x):
            return len(x["mel"])

        batch_size = self._config.pop("batch_size", 6000)
        bucket_scheme = get_bucket_scheme(batch_size, 8, 1.1)
        datapipe = datapipe.dynamic_batch(
            group_key_fn=get_frames,
            bucket_boundaries=bucket_scheme["boundaries"],
            batch_sizes=bucket_scheme["batch_sizes"],
        )

        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=32)

        datapipe = datapipe.collate(
            fn_kwargs={
                "padding_axes": {"phone_id": -1, "duration": -1, "mel": 0},
                "padding_values": {"phone_id": 0, "duration": 0, "mel": -4.0},
            }
        )
        return datapipe


def _read_and_decode(serialized_example):
    parsed_data = tf.io.parse_single_example(
        serialized_example,
        features={
            "encdec_attn": tf.io.VarLenFeature(tf.float32),
            "inputs": tf.io.VarLenFeature(tf.int64),
            "linguisticfeature": tf.io.VarLenFeature(tf.float32),
            "locale_id": tf.io.VarLenFeature(tf.int64),
            "mel_data": tf.io.VarLenFeature(tf.float32),
            "mel_lens": tf.io.VarLenFeature(tf.float32),
            "phone_dur": tf.io.VarLenFeature(tf.float32),
            "phones": tf.io.VarLenFeature(tf.int64),
            "sf": tf.io.VarLenFeature(tf.float32),
            "spk_id": tf.io.VarLenFeature(tf.int64),
            "spkemb": tf.io.VarLenFeature(tf.float32),
            "style_id": tf.io.VarLenFeature(tf.int64),
            "utt_id": tf.io.VarLenFeature(tf.int64),
            "uv": tf.io.VarLenFeature(tf.float32),
            "raw_transcript": tf.io.FixedLenFeature([], tf.string),
        },
    )
    return {
        "phone_id": tf.sparse.to_dense(parsed_data["phones"]),
        "duration": tf.cast(tf.sparse.to_dense(parsed_data["mel_lens"]), tf.int64),
        "mel": tf.reshape(tf.sparse.to_dense(parsed_data["mel_data"]), (-1, 80)),
        "f0": tf.sparse.to_dense(parsed_data["sf"]),
        "uv": tf.sparse.to_dense(parsed_data["uv"]),
    }

import logging
import multiprocessing as mp
import os
import random
from functools import partial
from pathlib import Path

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from torchtts.data.core import audio
from torchtts.data.core import features
from torchtts.data.core.dataset_builder import GeneratorBasedBuilder
from torchtts.data.core.dataset_info import DatasetInfo

logger = logging.getLogger(__name__)

from librosa.filters import mel as librosa_mel_fn


class TacotronSTFT(torch.nn.Module):
    def __init__(self, filter_length=1024, hop_length=256, win_length=1024,
                 n_mel_channels=100, sampling_rate=24000, mel_fmin=0.0,
                 mel_fmax=12000, center=False, device='cpu'):
        super(TacotronSTFT, self).__init__()
        self.n_mel_channels = n_mel_channels
        self.sampling_rate = sampling_rate
        self.n_fft = filter_length
        self.hop_size = hop_length
        self.win_size = win_length
        self.fmin = mel_fmin
        self.fmax = mel_fmax
        self.center = center

        mel = librosa_mel_fn(
            sampling_rate, filter_length, n_mel_channels, mel_fmin, mel_fmax)

        mel_basis = torch.from_numpy(mel).float().to(device)
        hann_window = torch.hann_window(win_length).to(device)

        self.register_buffer('mel_basis', mel_basis)
        self.register_buffer('hann_window', hann_window)

    def linear_spectrogram(self, y):
        assert (torch.min(y.data) >= -1)
        assert (torch.max(y.data) <= 1)

        y = torch.nn.functional.pad(y.unsqueeze(1),
                                    (int((self.n_fft - self.hop_size) / 2), int((self.n_fft - self.hop_size) / 2)),
                                    mode='reflect')
        y = y.squeeze(1)
        spec = torch.stft(y, self.n_fft, hop_length=self.hop_size, win_length=self.win_size, window=self.hann_window,
                          center=self.center, pad_mode='reflect', normalized=False, onesided=True)
        spec = torch.norm(spec, p=2, dim=-1)

        return spec

    def mel_spectrogram(self, y):
        """Computes mel-spectrograms from a batch of waves
        PARAMS
        ------
        y: Variable(torch.FloatTensor) with shape (B, T) in range [-1, 1]
        RETURNS
        -------
        mel_output: torch.FloatTensor of shape (B, n_mel_channels, T)
        """
        y = torch.nn.functional.pad(y.unsqueeze(1),
                                    (int((self.n_fft - self.hop_size) / 2), int((self.n_fft - self.hop_size) / 2)),
                                    mode='reflect')
        y = y.squeeze(1)

        spec = torch.stft(y, self.n_fft, hop_length=self.hop_size, win_length=self.win_size, window=self.hann_window,
                          center=self.center, pad_mode='reflect', normalized=False, onesided=True)

        spec = torch.sqrt(spec.pow(2).sum(-1) + (1e-9))

        spec = torch.matmul(self.mel_basis, spec)
        spec = self.spectral_normalize_torch(spec)

        return spec

    def spectral_normalize_torch(self, magnitudes):
        output = self.dynamic_range_compression_torch(magnitudes)
        return output

    def dynamic_range_compression_torch(self, x, c=1, clip_val=1e-5):
        return torch.log(torch.clamp(x, min=clip_val) * c)


class HiFiNetDataset(GeneratorBasedBuilder):
    def __init__(self,
                 mel_dim=80, **kwargs
                 ):
        super().__init__(**kwargs)
        self.mel_dim = mel_dim

    def _info(self):
        return DatasetInfo(
            builder=self,
            description="HiFiNet dataset builder",
            features=features.FeaturesDict({
                'audio': features.Audio(),
                'mel': features.Tensor(shape=(None, self.mel_dim), dtype=np.float32),
            })
        )

    def _split_generators(self):
        path = self._config.get('raw_data', None)
        if path is None:
            raise ValueError("You should specify raw_data in dataset builder")
        path = Path(path)
        testfiles = []
        trainfiles = []
        for i, fname in enumerate(path.rglob("*.wav")):
            if i % 100 == 0:
                testfiles.append(str(fname))
            else:
                trainfiles.append(str(fname))

        return {
            'train': self._raw_data_generator(split='train', files=trainfiles),
            'dev': self._raw_data_generator(split='dev', files=testfiles)
        }

    def _raw_data_generator(self, split, files):
        example_index = 0
        num_workers = self._config.get("preprocess_workers", os.cpu_count())
        if num_workers > 1:
            with mp.Pool(num_workers, maxtasksperchild=3000) as pool:
                extract_fn = partial(self._extract_feature,
                                     audio_config=self._config['audio_config'])
                for result in pool.imap_unordered(extract_fn, files):
                    if result is not None:
                        yield f"{example_index:010}", result
                        example_index += 1
        else:
            for wav_file in files:
                result = self._extract_feature(wav_file=wav_file,
                                               audio_config=self._config['audio_config'])
                if result is not None:
                    yield f"{example_index:010}", result
                    example_index += 1

    def _data_pipeline(self, datapipe, shuffle, split):
        if shuffle:
            datapipe = datapipe.shuffle(buffer_size=100)
        # Random clip (audio, mel) pairs for training
        audio_config = self._config['audio_config']
        hop_length = int(audio_config['frame_shift_ms'] / 1000
                         * audio_config['target_sample_rate'])
        segment_length = self._config['segment_length']
        if split != 'dev':
            datapipe = datapipe.map(self._random_clip,
                                    fn_kwargs={'hop_length': hop_length, 'segment_length': segment_length})
        # Scale mel range to [-1, 1]
        datapipe = datapipe.map(self._scale_and_transpose_mel)
        # Batch and collate
        if split == 'dev':
            datapipe = datapipe.batch(1)
        else:
            datapipe = datapipe.batch(self._config["batch_size"])
        datapipe = datapipe.collate()
        return datapipe

    @staticmethod
    def _extract_feature(wav_file, audio_config):
        # We need this to limit the threads of common native libraries used by numpy for scientific
        # computing and data science (e.g. BLAS and OpenMP). Otherwise, each worker may have risk
        # of draining system resources.
        with threadpool_limits(limits=1, user_api='blas'):
            if os.path.splitext(wav_file)[1] != '.wav':
                return None
            res_type = audio_config.get('res_type', 'soxr_hq')
            # Vocoder target synthesis sample rate
            target_wav_data, _ = audio.load_wav(wav_file, audio_config['target_sample_rate'],
                                                res_type=res_type)
            # Maybe down-sampled audio data for mel extraction
            # feats_wav_data, _ = audio.load_wav(wav_file, audio_config['sample_rate'],
            #                                    res_type=res_type)
            # mel_spec = audio.mel_spectrogram(feats_wav_data, **audio_config)

            stft = TacotronSTFT()
            wav = torch.from_numpy(target_wav_data).unsqueeze(0)
            mel = stft.mel_spectrogram(wav).squeeze().T
            return {'audio': target_wav_data, 'mel': mel}

    @staticmethod
    def _random_clip(x, hop_length, segment_length):
        if segment_length <= len(x['audio']):
            max_wav_start = len(x['audio']) - segment_length
            wav_start = random.randint(0, max_wav_start)
            wav_start = wav_start // hop_length * hop_length
            x['audio'] = x['audio'][wav_start: wav_start + segment_length]
            start_frame = wav_start // hop_length
            x['mel'] = x['mel'][start_frame:start_frame + segment_length // hop_length, :]
        else:
            x['audio'] = np.pad(x['audio'], [0, segment_length - len(x['audio'])],
                                mode='constant', constant_values=0.0)
            x['mel'] = np.pad(x['mel'], ((0, int(segment_length // hop_length - len(x['mel']))), (0, 0)),
                              mode='constant', constant_values=-10.)
        return x

    @staticmethod
    def _scale_and_transpose_mel(x):
        x['mel'] = (x['mel'].T + 5) / 6.
        return x

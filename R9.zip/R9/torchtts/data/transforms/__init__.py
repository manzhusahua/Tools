from torchtts.data.transforms.mel_spectrogram import MelSpectrogram
from torchtts.data.transforms.spectrogram import Spectrogram

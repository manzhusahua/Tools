from abc import ABC
from abc import abstractmethod


class Engine(ABC):
    def setup(self, *args, **kwargs):
        pass

    def cleanup(self):
        pass

    @property
    @abstractmethod
    def rank(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @property
    def is_master_process(self):
        return self.rank == -1 or self.rank == 0

    @abstractmethod
    def barrier(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def to_device(self, component):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def setup_model(self, model):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def setup_optimizer(self, model, optimizer):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def optimize_step(self, loss, optimizer, scheduler):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def save_checkpoint(self, filename, trainer):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def load_checkpoint(self, filename, trainer, reset_trainer=False, parameter_list=False):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def context(self):
        raise NotImplementedError("Must be implemented in subclasses.")

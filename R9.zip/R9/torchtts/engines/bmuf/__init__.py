"""distoptim.bmuf package"""
import logging
import torch.distributed as dist

from torchtts.engines.bmuf.bmuf_optimizer import BMUFDistributedOptimizer
from torchtts.engines.bmuf.bmuf_optimizer import broadcast_parameters

logger = logging.getLogger(__name__)

__version__ = "0.0.1"


def _validate_config(config):
    """Validate configuration."""

    # validate total_num_workers, should match world size
    world_size = dist.get_world_size()

    # validate BMUF configurations
    bmuf_config = config["bmuf"]

    local_group_size = bmuf_config.get("local_group_size", 1)
    local_group_num = bmuf_config.get("local_group_num", None)
    if local_group_num is None:
        local_group_num = world_size / local_group_size

    if world_size % local_group_size != 0:
        raise ValueError(f"ERROR: Invalid local group size, " f"should be divisible by {world_size}")

    sync_steps = bmuf_config["sync_steps"]
    if sync_steps <= 1:
        raise ValueError(f"ERROR: Invalid sync step size({sync_steps}), " f"should be larger than 1")
    best_momentum = 1.0 - 1.0 / local_group_num
    block_momentum = bmuf_config.get("block_momentum", best_momentum)

    if block_momentum < best_momentum:
        logger.warning(f"To achieve best performance, block momentum should be larger than {best_momentum}")


def create_distributed_optimizer(model, optimizer, config):
    """Create BMUFDistributedOptimizer."""

    logger.info(f"BMUF version {__version__}")

    _validate_config(config)
    world_size = dist.get_world_size()
    bmuf_config = config["bmuf"]
    local_group_size = bmuf_config.get("local_group_size", 1)
    sync_steps = bmuf_config.get("sync_steps", 16)
    block_lr = bmuf_config.get("block_lr", 1)
    local_group_num = bmuf_config.get("local_group_num", None)
    if local_group_num is None:
        local_group_num = world_size / local_group_size

    block_momentum = bmuf_config.get("block_momentum", 1 - 1.0 / local_group_num)
    local_ddp = bmuf_config.get("local_ddp", False)

    cls = type(
        "BMUF-" + optimizer.__class__.__name__,
        (optimizer.__class__,),
        dict(BMUFDistributedOptimizer.__dict__),
    )
    return cls(model, optimizer, block_lr, block_momentum, sync_steps, local_group_size, local_ddp, version=__version__)

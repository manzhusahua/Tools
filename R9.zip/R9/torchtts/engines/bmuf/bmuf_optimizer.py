"""distoptim.bmuf package"""
import logging

import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.optim import SGD, Adam, AdamW

from torchtts.utils.import_utils import _APEX_AVAILABLE

if _APEX_AVAILABLE:
    from apex.optimizers import FusedAdam, FusedSGD

    AdamCls = (Adam, FusedAdam, AdamW)
    SGDCls = (SGD, FusedSGD)
else:
    AdamCls = (Adam, AdamW)
    SGDCls = (SGD,)

logger = logging.getLogger(__name__)


class BMUFDistributedOptimizer(torch.optim.Optimizer):
    r"""Implements Blockwise Model-Update Filtering.

    It has been proposed in `Scalable training of deep learning machines by incremental
        block training with intra-block parallel optimization and block wise model-update
        filtering`_.

    Arguments:
        model: machine learning model to be optimized
        optimizer: local optimizer used by each worker, SGD and Adam are supported now
        block_lr (float, optional): block learning rate (default: 1.0)
        block_momentum (float,optional): block momentum (default: 0.9)
        sync_steps (int,optional): sync period of local workers (default: 16)
        local_group_size (int, optional): num_gpus per worker (default: 1)
        version (string, optional): version of BMUFDistributedOptimizer (default: 0.0.1)
    """

    def __init__(
        self,
        model,
        optimizer,
        block_lr=1.0,
        block_momentum=0.9,
        sync_steps=16,
        local_group_size=1,
        local_ddp=False,
        version="0.0.1",
    ):
        logger.info("BMUF - creating BMUFDistributedOptimizer")

        super(self.__class__, self).__init__(optimizer.param_groups)
        self._model = model
        self._optimizer = optimizer
        self._block_lr = block_lr
        self._block_momentum = block_momentum
        self._sync_steps = sync_steps
        self._local_group_size = local_group_size
        self._version = version

        self._rank = dist.get_rank()
        self._local_rank = self._rank % self._local_group_size
        self._world_size = dist.get_world_size()

        self._local_ddp = local_ddp
        self._local_group = None
        self._group_idx = 0
        self._group_ranks = [self._rank]
        self._num_groups = self._world_size

        if self._local_group_size > 1:
            self._create_local_comm_group()
            if self._local_ddp:
                self._model = DistributedDataParallel(
                    self._model, device_ids=[self._local_rank], process_group=self._local_group
                )
        self._num_steps = 0

    def _create_local_comm_group(self):
        """Create communication group for local worker, which may contain several gpus"""

        all_ranks = np.arange(self._world_size).reshape(-1, self._local_group_size)
        self._group_idx = self._rank // self._local_group_size
        for idx, row in enumerate(all_ranks):
            group_ranks = row.tolist()
            local_group = dist.new_group(group_ranks)

            if idx == self._group_idx:
                self._group_ranks = group_ranks
                self._local_group = local_group

        self._num_groups = self._world_size // self._local_group_size
        logger.info(
            f"worker {self._rank}, group {self._group_idx}, group_ranks {self._group_ranks},"
            f"num_groups {self._num_groups}"
        )

    def state_dict(self):
        """Return optimizer state"""

        new_state_dict = super(self.__class__, self).state_dict()

        bmuf_state = self._get_bmuf_state()
        new_state_dict["bmuf_state"] = bmuf_state
        return new_state_dict

    def load_state_dict(self, state_dict):
        """Load optimizer state"""

        bmuf_state = None
        if "bmuf_state" in state_dict:
            bmuf_state = state_dict["bmuf_state"]
            del state_dict["bmuf_state"]
        else:
            logger.info("bmuf_state not found in state_dict")

        # first load on base optimizer
        super(self.__class__, self).load_state_dict(state_dict)

        if bmuf_state:
            logger.info("load BMUF states")
            self._load_bmuf_state(bmuf_state)

    def _get_bmuf_state(self):
        """Return BMUF state"""

        bmuf_state = {"num_steps": self._num_steps, "version": self._version}
        return bmuf_state

    def _load_bmuf_state(self, bmuf_state):
        """Load BMUF state"""

        self._version = bmuf_state["version"]
        logger.info(f"  BMUFDistributedOptimizer Version = {self._version}")
        self._num_steps = bmuf_state["num_steps"]
        logger.info(f"  restoring _num_steps {self._num_steps}")

    def model(self):
        """Return the model"""

        return self._model

    def _sync_local_group_gradients(self):
        """sync gradients within local group"""

        handles = {}
        for name, param in self._model.named_parameters():
            if param.requires_grad:
                if param.grad is None:
                    param.grad = torch.zeros_like(param, requires_grad=False)
                param.grad.div_(self._local_group_size)
                handles[name] = dist.all_reduce(param.grad, group=self._local_group, async_op=True)

        for name in handles.keys():
            handles[name].wait()

    def _initialize_optimizer_state(self):
        """initialize optimizer state"""

        for group in self.param_groups:
            amsgrad = group.get("amsgrad", False)
            for param in group["params"]:
                if param.grad is None:
                    if param.requires_grad:
                        param.grad = torch.zeros_like(param, requires_grad=False)
                    else:
                        continue

                param_state = self.state[param]

                param_state["bmuf_param"] = param.clone().data
                param_state["bmuf_delta"] = param.clone().data.fill_(0)
                param_state["bmuf_buf"] = param.clone().data.fill_(0)

                if isinstance(self._optimizer, AdamCls):
                    param_state["step"] = 0

                    param_state["exp_avg"] = param.clone().data.fill_(0)
                    param_state["exp_avg_sq"] = param.clone().data.fill_(0)
                    if amsgrad:
                        param_state["max_exp_avg_sq"] = param.clone().data.fill_(0)

                    param_state["pre_exp_avg"] = param.clone().data.fill_(0)
                    param_state["pre_exp_avg_sq"] = param.clone().data.fill_(0)

                    param_state["eqv_num_steps"] = 0

    def _allreduce_param_and_state(self, handles):
        """All reduce updated local params and local optimizer states"""

        for group in self.param_groups:
            amsgrad = group.get("amsgrad", False)
            for param in group["params"]:
                if param.grad is None:
                    if param.requires_grad:
                        param.grad = torch.zeros_like(param, requires_grad=False)
                    else:
                        continue

                param_state = self.state[param]

                handles[param] = {}

                param_state["bmuf_buf"].copy_(param.data).div_(self._world_size)
                handles[param]["bmuf_buf"] = dist.all_reduce(param_state["bmuf_buf"], async_op=True)

                if isinstance(self._optimizer, AdamCls):
                    param_state["exp_avg"].div_(self._world_size)
                    handles[param]["exp_avg"] = dist.all_reduce(param_state["exp_avg"], async_op=True)

                    param_state["exp_avg_sq"].div_(self._world_size)
                    handles[param]["exp_avg_sq"] = dist.all_reduce(param_state["exp_avg_sq"], async_op=True)

                    if amsgrad:
                        param_state["max_exp_avg_sq"].div_(self._world_size)
                        handles[param]["max_exp_avg_sq"] = dist.all_reduce(param_state["max_exp_avg_sq"], async_op=True)

    def _bmuf_step(self, handles):
        """Update global model by one BMUF step"""

        for group in self.param_groups:
            for param in group["params"]:
                if param.grad is None:
                    if param.requires_grad:
                        param.grad = torch.zeros_like(param, requires_grad=False)
                    else:
                        continue

                param_state = self.state[param]
                handles[param]["bmuf_buf"].wait()

                bmuf_buf, bmuf_delta, bmuf_param = (
                    param_state["bmuf_buf"],
                    param_state["bmuf_delta"],
                    param_state["bmuf_param"],
                )

                bmuf_buf.sub_(bmuf_param + self._block_momentum * bmuf_delta)
                bmuf_delta.mul_(self._block_momentum).add_(bmuf_buf.mul_(self._block_lr))
                bmuf_param.add_(bmuf_delta)

                param.data.copy_(bmuf_param + self._block_momentum * bmuf_delta)

    def _update_local_optimizer_state(self, handles):
        """Update states of local optimizer"""

        if isinstance(self._optimizer, AdamCls):
            for group in self.param_groups:
                amsgrad = group.get("amsgrad", False)
                beta1, beta2 = group["betas"]
                for param in group["params"]:
                    if param.grad is None:
                        if param.requires_grad:
                            param.grad = torch.zeros_like(param, requires_grad=False)
                        else:
                            continue
                    param_state = self.state[param]

                    # update equivalent num steps w.r.t updated moment buffers
                    param_state["eqv_num_steps"] = (
                        param_state["eqv_num_steps"] * self._block_momentum + self._sync_steps * self._block_lr
                    )
                    virtual_step = param_state["eqv_num_steps"] * self._block_momentum

                    handles[param]["exp_avg"].wait()
                    pre_exp_avg, exp_avg = param_state["pre_exp_avg"], param_state["exp_avg"]

                    pre_exp_avg.mul_((beta1**self._sync_steps) * (beta1**virtual_step - 1)).add_(
                        exp_avg, alpha=1 - beta1 ** (virtual_step + self._sync_steps)
                    ).div_(1 - beta1**self._sync_steps)
                    exp_avg.copy_(pre_exp_avg)

                    handles[param]["exp_avg_sq"].wait()
                    pre_exp_avg_sq, exp_avg_sq = param_state["pre_exp_avg_sq"], param_state["exp_avg_sq"]

                    pre_exp_avg_sq.mul_((beta2**self._sync_steps) * (beta2**virtual_step - 1)).add_(
                        exp_avg_sq, alpha=1 - beta2 ** (virtual_step + self._sync_steps)
                    ).div_(1 - beta2**self._sync_steps)
                    exp_avg_sq.copy_(pre_exp_avg_sq)

                    if amsgrad:
                        handles[param]["max_exp_avg_sq"].wait()
                        max_exp_avg_sq = param_state["max_exp_avg_sq"]
                        torch.max(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)

                    param_state["step"] += virtual_step

        elif isinstance(self._optimizer, SGDCls):
            for _, param in self._model.named_parameters():
                if param.grad is None:
                    if param.requires_grad:
                        param.grad = torch.zeros_like(param, requires_grad=False)
                    else:
                        continue

                param_state = self.state[param]
                if "momentum_buffer" in param_state:
                    param_state["momentum_buffer"].zero_()
        else:
            raise ValueError("Only Adam and SGD optimizer are supported currently")

    def step(self, closure=None):
        """Performs a single optimization step. If num_steps % sync_steps == 0, call BMUF operation

        Arguments:
            closure (callable, optional): A closure that reevaluates the model
                and returns the loss.
        """

        # initalize optimizer state
        if self._num_steps == 0:
            self._initialize_optimizer_state()

        # local model update
        if self._local_group and not self._local_ddp:
            self._sync_local_group_gradients()
        loss = super(self.__class__, self).step(closure)

        self._num_steps += 1

        # bmuf operation
        if self._num_groups > 1 and self._num_steps % self._sync_steps == 0:
            handles = {}
            # all_reduce param and stat values
            self._allreduce_param_and_state(handles)

            # bmuf
            self._bmuf_step(handles)

            # modify local optimizer buffer
            self._update_local_optimizer_state(handles)

            handles.clear()

        return loss


def broadcast_parameters(state_dict, root_rank=0):
    if dist.get_world_size() == 1:
        return
    params = sorted(state_dict.items())
    for _, p in params:
        dist.broadcast(p, src=root_rank)
    dist.barrier()

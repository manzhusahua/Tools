import contextlib
import torch
from torch.cuda.amp import GradScaler

from torchtts.engines.base_engine import Engine
from torchtts.utils.dict_utils import map_nested
from torchtts.utils.torch_utils import unwrap_ddp

import logging

logger = logging.getLogger(__name__)


class DeviceEngine(Engine):
    """Single device engine."""

    def __init__(self, device, use_amp=False, **kwargs):
        self.device = torch.device(device)
        self.use_amp = use_amp
        self.kwargs = kwargs
        self.use_hvd = False

        if use_amp:
            if not self.on_gpu:
                raise ValueError("GPU is unavailable. amp + cpu is not supported.")
            self.scaler = GradScaler()
            self.prev_autocast_state = False

    def setup(self):
        if self.on_gpu:
            torch.backends.cudnn.enabled = True
            torch.backends.cudnn.benchmark = self.kwargs.get("use_cudnn_benchmark", False)

    @property
    def rank(self):
        return -1

    @property
    def on_gpu(self):
        return self.device.type == "cuda" and torch.cuda.is_available()

    def barrier(self):
        pass

    def to_device(self, component):
        def map_func(c):
            if hasattr(c, "to"):
                c = c.to(self.device, non_blocking=True)
            return c

        return map_nested(map_func, component)

    def setup_model(self, model):
        return self.to_device(model)

    def setup_optimizer(self, model, optimizer):
        return model, optimizer

    def optimize_step(self, loss, optimizer, lr_scheduler=None):
        optimizer.zero_grad()

        # Apply backward
        if self.use_amp:
            self.scaler.scale(loss).backward()
        else:
            loss.backward()

        if self.use_hvd:
            optimizer.synchronize()

        # Apply gradient clipping
        # TODO: Add control of scale
        scale_grad = True
        if scale_grad:
            if self.use_amp:
                self.scaler.unscale_(optimizer)
            for group in optimizer.param_groups:
                torch.nn.utils.clip_grad_norm_(group["params"], 1.0)

        # Apply optimizing step
        if self.use_hvd:
            with optimizer.skip_synchronize():
                if self.use_amp:
                    self.scaler.step(optimizer)
                else:
                    optimizer.step()
        else:
            if self.use_amp:
                self.scaler.step(optimizer)
            else:
                optimizer.step()

        if self.use_amp:
            self.scaler.update()

        if lr_scheduler is not None:
            lr_scheduler.step()

    @contextlib.contextmanager
    def context(self):
        """Engine context for calculation.

        The context is used to hide the detail of whether to use auto precision
        training. Although users can use autocast with enabled=self.use_amp to
        enable or disable this feature, it's too detailed for the user.
        """
        with torch.cuda.amp.autocast(self.use_amp):
            yield

    def save_checkpoint(self, filename, trainer):
        checkpoint = {}
        checkpoint["model"] = map_nested(lambda m: unwrap_ddp(m).state_dict(), trainer.model)

        if trainer.optimizers is not None:
            checkpoint["optimizer"] = map_nested(lambda o: o.state_dict(), trainer.optimizers)

        if trainer.lr_schedulers is not None:
            checkpoint["scheduler"] = map_nested(lambda s: s.state_dict(), trainer.lr_schedulers)

        checkpoint["global_steps"] = trainer.global_steps
        checkpoint["epochs"] = trainer.epochs
        checkpoint["extra_states"] = trainer.extra_states

        torch.save(checkpoint, filename)

    def load_checkpoint(self, filename, trainer, strict=True, reset_trainer=False, parameter_list=None):
        checkpoint = torch.load(filename, map_location=self.device)

        if parameter_list is not None:
            parameter_list = list(parameter_list)
            states_dict = {}
            for para in parameter_list:
                para_loaded = False
                for k, v in checkpoint["model"].items():
                    if para in k:
                        states_dict[k] = v
                        logger.info(f"load: {k}")
                        para_loaded = True
                if para_loaded is False:
                    states_dict[para] = {"placeholder": 1}

            self._load_state_dict(trainer.model, states_dict, strict=False)
        else:
            self._load_state_dict(trainer.model, checkpoint["model"], strict=strict)

        if reset_trainer is False:
            # Parameter groups may mismatch in non-strict mode
            if "optimizer" in checkpoint and strict:
                self._load_state_dict(trainer.optimizers, checkpoint["optimizer"])

            if "scheduler" in checkpoint:
                self._load_state_dict(trainer.lr_schedulers, checkpoint["scheduler"])

            trainer.global_steps = checkpoint["global_steps"]
            trainer.epochs = checkpoint["epochs"]

            if "extra_states" in checkpoint:
                trainer.extra_states = checkpoint["extra_states"]

    @staticmethod
    def _load_state_dict(maybe_module_dict, state_dict, **kwargs):
        if isinstance(maybe_module_dict, dict):
            for key, value in maybe_module_dict.items():
                if value is not None:
                    unwrap_ddp(value).load_state_dict(state_dict[key], **kwargs)
        else:
            unwrap_ddp(maybe_module_dict).load_state_dict(state_dict, **kwargs)

    def __repr__(self):
        return f"DeviceEngine(device='{self.device}')"

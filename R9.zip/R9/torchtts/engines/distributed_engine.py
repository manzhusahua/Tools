import logging

import torch
import torch.distributed as dist
import torch.nn as nn

from torchtts.engines.device_engine import DeviceEngine
from torchtts.utils.dict_utils import map_nested
from torchtts.utils.import_utils import _HOROVOD_AVAILABLE
from torchtts.utils.import_utils import _HIT_AVAILABLE

logger = logging.getLogger(__name__)

if _HOROVOD_AVAILABLE:
    import horovod.torch as hvd

if _HIT_AVAILABLE:
    import hit


class DistributedDeviceEngine(DeviceEngine):
    def __init__(self, device, rank, local_rank, world_size, address, port, dist_config, use_amp=False, **kwargs):
        super(DistributedDeviceEngine, self).__init__(f"{device}:{local_rank}", use_amp=use_amp, **kwargs)
        self._rank = rank
        self._local_rank = local_rank
        self._world_size = world_size
        self._address = address
        self._port = port
        self.dist_config = dist_config
        self.backend = dist_config["backend"]
        self.dist_type = dist_config["type"].lower()
        assert self.dist_type in (
            "bmuf",
            "ddp",
            "hit",
            "horovod",
        ), "ERROR: training type should be one of bmuf, ddp, hit or horovod!"
        self.use_hvd = self.dist_type == "horovod"

    def setup(self):
        super(DistributedDeviceEngine, self).setup()
        # TODO: redesign engine part to distangle training types and precision
        if self.dist_type == "horovod":  # horovod
            if not hvd.is_initialized():
                hvd.init()
                logger.info(
                    "Horovod distributed is initialized with (NCCL version: "
                    f"{hvd.nccl_built()}, World Size: {hvd.size()}, "
                    f"Rank: {hvd.rank()})"
                )
            else:
                logger.warning("Horovod distributed has already been initialized.")
        else:  # "bmuf", "ddp", "hit"
            if not dist.is_initialized():
                dist.init_process_group(
                    backend=self.backend,
                    init_method=f"tcp://{self._address}:{self._port}",
                    world_size=self._world_size,
                    rank=self._rank,
                )
                logger.info(
                    f"Torch distributed is initialized with (Init Method: "
                    f"{self._address}, World Size: {self._world_size}, "
                    f"Rank: {self._rank}, Backend: {self.backend})"
                )
            else:
                logger.warning("Torch distributed has already been initialized.")

        if self.on_gpu:
            torch.cuda.set_device(self._local_rank)

    def cleanup(self):
        if self.dist_type == "horovod":  # horovod
            hvd.shutdown()
        else:  # "bmuf", "ddp", "hit"
            dist.destroy_process_group()

    def setup_model(self, model):
        model = super(DistributedDeviceEngine, self).setup_model(model)
        if self.dist_type == "ddp":

            def map_func(m):
                if not any((p.requires_grad for p in m.parameters())):
                    return m
                m = torch.nn.SyncBatchNorm.convert_sync_batchnorm(m)
                return nn.parallel.DistributedDataParallel(
                    m, device_ids=[self._local_rank], output_device=self._local_rank, **self.dist_config["ddp"]
                )

            model = map_nested(map_func, model)
        return model

    def setup_optimizer(self, model, optimizer):
        """Init distributed optimizer according to config."""
        if self.dist_type != "ddp":
            any_dict = isinstance(model, dict) or isinstance(optimizer, dict)
            all_dict = isinstance(model, dict) and isinstance(optimizer, dict)
            if (any_dict and not all_dict) or (all_dict and model.keys() != optimizer.keys()):
                raise ValueError(
                    "Distributed methods other than DDP need model and optimizer "
                    "match each other. It means that they both be single object, "
                    "or dict with the same keys."
                )

        func_dict = {
            "bmuf": self._setup_optimizer_bmuf,
            "hit": self._setup_optimizer_hit,
            "horovod": self._setup_optimizer_hvd,
            "ddp": lambda *args: args,
        }
        return func_dict[self.dist_type](model, optimizer)

    def _setup_optimizer_bmuf(self, model, optimizer):
        """Call BMUF DistributedOptimizer."""
        from torchtts.engines import bmuf

        bmuf.broadcast_parameters(model.state_dict(), root_rank=0)
        optimizer = bmuf.create_distributed_optimizer(model, optimizer, self.dist_config)
        return optimizer.model(), optimizer

    def _setup_optimizer_hit(self, model, optimizer):
        """Call HiT DistributedOptimizer."""

        class Dict(dict):
            def __getattr__(self, key):
                return self.get(key)

        args = Dict(hit=True, hit_config_file=None, hit_config_params=self.dist_config)
        return hit.initialize_hit_optimizer(model, optimizer, args)

    def _setup_optimizer_hvd(self, model, optimizer):
        """Call Horovod DistributedOptimizer."""
        # Horovod: broadcast parameters & optimizer state.
        hvd.broadcast_parameters(model.state_dict(), root_rank=0)
        hvd.broadcast_optimizer_state(optimizer, root_rank=0)
        # Horovod: (optional) compression algorithm.
        compression = (
            hvd.Compression.fp16 if self.dist_config["horovod"]["compression"] == "fp16" else hvd.Compression.none
        )
        backward_passes_per_step = int(self.dist_config["horovod"]["backward_passes_per_step"])
        optimizer = hvd.DistributedOptimizer(
            optimizer,
            named_parameters=model.named_parameters(),
            compression=compression,
            backward_passes_per_step=backward_passes_per_step,
        )
        return model, optimizer

    @property
    def rank(self):
        return self._rank

    def barrier(self):
        if self.dist_type == "horovod":  # horovod
            hvd.join()
        else:  # "bmuf", "ddp", "hit"
            dist.barrier()

    def __repr__(self):
        return (
            f"DistributedDeviceEngine(dist_type={self.dist_type}, "
            f"address={self._address}, port={self._port}, "
            f"backend='{self.backend}', rank={self._rank}, "
            f"local_rank={self._local_rank}, world_size={self._world_size})"
        )

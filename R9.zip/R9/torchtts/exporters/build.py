import hydra
import logging
from omegaconf import OmegaConf

logger = logging.getLogger(__name__)


def build_exporter(exporter_config):
    logger.info("Instantiating exporter with config: \n" f"{OmegaConf.to_yaml(exporter_config, sort_keys=True)}")
    exporter = hydra.utils.instantiate(exporter_config)
    return exporter

import logging
import torch
import os

from torchtts.exporters.exporter import Exporter
from torch.onnx import register_custom_op_symbolic

logger = logging.getLogger(__name__)


def custom_fmoe(g, input, weight, bias, num_expert, top_k, gate_idx, gate_score, num_repeat):
    return g.op("com.microsoft::FMoE", input, weight, bias, num_expert, top_k, gate_idx, gate_score, num_repeat)


class ConformerExporter(Exporter):
    def to_onnx(self, path, fmoe_custom_lib_path=None):
        self.model.forward = self.model.inference

        if self.model.enable_style_transfer:
            self.model.forward = self.model.inference_style_transfer

        if self.model.dump_cross_lingual_v2:
            self.model.forward = self.model.inference

        if self.model.enable_fmoe:
            torch.ops.load_library(fmoe_custom_lib_path)
            register_custom_op_symbolic("mstts::custom_fmoe", custom_fmoe, 12)

        model_args = []
        input_names = []
        output_names = [
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0",
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0",
        ]
        dynamic_axes = {
            "X_inputs:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0": {1: "num_frames"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0": {1: "num_phones"},
        }

        phone_id = torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32)
        model_args.append(phone_id)
        input_names.append("X_inputs:0")

        if self.model.enable_multi_speaker:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/spk_id:0")
        else:
            model_args.append(None)

        if self.model.enable_cross_lingual:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/locale_id:0")
        else:
            model_args.append(None)

        if self.model.enable_multi_style:
            # Style id
            model_args.append(torch.tensor([0], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/Placeholder:0")
            # Style degree
            model_args.append(torch.tensor([1.0], dtype=torch.float32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/style_scale:0")
        else:
            # Style id
            model_args.append(None)
            # Style degree
            model_args.append(None)

        speaking_rate = torch.ones(1, 10, dtype=torch.float32)
        model_args.append(speaking_rate)
        input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0")

        if self.model.enable_pitch_contour and not self.model.use_singing_feature:
            f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
            model_args.append(f0_scale_ratio)
            input_names.append(
                "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0"
            )
            dynamic_axes.update(
                {
                    "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0": {
                        1: "num_phones"
                    }
                }
            )
        else:
            model_args.append(None)

        if self.model.use_singing_feature:
            if self.model.enable_frame_pitch:
                model_args.append(None)
            else:
                model_args.append(torch.randint(0, 80, (1, 10, 1, 1), dtype=torch.int32))
                input_names.append("note_pitch")
                dynamic_axes.update({"note_pitch": {1: "num_phones"}})

            model_args.append(torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32))
            input_names.append("note_duration")
            dynamic_axes.update({"note_duration": {1: "num_phones"}})

            model_args.append(torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32))
            input_names.append("syllable_boundary")
            dynamic_axes.update({"syllable_boundary": {1: "num_phones"}})

            model_args.append(torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32))
            input_names.append("syllable_duration")
            dynamic_axes.update({"syllable_duration": {1: "num_syllables"}})

            if self.model.enable_syllabledurforsinging:
                model_args.append(torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32))
                input_names.append("phone_syllable_duration")
                dynamic_axes.update({"phone_syllable_duration": {1: "num_phones"}})

        if self.model.enable_context:
            model_args.append(torch.randn(1, phone_id.size(1), 518))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/context_phone:0")
            dynamic_axes.update(
                {"na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/context_phone:0": {1: "num_phones"}}
            )
            # context len = 5
            model_args.append(torch.randn(1, 5, 512))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/context_seq:0")

        if self.model.use_singing_feature:
            self.model.forward = self.model.dumpencoder
            dynamic_axes.update({"encoderout": {1: "num_phones"}})
            dynamic_axes.update({"duration": {1: "num_phones"}})
            torch.onnx.export(
                self.model,
                tuple(model_args),
                path + "_singing_encoder.obin",
                opset_version=12,
                do_constant_folding=True,
                input_names=input_names,
                output_names=["encoderout", "duration"],
                dynamic_axes=dynamic_axes,
            )
            self.model.forward = self.model.dumpdecoder
            if self.model.enable_frame_pitch:
                torch.onnx.export(
                    self.model,
                    (
                        torch.rand(1, 10, 384),
                        torch.randint(0, 20, (1, 10), dtype=torch.int32),
                        torch.randint(0, 80, (1, 10, 1, 1), dtype=torch.int32),
                    ),
                    path + "_singing_decoder.obin",
                    opset_version=12,
                    do_constant_folding=True,
                    input_names=["encoderout", "duration", "note_pitch"],
                    output_names=["mel"],
                    dynamic_axes={
                        "encoderout": {1: "num_phones"},
                        "duration": {1: "num_phones"},
                        "note_pitch": {1: "num_phones"},
                        "mel": {1: "num_frames"},
                    },
                )
            else:
                torch.onnx.export(
                    self.model,
                    (torch.rand(1, 10, 384), torch.randint(0, 20, (1, 10), dtype=torch.int32)),
                    path + "_singing_decoder.obin",
                    opset_version=12,
                    do_constant_folding=True,
                    input_names=["encoderout", "duration"],
                    output_names=["mel"],
                    dynamic_axes={
                        "encoderout": {1: "num_phones"},
                        "duration": {1: "num_phones"},
                        "mel": {1: "num_frames"},
                    },
                )

        else:
            torch.onnx.export(
                self.model,
                tuple(model_args),
                path,
                opset_version=12,
                do_constant_folding=True,
                input_names=input_names,
                output_names=output_names,
                dynamic_axes=dynamic_axes,
            )

            if self.model.dec_use_highwayrnn:
                output_path = path[0: path.rindex('/')]
                am_encoder_path = os.path.join(output_path, "am_encoder.obin")
                am_decoder_path = os.path.join(output_path, "am_decoder.obin")

                self.model.forward = self.model.inference_encoder
                torch.onnx.export(
                    self.model,
                    tuple(model_args),
                    am_encoder_path,
                    opset_version=12,
                    do_constant_folding=True,
                    input_names=input_names,
                    output_names=output_names,
                    dynamic_axes=dynamic_axes)

                model_args = []
                input_names = []
                model_args.append(torch.ones(1, 1, 384, dtype=torch.float32))
                input_names.append('am_encoder_output')
                output_names = ['mel']

                dynamic_axes = {
                    'am_encoder_output': {
                        1: 'num_frames'
                    },
                    'mel': {
                        1: 'num_frames'
                    }
                }
                self.model.forward = self.model.inference_decoder
                torch.onnx.export(
                    self.model,
                    tuple(model_args),
                    am_decoder_path,
                    opset_version=12,
                    do_constant_folding=True,
                    input_names=input_names,
                    output_names=output_names,
                    dynamic_axes=dynamic_axes)

        logger.info(f"Finished exporting onnx model to {path}")

    def to_cuda(self, path, fmoe_custom_lib_path=None):
        return

from abc import ABC
from abc import abstractmethod


class Exporter(ABC):
    def __init__(self, **kwargs):
        self.model = None
        self.config = kwargs

    def setup(self, model, checkpoint):
        self.model = model
        self.model.load_state_dict(checkpoint["model"])
        self.model.eval()

    @abstractmethod
    def to_onnx(self, path):
        raise NotImplementedError

    @abstractmethod
    def to_cuda(self, path):
        raise NotImplementedError

import io
import logging
import onnx
import re
import torch

from torchtts.exporters.exporter import Exporter
from torchtts.utils import onnx_utils

logger = logging.getLogger(__name__)


class FastSpeech2Exporter(Exporter):
    def setup(self, model, checkpoint):
        self.model = model
        del checkpoint["model"]["enc_pos_encoding.pe"]
        del checkpoint["model"]["dec_pos_encoding.pe"]
        self.model.load_state_dict(checkpoint["model"], strict=False)
        self.model.eval()

    def to_onnx(self, path):
        # Override default forward method for inference
        self.model.forward = self.model.inference

        # Note: onnx export relies on the relative order of parameters. Support for dict-based args and input/output
        # names is still limited in PyTorch 1.8.1. May update this once PyTorch has stable support on this.

        # The order need to match the inference signature:
        # def inference(self, phone_id, speaker_id=None, locale_id=None,
        #               speaking_rate=None):

        model_args = []
        input_names = []
        output_names = [
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0",
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0",
        ]
        dynamic_axes = {
            "X_inputs:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0": {1: "num_frames"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0": {1: "num_phones"},
        }

        phone_id = torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32)
        model_args.append(phone_id)
        input_names.append("X_inputs:0")

        if self.model.use_multi_speaker:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/spk_id:0")
        else:
            model_args.append(None)

        if self.model.use_multi_locale:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/locale_id:0")
        else:
            model_args.append(None)

        speaking_rate = torch.ones(1, 10, dtype=torch.float32)
        model_args.append(speaking_rate)
        input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0")

        f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
        model_args.append(f0_scale_ratio)
        input_names.append(
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0"
        )
        dynamic_axes.update(
            {
                "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0": {
                    1: "num_phones"
                }
            }
        )

        if self.config["export_partial_model"]:
            # Export onnx model to temporary BytesIO
            bytes_io = io.BytesIO()
            torch.onnx.export(
                self.model,
                tuple(model_args),
                bytes_io,
                opset_version=12,  # Use version 12 to support clamp with int
                do_constant_folding=True,
                input_names=input_names,
                output_names=output_names,
                dynamic_axes=dynamic_axes,
            )
            # Load and modify for partial dumping
            bytes_io.seek(0)
            onnx_model = onnx.load_model(bytes_io)
            graph = onnx_model.graph

            initializer_map = onnx_utils.create_graph_member_map(graph.initializer)

            pattern = re.compile("(speaker_embedding.linear.bias|locale_embedding.linear.bias|weight_proj|bias_proj)")

            for node in graph.node:
                for input_node_name in node.input:
                    if re.search(pattern, input_node_name):
                        # Replace node with identity node as a connector
                        if "speaker_embedding" in input_node_name or "locale_embedding" in input_node_name:
                            new_input = input_node_name + ":0"
                        else:
                            new_input = "_".join(input_node_name.split("_")[:-1]) + ":0"
                        new_node = onnx_utils.make_node("Identity", inputs=[new_input], outputs=node.output)
                        onnx_utils.replace_node(graph, node.name, new_node)
                        # Clean up dependent initializers
                        onnx_utils.delete_initializer(graph, input_node_name)
                        # Connect input with previous created identity node
                        dim = initializer_map[input_node_name].dims[0]
                        onnx_utils.add_input(graph, new_input, "FLOAT", [1, 1, dim])

            # Check modified onnx model
            onnx.checker.check_model(onnx_model)
            onnx.save(onnx_model, path)

        else:
            torch.onnx.export(
                self.model,
                tuple(model_args),
                path,
                opset_version=12,  # Use version 12 to support clamp with int
                do_constant_folding=True,
                input_names=input_names,
                output_names=output_names,
                dynamic_axes=dynamic_axes,
            )

        logger.info(f"Finished exporting onnx model to {path}")

    def to_cuda(self, path):
        raise NotImplementedError

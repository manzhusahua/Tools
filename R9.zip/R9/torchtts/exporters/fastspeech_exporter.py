import logging
import os
import re
import numpy as np
import torch

from torchtts.exporters.exporter import Exporter
from torch.onnx import register_custom_op_symbolic

logger = logging.getLogger(__name__)


def custom_fmoe(g, input, weight, bias, num_expert, top_k, gate_idx, gate_score, num_repeat):
    return g.op("com.microsoft::FMoE", input, weight, bias, num_expert, top_k, gate_idx, gate_score, num_repeat)


class FastSpeechExporter(Exporter):
    def setup(self, model, checkpoint):
        self.model = model
        del checkpoint["model"]["enc_pos_encoding.pe"]
        del checkpoint["model"]["dec_pos_encoding.pe"]
        self.model.load_state_dict(checkpoint["model"], strict=False)
        self.model.eval()
        if model.enable_fmoe:
            torch.ops.load_library("torch_custom.so")
            register_custom_op_symbolic("mstts::custom_fmoe", custom_fmoe, 12)

    def to_onnx(self, path):
        # Override default forward method for inference
        self.model.forward = self.model.inference

        # Note: onnx export relies on the relative order of parameters. Support for dict-based args and input/output
        # names is still limited in PyTorch 1.8.1. May update this once PyTorch has stable support on this.

        # The order need to match the inference signature:
        # def inference(self, phone_id, speaker_id=None, locale_id=None,
        #               style_id=None, style_scale_ratio=None,
        #               speaking_rate=None, f0_scale_ratio=None,
        #               f0_scale_min=0.97, f0_scale_max=1.03):

        model_args = []
        input_names = []
        output_names = [
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0",
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0",
        ]
        dynamic_axes = {
            "X_inputs:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0": {1: "num_frames"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0": {1: "num_phones"},
        }

        phone_id = torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32)
        model_args.append(phone_id)
        input_names.append("X_inputs:0")

        if self.model.use_multi_speaker:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/spk_id:0")
        else:
            model_args.append(None)

        if self.model.use_multi_locale:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/locale_id:0")
        else:
            model_args.append(None)

        if self.model.use_multi_style:
            # Style id
            model_args.append(torch.tensor([0], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/Placeholder:0")
            # Style degree
            model_args.append(torch.tensor([1.0], dtype=torch.float32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/style_scale:0")
        else:
            # Style id
            model_args.append(None)
            # Style degree
            model_args.append(None)

        speaking_rate = torch.ones(1, 10, dtype=torch.float32)
        model_args.append(speaking_rate)
        input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0")

        if self.model.enable_pitch_contour:
            f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
            model_args.append(f0_scale_ratio)
            input_names.append(
                "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0"
            )
            dynamic_axes.update(
                {
                    "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0": {
                        1: "num_phones"
                    }
                }
            )
        else:
            model_args.append(None)

        torch.onnx.export(
            self.model,
            tuple(model_args),
            path,
            opset_version=12,  # Use version 12 to support clamp with int
            do_constant_folding=True,
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes,
        )

        logger.info(f"Finished exporting onnx model to {path}")

    def to_cuda(self, path):
        for name, params in self.model.named_parameters():
            missing_key = True
            for torch_pattern, cuda_name in self.config["cuda_name_mapping"].items():
                match = re.match(torch_pattern, name)
                if not match:
                    continue
                self._save_params_to_cuda(path, torch_pattern, cuda_name, params, *match.groups())
                # We already get the matching key here
                missing_key = False
                break

            # T2t target space embedding is only constant for tts task. Here we just
            # make a fake embedding table with all zeros for runtime compatibility.
            _save_txt(
                os.path.join(path, "na_speech_model/body/target_space_embedding/kernel"),
                np.zeros((32, 384), dtype=np.float32),
            )

            if missing_key:
                logger.error(f"Could not find a cuda mapping for {name}")

        logger.info(f"Finished exporting model weights for cuda runtime to {path}")

    @staticmethod
    def _save_params_to_cuda(path, name_pattern, cuda_name, params, *groups):
        if params.dim() == 3:
            # Convolution
            for i in range(params.size(-1)):
                save_path = os.path.join(path, cuda_name.format(*groups, i))
                _save_txt(save_path, params[..., i].detach().numpy().T)
        elif params.dim() == 2:
            save_path = os.path.join(path, cuda_name.format(*groups))
            if "embedding.weight" in name_pattern:
                weights = params.detach().numpy()
            elif "mel_softmax" in cuda_name:
                weights = params.detach().numpy().T
                weights = np.pad(weights, ((0, 0), (0, 1)))
            else:
                weights = params.detach().numpy().T
            _save_txt(save_path, weights)
        elif params.dim() == 1:
            save_path = os.path.join(path, cuda_name.format(*groups))
            _save_txt(save_path, params.detach().numpy())
        else:
            raise ValueError(f"{params.dim()}D parameters are not supported to save")


def _save_txt(save_path, weights):
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    logger.info(f"Saving weights to {save_path}")
    np.savetxt(save_path, weights)

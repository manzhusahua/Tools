import logging
import os
import json
import torch

from torchtts.exporters.exporter import Exporter
from torchtts.exporters.weight_dumpers.hifinet import FullBandGeneratorWeightDumper

logger = logging.getLogger(__name__)
# Add json config to the export dir
config = {"upsampling_ratios": "5,5,4,3", "relu_after_mel_conv": True, "input_dim": 128, "use_gru": True}


class FoundationTTSExporter(Exporter):
    def setup(self, model, checkpoint):
        self.vocoder = model["codec_decoder"]
        self.vocoder.load_state_dict(checkpoint["model"]["codec_decoder"])

        if "generator_ema" in checkpoint["extra_states"]:
            shadow = checkpoint["extra_states"]["generator_ema"]
            for name, param in self.vocoder.named_parameters():
                if param.requires_grad:
                    param.data.copy_(shadow[name])
        # Set to eval now
        self.vocoder.remove_weight_norm()
        self.vocoder.eval()

        self.am = model["acoustic_model"]
        self.am.load_state_dict(checkpoint["model"]["acoustic_model"])
        self.am.eval()

    def to_onnx(self, path):
        self.vocoder_to_onnx(path)
        self.am_to_onnx(path)

    def to_cuda(self, path):
        self.vocoder_to_cuda(path)
        return

    def am_to_onnx(self, path):
        path = os.path.join(path, "am.obin")

        self.am.forward = self.am.inference

        if self.am.enable_style_transfer:
            self.am.forward = self.am.inference_style_transfer

        model_args = []
        input_names = []
        output_names = [
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0",
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0",
        ]
        dynamic_axes = {
            "X_inputs:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0": {1: "num_frames"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0": {1: "num_phones"},
        }

        phone_id = torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32)
        model_args.append(phone_id)
        input_names.append("X_inputs:0")

        if self.am.enable_multi_speaker:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/spk_id:0")
        else:
            model_args.append(None)

        if self.am.enable_cross_lingual:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/locale_id:0")
        else:
            model_args.append(None)

        if self.am.enable_multi_style:
            # Style id
            model_args.append(torch.tensor([0], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/Placeholder:0")
            # Style degree
            model_args.append(torch.tensor([1.0], dtype=torch.float32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/style_scale:0")
        else:
            # Style id
            model_args.append(None)
            # Style degree
            model_args.append(None)

        speaking_rate = torch.ones(1, 10, dtype=torch.float32)
        model_args.append(speaking_rate)
        input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0")

        if self.am.enable_pitch_contour:
            f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
            model_args.append(f0_scale_ratio)
            input_names.append(
                "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0"
            )
            dynamic_axes.update(
                {
                    "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0": {
                        1: "num_phones"
                    }
                }
            )
        else:
            model_args.append(None)

        torch.onnx.export(
            self.am,
            tuple(model_args),
            path,
            opset_version=12,
            do_constant_folding=True,
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes,
        )

        logger.info(f"Finished exporting acoustic onnx model to {path}")

    def vocoder_to_onnx(self, path):
        path = os.path.join(path, "vocoder_24k_cpu")
        os.makedirs(path, exist_ok=True)

        mel = torch.rand((1, 128, 100))
        torch.onnx.export(
            self.vocoder.model["pre_model"],
            (mel,),
            os.path.join(path, "foundationtts_gru.obin"),
            input_names=["mel"],
            output_names=["wave"],
            dynamic_axes={"mel": [2], "wave": [2]},
            opset_version=10,
        )

        num_upsample_layers = len(self.vocoder.up_ratios)
        for i in range(num_upsample_layers):
            up_channel = int(2 ** (num_upsample_layers - i)) * self.vocoder.ngf
            mel = torch.rand((1, up_channel, 100))
            torch.onnx.export(
                self.vocoder.model[f"upsample_{i}"],
                (mel,),
                os.path.join(path, f"foundationtts_upsampling{i}.obin"),
                input_names=["mel"],
                output_names=["wave"],
                dynamic_axes={"mel": [2], "wave": [2]},
                opset_version=10,
            )

        mel = torch.rand((1, 32, 100))
        torch.onnx.export(
            self.vocoder.model["post_model"],
            (mel,),
            os.path.join(path, "foundationtts_lastconv.obin"),
            input_names=["mel"],
            output_names=["wave"],
            dynamic_axes={"mel": [2], "wave": [2]},
            opset_version=10,
        )
        # Add json config to the export dir
        with open(os.path.join(path, "config.json"), "w") as config_file:
            json.dump(config, config_file, indent=4)

        logger.info(f"Finished exporting onnx vocoder to {path}")

    def vocoder_to_cuda(self, path):
        path = os.path.join(path, "vocoder_24k_gpu")
        os.makedirs(path, exist_ok=True)

        num_upsample_layers = len(self.vocoder.up_ratios)
        dumper = FullBandGeneratorWeightDumper(
            path, num_upsampling_blocks=num_upsample_layers, num_residual_layers=3, with_gru=True
        )
        name_list = []
        for name in self.vocoder.state_dict().keys():
            if "quantizer" in name:
                continue
            name_list.append(name)
            logger.info(f"gpu cuda dump name {name}")
        loaded_var_num = dumper.load(name_list, self.vocoder.state_dict(), 0)
        assert loaded_var_num == len(name_list)
        dumper.dump()

        # Add json config to the export dir
        with open(os.path.join(path, "config.json"), "w") as config_file:
            json.dump(config, config_file, indent=4)

        logger.info(f"Finished exporting vocoder model weights for cuda runtime to {path}")

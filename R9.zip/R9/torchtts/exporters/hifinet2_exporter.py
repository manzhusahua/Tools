import logging
import os
import json
import torch
import onnx
from functools import partial

from torchtts.exporters.exporter import Exporter
from torchtts.exporters.weight_dumpers.HiFinet2 import Hifinet2Dumper

logger = logging.getLogger(__name__)


class Hifinet2TTSExporter(Exporter):

    def setup(self, model, checkpoint):

        # load weight to base model
        self.base_model = model['multibands_generator']
        self.base_model.load_state_dict(checkpoint['model']['multibands_generator'])
        # self.base_model.remove_weight_norm()

        self.vocoder_gpu = model['multibands_generator']
        self.vocoder_gpu.load_state_dict(checkpoint['model']['multibands_generator'])
        # self.vocoder_gpu.remove_weight_norm()
        if 'generator_ema' in checkpoint['extra_states']:
            shadow = checkpoint['extra_states']['generator_ema']
            for name, param in self.vocoder_gpu.named_parameters():
                if param.requires_grad:
                    param.data.copy_(shadow[name])

        # load weight to dump model
        self.vocoder = model['multibands_generator_dumper']
        self.vocoder.load_state_dict(self.base_model.state_dict(), strict=False)
        self.vocoder.eval()

        if 'generator_ema' in checkpoint['extra_states']:
            shadow = checkpoint['extra_states']['generator_ema']
            for name, param in self.vocoder.named_parameters():
                if param.requires_grad:
                    param.data.copy_(shadow[name])

    def to_onnx(self, path):
        self.vocoder_to_onnx(path)
        # self.am_to_onnx(path)

    def to_cuda(self, path):
        self.vocoder_to_cuda(path)
        print(path)
        return

    def am_to_onnx(self, path):
        path = os.path.join(path, 'am.obin')

        self.am.forward = self.am.inference

        if self.am.enable_style_transfer:
            self.am.forward = self.am.inference_style_transfer

        model_args = []
        input_names = []
        output_names = [
            'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0',
            'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0',
        ]
        dynamic_axes = {
            'X_inputs:0': {
                1: 'num_phones'
            },
            'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0': {
                1: 'num_phones'
            },
            'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0': {
                1: 'num_frames'
            },
            'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0': {
                1: 'num_phones'
            }
        }

        phone_id = torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32)
        model_args.append(phone_id)
        input_names.append('X_inputs:0')

        if self.am.enable_multi_speaker:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append(
                'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/spk_id:0')
        else:
            model_args.append(None)

        if self.am.enable_cross_lingual:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append(
                'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/locale_id:0')
        else:
            model_args.append(None)

        if self.am.enable_multi_style:
            # Style id
            model_args.append(torch.tensor([0], dtype=torch.int32))
            input_names.append(
                'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/Placeholder:0')
            # Style degree
            model_args.append(torch.tensor([1.0], dtype=torch.float32))
            input_names.append(
                'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/style_scale:0')
        else:
            # Style id
            model_args.append(None)
            # Style degree
            model_args.append(None)

        speaking_rate = torch.ones(1, 10, dtype=torch.float32)
        model_args.append(speaking_rate)
        input_names.append('na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0')

        if self.am.enable_pitch_contour:
            f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
            model_args.append(f0_scale_ratio)
            input_names.append(
                'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0')
            dynamic_axes.update({
                'na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0': {
                    1: 'num_phones'
                }
            })
        else:
            model_args.append(None)

        torch.onnx.export(
            self.am,
            tuple(model_args),
            path,
            opset_version=12,
            do_constant_folding=True,
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes)

        logger.info(f"Finished exporting acoustic onnx model to {path}")

    def vocoder_to_onnx(self, path):
        path = os.path.join(path, 'vocoder_48k_cpu')
        os.makedirs(path, exist_ok=True)

        mel = torch.zeros(1, 128, 100, dtype=torch.float32)
        # dump to onnx
        self.vocoder.forward = partial(self.vocoder.onnx_forward)
        output_dir = path
        torch.onnx.export(self.vocoder,
                          (mel,),
                          os.path.join(output_dir, '48k.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        self.vocoder.forward = partial(self.vocoder.onnx_dump_prenet)
        torch.onnx.export(self.vocoder,
                          (mel,),
                          os.path.join(output_dir, '48k_prenet.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        self.vocoder.forward = partial(self.vocoder.onnx_dump_ups_48k)
        feature = torch.zeros(mel.shape[0], 512, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder,
                          (feature,),
                          os.path.join(output_dir, 'vocoder_ups_48k.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        self.vocoder.forward = partial(self.vocoder.onnx_dump_last_conv_48k)
        feature1 = torch.zeros(mel.shape[0], 64, mel.shape[2], dtype=torch.float32)
        feature2 = torch.zeros(mel.shape[0], 64, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder,
                          (feature1, feature2),
                          os.path.join(output_dir, 'lastconv.onnx'),
                          opset_version=12,
                          input_names=['x1', 'x2'], output_names=['wave_24', 'wave_48'],
                          dynamic_axes={'x1': {2: 'sequence'},
                                        'x2': {2: 'sequence'},
                                        'wave_24': {2: 'sequence'},
                                        'wave_48': {2: 'sequence'}})

        self.vocoder.forward = partial(self.vocoder.onnx_dump_pqmf_48k)
        x1 = torch.rand((1, 4, 300))
        x2 = torch.rand((1, 4, 300))

        torch.onnx.export(self.vocoder,
                          (x1, x2),
                          os.path.join(output_dir, 'pqmf.onnx'),
                          opset_version=12,
                          input_names=['x1', 'x2'], output_names=['wave'],
                          dynamic_axes={'x1': {2: 'sequence'},
                                        'x2': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        self.vocoder.forward = partial(self.vocoder.onnx_dump_pqmf_24k)
        feature = torch.zeros(mel.shape[0], 64, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder,
                          (feature),
                          os.path.join(output_dir, '48k_lastconv.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        self.vocoder.forward = partial(self.vocoder.onnx_dump_ups_24k)
        feature = torch.zeros(mel.shape[0], 512, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder,
                          (feature,),
                          os.path.join(output_dir, 'vocoder_ups_24k.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        feature = torch.zeros(mel.shape[0], 512, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder.model_24_up0,
                          (feature,),
                          os.path.join(output_dir, '48k_upsampling0.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        feature = torch.zeros(mel.shape[0], 256, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder.model_24_up1,
                          (feature,),
                          os.path.join(output_dir, '48k_upsampling1.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        feature = torch.zeros(mel.shape[0], 128, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder.model_24_up2,
                          (feature,),
                          os.path.join(output_dir, '48k_upsampling2.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        feature = torch.zeros(mel.shape[0], 512, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder.model_24_48_up0,
                          (feature,),
                          os.path.join(output_dir, '48k_upsampling0_48k.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        feature = torch.zeros(mel.shape[0], 256, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder.model_24_48_up1,
                          (feature,),
                          os.path.join(output_dir, '48k_upsampling1_48k.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        feature = torch.zeros(mel.shape[0], 128, mel.shape[2], dtype=torch.float32)
        torch.onnx.export(self.vocoder.model_24_48_up2,
                          (feature,),
                          os.path.join(output_dir, '48k_upsampling2_48k.onnx'),
                          opset_version=12,
                          input_names=['mel'], output_names=['wave'],
                          dynamic_axes={'mel': {2: 'sequence'},
                                        'wave': {2: 'sequence'}})

        onnx_model = onnx.load(os.path.join(output_dir, '48k.onnx'))
        onnx.checker.check_model(onnx_model)
        print(onnx_model.graph.input)
        print(onnx_model.graph.output)

        logger.info(f"Finished exporting onnx vocoder to {path}")

    def vocoder_to_cuda(self, path):
        path = os.path.join(path, 'vocoder_24k_gpu')
        os.makedirs(path, exist_ok=True)

        dumper = Hifinet2Dumper(path, enable_rezero=1)
        name_list = []
        for name in self.vocoder_gpu.state_dict().keys():
            if 'quantizer' in name:
                continue
            name_list.append(name)
            logger.info(f"gpu cuda dump name {name}")
        loaded_var_num = dumper.load(name_list, self.vocoder_gpu.state_dict(), 0)
        assert (loaded_var_num == len(name_list))
        dumper.dump()

        # Add json config to the export dir
        config = {
            "upsampling_ratios": "5,5,4,3",
            "relu_after_mel_conv": True,
            "input_dim": 128
        }
        with open(os.path.join(path, 'config.json'), "w") as config_file:
            json.dump(config, config_file, indent=4)

        logger.info(f"Finished exporting vocoder model weights for cuda runtime to {path}")

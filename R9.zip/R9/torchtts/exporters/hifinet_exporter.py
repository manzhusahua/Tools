import logging
import os
import json
import torch

from torchtts.exporters.exporter import Exporter
from torchtts.exporters.weight_dumpers.hifinet import FullBandGeneratorWeightDumper

logger = logging.getLogger(__name__)


class HiFiNetExporter(Exporter):
    def setup(self, model, checkpoint):
        self.model = model["generator"]
        self.model.load_state_dict(checkpoint["model"]["generator"])
        # Apply ema if possible
        if "generator_ema" in checkpoint["extra_states"]:
            shadow = checkpoint["extra_states"]["generator_ema"]
            for name, param in self.model.named_parameters():
                if param.requires_grad:
                    param.data.copy_(shadow[name])
        # Set to eval now
        self.model.remove_weight_norm()
        self.model.eval()

    def to_onnx(self, path):
        # HiFiNet exporter dumps the whole model to several parts
        os.makedirs(path, exist_ok=True)

        mel = torch.rand((1, 80, 100))
        torch.onnx.export(
            self.model.model["pre_model"],
            (mel,),
            os.path.join(path, "mvocoder_gru.obin"),
            input_names=["mel"],
            output_names=["wave"],
            dynamic_axes={"mel": [2], "wave": [2]},
            opset_version=10,
        )

        num_upsample_layers = len(self.model.up_ratios)
        for i in range(num_upsample_layers):
            up_channel = int(2 ** (num_upsample_layers - i)) * self.model.ngf
            mel = torch.rand((1, up_channel, 100))
            torch.onnx.export(
                self.model.model[f"upsample_{i}"],
                (mel,),
                os.path.join(path, f"mvocoder_upsampling{i}.obin"),
                input_names=["mel"],
                output_names=["wave"],
                dynamic_axes={"mel": [2], "wave": [2]},
                opset_version=10,
            )

        mel = torch.rand((1, 32, 100))
        torch.onnx.export(
            self.model.model["post_model"],
            (mel,),
            os.path.join(path, "mvocoder_lastconv.obin"),
            input_names=["mel"],
            output_names=["wave"],
            dynamic_axes={"mel": [2], "wave": [2]},
            opset_version=10,
        )

        logger.info(f"Finished exporting onnx model to {path}")

    def to_cuda(self, path):
        num_upsample_layers = len(self.model.up_ratios)
        dumper = FullBandGeneratorWeightDumper(
            path, num_upsampling_blocks=num_upsample_layers, num_residual_layers=3, enable_rezero=True
        )
        name_list = []
        for name in self.model.state_dict().keys():
            name_list.append(name)
        loaded_var_num = dumper.load(name_list, self.model.state_dict(), 0)
        assert loaded_var_num == len(name_list)
        dumper.dump()

        # Add json config to the export dir
        config = {"upsampling_ratios": "3,4,5,5", "relu_after_mel_conv": True}
        with open(os.path.join(path, "config.json"), "w") as config_file:
            json.dump(config, config_file, indent=4)

        logger.info(f"Finished exporting model weights for cuda runtime to {path}")

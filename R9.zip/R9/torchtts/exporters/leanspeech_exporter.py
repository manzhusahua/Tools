import logging

import torch
import itertools
import re
from onnxruntime.quantization import quantize_dynamic

from torchtts.exporters.exporter import Exporter

logger = logging.getLogger(__name__)


class LeanSpeechExporter(Exporter):
    def __init__(self):
        super(LeanSpeechExporter, self).__init__()
        self.export_encoder = True
        self.export_decoder = True
        self.op_types_to_quantize = ["LSTM", "MatMul"]

    def to_onnx(self, path):
        phone_id = torch.randint(0, 30, (1, 10), dtype=torch.int32)
        speaking_rate = torch.ones(1, 10, dtype=torch.float32)
        model_args = [phone_id.unsqueeze(-1).unsqueeze(-1), speaking_rate]

        self.model.forward = self.model.inference

        input_names = [
            "X_inputs:0",
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0",
        ]
        output_names = [
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0",
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0",
        ]
        dynamic_axes = {
            "X_inputs:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0": {  # noqa: E501
                1: "num_phones"
            },
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0": {1: "num_frames"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0": {1: "num_phones"},
        }

        if self.model.enable_pitch_contour:
            f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
            model_args.append(f0_scale_ratio)
            input_names.append(
                "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0"
            )
            dynamic_axes.update(
                {
                    "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0": {
                        1: "num_phones"
                    }
                }
            )

        torch.onnx.export(
            self.model,
            tuple(model_args),
            path,
            opset_version=12,
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes,
        )
        quant_path = path.replace(".onnx", "-quant.onnx")
        quantize_dynamic(model_input=path, model_output=quant_path, op_types_to_quantize=self.op_types_to_quantize)
        logger.info(f"Finished exporting whole model to {path}")

        if self.export_encoder:
            # Export Encoder
            encoder_path = path.replace(".onnx", "-encoder.onnx")
            self.model.forward = self.model.export_encoder
            encoder_args = [phone_id, speaking_rate]
            encoder_input_names = ["inputs", "speed_ratios"]
            encoder_output_names = ["decoder_inputs", "prediction_durations"]
            encoder_dynamic_axes = {
                "inputs": {1: "num_phones"},
                "speed_ratios": {1: "num_phones"},
                "decoder_inputs": {1: "num_frames"},
                "prediction_durations": {1: "num_phones"},
            }

            if self.model.enable_pitch_contour:
                f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
                encoder_args.append(f0_scale_ratio)
                encoder_input_names.append("f0_scale_ratios")
                encoder_dynamic_axes.update(
                    {
                        "f0_scale_ratios": {1: "num_phones"},
                    }
                )

            torch.onnx.export(
                self.model,
                tuple(encoder_args),
                encoder_path,
                opset_version=12,
                input_names=encoder_input_names,
                output_names=encoder_output_names,
                dynamic_axes=encoder_dynamic_axes,
            )

            encoder_quant_path = encoder_path.replace(".onnx", "-quant.onnx")
            quantize_dynamic(
                model_input=encoder_path,
                model_output=encoder_quant_path,
                op_types_to_quantize=self.op_types_to_quantize,
            )
            logger.info(f"Finished exporting encoder model to {encoder_path}")

        if self.export_decoder:
            # Export Decoder
            dec_size = self.model.mel_proj.weight.shape[-1]
            dec_rnn_reduce = dec_size // self.model.dec_0.rnn_module.lstm.hidden_size
            decoder_inputs = torch.rand(1, 100, dec_size, dtype=torch.float32)
            dec_layers = []
            for name, _param in self.model.named_parameters():
                res = re.match(r"^dec_(\d+)", name)
                if res is not None:
                    print(name, res)
                    dec_layers.append(int(res.group(1)))
            dec_num_layers = len(set(dec_layers))
            dec_hidden_seq = [torch.zeros(1, 1, dec_size // dec_rnn_reduce, dtype=torch.float32)] * 2 * dec_num_layers
            h_seq = [f"h{i}" for i in range(1, dec_num_layers + 1)]
            c_seq = [f"c{i}" for i in range(1, dec_num_layers + 1)]
            h_new_seq = [f"h{i}_new" for i in range(1, dec_num_layers + 1)]
            c_new_seq = [f"c{i}_new" for i in range(1, dec_num_layers + 1)]
            hc_input_names = list(itertools.chain.from_iterable(zip(h_seq, c_seq)))
            hc_output_names = list(itertools.chain.from_iterable(zip(h_new_seq, c_new_seq)))

            decoder_path = path.replace(".onnx", "-decoder.onnx")
            self.model.forward = self.model.export_decoder
            torch.onnx.export(
                self.model,
                (decoder_inputs, dec_hidden_seq),
                decoder_path,
                opset_version=12,
                input_names=["decoder_inputs"] + hc_input_names,
                output_names=["output_mels"] + hc_output_names,
                dynamic_axes={
                    "decoder_inputs": {1: "num_frames"},
                    "output_mels": {1: "num_frames"},
                },
            )

            decoder_quant_path = decoder_path.replace(".onnx", "-quant.onnx")
            quantize_dynamic(
                model_input=decoder_path,
                model_output=decoder_quant_path,
                op_types_to_quantize=self.op_types_to_quantize,
            )

    def to_cuda(self, path):
        pass

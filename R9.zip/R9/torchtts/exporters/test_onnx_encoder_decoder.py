import os
import sys
import argparse
import numpy as np

import onnxruntime
from onnxruntime.capi import _pybind_state as C

sys.path.append(os.path.dirname(sys.path[0]))


def test_infer(inputs, onnx_model):
    opts = C.get_default_session_options()
    opts.inter_op_num_threads = 1
    opts.intra_op_num_threads = 1
    sess = onnxruntime.InferenceSession(onnx_model, opts)

    input_dict = {}
    sess_inputs = sess.get_inputs()
    sess_outputs = sess.get_outputs()
    sess_output_names = [sess_output.name for sess_output in sess_outputs]
    assert len(inputs) == len(sess_inputs), "inputs do not match with model"

    for i, sess_in in enumerate(sess_inputs):
        input_dict[sess_in.name] = inputs[i]

    outputs = sess.run(sess_output_names, input_feed=input_dict)
    return sess_output_names, outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phseq", type=str, required=True)
    parser.add_argument("--encoder", type=str, required=True)
    parser.add_argument("--decoder", type=str, required=True)
    parser.add_argument("--output", type=str, required=True)
    args = parser.parse_args()
    os.makedirs(args.output, exist_ok=True)

    # input phoneme id sequence
    phone_seq = np.loadtxt(args.phseq)
    phone_seq = np.expand_dims(phone_seq, 0).astype(np.int32)
    speed_ratio = np.ones(phone_seq.shape).astype(np.float32)

    enc_inputs = [phone_seq, speed_ratio]
    enc_output_names, enc_outputs = test_infer(enc_inputs, args.encoder)
    for out_name, out_val in zip(enc_output_names, enc_outputs):
        np.save(os.path.join(args.output, out_name), out_val)

    pred_mel = enc_outputs[0]
    hidden_dim = pred_mel.shape[-1] // 2
    h1 = np.zeros((1, 1, hidden_dim)).astype(np.float32)
    c1 = np.zeros((1, 1, hidden_dim)).astype(np.float32)
    h2 = np.zeros((1, 1, hidden_dim)).astype(np.float32)
    c2 = np.zeros((1, 1, hidden_dim)).astype(np.float32)
    dec_inputs = [pred_mel, h1, c1, h2, c2]
    dec_output_names, dec_outputs = test_infer(dec_inputs, args.decoder)
    for out_name, out_val in zip(dec_output_names, dec_outputs):
        np.save(os.path.join(args.output, out_name), out_val)
    print("ok")


if __name__ == "__main__":
    main()

import logging
import os
import json
import torch

from torchtts.exporters.exporter import Exporter
from torchtts.exporters.weight_dumpers.tiny_fullband import TinyfullbandDumper

logger = logging.getLogger(__name__)


# Add json config to the export dir


class TinyfullbandExporter(Exporter):
    def setup(self, model, checkpoint, export_type):
        # load weight to base model
        self.base_model = model['fullband_generator_tiny']
        self.base_model.load_state_dict(checkpoint['model']['fullband_generator_tiny'])
        if export_type == "onnx":
            self.base_model.remove_weight_norm()

        if 'generator_ema' in checkpoint['extra_states']:
            shadow = checkpoint['extra_states']['generator_ema']
            for name, param in self.vocoder_gpu.named_parameters():
                if param.requires_grad:
                    param.data.copy_(shadow[name])

        # load weight to dump model
        self.vocoder = model['fullband_generator_tiny_dumper']
        self.vocoder.load_state_dict(self.base_model.state_dict(), strict=False)
        self.vocoder.eval()

        if 'generator_ema' in checkpoint['extra_states']:
            shadow = checkpoint['extra_states']['generator_ema']
            for name, param in self.vocoder.named_parameters():
                if param.requires_grad:
                    param.data.copy_(shadow[name])

    def to_onnx(self, path):
        self.vocoder_to_onnx(path)

    def to_cuda(self, path):
        self.vocoder_to_cuda(path)
        return

    def am_to_onnx(self, path):
        path = os.path.join(path, "am.obin")

        self.am.forward = self.am.inference

        if self.am.enable_style_transfer:
            self.am.forward = self.am.inference_style_transfer

        model_args = []
        input_names = []
        output_names = [
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0",
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0",
        ]
        dynamic_axes = {
            "X_inputs:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0": {1: "num_phones"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/strided_slice:0": {1: "num_frames"},
            "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/ToInt32:0": {1: "num_phones"},
        }

        phone_id = torch.randint(0, 128, (1, 10, 1, 1), dtype=torch.int32)
        model_args.append(phone_id)
        input_names.append("X_inputs:0")

        if self.am.enable_multi_speaker:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/spk_id:0")
        else:
            model_args.append(None)

        if self.am.enable_cross_lingual:
            model_args.append(torch.tensor([[1]], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/locale_id:0")
        else:
            model_args.append(None)

        if self.am.enable_multi_style:
            # Style id
            model_args.append(torch.tensor([0], dtype=torch.int32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/Placeholder:0")
            # Style degree
            model_args.append(torch.tensor([1.0], dtype=torch.float32))
            input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/style_scale:0")
        else:
            # Style id
            model_args.append(None)
            # Style degree
            model_args.append(None)

        speaking_rate = torch.ones(1, 10, dtype=torch.float32)
        model_args.append(speaking_rate)
        input_names.append("na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/rate_scale_lengths:0")

        if self.am.enable_pitch_contour:
            f0_scale_ratio = torch.ones(1, 10, 1, dtype=torch.float32)
            model_args.append(f0_scale_ratio)
            input_names.append(
                "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0"
            )
            dynamic_axes.update(
                {
                    "na_speech_model/parallel_0_3/na_speech_model/na_speech_model/body/pitch_adapter/f0_scale_ratio:0": {
                        1: "num_phones"
                    }
                }
            )
        else:
            model_args.append(None)

        torch.onnx.export(
            self.am,
            tuple(model_args),
            path,
            opset_version=12,
            do_constant_folding=True,
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes,
        )

        logger.info(f"Finished exporting acoustic onnx model to {path}")

    def vocoder_to_onnx(self, path):
        output_dir = os.path.join(path, 'vocoder_48k_cpu')
        os.makedirs(output_dir, exist_ok=True)
        onnx_prefix = "high"

        x1 = torch.rand((1, 1, 300))
        x2 = torch.rand((1, 1, 300))
        self.vocoder.forward = self.vocoder.pqmf_forward
        torch.onnx.export(self.vocoder, (x1, x2),
                          os.path.join(output_dir, 'pqmf.obin'),
                          input_names=['x1', 'x2'],
                          output_names=['wave'],
                          dynamic_axes={'x1': [2], 'x2': [2], 'wave': [2]}, opset_version=10)

        mel = torch.rand((1, 128, 100))
        torch.onnx.export(self.vocoder.model,
                          (mel,),
                          os.path.join(output_dir, onnx_prefix + '.obin'),
                          input_names=['mel'],
                          output_names=['wave'],
                          dynamic_axes={'mel': [2], 'wave': [2]},
                          opset_version=10)

        mel = torch.rand((1, 128, 100))
        torch.onnx.export(self.vocoder.modelPrenet,
                          (mel,),
                          os.path.join(output_dir, onnx_prefix + '_gru.obin'),
                          input_names=['mel'],
                          output_names=['wave'],
                          dynamic_axes={'mel': [2], 'wave': [2]},
                          opset_version=10)

        mel = torch.rand((1, 128, 100))
        torch.onnx.export(self.vocoder.modelUpSampling0,
                          (mel,),
                          os.path.join(output_dir, onnx_prefix + '_upsampling0.obin'),
                          input_names=['mel'],
                          output_names=['wave'],
                          dynamic_axes={'mel': [2], 'wave': [2]},
                          opset_version=10)

        mel = torch.rand((1, 64, 100))
        torch.onnx.export(self.vocoder.modelUpSampling1,
                          (mel,),
                          os.path.join(output_dir, onnx_prefix + '_upsampling1.obin'),
                          input_names=['mel'],
                          output_names=['wave'],
                          dynamic_axes={'mel': [2], 'wave': [2]}, opset_version=10)

        mel = torch.rand((1, 32, 100))
        torch.onnx.export(self.vocoder.modelUpSampling2,
                          (mel,),
                          os.path.join(output_dir, onnx_prefix + '_upsampling2.obin'),
                          input_names=['mel'],
                          output_names=['wave'], dynamic_axes={'mel': [2], 'wave': [2]},
                          opset_version=10)

        mel = torch.rand((1, 16, 100))
        torch.onnx.export(self.vocoder.modelUpSampling3, (mel,),
                          os.path.join(output_dir, onnx_prefix + '_upsampling3.obin'),
                          input_names=['mel'],
                          output_names=['wave'],
                          dynamic_axes={'mel': [2], 'wave': [2]},
                          opset_version=10)

        mel = torch.rand((1, 8, 100))
        torch.onnx.export(self.vocoder.modelLastConv, (mel,),
                          os.path.join(output_dir, onnx_prefix + '_lastconv.obin'),
                          input_names=['mel'],
                          output_names=['wave'],
                          dynamic_axes={'mel': [2], 'wave': [2]}, opset_version=10)

        logger.info(f"Finished exporting onnx vocoder to {path}")

    def vocoder_to_cuda(self, path):
        path = os.path.join(path, "vocoder_48k_tiny_gpu")
        os.makedirs(path, exist_ok=True)

        dumper = TinyfullbandDumper(path, enable_rezero=1)
        name_list = []
        for name in self.base_model.state_dict().keys():
            if "quantizer" in name:
                continue
            name_list.append(name)
            logger.info(f"gpu cuda dump name {name}")
        loaded_var_num = dumper.load(name_list, self.base_model.state_dict(), 0)
        assert loaded_var_num == len(name_list)
        dumper.dump()

        config = {
            "upsampling_ratios": "3,4,5,5",
            "relu_after_mel_conv": True
        }
        # Add json config to the export dir
        with open(os.path.join(path, "config.json"), "w") as config_file:
            json.dump(config, config_file, indent=4)

        logger.info(f"Finished exporting vocoder model weights for cuda runtime to {path}")

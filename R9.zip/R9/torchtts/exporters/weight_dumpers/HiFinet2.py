import os
import sys
import numpy as np

sys.path.append(os.path.dirname(sys.path[0]))

upsampling_block_num = 3
sub_band_num = 8


class Dumper:
    def load(self, name_list, state_dict, start_idx):
        pass

    def dump(self):
        pass

    def get_numpy(self, name, state_dict):
        return state_dict[name].cpu().numpy()


class LinerDumper(Dumper):
    def __init__(self, folder, is_band_liner):
        self._folder = folder
        self._isBandLiner = is_band_liner

    def load(self, name_list, state_dict, start_idx):
        if not self._isBandLiner:
            suffix_list = ['weight']
            for i, suffix in enumerate(suffix_list):
                assert (name_list[start_idx + i].split('.')[-1] == suffix)
            self._weight = self.get_numpy(name_list[start_idx], state_dict)
            return start_idx + 1
        else:
            suffix_list = ['weight', 'a', 'b']
            for i, suffix in enumerate(suffix_list):
                assert (name_list[start_idx + i].split('.')[-1] == suffix)
            self._weight = self.get_numpy(name_list[start_idx], state_dict)
            self._a = self.get_numpy(name_list[start_idx + 1], state_dict)
            self._b = self.get_numpy(name_list[start_idx + 2], state_dict)
            return start_idx + 3

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(self._folder + '/kernel', self._weight.T)
        if self._isBandLiner:
            np.savetxt(self._folder + '/a', self._a.T)
            np.savetxt(self._folder + '/b', self._b.T)


class PQMFDumper(Dumper):
    def __init__(self, folder):
        self._folder = folder

    def load(self, name_list, state_dict, start_idx):
        suffix_list = ['analysis_filter', 'synthesis_filter', 'updown_filter']
        for i, suffix in enumerate(suffix_list):
            assert (name_list[start_idx + i].split('.')[-1] == suffix)
        self._analysis_filter_weight = self.get_numpy(name_list[start_idx], state_dict)
        self._synthesis_filter_weight = self.get_numpy(name_list[start_idx + 1], state_dict)
        self._updown_filter_weight = self.get_numpy(name_list[start_idx + 2], state_dict)
        return start_idx + 3

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
            os.makedirs(self._folder + "/conv_trans")
            os.makedirs(self._folder + "/conv_trans/conv_trans_1d")
            os.makedirs(self._folder + "/conv")
            os.makedirs(self._folder + "/conv/conv1d")
        np.savetxt(self._folder + '/analysis_filter', np.ndarray.flatten(self._analysis_filter_weight))
        # conv_trans
        for k in range(self._updown_filter_weight.shape[-1]):
            np.savetxt(self._folder + '/conv_trans/conv_trans_1d/kernel_' + str(k),
                       self._updown_filter_weight[:, :, k] * 6)
        # conv
        for k in range(self._synthesis_filter_weight.shape[-1]):
            np.savetxt(self._folder + '/conv/conv1d/kernel_' + str(k), self._synthesis_filter_weight[:, :, k].T)


class ConvDumper(Dumper):
    def __init__(self, folder):
        self._folder = folder + '/conv1d'

    def load(self, name_list, state_dict, start_idx):
        suffix_list = ['bias', 'weight_g', 'weight_v']
        # suffix_list = ['bias', 'weight']
        for i, _ in enumerate(suffix_list):
            assert (name_list[start_idx + i].split('.')[-1] == suffix_list[i])
        self._bias = np.squeeze(self.get_numpy(name_list[start_idx], state_dict))
        if len(self._bias.shape) == 0:
            self._bias = self._bias.reshape((1))
        g = self.get_numpy(name_list[start_idx + 1], state_dict)
        v = self.get_numpy(name_list[start_idx + 2], state_dict)
        self._weight = g * (v / np.expand_dims(np.expand_dims(np.linalg.norm(v, axis=(1, 2)), 1), 2))
        return start_idx + 3

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(self._folder + '/bias', self._bias)
        for k in range(self._weight.shape[-1]):
            np.savetxt(self._folder + '/kernel_' + str(k), self._weight[:, :, k].T)


class ConvTransDumper(ConvDumper):
    def __init__(self, folder):
        super().__init__(folder)
        self._folder = folder + '/conv_trans_1d'

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(self._folder + '/bias', self._bias)
        for k in range(self._weight.shape[-1]):
            np.savetxt(self._folder + '/kernel_' + str(k), self._weight[:, :, k])


class GruDumper(Dumper):
    def __init__(self, folder, is_backward):
        self._folder = folder
        self._is_backward = is_backward

    def load(self, name_list, state_dict, start_idx):
        if not self._is_backward:
            suffix_list = ['weight_ih_l0', 'weight_hh_l0', 'bias_ih_l0', 'bias_hh_l0',
                           'weight_ih_l0_reverse', 'weight_hh_l0_reverse', 'bias_ih_l0_reverse', 'bias_hh_l0_reverse']
        else:
            suffix_list = ['weight_ih_l1', 'weight_hh_l1', 'bias_ih_l1', 'bias_hh_l1',
                           'weight_ih_l1_reverse', 'weight_hh_l1_reverse', 'bias_ih_l1_reverse', 'bias_hh_l1_reverse']
        for i, suffix in enumerate(suffix_list):
            assert (name_list[start_idx + i].split('.')[-1] == suffix)
        self._weight_in = self.get_numpy(name_list[start_idx], state_dict)
        self._weight_re = self.get_numpy(name_list[start_idx + 1], state_dict)
        self._bias_in = np.squeeze(self.get_numpy(name_list[start_idx + 2], state_dict))
        self._bias_re = np.squeeze(self.get_numpy(name_list[start_idx + 3], state_dict))
        self._weight_in_reverse = self.get_numpy(name_list[start_idx + 4], state_dict)
        self._weight_re_reverse = self.get_numpy(name_list[start_idx + 5], state_dict)
        self._bias_in_reverse = np.squeeze(self.get_numpy(name_list[start_idx + 6], state_dict))
        self._bias_re_reverse = np.squeeze(self.get_numpy(name_list[start_idx + 7], state_dict))
        return start_idx + 8

    def dump(self):
        fw_folder = self._folder + '/fw'
        bw_folder = self._folder + '/bw'
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
            os.makedirs(fw_folder)
            os.makedirs(bw_folder)
        np.savetxt(fw_folder + '/kernel', self.convert_weight(self._weight_in))
        np.savetxt(fw_folder + '/recurrent_kernel', self.convert_weight(self._weight_re))
        np.savetxt(fw_folder + '/bias', self.convert_bias(self._bias_in, self._bias_re))
        np.savetxt(bw_folder + '/kernel', self.convert_weight(self._weight_in_reverse))
        np.savetxt(bw_folder + '/recurrent_kernel', self.convert_weight(self._weight_re_reverse))
        np.savetxt(bw_folder + '/bias', self.convert_bias(self._bias_in_reverse, self._bias_re_reverse))

    def convert_weight(self, weight):
        hidden_chs = weight.shape[0] // 3
        input_chs = weight.shape[1]
        wr_t = weight[0:hidden_chs, :].reshape((input_chs, hidden_chs))
        wz_t = weight[hidden_chs:2 * hidden_chs, :].reshape((input_chs, hidden_chs))
        wh_t = weight[2 * hidden_chs:3 * hidden_chs, :].reshape((input_chs, hidden_chs))
        return np.concatenate((wz_t, wr_t, wh_t), axis=1)

    def convert_bias(self, bias_in, bias_re):
        assert (bias_in.shape[0] == bias_re.shape[0])
        hidden_chs = bias_in.shape[0] // 3
        r_in = bias_in[0:hidden_chs]
        z_in = bias_in[hidden_chs:2 * hidden_chs]
        h_in = bias_in[2 * hidden_chs:]
        r_re = bias_re[0:hidden_chs]
        z_re = bias_re[hidden_chs:2 * hidden_chs]
        h_re = bias_re[2 * hidden_chs:]
        return np.concatenate((z_in, r_in, h_in, z_re, r_re, h_re), axis=0)


class ReZeroAlphaDumper(Dumper):
    def __init__(self, folder):
        self._folder = folder

    def load(self, name_list, state_dict, start_idx):
        assert (name_list[start_idx].split('.')[-1] == 'alpha')
        self._alpha = self.get_numpy(name_list[start_idx], state_dict)
        return start_idx + 1

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(self._folder + '/alpha', self._alpha)


class ResnetBlockDumper(Dumper):
    def __init__(self, folder, enable_rezero):
        self._folder = folder
        self._elements = []
        if enable_rezero:
            self._elements.append(ReZeroAlphaDumper(self._folder))
        self._elements.append(ConvDumper(self._folder + '/conv_1'))
        self._elements.append(ConvDumper(self._folder + '/conv_2'))
        self._elements.append(ConvDumper(self._folder + '/shortcut'))

    def load(self, name_list, state_dict, start_idx):
        idx = start_idx
        for e in self._elements:
            idx = e.load(name_list, state_dict, idx)
        return idx

    def dump(self):
        for e in self._elements:
            e.dump()


class UpSamplingBlockDumper(Dumper):
    def __init__(self, folder, enable_rezero, residual_layer_num):
        self._folder = folder
        self._elements = []
        self._elements.append(ConvTransDumper(self._folder + '/conv_trans'))
        for i in range(residual_layer_num):
            self._elements.append(ResnetBlockDumper(self._folder + '/resnet_block_' + str(i), enable_rezero))

    def load(self, name_list, state_dict, start_idx):
        idx = start_idx
        for e in self._elements:
            idx = e.load(name_list, state_dict, idx)
        return idx

    def dump(self):
        for e in self._elements:
            e.dump()


class Hifinet2Dumper(Dumper):
    def __init__(self, folder, enable_rezero):
        self._folder = folder
        self._elements = []
        for i in range(sub_band_num):
            self._elements.append(LinerDumper(self._folder + '/band_linear_' + str(i), True))
        self._elements.append(PQMFDumper(self._folder + '/pqmf4'))
        self._elements.append(PQMFDumper(self._folder + '/pqmf2'))
        self._elements.append(ConvDumper(self._folder + '/mel_conv'))
        self._elements.append(GruDumper(self._folder + '/gru1', is_backward=False))
        self._elements.append(GruDumper(self._folder + '/gru2', is_backward=True))
        # self._elements.append(LinerDumper(self._folder + '/linear', False))
        for i in range(upsampling_block_num):
            self._elements.append(UpSamplingBlockDumper(self._folder + '/upsampling_' + str(i), enable_rezero, 3 + i))
        self._elements.append(ConvDumper(self._folder + '/output_conv'))
        for i in range(upsampling_block_num):
            self._elements.append(
                UpSamplingBlockDumper(self._folder + '/upsampling_48k_' + str(i), enable_rezero, 3 + i))
        self._elements.append(ConvDumper(self._folder + '/output_conv_48k'))

    def load(self, name_list, state_dict, start_idx):
        idx = start_idx
        for e in self._elements:
            idx = e.load(name_list, state_dict, idx)
        return idx

    def dump(self):
        for e in self._elements:
            e.dump()

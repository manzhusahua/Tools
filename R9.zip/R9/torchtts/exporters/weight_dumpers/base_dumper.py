from abc import ABC
from abc import abstractmethod
import os


class WeightDumper(ABC):
    """Recursively dumping the weights of the whole model for native runtime use."""

    def __init__(self, folder, name=""):
        self._folder = os.path.join(folder, name)

    @abstractmethod
    def load(self, name_list, state_dict, start_idx):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def dump(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @staticmethod
    def get_numpy(name, state_dict):
        return state_dict[name].cpu().numpy()

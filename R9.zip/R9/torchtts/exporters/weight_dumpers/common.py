import numpy as np
import os

from torchtts.exporters.weight_dumpers.base_dumper import WeightDumper


class ConvWeightDumper(WeightDumper):
    def __init__(self, folder, name="conv1d"):
        super().__init__(folder, name)
        self._bias = None
        self._weight = None

    def load(self, name_list, state_dict, start_idx):
        suffix_list = ["bias", "weight"]
        for i, name in enumerate(suffix_list):
            assert name_list[start_idx + i].split(".")[-1] == name
        self._bias = np.squeeze(self.get_numpy(name_list[start_idx], state_dict))
        if len(self._bias.shape) == 0:
            self._bias = self._bias.reshape(1)
        self._weight = self.get_numpy(name_list[start_idx + 1], state_dict)
        return start_idx + 2

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(os.path.join(self._folder, "bias"), self._bias)
        for k in range(self._weight.shape[-1]):
            np.savetxt(os.path.join(self._folder, f"kernel_{k}"), self._weight[:, :, k].T)


class ConvTransWeightDumper(ConvWeightDumper):
    def __init__(self, folder, name="conv_trans_1d"):
        super().__init__(folder, name)

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(os.path.join(self._folder, "bias"), self._bias)
        for k in range(self._weight.shape[-1]):
            np.savetxt(os.path.join(self._folder, f"kernel_{k}"), self._weight[:, :, k])


class GruWeightDumper(WeightDumper):
    def __init__(self, folder, name="gru", is_backward=False):
        super().__init__(folder, name)
        self._weight_in = None
        self._weight_re = None
        self._bias_in = None
        self._bias_re = None
        self._is_backward = is_backward

    def load(self, name_list, state_dict, start_idx):
        suffix_list = ["weight_ih_l0", "weight_hh_l0", "bias_ih_l0", "bias_hh_l0"]
        for i, suffix in enumerate(suffix_list):
            es = suffix + "_reverse" if self._is_backward else suffix
            assert name_list[start_idx + i].split(".")[-1] == es
        self._weight_in = self.get_numpy(name_list[start_idx], state_dict)
        self._weight_re = self.get_numpy(name_list[start_idx + 1], state_dict)
        self._bias_in = np.squeeze(self.get_numpy(name_list[start_idx + 2], state_dict))
        self._bias_re = np.squeeze(self.get_numpy(name_list[start_idx + 3], state_dict))
        return start_idx + 4

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(os.path.join(self._folder, "kernel"), self.convert_weight(self._weight_in))
        np.savetxt(os.path.join(self._folder, "recurrent_kernel"), self.convert_weight(self._weight_re))
        np.savetxt(os.path.join(self._folder, "bias"), self.convert_bias(self._bias_in, self._bias_re))

    @staticmethod
    def convert_weight(weight):
        hidden_chs = weight.shape[0] // 3
        input_chs = weight.shape[1]
        wr_t = weight[0:hidden_chs, :].reshape((input_chs, hidden_chs))
        wz_t = weight[hidden_chs : 2 * hidden_chs, :].reshape((input_chs, hidden_chs))
        wh_t = weight[2 * hidden_chs : 3 * hidden_chs, :].reshape((input_chs, hidden_chs))
        return np.concatenate((wz_t, wr_t, wh_t), axis=1)

    @staticmethod
    def convert_bias(bias_in, bias_re):
        assert bias_in.shape[0] == bias_re.shape[0]
        hidden_chs = bias_in.shape[0] // 3
        r_in = bias_in[0:hidden_chs]
        z_in = bias_in[hidden_chs : 2 * hidden_chs]
        h_in = bias_in[2 * hidden_chs :]
        r_re = bias_re[0:hidden_chs]
        z_re = bias_re[hidden_chs : 2 * hidden_chs]
        h_re = bias_re[2 * hidden_chs :]
        return np.concatenate((z_in, r_in, h_in, z_re, r_re, h_re), axis=0)

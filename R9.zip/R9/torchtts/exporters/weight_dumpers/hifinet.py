import numpy as np
import os

from torchtts.exporters.weight_dumpers.base_dumper import WeightDumper
from torchtts.exporters.weight_dumpers.common import ConvWeightDumper
from torchtts.exporters.weight_dumpers.common import ConvTransWeightDumper
from torchtts.exporters.weight_dumpers.common import GruWeightDumper


class ReZeroAlphaWeightDumper(WeightDumper):
    def __init__(self, folder, name=""):
        super().__init__(folder, name)
        self._alpha = None

    def load(self, name_list, state_dict, start_idx):
        assert name_list[start_idx].split(".")[-1] == "alpha"
        self._alpha = self.get_numpy(name_list[start_idx], state_dict)
        return start_idx + 1

    def dump(self):
        if not os.path.exists(self._folder):
            os.makedirs(self._folder)
        np.savetxt(os.path.join(self._folder, "alpha"), self._alpha)


class ResnetBlockWeightDumper(WeightDumper):
    def __init__(self, folder, name="resnet_block", enable_rezero=True):
        super().__init__(folder, name)
        self._elements = []
        if enable_rezero:
            self._elements.append(ReZeroAlphaWeightDumper(self._folder))
        self._elements.append(ConvWeightDumper(self._folder, os.path.join("conv_1", "conv1d")))
        self._elements.append(ConvWeightDumper(self._folder, os.path.join("conv_2", "conv1d")))
        self._elements.append(ConvWeightDumper(self._folder, os.path.join("shortcut", "conv1d")))

    def load(self, name_list, state_dict, start_idx):
        idx = start_idx
        for e in self._elements:
            idx = e.load(name_list, state_dict, idx)
        return idx

    def dump(self):
        for e in self._elements:
            e.dump()


class UpSamplingBlockWeightDumper(WeightDumper):
    def __init__(self, folder, name="upsampling", num_residual_layers=3, enable_rezero=True):
        super().__init__(folder, name)
        self._elements = []
        self._elements.append(ConvTransWeightDumper(self._folder, os.path.join("conv_trans", "conv_trans_1d")))
        for i in range(num_residual_layers):
            self._elements.append(ResnetBlockWeightDumper(self._folder, f"resnet_block_{i}", enable_rezero))

    def load(self, name_list, state_dict, start_idx):
        idx = start_idx
        for e in self._elements:
            idx = e.load(name_list, state_dict, idx)
        return idx

    def dump(self):
        for e in self._elements:
            e.dump()


class FullBandGeneratorWeightDumper(WeightDumper):
    def __init__(
        self, folder, name="", num_upsampling_blocks=4, num_residual_layers=3, enable_rezero=True, with_gru=True
    ):
        super().__init__(folder, name)
        self._elements = []
        self._elements.append(ConvWeightDumper(self._folder, os.path.join("mel_conv", "conv1d")))
        if with_gru:
            self._elements.append(GruWeightDumper(self._folder, "fw_gru", is_backward=False))
            self._elements.append(GruWeightDumper(self._folder, "bw_gru", is_backward=True))
        for i in range(num_upsampling_blocks):
            self._elements.append(
                UpSamplingBlockWeightDumper(self._folder, f"upsampling_{i}", num_residual_layers, enable_rezero)
            )
        self._elements.append(ConvWeightDumper(self._folder, os.path.join("output_conv", "conv1d")))

    def load(self, name_list, state_dict, start_idx):
        idx = start_idx
        for e in self._elements:
            idx = e.load(name_list, state_dict, idx)
        return idx

    def dump(self):
        for e in self._elements:
            e.dump()

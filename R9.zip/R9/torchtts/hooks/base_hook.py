from enum import IntFlag


class HookNode(IntFlag):
    ALL = 0
    MASTER = 1
    WORKER = 2


class HookOrder(IntFlag):
    INTERNAL = 0
    VALIDATION = 20
    LOGGING = 40
    METRIC = 60
    EXTERNAL = 80


class Hook:
    def __init__(self, order, node=HookNode.ALL):
        """Hook initializer.

        Args:
            order (HookOrder): The flag from HookOrder.
            node (HookNode): The flag from HookNode
        """
        self.order = order
        self.node = node

    def on_start(self, trainer):
        """Event handler for start.

        Args:
            trainer (Trainer): Trainer instance.
        """
        pass

    def on_end(self, trainer):
        """Event handler for end.

        Args:
            trainer (Trainer): Trainer instance.
        """
        pass

    def on_epoch_start(self, trainer):
        """Event handler for epoch start

        Args:
            trainer (Trainer): Trainer instance.
        """
        pass

    def on_epoch_end(self, trainer):
        """Event handler for epoch end

        Args:
            trainer (Trainer): Trainer instance.
        """
        pass

    def on_step_start(self, trainer):
        """Event handler for batch start

        Args:
            trainer (Trainer): Trainer instance.
        """
        pass

    def on_step_end(self, trainer):
        """Event handler for batch end

        Args:
            trainer (Trainer): Trainer instance.
        """
        pass

    def on_exception(self, trainer):
        """Event handler for exception

        Args:
            trainer (Trainer): Trainer instance.
        """
        pass

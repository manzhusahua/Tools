import logging
import os

from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookNode
from torchtts.hooks.base_hook import HookOrder

logger = logging.getLogger(__name__)


class CheckpointHook(Hook):
    def __init__(self, save_path, save_interval, warm_start_from=None, reset_trainer=False, parameter_list=None):
        super().__init__(order=HookOrder.EXTERNAL, node=HookNode.ALL)
        self.save_path = save_path
        self.save_interval = save_interval
        self.warm_start_from = warm_start_from
        self.reset_trainer = reset_trainer
        self.parameter_list = parameter_list

    def on_start(self, trainer):
        os.makedirs(self.save_path, exist_ok=True)
        # Restore from specified checkpoint first
        if self.warm_start_from is not None:
            logger.info("Loading warmup checkpoint from " f"{os.path.abspath(self.warm_start_from)}")
            trainer.engine.load_checkpoint(
                filename=self.warm_start_from,
                trainer=trainer,
                strict=False,
                reset_trainer=self.reset_trainer,
                parameter_list=self.parameter_list,
            )

        # Maybe restore from save path for occasional interruption
        self._maybe_restore_from(self.save_path, trainer)

    def on_step_end(self, trainer):
        if not trainer.engine.is_master_process:
            # Worker sync
            trainer.engine.barrier()
            return

        if trainer.global_steps % self.save_interval == 0:
            self._save_checkpoint(self.save_path, trainer)

        if trainer.engine.is_master_process:
            # Master sync
            trainer.engine.barrier()

    def on_end(self, trainer):
        if not trainer.engine.is_master_process:
            # Worker sync
            trainer.engine.barrier()
            return

        self._save_checkpoint(self.save_path, trainer)

        if trainer.engine.is_master_process:
            # Master sync
            trainer.engine.barrier()

    def on_exception(self, trainer):
        if trainer.engine.is_master_process:
            self._save_checkpoint(self.save_path, trainer)

    @staticmethod
    def _save_checkpoint(save_path, trainer):
        checkpoint_path = os.path.join(save_path, f"checkpoint-{trainer.global_steps}.pt")

        if os.path.isfile(checkpoint_path):
            logger.info(f"Checkpoint {os.path.abspath(checkpoint_path)} has been existed.")
            return

        logger.info(f"Saving checkpoint to {os.path.abspath(checkpoint_path)}")
        trainer.engine.save_checkpoint(filename=checkpoint_path, trainer=trainer)
        # Record the latest checkpoint
        with open(os.path.join(save_path, "checkpoint"), "w") as f:
            f.write(f"checkpoint-{trainer.global_steps}.pt")

    @staticmethod
    def _maybe_restore_from(save_path, trainer):
        checkpoint_path = os.path.join(save_path, "checkpoint")
        if os.path.exists(checkpoint_path):
            latest_checkpoint = open(checkpoint_path, "r").readline().strip("\n")
            checkpoint_path = os.path.join(save_path, latest_checkpoint)
            logger.info(f"Loading checkpoint from {os.path.abspath(checkpoint_path)}")
            trainer.engine.load_checkpoint(filename=checkpoint_path, trainer=trainer)

import logging

from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookOrder

logger = logging.getLogger(__name__)


class StopAtStepOrEpochHook(Hook):
    def __init__(self, last_steps=None, last_epochs=None):
        super().__init__(order=HookOrder.INTERNAL)
        if last_steps is None and last_epochs is None:
            raise ValueError("One of last_steps or last_epochs must be specified.")
        if last_steps is not None and last_epochs is not None:
            raise ValueError("Only one of last_steps or last_epochs can be specified.")
        self.last_steps = last_steps
        self.last_epochs = last_epochs

    def on_step_end(self, trainer):
        if self.last_steps is not None and trainer.global_steps >= self.last_steps - 1:
            trainer.should_stop = True

    def on_epoch_end(self, trainer):
        if self.last_epochs is not None and trainer.epochs >= self.last_epochs - 1:
            trainer.should_stop = True


class StepCounterHook(Hook):
    def __init__(self):
        super().__init__(order=HookOrder.INTERNAL)

    def on_epoch_start(self, trainer):
        trainer.steps = 0

    def on_epoch_end(self, trainer):
        trainer.epochs += 1

    def on_step_end(self, trainer):
        trainer.steps += 1
        trainer.global_steps += 1


class SetEpochForDataPipelineHook(Hook):
    def __init__(self):
        super().__init__(order=HookOrder.INTERNAL)

    def on_epoch_start(self, trainer):
        datapipe = trainer.dataloader.datapipe
        datapipe.set_epoch(trainer.epochs)

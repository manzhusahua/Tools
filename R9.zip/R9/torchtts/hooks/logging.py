import logging

from torchtts.utils import exception_utils
from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookNode
from torchtts.hooks.base_hook import HookOrder
from torchtts.utils.dict_utils import map_nested
from torchtts.utils.model_utils import model_summary_string

logger = logging.getLogger(__name__)


class LoggerHook(Hook):
    """Logger hook interface."""

    pass


class ConsoleLogger(LoggerHook):
    """Log the training logs to console."""

    def __init__(self, log_interval, save_interval):
        super().__init__(order=HookOrder.LOGGING, node=HookNode.MASTER)
        self.log_interval = log_interval
        self.save_interval = save_interval

    def on_start(self, trainer):
        def map_fun(model):
            logger.info("Model summary:\n" + model_summary_string(model))

        map_nested(map_fun, trainer.model)

    def on_epoch_end(self, trainer):
        stats = [f"Epoch {trainer.epochs} finished"]
        for key, value in trainer.logs.items():
            stats.append(f"{key} = {value:.4g}")
        logger.info(", ".join(stats) + "\n")

    def on_step_end(self, trainer):
        if trainer.global_steps % self.log_interval == 0:
            stats = [f"epoch = {trainer.epochs + 1}, step = {trainer.global_steps}"]
            for key, value in trainer.logs.items():
                stats.append(f"{key} = {value:.4g}")
            if isinstance(trainer.optimizers, dict):
                for k, v in trainer.optimizers.items():
                    stats.append(f"{k}_lr = {v.param_groups[0]['lr']:4.3e}")
            else:
                stats.append(f"lr = {trainer.optimizers.param_groups[0]['lr']:4.3e}")
            logger.info(", ".join(stats))

        # Validation log
        if trainer.global_steps % self.save_interval == 0:
            if trainer.cv_logs is not None:
                stats = [f"CROSSVAL: epoch = {trainer.epochs + 1}, step = {trainer.global_steps}"]
                for key, value in trainer.cv_logs.items():
                    stats.append(f"{key} = {value:.4g}")
                logger.info(", ".join(stats))

    def on_exception(self, trainer):
        exception = trainer.exception
        if not exception_utils.is_exception(exception):
            return
        if isinstance(exception, KeyboardInterrupt):
            logger.info("Key board interruption encountered.")
            trainer.should_raise_exception = False


class TensorboardLogger(LoggerHook):
    def __init__(self, log_interval, save_interval, writer):
        """Log the training logs to tensorboard."""
        super().__init__(order=HookOrder.LOGGING, node=HookNode.MASTER)
        self.log_interval = log_interval
        self.save_interval = save_interval
        self.writer = writer

    def on_step_end(self, trainer):
        if trainer.global_steps % self.log_interval == 0:
            for key, value in trainer.logs.items():
                self._add_scalar(f"step/{key}", value, trainer.global_steps)
            if isinstance(trainer.optimizers, dict):
                for k, _ in trainer.optimizers.items():
                    self._add_scalar(f"step/{k}_lr", trainer.optimizers[k].param_groups[0]["lr"], trainer.global_steps)
            else:
                self._add_scalar("step/lr", trainer.optimizers.param_groups[0]["lr"], trainer.global_steps)
        # Add validation log
        if trainer.global_steps % self.save_interval == 0:
            if trainer.cv_logs is not None:
                for key, value in trainer.cv_logs.items():
                    self._add_scalar(f"valid/{key}", value, trainer.global_steps)

    def on_epoch_end(self, trainer):
        for key, value in trainer.logs.items():
            self._add_scalar(f"epoch/{key}", value, trainer.epochs)

    def _add_scalar(self, key, values, global_steps):
        if isinstance(values, dict):
            for inner_key, inner_value in values.items():
                self.writer.add_scalar(f"{key}/{inner_key}", inner_value, global_steps)
        else:
            self.writer.add_scalar(key, values, global_steps)

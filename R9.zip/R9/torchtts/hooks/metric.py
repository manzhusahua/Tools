import logging

from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookNode
from torchtts.hooks.base_hook import HookOrder

logger = logging.getLogger(__name__)


class MetricResetHook(Hook):
    def __init__(self, reset_interval, save_interval, reset_each_epoch=False):
        super().__init__(order=HookOrder.METRIC, node=HookNode.ALL)
        self.reset_interval = reset_interval
        self.save_interval = save_interval
        self.reset_each_epoch = reset_each_epoch

    def on_start(self, trainer):
        if trainer.metrics is not None:
            trainer.engine.to_device(trainer.metrics)
            trainer.engine.to_device(trainer.cv_metrics)
            # Reset metrics
            self._reset_metrics(trainer.metrics)
            self._reset_metrics(trainer.cv_metrics)

    def on_step_end(self, trainer):
        if not self.reset_each_epoch:
            if trainer.global_steps % self.reset_interval == 0:
                self._reset_metrics(trainer.metrics)
            if trainer.global_steps % self.save_interval == 0:
                self._reset_metrics(trainer.cv_metrics)

    def on_epoch_start(self, trainer):
        if self.reset_each_epoch:
            self._reset_metrics(trainer.metrics)

    @staticmethod
    def _reset_metrics(metrics):
        if metrics is not None:
            if isinstance(metrics, dict):
                for v in metrics.values():
                    v.reset_states()
            else:
                metrics.reset_states()

import logging
import torch

from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookOrder
from torchtts.utils.torch_utils import unwrap_ddp

logger = logging.getLogger(__name__)


class ExponentialMovingAverageHook(Hook):
    def __init__(self, name, model, decay, update_interval=1, reset_interval=None):
        super().__init__(order=HookOrder.INTERNAL - 1)
        self.name = name
        self.model = unwrap_ddp(model)
        self.decay = decay
        self.update_interval = update_interval
        self.reset_interval = reset_interval

    def _reset(self, shadow):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                shadow[name] = param.clone().detach()

    def _update(self, shadow):
        with torch.no_grad():
            for name, param in self.model.named_parameters():
                if param.requires_grad:
                    assert name in shadow
                    update_delta = shadow[name] - param
                    shadow[name] -= (1.0 - self.decay) * update_delta

    def on_start(self, trainer):
        trainer.extra_states[self.name] = {}
        self._reset(trainer.extra_states[self.name])

    def on_step_end(self, trainer):
        if trainer.global_steps % self.update_interval == 0:
            self._update(trainer.extra_states[self.name])

        if self.reset_interval is not None and trainer.global_steps % self.reset_interval == 0:
            self._reset(trainer.extra_states[self.name])

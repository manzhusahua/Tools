from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookNode
from torchtts.hooks.base_hook import HookOrder
from torchtts.utils.time_utils import TimeManager


class TimerHook(Hook):
    def __init__(self):
        super().__init__(order=HookOrder.LOGGING - 1, node=HookNode.ALL)
        self.timer = TimeManager()
        self.inner_step_counter = 0

    def on_epoch_start(self, trainer):
        self.inner_step_counter = 0
        self.timer.reset()
        self.timer.start("timer/epoch_time")

    def on_epoch_end(self, trainer):
        self.timer.stop("timer/epoch_time")
        epoch_time = self.timer.elapsed["timer/epoch_time"]
        step_time = epoch_time / self.inner_step_counter
        trainer.logs.update({"timer/step_time": step_time, "timer/epoch_time": epoch_time})

    def on_step_end(self, trainer):
        self.inner_step_counter += 1

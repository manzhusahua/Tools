import logging
import torch

from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookNode
from torchtts.hooks.base_hook import HookOrder
from torchtts.utils.time_utils import TimeManager
from torchtts.utils.torch_utils import recursive_detach

logger = logging.getLogger(__name__)


class ValidationHook(Hook):
    def __init__(self, save_interval):
        super().__init__(order=HookOrder.VALIDATION, node=HookNode.ALL)
        self.save_interval = save_interval

    def on_step_end(self, trainer):
        if trainer.global_steps % self.save_interval == 0:
            if trainer.cv_dataloader is not None:
                # Turn on evaluation mode
                trainer.model.eval()

                timer = TimeManager()
                timer.reset()
                timer.start("timer/valid_time")

                with torch.no_grad():
                    cv_logs = trainer.validate()

                timer.stop("timer/valid_time")
                valid_time = timer.elapsed["timer/valid_time"]

                trainer.cv_logs = recursive_detach(cv_logs)
                trainer.cv_logs.update(
                    {
                        "valid_time": valid_time,
                    }
                )

                # TODO averger validation loss cross each rank

                # Turn on training mode
                trainer.model.train()

                # Worker sync
                trainer.engine.barrier()

import hydra
import logging
from omegaconf import OmegaConf

logger = logging.getLogger(__name__)


def build_model(model_config):
    logger.info("Instantiating model with config: \n" f"{OmegaConf.to_yaml(model_config, sort_keys=True)}")
    model = hydra.utils.instantiate(model_config)
    # Convert from OmegaConf types to built-in types if needed
    if OmegaConf.is_config(model):
        model = OmegaConf.to_container(model)
    return model

"""Conformer TTS."""

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchtts.nn.modules.conformer.zero_shot_tts as zero_shot_tts
import numpy as np
from typing import Dict, List

from torchtts.nn.modules.attention.rel_attention import MultiHeadedAttention
from torchtts.nn.modules.common import LengthRegulator, LayerNorm, LinearNorm
from torchtts.nn.modules.common.functional import make_non_pad_mask
from torchtts.nn.modules.common.functional import make_pad_mask
from torchtts.nn.modules.conformer.duration_predictor import DurationPredictor
from torchtts.nn.modules.conformer.encoder import Encoder as ConformerEncoder
from torchtts.nn.modules.conformer.initializer import initialize
from torchtts.nn.modules.conformer.lm import LMHead
from torchtts.nn.modules.conformer.repeat import repeat
from torchtts.nn.modules.conformer.variance_predictor import PitchPredictor, EnergyPredictor
from torchtts.nn.modules.conformer.new_voice_generation import SpeakerEncoder, AttributesEncoder, AttributesDecoder
from torchtts.nn.modules.conformer.new_voice_generation import MixtureDensityNetwork
from torchtts.nn.modules.style_encoders.acoustic_residual_predictor import GlobalStyleToken
from torchtts.nn.modules.style_encoders.acoustic_residual_predictor import PhoneProsodyPredictor, hierarchical_softmax
from torchtts.nn.modules.style_encoders.acoustic_residual_predictor import TextPredictedProsody, ReferenceEncoder
from torchtts.nn.modules.transformer import RelPositionalEncoding
from torchtts.nn.modules.conformer.gmvae_labeled import GMVAELabeled
from torchtts.nn.modules.conformer.discriminator import ConformerDiscriminator
from torchtts.nn.modules.conformer.discriminator import GP
from torchtts.nn.modules.transformer.prenet_postnet import DecoderPrenet
from torchtts.nn.modules.conformer.SpeakerBank import SpeakerBankExtractor
from torchtts.nn.modules.common.gradient_reversal_layer import GRL

logger = logging.getLogger(__name__)


class ConformerTTS(torch.nn.Module):
    """Text-to-Speech Conformer module.

    This is a module of text-to-speech Conformer model motivated by
    TransformerTTS, FastSpeech, Conformer.

    """
    def __init__(
        self,
        symbol_size=256,
        spk_size=128,
        dmodel=384,
        odim=80,
        duration_predictor_layers=2,
        duration_predictor_chans=256,
        duration_predictor_kernel_size=3,
        duration_predictor_dropout_rate=0.1,
        positionwise_conv_kernel_size=3,
        enc_layers=6,
        enc_num_heads=4,
        enc_ffn_dim=1536,
        dec_layers=6,
        dec_num_heads=4,
        dec_ffn_dim=1536,
        cnn_module_kernel=7,
        dropout_rate=0.1,
        enable_multi_speaker=False,
        macaron_style=False,
        style_dim=16,
        pitch_dim=16,
        enable_pitch_contour=False,
        pitch_predictor_layers=3,
        pitch_predictor_chans=384,
        pitch_predictor_kernel_size=5,
        pitch_predictor_dropout=0.1,
        pitch_embed_kernel_size=3,
        pitch_embed_dropout=0.1,
        enable_gst=True,
        enable_phone_emb=True,
        enable_hierarchical_cond=True,
        enable_phone_vae=False,
        enable_cross_lingual=False,
        enable_ar_phn_pred=True,
        gru_layer_num=2,
        lang_size=128,
        padding_idx=0,
        enable_multi_style=False,
        style_embedding_size=16,
        enable_concat_lut=False,
        enable_mel2vec_pretrain=False,
        enbale_phoneme_bert_pretrain=False,
        pitch_mean=178.47,
        pitch_var=53.47,
        export_onnx=False,
        embedding_activation="softplus",
        enable_style_transfer=False,
        enable_moe=False,
        num_moe_experts=16,
        normalize_before=False,
        distil="",
        sdetach=True,
        sdmodel=256,
        sdec_ffn_dim=None,
        sdec_num_heads=4,
        sdec_layers=3,
        enable_retrain_phnpred=False,
        enable_sdecoder=True,
        enable_encoder_conditional_layernorm=False,
        use_encoder_spk_condition=False,
        enable_decoder_conditional_layernorm=False,
        decoder_normalize_before=False,
        teacher_dmodel=384,
        ffn_layer_type="conv1d",
        encoder_hidden_constraint=False,
        att_constraint=False,
        enable_dur_check=False,
        enable_energy_predict=True,
        pred_odim=80,
        enable_context=False,
        context_phone_dim=518,
        context_seq_dim=512,
        context_dropout=0.5,
        transfer_style_mapping: Dict[int, int] = None,
        speaking_rate_tuning: Dict[int, float] = None,
        f0_scale_tuning: Dict[int, float] = None,
        f0_auto_scale: Dict[int, List[float]] = None,
        energy_auto_scale: Dict[int, List[float]] = None,
        enable_zeroshot=False,
        enable_zeroshot_finegrained=False,
        enable_zeroshot_autoregressive=False,
        enable_zeroshot_prosody_selection=False,
        pretrain_speaker_embeddingdim=128,
        new_voice_generation=False,
        semi_supervised_training=False,
        model_attri_distribution=False,
        attri_feature_dim=10,
        full_attribute_list=None,
        attribute_in_use=None,
        rand_attri_unrelate_feat=True,
        use_obj_attri=True,
        use_energy_attri=True,
        attributes_dim=10,
        unrelate_feat_dim=6,
        normalize_spk_emb=True,
        spk_emb_dim=256,
        use_pitch_condition=False,
        pitch_condition_dim=-1,
        use_duration_condition=False,
        duration_condition_dim=-1,
        use_energy_condition=False,
        energy_condition_dim=-1,
        enable_cross_lingual_spk_loss=False,
        only_update_decoder_in_cross_lingual_loss=True,
        moe_capacity_factor=1.2,
        dump_cross_lingual_v2=False,
        speech_inpainting=False,
        use_singing_feature=False,
        enable_syllabledurforsinging=False,
        note_pitch_embedding_size=5000,
        note_duration_embedding_size=5000,
        syllable_duration_embedding_size=5000,
        phone_level_localeid=False,
        enus_phone_id="",
        enus_loc_id=None,
        enable_fmoe=False,
        fmoe_num_expert=64,
        fmoe_hidden_dim=1024,
        fmoe_top_k=2,
        enable_style_vae=False,
        enable_style_vae_withspk=False,
        style_vae_layers=1,
        enable_adversarial_training=False,
        gp_beata=10,
        predict_mel=False,
        predict_mel_layer=0,
        enable_frame_pitch=False,
        frame_pitch_predictor_layers=2,
        use_pred_pitch_input=False,
        enable_dar_prediction=False,
        dar_droprate=0.75,
        enable_quant2cont_prediction=False,
        dec_use_highwayrnn=False,
        dec_rnn_bidirectional=False,
        dec_rnn_reduce=1,
        dec_hidden_dim=384,
        dec_ffn_groups_batch_size=8,
        enable_ar_prosody=False,
        ar_prosody_dmodel=192,
        enable_diff_prosody=False,
        diff_prosody_dmodel=192,
        enable_emotion_encoder=False,
        exponent_alpha=1.2,
        emt_logits_dim=128,
        enable_power=False,
        enable_tilt=False
    ):
        super(ConformerTTS, self).__init__()

        self.dec_layers = dec_layers
        self.style_dim = style_dim
        self.enable_phone_vae = enable_phone_vae

        self.enable_multi_speaker = enable_multi_speaker
        self.enable_cross_lingual = enable_cross_lingual
        self.enable_multi_style = enable_multi_style
        self.enable_mel2vec_pretrain = enable_mel2vec_pretrain
        self.enbale_phoneme_bert_pretrain = enbale_phoneme_bert_pretrain
        self.enable_pitch_contour = enable_pitch_contour
        self.pitch_mean = pitch_mean
        self.pitch_var = pitch_var
        self.dmodel = dmodel
        self.enable_style_transfer = enable_style_transfer
        self.enable_energy_predict = enable_energy_predict
        self.enable_moe = enable_moe
        self.enable_encoder_conditional_layernorm = enable_encoder_conditional_layernorm
        self.enable_decoder_conditional_layernorm = enable_decoder_conditional_layernorm
        self.enable_fmoe = enable_fmoe
        self.enable_style_vae = enable_style_vae
        self.enable_style_vae_withspk = enable_style_vae_withspk
        self.enable_adversarial_training = enable_adversarial_training
        self.style_dim = style_dim
        self.enc_num_heads = enc_num_heads
        self.style_embedding_size = style_embedding_size
        self.spk_size = spk_size
        self.enable_dur_check = enable_dur_check
        self.predict_mel = predict_mel
        self.predict_mel_layer = predict_mel_layer
        self.dec_use_highwayrnn = dec_use_highwayrnn

        self.enable_context = enable_context

        self.distil = distil.strip()
        self.ffn_layer_type = ffn_layer_type
        assert self.distil in ["", "online_decoder", "offline_decoder", "full", "full_tiny"]
        self.encoder_hidden_constraint = encoder_hidden_constraint
        self.att_constraint = att_constraint

        self.new_voice_generation = new_voice_generation
        self.semi_supervised_training = semi_supervised_training
        self.model_attri_distribution = model_attri_distribution
        self.full_attribute_list = full_attribute_list
        self.attribute_in_use = attribute_in_use
        self.use_obj_attri = use_obj_attri
        self.use_energy_attri = use_energy_attri
        self.rand_attri_unrelate_feat = rand_attri_unrelate_feat
        self.unrelate_feat_dim = unrelate_feat_dim  # when using random attribute unrelated features.
        self.normalize_spk_emb = normalize_spk_emb
        self.use_energy_condition = use_energy_condition
        self.enable_cross_lingual_spk_loss = enable_cross_lingual_spk_loss
        self.only_update_decoder_in_cross_lingual_loss = only_update_decoder_in_cross_lingual_loss
        self.use_encoder_spk_condition = use_encoder_spk_condition
        self.dump_cross_lingual_v2 = dump_cross_lingual_v2
        self.use_singing_feature = use_singing_feature
        self.enable_syllabledurforsinging = enable_syllabledurforsinging

        self.phone_level_localeid = phone_level_localeid  # using in inference/export mode

        self.enable_frame_pitch = enable_frame_pitch
        self.frame_pitch_predictor_layers = frame_pitch_predictor_layers
        self.use_pred_pitch_input = use_pred_pitch_input
        self.enable_dar_prediction = enable_dar_prediction
        self.enable_quant2cont_prediction = enable_quant2cont_prediction
        self.dar_droprate = dar_droprate

        self.enable_emotion_encoder = enable_emotion_encoder
        self.exponent_alpha = exponent_alpha
        self.style_embedding_size = style_embedding_size

        self.enable_power = enable_power
        self.enable_tilt = enable_tilt

        if self.phone_level_localeid:
            # enus_phone_id example: 38,112,193,204,225,...
            assert isinstance(enus_phone_id, str)
            enus_phone_id_array = enus_phone_id.strip().split(",")
            self.enus_phone = torch.from_numpy(np.array(enus_phone_id_array, dtype=np.int32)).int()
            assert isinstance(enus_loc_id, int)
            self.enus_loc_id = enus_loc_id

        self.enus_loc_id = enus_loc_id

        if use_singing_feature:
            self.note_pitch_embedding = torch.nn.Embedding(
                num_embeddings=note_pitch_embedding_size, embedding_dim=dmodel, padding_idx=0
            )

            self.note_duration_embedding = torch.nn.Embedding(
                num_embeddings=note_duration_embedding_size, embedding_dim=dmodel, padding_idx=0
            )

            self.syllable_duration_embedding = torch.nn.Embedding(
                num_embeddings=syllable_duration_embedding_size, embedding_dim=dmodel, padding_idx=0
            )
            self.syllable_duration_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        positionwise_layer_type = ffn_layer_type
        self.frame_pitch_predictor = None
        if enable_frame_pitch:
            self.frame_pitch_predictor = ConformerEncoder(
                attention_dim=dmodel,
                attention_heads=dec_num_heads,
                linear_units=dec_ffn_dim,
                num_blocks=frame_pitch_predictor_layers,
                input_layer=None,
                normalize_before=normalize_before,
                dropout_rate=dropout_rate,
                positional_dropout_rate=dropout_rate,
                attention_dropout_rate=dropout_rate,
                positionwise_conv_kernel_size=positionwise_conv_kernel_size,
                macaron_style=macaron_style,
                cnn_module_kernel=cnn_module_kernel,
                enable_moe=enable_moe,
                export_onnx=export_onnx,
                enable_conditional_layernorm=enable_encoder_conditional_layernorm,
                condition_dim=dmodel,
                n_experts=num_moe_experts,
                positionwise_layer_type=positionwise_layer_type,
                output_all=False,
                moe_capacity_factor=moe_capacity_factor,
            )
            if enable_dar_prediction:
                self.frame_pitch_predictor_dar = PhoneProsodyPredictor(
                    dmodel, 256, gru_layer_num=gru_layer_num, enable_ar_phn_pred=True
                )
            else:
                self.quantized_proj = LinearNorm(dmodel, 256)
            self.continuous_lut = LinearNorm(2, dmodel, bias=True)
            self.frame_pitch_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        self.teacher_dmodel = teacher_dmodel
        if self.encoder_hidden_constraint and dmodel != self.teacher_dmodel:
            self.enc_constraint_proj_layers = repeat(
                enc_layers,
                lambda lnum: torch.nn.Linear(dmodel, self.teacher_dmodel),
            )

        self.enable_concat_lut = enable_concat_lut
        # dimension change aim to reuse teacher's look up table
        if self.distil == "full_tiny":
            self.symbol_embedding = torch.nn.Sequential(
                torch.nn.Embedding(
                    num_embeddings=symbol_size, embedding_dim=self.teacher_dmodel, padding_idx=padding_idx
                ),
                torch.nn.Linear(self.teacher_dmodel, dmodel),
            )
        else:
            self.symbol_embedding = torch.nn.Embedding(
                num_embeddings=symbol_size, embedding_dim=dmodel, padding_idx=padding_idx
            )

        self.speech_inpainting = speech_inpainting
        if speech_inpainting:
            enable_multi_speaker = False
            enable_multi_style = False
            enable_gst = True
            enable_phone_emb = True
            self.refmel_proj = DecoderPrenet(80, n_layers=2, model_dim=dmodel, dropout_rate=dropout_rate)
            self.style_encoder = SpeakerBankExtractor(80, 4, 16, dmodel, 8, dmodel * 4, 0.1, 'gelu', fpn_stages=3, fpn_stride=4)
            enable_crossattn = True
        else:
            enable_crossattn = False

        self.speaker_embedding = None
        if self.new_voice_generation:
            self.spk_encoder = SpeakerEncoder()  # speaker encoder
            self.speaker_embeddinglinear = torch.nn.Linear(spk_emb_dim, dmodel)
            self.speaker_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)
        elif enable_zeroshot:
            self.speaker_embeddinglinear = torch.nn.Linear(pretrain_speaker_embeddingdim, dmodel)
            self.speaker_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)
        elif enable_multi_speaker and not self.distil == "full_tiny":
            self.speaker_embedding = torch.nn.Embedding(
                num_embeddings=spk_size, embedding_dim=dmodel, padding_idx=padding_idx
            )
            if self.enable_cross_lingual_spk_loss:
                self.spk_encoder = SpeakerEncoder()
            if self.enable_concat_lut:
                self.speaker_embeddinglinear = torch.nn.Linear(dmodel, dmodel)
                self.speaker_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        self.lang_embedding = None
        if enable_cross_lingual:
            self.lang_embedding = torch.nn.Embedding(
                num_embeddings=lang_size, embedding_dim=dmodel, padding_idx=padding_idx
            )
            if self.enable_concat_lut:
                self.lang_embeddinglinear = torch.nn.Linear(dmodel, dmodel)
                self.lang_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        self.style_embedding = None
        if enable_multi_style and not self.distil == "full_tiny":
            self.style_embedding = torch.nn.Embedding(
                num_embeddings=style_embedding_size, embedding_dim=dmodel, padding_idx=padding_idx
            )
            if self.enable_concat_lut:
                self.style_embeddinglinear = torch.nn.Linear(dmodel, dmodel)
                self.style_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        if enable_context:
            self.prenet_phone = torch.nn.Sequential(
                torch.nn.Conv1d(
                    in_channels=context_phone_dim,
                    out_channels=dmodel,
                    kernel_size=5,
                    padding=(5 - 1) // 2,
                    stride=1,
                ),
                torch.nn.ReLU(),
                LayerNorm(dmodel, dim=1),
                torch.nn.Dropout(context_dropout),
            )

            self.prenet_phone_dense = torch.nn.Linear(dmodel, dmodel, bias=False)
            self.prenet_seq_inproj = torch.nn.Linear(context_seq_dim, dmodel, bias=False)
            self.prenet_seq_gru = torch.nn.GRU(input_size=dmodel, hidden_size=dmodel, batch_first=True)
            self.prenet_seq_outproj = torch.nn.Sequential(
                torch.nn.ReLU(),
                torch.nn.Dropout(context_dropout),
                torch.nn.Linear(dmodel + dmodel, dmodel, bias=False),
            )

        if embedding_activation == "softplus":
            self.emb_act = nn.Softplus()
        elif embedding_activation == "softsign":
            self.emb_act = nn.Softsign()

        self.encoder = ConformerEncoder(
            idim=dmodel,
            attention_dim=dmodel,
            attention_heads=enc_num_heads,
            linear_units=enc_ffn_dim,
            num_blocks=enc_layers,
            input_layer=self.symbol_embedding,
            normalize_before=normalize_before,
            dropout_rate=dropout_rate,
            positional_dropout_rate=dropout_rate,
            attention_dropout_rate=dropout_rate,
            positionwise_conv_kernel_size=positionwise_conv_kernel_size,
            macaron_style=macaron_style,
            cnn_module_kernel=cnn_module_kernel,
            use_singing_feature=use_singing_feature,
            enable_moe=enable_moe,
            export_onnx=export_onnx,
            enable_conditional_layernorm=enable_encoder_conditional_layernorm,
            condition_dim=dmodel,
            n_experts=num_moe_experts,
            positionwise_layer_type=positionwise_layer_type,
            output_all=True if self.encoder_hidden_constraint else False,
            return_att=self.att_constraint,
            moe_capacity_factor=moe_capacity_factor,
            enable_crossattn=enable_crossattn,
        )

        if enbale_phoneme_bert_pretrain:
            self.lm_head = LMHead(
                embed_dim=dmodel,
                output_dim=symbol_size,
                weight=self.symbol_embedding.weight,
            )
            self._reset_parameters("pytorch")
            return

        self.enable_hierarchical_cond = enable_hierarchical_cond
        self.duration_predictor = DurationPredictor(
            idim=dmodel,
            n_layers=duration_predictor_layers,
            n_chans=duration_predictor_chans,
            kernel_size=duration_predictor_kernel_size,
            dropout_rate=duration_predictor_dropout_rate,
            enable_zero_cross_rate=enable_zeroshot,
            use_condition=use_duration_condition,
            condition_dim=duration_condition_dim,
        )
        self.length_regulator = LengthRegulator()

        self.decoder = ConformerEncoder(
            attention_dim=dmodel,
            attention_heads=dec_num_heads,
            linear_units=dec_ffn_dim,
            num_blocks=dec_layers,
            input_layer=None,
            normalize_before=decoder_normalize_before,
            dropout_rate=dropout_rate,
            positional_dropout_rate=dropout_rate,
            attention_dropout_rate=dropout_rate,
            positionwise_conv_kernel_size=positionwise_conv_kernel_size,
            macaron_style=macaron_style,
            cnn_module_kernel=cnn_module_kernel,
            output_all=True,
            enable_conditional_layernorm=enable_decoder_conditional_layernorm,
            condition_dim=dmodel,
            positionwise_layer_type=positionwise_layer_type,
            return_att=self.att_constraint,
            enable_fmoe=enable_fmoe,
            fmoe_num_expert=fmoe_num_expert,
            fmoe_hidden_dim=fmoe_hidden_dim,
            fmoe_top_k=fmoe_top_k,
            predict_mel=predict_mel,
            predict_mel_layer=predict_mel_layer,
            use_highway_rnn=dec_use_highwayrnn,
            rnn_reduce=dec_rnn_reduce,
            rnn_bidirectional=dec_rnn_bidirectional,
            hidden_dim=dec_hidden_dim,
            ffn_groups_batch_size=dec_ffn_groups_batch_size
        )
        if enable_mel2vec_pretrain:
            self.mel2vec_proj = torch.nn.Linear(odim, dmodel, bias=False)
            self.m2v_token_embeddings = torch.nn.Embedding(1, dmodel, padding_idx=padding_idx)

        self.output_layers = repeat(
            dec_layers,
            lambda lnum: torch.nn.Linear(dmodel, pred_odim),
        )

        self.gst_predictor = None
        # full tiny will disable gst / phn predictor
        if enable_gst and not self.distil == "full_tiny":
            if self.distil != "full":
                self.gst = GlobalStyleToken(dmodel, mel_dim=odim)
            self.gst_proj = torch.nn.Linear(dmodel + style_dim, dmodel, bias=False)
            self.gst_predictor = TextPredictedProsody(dmodel, style_dim)

        if enable_style_vae:
            self.style_vae_encoder = ConformerEncoder(
                idim=odim,
                attention_dim=dmodel,
                attention_heads=enc_num_heads,
                linear_units=enc_ffn_dim,
                num_blocks=style_vae_layers,
                input_layer="linear",
                dropout_rate=dropout_rate,
                positional_dropout_rate=dropout_rate,
                attention_dropout_rate=dropout_rate,
                normalize_before=normalize_before,
                positionwise_layer_type="conv1d",
                positionwise_conv_kernel_size=positionwise_conv_kernel_size,
                macaron_style=macaron_style,
                cnn_module_kernel=cnn_module_kernel,
            )

            self.style_vae_compress_layer = torch.nn.GRU(
                input_size=dmodel, hidden_size=style_dim * 2, batch_first=True, bidirectional=True
            )
            self.style_vae_compress_proj = torch.nn.Linear(style_dim * 4, style_dim)
            self.style_vae_proj = torch.nn.Linear(dmodel + style_dim, dmodel)
            if enable_style_vae_withspk:
                self.vae_dim_qz_graph = style_dim + style_embedding_size + spk_size
                self.vae_dim_pz_graph = style_embedding_size + spk_size
            else:
                self.vae_dim_qz_graph = style_dim + style_embedding_size
                self.vae_dim_pz_graph = style_embedding_size
            self.style_gmvaeLabeled = GMVAELabeled(
                vae_dim_qz_graph=self.vae_dim_qz_graph,
                vae_dim_pz_graph=self.vae_dim_pz_graph,
                vae_dim_hidden=style_dim * 4,
                vae_dim_latent=style_dim * 2,
                style_dim=style_dim,
            )

        self.phone_emb_predictor = None
        self.enable_ar_phn_pred = enable_ar_phn_pred
        if enable_phone_emb and not self.distil == "full_tiny":
            if self.distil != "full":
                self.pos_emb = RelPositionalEncoding(dmodel, dropout_rate=0.1)
                spec_enc_input_dim = odim
                spec_enc_input_dim = (
                    spec_enc_input_dim + dmodel
                    if enable_multi_speaker or self.new_voice_generation
                    else spec_enc_input_dim
                )
                spec_enc_input_dim = spec_enc_input_dim + dmodel if enable_cross_lingual else spec_enc_input_dim
                spec_enc_input_dim = spec_enc_input_dim + dmodel if enable_multi_style else spec_enc_input_dim
                self.spec_enc_input_proj = torch.nn.Linear(spec_enc_input_dim, dmodel)
                self.enc_norm = torch.nn.LayerNorm(dmodel)

                att_out_dim = style_dim
                if enable_phone_vae:
                    self.raw_spec_input_proj = torch.nn.Linear(odim, dmodel)
                    att_out_dim *= 2  # `* 2` for mu and std
                self.ph_spec_att = MultiHeadedAttention(
                    n_head=dec_num_heads, n_feat=dmodel, dropout_rate=dropout_rate, n_out=att_out_dim
                )
                self.spec_encoder = ConformerEncoder(
                    idim=0,
                    attention_dim=dmodel,
                    attention_heads=4,
                    linear_units=dec_ffn_dim,
                    num_blocks=4,
                    input_layer=None,
                    dropout_rate=dropout_rate,
                    positional_dropout_rate=dropout_rate,
                    attention_dropout_rate=dropout_rate,
                    normalize_before=False,
                    concat_after=False,
                    positionwise_layer_type="conv1d",
                    positionwise_conv_kernel_size=3,
                    macaron_style=True,
                    pos_enc_layer_type="rel_pos",
                    selfattention_layer_type="rel_selfattn",
                    activation_type="swish",
                    use_cnn_module=True,
                    cnn_module_kernel=7,
                )
            self.ph_emb_enc_proj = torch.nn.Linear(dmodel + style_dim, dmodel)
            self.phone_emb_predictor = PhoneProsodyPredictor(
                dmodel, style_dim, gru_layer_num=gru_layer_num, enable_ar_phn_pred=self.enable_ar_phn_pred
            )

        self.pitch_predictor = None
        if enable_pitch_contour:
            self.pitch_predictor = PitchPredictor(
                idim=dmodel,
                n_layers=pitch_predictor_layers,
                n_chans=pitch_predictor_chans,
                kernel_size=pitch_predictor_kernel_size,
                dropout_rate=pitch_predictor_dropout,
                enable_global_pitch=enable_zeroshot,
                use_condition=use_pitch_condition,
                condition_dim=pitch_condition_dim,
            )
            self.pitch_embed = torch.nn.Sequential(
                torch.nn.Conv1d(
                    in_channels=1,
                    out_channels=pitch_dim,
                    kernel_size=pitch_embed_kernel_size,
                    padding=(pitch_embed_kernel_size - 1) // 2,
                ),
                torch.nn.ReLU(),
                LayerNorm(pitch_dim, dim=1),
                torch.nn.Dropout(pitch_embed_dropout),
            )
            self.pitch_emb_enc_proj = torch.nn.Linear(dmodel + pitch_dim, dmodel)

        self.power_predictor = None
        if self.use_singing_feature and self.enable_power:
            self.power_predictor = EnergyPredictor(
                idim=dmodel,
                n_layers=pitch_predictor_layers,
                n_chans=pitch_predictor_chans,
                kernel_size=pitch_predictor_kernel_size,
                dropout_rate=pitch_predictor_dropout,
                enable_global_energy=False,
                use_condition=False,
                condition_dim=-1
            )
            self.power_embed = torch.nn.Sequential(
                torch.nn.Conv1d(in_channels=1,
                                out_channels=pitch_dim,
                                kernel_size=pitch_embed_kernel_size,
                                padding=(pitch_embed_kernel_size - 1) // 2, ),
                torch.nn.ReLU(),
                LayerNorm(pitch_dim, dim=1),
                torch.nn.Dropout(pitch_embed_dropout)
            )
            self.power_emb_enc_proj = torch.nn.Linear(dmodel + pitch_dim, dmodel)

        self.tilt_predictor = None
        if self.use_singing_feature and self.enable_tilt:
            self.tilt_predictor = EnergyPredictor(
                idim=dmodel,
                n_layers=pitch_predictor_layers,
                n_chans=pitch_predictor_chans,
                kernel_size=pitch_predictor_kernel_size,
                dropout_rate=pitch_predictor_dropout,
                enable_global_energy=False,
                use_condition=False,
                condition_dim=-1
            )
            self.tilt_embed = torch.nn.Sequential(
                torch.nn.Conv1d(in_channels=1,
                                out_channels=pitch_dim,
                                kernel_size=pitch_embed_kernel_size,
                                padding=(pitch_embed_kernel_size - 1) // 2, ),
                torch.nn.ReLU(),
                LayerNorm(pitch_dim, dim=1),
                torch.nn.Dropout(pitch_embed_dropout)
            )
            self.tilt_emb_enc_proj = torch.nn.Linear(dmodel + pitch_dim, dmodel)

        self.energy_predictor = None
        if enable_style_transfer or enable_energy_predict:
            self.energy_predictor = EnergyPredictor(
                idim=dmodel,
                n_layers=pitch_predictor_layers,
                n_chans=pitch_predictor_chans,
                kernel_size=pitch_predictor_kernel_size,
                dropout_rate=pitch_predictor_dropout,
                enable_global_energy=enable_zeroshot,
                use_condition=use_energy_condition,
                condition_dim=energy_condition_dim,
            )
            self.energy_embed = torch.nn.Sequential(
                torch.nn.Conv1d(
                    in_channels=1,
                    out_channels=pitch_dim,
                    kernel_size=pitch_embed_kernel_size,
                    padding=(pitch_embed_kernel_size - 1) // 2,
                ),
                torch.nn.ReLU(),
                LayerNorm(pitch_dim, dim=1),
                torch.nn.Dropout(pitch_embed_dropout),
            )
            self.energy_emb_enc_proj = torch.nn.Linear(dmodel + pitch_dim, dmodel)

        self.enable_retrain_phnpred = enable_retrain_phnpred
        self.enable_sdecoder = enable_sdecoder
        self.sdecoder = None
        self.sdetach = sdetach
        if self.distil.endswith("_decoder"):
            if self.distil == "offline_decoder":
                self.sdetach = True
            if sdec_ffn_dim is None:
                sdec_ffn_dim = sdmodel * 4
            self.sdecoder = ConformerEncoder(
                attention_dim=sdmodel,
                attention_heads=sdec_num_heads,
                linear_units=sdec_ffn_dim,
                num_blocks=sdec_layers,
                input_layer=None,
                normalize_before=decoder_normalize_before,
                dropout_rate=dropout_rate,
                positional_dropout_rate=dropout_rate,
                attention_dropout_rate=dropout_rate,
                positionwise_conv_kernel_size=positionwise_conv_kernel_size,
                macaron_style=False,
                cnn_module_kernel=cnn_module_kernel,
                output_all=True,
                positionwise_layer_type=positionwise_layer_type,
                enable_fmoe=enable_fmoe,
                fmoe_num_expert=fmoe_num_expert,
                fmoe_hidden_dim=fmoe_hidden_dim,
                fmoe_top_k=fmoe_top_k,
            )
            self.sdecoder_proj = torch.nn.Linear(dmodel, sdmodel)
            if enable_fmoe:
                self.sgating_features_proj = torch.nn.Linear(dmodel, sdmodel)
            self.soutput_layers = repeat(
                sdec_layers,
                lambda lnum: torch.nn.Linear(sdmodel, pred_odim),
            )
        if self.enable_retrain_phnpred:
            # add spitch
            self.spitch_predictor = None
            if enable_pitch_contour:
                self.spitch_predictor = PitchPredictor(
                    idim=dmodel,
                    n_layers=pitch_predictor_layers,
                    n_chans=pitch_predictor_chans,
                    kernel_size=pitch_predictor_kernel_size,
                    dropout_rate=pitch_predictor_dropout,
                )
                self.spitch_embed = torch.nn.Sequential(
                    torch.nn.Conv1d(
                        in_channels=1,
                        out_channels=pitch_dim,
                        kernel_size=pitch_embed_kernel_size,
                        padding=(pitch_embed_kernel_size - 1) // 2,
                    ),
                    torch.nn.ReLU(),
                    LayerNorm(pitch_dim, dim=1),
                    torch.nn.Dropout(pitch_embed_dropout),
                )
                self.spitch_emb_enc_proj = torch.nn.Linear(dmodel + pitch_dim, dmodel)

            # add duration
            self.sduration_predictor = DurationPredictor(
                idim=dmodel,
                n_layers=duration_predictor_layers,
                n_chans=duration_predictor_chans,
                kernel_size=duration_predictor_kernel_size,
                dropout_rate=duration_predictor_dropout_rate,
            )
            self.sduration_embed = torch.nn.Sequential(
                torch.nn.Conv1d(
                    in_channels=1,
                    out_channels=pitch_dim,
                    kernel_size=pitch_embed_kernel_size,
                    padding=(pitch_embed_kernel_size - 1) // 2,
                ),
                torch.nn.ReLU(),
                LayerNorm(pitch_dim, dim=1),
                torch.nn.Dropout(pitch_embed_dropout),
            )
            self.sduration_emb_enc_proj = torch.nn.Linear(dmodel + pitch_dim, dmodel)

        if enable_style_transfer:
            # only used in inference_style_transfer, just leave them null during training
            self.transfer_style_mapping = {} if transfer_style_mapping is None else transfer_style_mapping
            self.speaking_rate_tuning = {} if speaking_rate_tuning is None else speaking_rate_tuning
            self.f0_scale_tuning = {} if f0_scale_tuning is None else f0_scale_tuning
            self.f0_auto_scale = {} if f0_auto_scale is None else f0_auto_scale
            self.energy_auto_scale = {} if energy_auto_scale is None else energy_auto_scale
            logger.info(f"transfer_style_mapping = {self.transfer_style_mapping}")
            logger.info(f"speaking_rate_tuning = {self.speaking_rate_tuning}")
            logger.info(f"f0_scale_tuning = {self.f0_scale_tuning}")
            logger.info(f"f0_scale_tuning_autoScale = {self.f0_auto_scale}")
            logger.info(f"energy_autoScale = {self.energy_auto_scale}")
            for transfer_style_id, source_speaker_id in self.transfer_style_mapping.items():
                if list(self.transfer_style_mapping.values()).count(source_speaker_id) == 1:
                    logger.info(f"[style={transfer_style_id}, spk={source_speaker_id}] use style_embedding_general")

        self.enable_zeroshot = enable_zeroshot
        if enable_zeroshot:
            self.gst_projmeanf0 = torch.nn.Linear(dmodel + style_dim, 1, bias=False)

        self.enable_zeroshot_finegrained = enable_zeroshot_finegrained
        if enable_zeroshot_finegrained:
            self.zeroshot_finegrained = zero_shot_tts.ZeroshotFineGrained(dmodel, dec_num_heads, dropout_rate, meldim=odim)
            self.gst_projmeanf0 = torch.nn.Linear(style_dim, 1, bias=False)

        self.enable_zeroshot_prosody_selection = enable_zeroshot_prosody_selection
        self.enable_zeroshot_autoregressive = enable_zeroshot_autoregressive
        if enable_zeroshot_autoregressive:
            self.zeroshot_autoregressive = zero_shot_tts.AutoregressiveDecoder(dmodel, meldim=odim)

        if new_voice_generation:
            self.attri_encoder = AttributesEncoder(idim=spk_emb_dim, odim=attributes_dim)
            self.attri_decoder = AttributesDecoder(attributes_dim, unrelate_feat_dim, odim=spk_emb_dim)
            if self.model_attri_distribution:
                # use mixture density network to model the attributes distribution
                self.MDN = MixtureDensityNetwork(in_dim=1, model_dim=128, mixture_num=12, feature_dim=attri_feature_dim)

        if self.enable_adversarial_training:
            self.model_disc = ConformerDiscriminator(
                out_dim=odim,
                num_heads=enc_num_heads,
                window_sizes=[100, 50],
                channels=[128, 64, 32],
                dropout_rate=dropout_rate,
            )
            self.calc_gradient_penalty = GP(gp_beata)

        self.enable_ar_prosody = enable_ar_prosody
        if enable_ar_prosody:
            from torchtts.nn.modules.conformer.ar_prosody import ARProsodyPredictor
            self.ar_prosody_predictor = ARProsodyPredictor(n=3, d_model=ar_prosody_dmodel, d_model_base=dmodel, dropout=dropout_rate)

        self.enable_diff_prosody = enable_diff_prosody
        if enable_diff_prosody:
            from torchtts.nn.modules.conformer.diff_prosody import DiffProsodyPredictor
            self.diff_prosody_predictor = DiffProsodyPredictor(n=3, d_model=diff_prosody_dmodel, d_model_base=dmodel, dropout=dropout_rate)

        if enable_emotion_encoder:
            self.emotion_encoder = ReferenceEncoder(mel_dim=odim)
            self.emt_logits = torch.nn.Linear(emt_logits_dim, style_embedding_size)
            self.spk_logits = torch.nn.Linear(emt_logits_dim, spk_size)
            self.locale_logits = torch.nn.Linear(emt_logits_dim, lang_size)

        self.export_onnx = export_onnx

        self._reset_parameters("pytorch")

    def _reset_parameters(self, init_type):
        initialize(self, init_type)

    def _add_first_frame_and_remove_last_frame(self, ys):
        ys_in = torch.cat([ys.new_zeros((ys.shape[0], 1, ys.shape[2])), ys[:, :-1]], dim=1)
        return ys_in

    def _get_m2v_mask(self, ys, p=0.05, m=9):
        _bsz, _time, _dim = ys.size()
        a = torch.zeros(_time, _time)
        b = torch.triu(torch.ones(_time, _time))
        c = torch.tril(torch.ones(_time, _time), diagonal=m - 1)
        d = c * b
        d = d[None, :, :].repeat(_bsz, 1, 1)

        _rand = torch.rand(_bsz, _time) < p
        while torch.equal(_rand, torch.zeros(_bsz, _time).bool()):
            _rand = torch.rand(_bsz, _time) < p

        mask_tag = _rand.unsqueeze(-1).repeat(1, 1, _time)
        m2v_mask = torch.where(mask_tag > 0, d, a)
        m2v_mask = m2v_mask.sum(1) > 0
        return m2v_mask

    def forward(
        self,
        xs,
        ilens,
        ys,
        olens,
        ds,
        speaker_id=None,
        f0=None,
        lang_id=None,
        style_id=None,
        masked_tokens=None,
        job="tts",
        energy=None,
        ref_prosody=None,
        ph_hs=None,
        context_phone=None,
        context_seq=None,
        spembsinput=None,
        global_zero_cross_rate=None,
        global_f0=None,
        global_energy=None,
        attributes=None,
        spk_rate_level=None,
        pitch_level=None,
        energy_level=None,
        with_attri_label=None,
        sp_tgtxseqs=None,
        sp_tgtyseqs=None,
        sp_reflens=None,
        sp_ref=None,
        note_duration=None,
        note_pitch=None,
        syllable_duration=None,
        gan_step=None,
        gan_interp=None,
        gan_reltaed=None,
        interp_pitch=None,
        quantized_pitch=None,
        uv=None,
        mel_shuffle=None,
        power=None,
        tilt=None,
        mode="train",
        emt_tau=1
    ):
        if "tts" == job:
            return self.tts_forward(
                xs,
                ilens,
                ys,
                olens,
                ds,
                speaker_id,
                f0,
                lang_id,
                style_id,
                energy,
                ref_prosody,
                ph_hs,
                context_phone,
                context_seq,
                spembsinput,
                global_zero_cross_rate,
                global_f0,
                global_energy,
                attributes,
                spk_rate_level,
                pitch_level,
                energy_level,
                with_attri_label,
                sp_tgtxseqs,
                sp_tgtyseqs,
                sp_reflens,
                sp_ref,
                note_duration,
                note_pitch,
                syllable_duration,
                gan_step,
                gan_interp,
                gan_reltaed,
                interp_pitch,
                quantized_pitch,
                uv,
                mel_shuffle,
                power,
                tilt,
                mode,
                emt_tau
            )
        elif "m2v" == job:
            return self.m2v_forward(ys, olens, speaker_id, lang_id)
        elif "phoneme_bert" == job:
            return self.phoneme_bert_forward(xs, ilens, masked_tokens)
        else:
            raise ValueError("undefined trining job %s" % job)

    def m2v_forward(self, ys, olens, speaker_id=None, lang_id=None):
        """Calculate forward propagation.

        Args:
            ys (Tensor): Batch of padded target features (B, Lmax, odim).
            olens (LongTensor): Batch of the lengths of each target (B,).
            lang_id (Tensor, optional): Batch of language id (B,).

        Returns:
            Tensor: Loss value.

        """
        max_olen = max(olens)
        if max_olen != ys.shape[1]:
            ys = ys[:, :max_olen]
        m2v_hidden = self.mel2vec_proj(ys)
        # multli speaker
        if self.speaker_embedding is not None:
            spembs = self.speaker_embedding(speaker_id)
            if len(spembs.size()) == 2:
                spembs = spembs.unsqueeze(1)
            spembs = F.normalize(spembs)
            spembs = spembs.repeat(1, m2v_hidden.size(1), 1)
            m2v_hidden += spembs
        _bsz, _time, _dim = m2v_hidden.size()

        m2v_mask = self._get_m2v_mask(m2v_hidden).to(m2v_hidden.device)
        # replace input with mask_embed
        mask_token = self.m2v_token_embeddings(torch.LongTensor([0]).to(m2v_hidden.device))

        mask_token = mask_token[None, :, :].repeat(_bsz, _time, 1)
        masked_m2v_hidden = torch.where(m2v_mask[:, :, None] > 0, mask_token, m2v_hidden)

        decoder_masks = self._source_mask(olens)
        zs, _ = self.decoder(masked_m2v_hidden, decoder_masks)

        mask_frame = m2v_mask.view(-1)
        target_frame = m2v_hidden.view(-1, _dim)[mask_frame]
        pred_frame = zs[-1].view(-1, _dim)[mask_frame]

        frame_start = 0
        max_fram_len = 500
        m2v_loss = 0
        m2v_loss_len = 0
        while frame_start < target_frame.size(0):
            sub_target_frame = target_frame[frame_start : frame_start + max_fram_len]
            sub_pred_frame = pred_frame[frame_start : frame_start + max_fram_len]
            frame_start += max_fram_len
            # l2-norm
            sub_target_frame = sub_target_frame / (torch.norm(sub_target_frame.float(), p=2, dim=-1)[:, None] + 0.00001)
            sub_pred_frame = sub_pred_frame / (torch.norm(sub_pred_frame.float(), p=2, dim=-1)[:, None] + 0.00001)
            # dot product
            pre_nll = torch.mm(sub_pred_frame, sub_target_frame.T)
            # softmax with temperature
            target_idx = torch.arange(pre_nll.size(0)).to(m2v_hidden.device).long()
            sum_m2v_loss = torch.nn.functional.nll_loss(
                torch.nn.functional.log_softmax(pre_nll / 0.1, dim=-1), target_idx, reduction="sum"
            )
            m2v_loss_len += pre_nll.size(0)
            m2v_loss += sum_m2v_loss
        m2v_loss = m2v_loss / m2v_loss_len
        return m2v_loss

    def phoneme_bert_forward(self, xs, ilens=None, masked_tokens=None):
        """Phoneme bert pretrain forward.

        Args:
            xs (Tensor): Batch of padded character ids (B, Tmax).
            ilens (LongTensor): Batch of lengths of each input batch (B,).
            masked_tokens (Tensor): Input Mask.

        Returns:
            Tensor: LM prediction.

        """
        max_ilen = max(ilens)
        if max_ilen != xs.shape[1]:
            xs = xs[:, :max_ilen]

        encoder_masks = self._source_mask(ilens)
        encoder_hidden, _ = self.encoder(xs, encoder_masks)

        return self.lm_head(encoder_hidden, masked_tokens)

    def tts_forward(
        self,
        xs,
        ilens,
        ys=None,
        olens=None,
        ds=None,
        speaker_id=None,
        f0=None,
        lang_id=None,
        style_id=None,
        energy=None,
        ref_prosody=None,
        ph_hs=None,
        context_phone=None,
        context_seq=None,
        spembsinput=None,
        global_zero_cross_rate=None,
        global_f0=None,
        global_energy=None,
        attributes=None,
        spk_rate_level=None,
        pitch_level=None,
        energy_level=None,
        with_attri_label=None,
        sp_tgtxseqs=None,
        sp_tgtyseqs=None,
        sp_reflens=None,
        sp_ref=None,
        note_duration=None,
        note_pitch=None,
        syllable_duration=None,
        gan_step=None,
        gan_interp=None,
        gan_reltaed=None,
        interp_pitch=None,
        quantized_pitch=None,
        uv=None,
        mel_shuffle=None,
        power=None,
        tilt=None,
        mode="train",
        emt_tau=1
    ):
        """Calculate forward propagation.

        Args:
            xs (Tensor): Batch of padded character ids (B, Tmax).
            ilens (LongTensor): Batch of lengths of each input batch (B,).
            ys (Tensor): Batch of padded target features (B, Lmax, odim).
            olens (LongTensor): Batch of the lengths of each target (B,).
            ds (Tensor): phone level frame number
            speaker_id (Tensor, optional): Batch of speaker id (B,).
            xs (Tensor): Batch of padded phone pitch (B, Tmax).
            lang_id (Tensor, optional): Batch of language id (B,).

        Returns:
            Tensor: Loss value.

        """
        output_mode = mode
        if output_mode == "eval-e2e":
            mode = "eval"
        elif output_mode == "train-e2e":
            mode = "train"

        if mode == "train" or mode == "semi":
            max_olen = max(olens)
            if ys is not None and max_olen != ys.shape[1]:
                ys = ys[:, :max_olen]
            if olens is None:
                olens = torch.sum(ds, dim=1)
            decoder_masks = self._source_mask(olens)
        elif mode == "eval":
            ys = None
            olens = None
            ds = None
            f0 = None
            energy = None
            ref_prosody = None
            ph_hs = None

        # adversarial_training
        disc_real = None
        gradient_penalty = None
        if self.enable_adversarial_training:
            if gan_step == "disc_real":
                disc_real, window_frame = self.model_disc(ys, olens)
                return disc_real, window_frame
            if gan_step == "gradient_penalty":
                gradient_penalty = self.calc_gradient_penalty(
                    self.model_disc, ys, gan_interp, olens, window_frame=gan_reltaed
                )
                return gradient_penalty
        max_ilen = max(ilens)
        if max_ilen != xs.shape[1]:
            xs = xs[:, :max_ilen]
        encoder_masks = self._source_mask(ilens)

        # add context feature
        context_feat = None
        if self.enable_context:
            context_phone = self.prenet_phone(context_phone.transpose(1, 2)).transpose(1, 2)
            context_phone = self.prenet_phone_dense(context_phone)
            context_seq = self.prenet_seq_inproj(context_seq)
            context_cur = context_seq[:, int((context_seq.size(1) - 1) / 2), :]
            self.prenet_seq_gru.flatten_parameters()
            _, memory_context = self.prenet_seq_gru(context_seq)
            context_seq = self.prenet_seq_outproj(torch.cat((context_cur, memory_context.squeeze(0)), -1)).unsqueeze(1)
            context_feat = context_phone + context_seq

        # text encoder
        encoder_hidden_tuple = ()
        if self.use_singing_feature:
            # Phoneme or character embedding
            phone_embedding = self.symbol_embedding(xs)
            note_duration_embedding = self.note_duration_embedding(note_duration)
            if self.enable_frame_pitch:
                xs = phone_embedding + note_duration_embedding
            else:
                note_pitch_embedding = self.note_pitch_embedding(note_pitch)
                xs = phone_embedding + note_pitch_embedding + note_duration_embedding

        if self.speech_inpainting:
            pcv_feat, _ = self.style_encoder(sp_ref.permute(1, 0, 2), lens=sp_reflens)
            pcv_feat = pcv_feat.permute(1, 0, 2)
            encoder_hidden, _ = self.encoder(xs, encoder_masks, sty_inp=pcv_feat)
        else:
            if self.enable_encoder_conditional_layernorm and self.enable_cross_lingual:
                if self.use_encoder_spk_condition:
                    encoder_condition = self.get_speaker_condition(speaker_id)
                else:
                    encoder_condition = self.get_conditional_embedding(lang_id)
                encoder_hidden, unused = self.encoder(
                    xs, encoder_masks, condition=encoder_condition, context_feat=context_feat
                )
            else:
                encoder_hidden, unused = self.encoder(xs, encoder_masks, context_feat=context_feat)

        if self.enable_zeroshot_finegrained:
            encoder_hidden_only_text = encoder_hidden
        if self.encoder_hidden_constraint:
            encoder_hidden_tuple = encoder_hidden
            encoder_hidden = encoder_hidden[-1]
            if self.dmodel != self.teacher_dmodel:
                encoder_hidden_tuple = [
                    self.enc_constraint_proj_layers[i](ehc) for i, ehc in enumerate(encoder_hidden_tuple)
                ]

        if self.att_constraint:
            encoder_hidden_tuple = (encoder_hidden_tuple, unused) if encoder_hidden_tuple != () else (unused,)

        spembs_condition = None
        # multli speaker
        if self.new_voice_generation:
            spk_emb = self.spk_encoder(ys, olens, normalize=self.normalize_spk_emb)  # [batch, 256]
            attri_emb = self.attri_encoder(spk_emb)  # [batch, attri_dim]

            full_attri_lst = self.full_attribute_list.copy()
            attri_in_use = self.attribute_in_use.copy()  # [gender,age,pitch_level,soft,sweet,husky,upbeat,deep,warm]
            idx = torch.tensor([full_attri_lst.index(item) for item in attri_in_use], device=attributes.device)
            attri_gt = torch.index_select(attributes, 1, idx)
            if self.use_obj_attri:
                attri_gt[:, attri_in_use.index("pitch_level")] = pitch_level[:, 0]
                if self.use_energy_attri:
                    attri_gt = torch.cat([attri_gt, energy_level], -1)  # concatenate with the energy level
                    energy_level = energy_level.unsqueeze(1)
                pitch_level = pitch_level.unsqueeze(1)
                spk_rate_level = spk_rate_level.unsqueeze(1)
            else:
                pitch_level = torch.index_select(
                    attributes, 1, torch.tensor([full_attri_lst.index("pitch_level")], device=attributes.device)
                ).unsqueeze(
                    1
                )  # [batch, 1, 1]
                spk_rate_level = torch.index_select(
                    attributes, 1, torch.tensor([full_attri_lst.index("speaking_rate")], device=attributes.device)
                ).unsqueeze(
                    1
                )  # [batch, 1, 1]
            logger.debug(f"attri_gt: {attri_gt}")
            if self.rand_attri_unrelate_feat:
                # using random variable for the attribute unrelated dimensions.
                attri_relate = attri_emb
                attri_unrelate = (
                    torch.rand(attributes.shape[0], self.unrelate_feat_dim, device=attributes.device) * 2 - 1.0
                )
                attri_emb = torch.cat([attri_relate, attri_unrelate], -1)
                logger.debug(f"random attri_unrelate: {attri_unrelate}")
            else:
                attri_relate = attri_emb[:, : attri_gt.shape[1]]
                attri_unrelate = attri_emb[:, attri_gt.shape[1] :]
            spk_emb_encdec = self.attri_decoder(attri_emb, normalize=self.normalize_spk_emb)  # [batch, 256]
            spembs_condition = self.emb_act(self.speaker_embeddinglinear(spk_emb_encdec.unsqueeze(1)))
            spembs = spembs_condition.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.speaker_embedding_proj(torch.cat([encoder_hidden, spembs], -1))
            # model the inferred attributes distibution
            log_like = None
            if self.model_attri_distribution:
                log_like = self.MDN(torch.tensor([[1.0]]).to(attri_relate.device), attri_relate.detach())  # [batch, 1]
            # semi-supervised training, for the unlabelled data, only pitch and energy are used.
            if self.semi_supervised_training:
                with_attri_label = with_attri_label.unsqueeze(1)  # reshape to [batch, 1]
                attri_mask = with_attri_label.repeat(1, attri_relate.size(1))
                if self.use_obj_attri:
                    # speaking rate is only used as condition
                    attri_mask[:, attri_in_use.index('pitch_level')] = 1.0
                    if self.use_energy_attri:
                        attri_mask[:, -1] = 1.0
                logger.debug(f'attri_mask, \n{attri_mask.shape}, \n{attri_mask}')
                logger.debug(f'attri_relate, \n{attri_relate.shape}, \n{attri_relate}')
                logger.debug(f'attri_gt, \n{attri_gt.shape}, \n{attri_gt}')
                attri_relate *= attri_mask
                logger.debug(f'attri_relate, \n{attri_relate.shape}, \n{attri_relate}')
                logger.debug(f'attri_emb, \n{attri_emb.shape}, \n{attri_emb}')
        elif self.speaker_embedding is not None and not self.distil == "full_tiny":
            spembs = self.speaker_embedding(speaker_id)
            if self.enable_zeroshot:
                spembs = spembsinput / torch.norm(spembsinput, dim=1, keepdim=True)

            if len(spembs.size()) == 2:
                spembs = spembs.unsqueeze(1)

            encoder_hidden_orig = encoder_hidden
            if self.enable_concat_lut:
                spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
                spembs_condition = spembs
                spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
                encoder_hidden = self.speaker_embedding_proj(torch.cat([encoder_hidden, spembs], -1))
            else:
                spembs = F.normalize(spembs)
                spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
                encoder_hidden += spembs

            if self.enable_cross_lingual_spk_loss:
                cross_idx = torch.randperm(speaker_id.size(0))
                cross_spk_id = speaker_id[cross_idx]
                cross_spembs = self.speaker_embedding(cross_spk_id)
                if len(cross_spembs.size()) == 2:
                    cross_spembs = cross_spembs.unsqueeze(1)
                if self.enable_concat_lut:
                    cross_spembs = self.emb_act(self.speaker_embeddinglinear(cross_spembs))
                    cross_spembs_condition = cross_spembs
                    cross_spembs = cross_spembs.repeat(1, encoder_hidden_orig.size(1), 1)
                    cross_encoder_hidden = self.speaker_embedding_proj(torch.cat([encoder_hidden_orig, cross_spembs], -1))
                else:
                    cross_spembs = F.normalize(cross_spembs)
                    cross_spembs = cross_spembs.repeat(1, encoder_hidden_orig.size(1), 1)
                    cross_encoder_hidden = encoder_hidden_orig + cross_spembs

        # cross lingual
        if self.lang_embedding is not None:
            langs = self.lang_embedding(lang_id)
            if len(langs.size()) == 2:
                langs = langs.unsqueeze(1)

            if self.enable_concat_lut:
                langs = self.emb_act(self.lang_embeddinglinear(langs))
                langs = langs.repeat(1, encoder_hidden.size(1), 1)
                encoder_hidden = self.lang_embedding_proj(torch.cat([encoder_hidden, langs], -1))
            else:
                langs = F.normalize(langs)
                langs = langs.repeat(1, encoder_hidden.size(1), 1)
                encoder_hidden += langs

            if self.enable_cross_lingual_spk_loss:
                if self.enable_concat_lut:
                    cross_encoder_hidden = self.lang_embedding_proj(torch.cat([cross_encoder_hidden, langs], -1))
                else:
                    cross_encoder_hidden += langs

        if self.enable_multi_style and not self.distil == "full_tiny" and not self.enable_emotion_encoder:
            style_embedding = self.style_embedding(style_id.long().unsqueeze(-1))
            if len(style_embedding.size()) == 4:
                style_embedding = style_embedding.squeeze(1)
            if len(style_embedding.size()) == 2:
                style_embedding = style_embedding.unsqueeze(1)

            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))

            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], -1))

            if self.enable_cross_lingual_spk_loss:
                # the order of the sytle IDs will be changed to be associated with the speakers.
                cross_encoder_hidden = self.style_embedding_proj(torch.cat([cross_encoder_hidden, style_embedding[cross_idx]], -1))

        if self.enable_emotion_encoder:
            emt_utt_emb = self.emotion_encoder(ys)
            emt_logits = self.emt_logits(emt_utt_emb)
            spk_logits = self.spk_logits(GRL.apply(emt_utt_emb))
            locale_logits = self.locale_logits(GRL.apply(emt_utt_emb))

            emt_latent = F.gumbel_softmax(emt_logits, tau=emt_tau, hard=True)
            emt_pre_labels = torch.sum(torch.mul(emt_latent,
                                                 torch.arange(0, self.style_embedding_size).to(
                                                     emt_logits.device).unsqueeze(0).repeat(emt_latent.size(0), 1)),
                                       dim=-1).long()

            emt_intensity = torch.sum(torch.mul(emt_latent, torch.pow(self.exponent_alpha, emt_logits)), dim=-1) / \
                torch.sum(torch.pow(self.exponent_alpha, emt_logits), dim=-1)

            style_embedding = self.style_embedding(emt_pre_labels)
            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))
            style_embedding = torch.mul(emt_intensity.unsqueeze(1).repeat(1, style_embedding.size(-1)), style_embedding)
            if len(style_embedding.size()) == 2:
                style_embedding = style_embedding.unsqueeze(1)

            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], -1))

        encoder_hidden_ps = encoder_hidden
        if self.enable_cross_lingual_spk_loss:
            cross_encoder_hidden_ps = cross_encoder_hidden

        if self.speech_inpainting:
            ys = sp_ref

        # global style token
        pred_prosody = None
        pred_global_f0 = None
        ref_gst = None
        if self.gst_predictor is not None:
            pred_prosody = self.gst_predictor(encoder_hidden, ilens)
            if ref_prosody is None:
                if mode == "train":
                    ref_prosody = self.gst(ys)
                elif mode == "semi":
                    ref_prosody = self.gst(ys)
                    ref_gst = ref_prosody.squeeze(1).detach()
                    ref_prosody = pred_prosody.unsqueeze(1)
                else:
                    ref_prosody = pred_prosody.unsqueeze(1)
            if self.enable_zeroshot:
                ref_prosodyf0 = ref_prosody
                if not self.enable_zeroshot_finegrained:
                    ref_prosodyf0 = torch.cat([ref_prosody, style_embedding.repeat(1, ref_prosody.size(1), 1)], -1)
                pred_global_f0 = self.gst_projmeanf0(ref_prosodyf0)
                pred_global_f0 = pred_global_f0.squeeze(-1)
                pred_global_f0 = pred_global_f0.squeeze(-1)
            ref_prosody_exp = ref_prosody.repeat(1, encoder_hidden.size(1), 1)
            ref_prosody = ref_prosody.squeeze(1)
            encoder_hidden_ps = torch.cat((encoder_hidden, ref_prosody_exp), dim=-1)
            encoder_hidden_ps = self.gst_proj(encoder_hidden_ps)

            if self.enable_cross_lingual_spk_loss:
                # use inference mode
                cross_pred_prosody = self.gst_predictor(cross_encoder_hidden, ilens)
                cross_ref_prosody = cross_pred_prosody.unsqueeze(1)
                cross_ref_prosody_exp = cross_ref_prosody.repeat(1, cross_encoder_hidden.size(1), 1)
                cross_encoder_hidden_ps = torch.cat((cross_encoder_hidden, cross_ref_prosody_exp), dim=-1)
                cross_encoder_hidden_ps = self.gst_proj(cross_encoder_hidden_ps)

        # style gmvae
        style_vae_embedding, kl_tuple_style_vae = None, None
        if self.enable_style_vae:
            style_vae_enc, _ = self.style_vae_encoder(ys, decoder_masks)

            _, style_vae_compress = self.style_vae_compress_layer(style_vae_enc)
            style_vae_compress = style_vae_compress.transpose(0, 1)
            style_vae_compress = style_vae_compress.reshape(style_vae_compress.size(0), -1)

            style_vae_compress = self.style_vae_compress_proj(style_vae_compress)
            if len(style_id.size()) == 2:
                style_id = style_id.squeeze(-1)
            style_onehot = F.one_hot(style_id.long(), num_classes=self.style_embedding_size).float()
            if self.enable_style_vae_withspk:
                if len(speaker_id.size()) == 2:
                    speaker_id = speaker_id.squeeze(-1)
                spk_onehot = F.one_hot(speaker_id.long(), num_classes=self.spk_size).float()
                xy = torch.cat((style_vae_compress, style_onehot, spk_onehot), dim=-1)
            else:
                xy = torch.cat((style_vae_compress, style_onehot), dim=-1)
            style_vae_embedding, qz_mu, qz_log_sigma2 = self.style_gmvaeLabeled.qz_graph(xy)
            if self.enable_style_vae_withspk:
                _, pz_mu, pz_log_sigma2 = self.style_gmvaeLabeled.pz_graph(
                    torch.cat((style_onehot, spk_onehot), dim=-1)
                )
            else:
                _, pz_mu, pz_log_sigma2 = self.style_gmvaeLabeled.pz_graph(style_onehot)
            style_vae_embedding = style_vae_embedding.unsqueeze(1).repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden_ps = torch.cat((encoder_hidden_ps, style_vae_embedding), dim=-1)
            encoder_hidden_ps = self.style_vae_proj(encoder_hidden_ps)
            kl_tuple_style_vae = (qz_mu, qz_log_sigma2, pz_mu, pz_log_sigma2)

        if self.enable_retrain_phnpred:
            # sduration prediction
            d_masks = make_pad_mask(ilens).to(xs.device)
            sd_outs = self.sduration_predictor(encoder_hidden, d_masks)
            sds = ds.float().unsqueeze(-1)
            sd_embs = self.sduration_embed(sds.transpose(1, 2)).transpose(1, 2)
            sencoder_hidden_ps = torch.cat((encoder_hidden_ps, sd_embs), dim=-1)
            sencoder_hidden_ps = self.sduration_emb_enc_proj(sencoder_hidden_ps)

            # spitch prediction
            sps, sp_outs = None, None
            sp_outs = self.spitch_predictor(encoder_hidden, d_masks.unsqueeze(-1))
            sps = f0.unsqueeze(-1)
            sp_embs = self.spitch_embed(sps.transpose(1, 2)).transpose(1, 2)
            sencoder_hidden_ps = torch.cat((sencoder_hidden_ps, sp_embs), dim=-1)
            sencoder_hidden_ps = self.spitch_emb_enc_proj(sencoder_hidden_ps)

        # phone prosody embedding
        ph_emb_predictor_input = encoder_hidden_ps if self.enable_hierarchical_cond else encoder_hidden
        ph_emb_pred = None
        kl_tuple = None
        ref_phemb = None
        if self.enable_cross_lingual_spk_loss:
            cross_ph_emb_predictor_input = cross_encoder_hidden_ps if self.enable_hierarchical_cond else cross_encoder_hidden
            cross_ph_emb_pred = None
        if self.phone_emb_predictor is not None:
            if (mode == "train" or mode == "semi") and ph_hs is None:
                refs = ys
                if self.speaker_embedding is not None or self.new_voice_generation:
                    frame_spembs = spembs[:, 0:1, :].expand(-1, ys.size(1), -1)
                    refs = torch.cat((refs, frame_spembs), dim=-1)
                if self.lang_embedding is not None:
                    frame_langs = langs[:, 0:1, :].expand(-1, ys.size(1), -1)
                    refs = torch.cat((refs, frame_langs), dim=-1)
                if self.style_embedding is not None:
                    frame_styles = style_embedding[:, 0:1, :].expand(-1, ys.size(1), -1)
                    refs = torch.cat((refs, frame_styles), dim=-1)
                spk_spec = self.spec_enc_input_proj(refs)
                spk_spec = self.pos_emb(spk_spec)
                if isinstance(spk_spec, tuple):
                    spk_spec = spk_spec[0]
                if self.speech_inpainting:
                    ref_masks = self._source_mask(sp_reflens)
                    spk_spec_hs, _ = self.spec_encoder(spk_spec, ref_masks)
                    yx_masks = self._source_to_target_mask(sp_reflens, ilens)
                else:
                    spk_spec_hs, _ = self.spec_encoder(spk_spec, decoder_masks)
                    yx_masks = self._source_to_target_mask(olens, ilens)
                enc_norm = self.enc_norm(ph_emb_predictor_input)

                # use phone level vae
                if self.enable_phone_vae:
                    raw_spec = self.raw_spec_input_proj(ys)
                    ph_hs = self.ph_spec_att(
                        query=enc_norm, key=spk_spec_hs, value=spk_spec_hs + raw_spec, mask=yx_masks
                    )
                    ph_z_mu, ph_z_log_sigma2 = ph_hs[:, :, : self.style_dim], ph_hs[:, :, self.style_dim :]
                    ph_hs = self.phone_emb_predictor.reparameterize(ph_z_mu, ph_z_log_sigma2)
                    ph_hs_detach = ph_z_mu.detach()  # phone level predictor only predicts mu, and assume std=1.0
                    kl_tuple = (ph_z_mu, ph_z_log_sigma2)
                # default use normal phone embedding
                else:
                    ph_hs = self.ph_spec_att(query=enc_norm, key=spk_spec_hs, value=spk_spec_hs, mask=yx_masks)
                    ph_hs_detach = ph_hs.detach()

                if self.enable_ar_phn_pred:
                    phs_zero = torch.zeros_like(ph_hs_detach[:, 0:1, :], dtype=ph_hs.dtype, device=ph_hs.device)
                    phs_ar = torch.cat((phs_zero, ph_hs_detach[:, :-1, :]), dim=1)
                    phs_ar = torch.cat((ph_emb_predictor_input, phs_ar), dim=-1)
                    ph_emb_pred = self.phone_emb_predictor(phs_ar, ilens)
                else:
                    ph_emb_pred = self.phone_emb_predictor(ph_emb_predictor_input, ilens)
                if mode == "semi":
                    ref_phemb = ph_hs.detach()
                    ph_hs = ph_emb_pred
            else:
                ph_emb_pred = self.phone_emb_predictor(ph_emb_predictor_input, ilens)
                ph_hs = ph_emb_pred

            encoder_hidden_ps = torch.cat((encoder_hidden_ps, ph_hs), dim=-1)
            encoder_hidden_ps = self.ph_emb_enc_proj(encoder_hidden_ps)

            if self.enable_cross_lingual_spk_loss:
                # use inference mode
                cross_ph_emb_pred = self.phone_emb_predictor(cross_ph_emb_predictor_input, ilens)
                cross_encoder_hidden_ps = torch.cat((cross_encoder_hidden_ps, cross_ph_emb_pred), dim=-1)
                cross_encoder_hidden_ps = self.ph_emb_enc_proj(cross_encoder_hidden_ps)

        d_masks = make_pad_mask(ilens).to(xs.device)

        duration_predictor_input = encoder_hidden_ps if self.enable_hierarchical_cond else encoder_hidden

        if self.enable_cross_lingual_spk_loss:
            # cross-lingual loss only affect pitch, energy predictors and conformer decoder.
            cross_encoder_hidden = cross_encoder_hidden.detach()
            cross_encoder_hidden_ps = cross_encoder_hidden_ps.detach()

        # pitch prediction
        ps, p_outs, ref_f0 = None, None, None
        if self.speech_inpainting:
            p_outs = self.pitch_predictor(encoder_hidden_ps, d_masks.unsqueeze(-1))
            ps = f0.unsqueeze(-1)
            p_embs = self.pitch_embed(ps.transpose(1, 2)).transpose(1, 2)
            encoder_hidden_ps = torch.cat((encoder_hidden_ps, p_embs), dim=-1)
            encoder_hidden_ps = self.pitch_emb_enc_proj(encoder_hidden_ps)
        elif self.pitch_predictor is not None:
            p_outs = self.pitch_predictor(encoder_hidden, d_masks.unsqueeze(-1), global_f0, condition=pitch_level)
            if mode == "train":
                ps = f0.unsqueeze(-1)
            elif mode == "semi":
                if f0 is not None:
                    ps = f0.unsqueeze(-1)
                    ref_f0 = ps.detach()
                ps = p_outs
            else:
                ps = p_outs
            p_embs = self.pitch_embed(ps.transpose(1, 2)).transpose(1, 2)
            encoder_hidden_ps = torch.cat((encoder_hidden_ps, p_embs), dim=-1)
            encoder_hidden_ps = self.pitch_emb_enc_proj(encoder_hidden_ps)

            if self.enable_cross_lingual_spk_loss:
                # use inference mode
                cross_p_outs = self.pitch_predictor(cross_encoder_hidden, d_masks.unsqueeze(-1), global_f0, condition=pitch_level)
                cross_p_embs = self.pitch_embed(cross_p_outs.transpose(1, 2)).transpose(1, 2)
                cross_encoder_hidden_ps = torch.cat((cross_encoder_hidden_ps, cross_p_embs), dim=-1)
                cross_encoder_hidden_ps = self.pitch_emb_enc_proj(cross_encoder_hidden_ps)

        # energy prediction
        es = None
        e_outs = None
        if self.energy_predictor is not None:
            e_outs = self.energy_predictor(encoder_hidden, d_masks.unsqueeze(-1), global_energy, condition=energy_level)
            if mode == "train":
                es = energy.unsqueeze(-1)
            else:
                es = e_outs
            e_embs = self.energy_embed(es.transpose(1, 2)).transpose(1, 2)
            encoder_hidden_ps = torch.cat((encoder_hidden_ps, e_embs), dim=-1)
            encoder_hidden_ps = self.energy_emb_enc_proj(encoder_hidden_ps)

            if self.enable_cross_lingual_spk_loss:
                cross_e_outs = self.energy_predictor(cross_encoder_hidden, d_masks.unsqueeze(-1), global_energy, condition=energy_level)
                cross_e_embs = self.energy_embed(cross_e_outs.transpose(1, 2)).transpose(1, 2)
                cross_encoder_hidden_ps = torch.cat((cross_encoder_hidden_ps, cross_e_embs), dim=-1)
                cross_encoder_hidden_ps = self.energy_emb_enc_proj(cross_encoder_hidden_ps)

        power_s = None
        power_outs = None
        if self.power_predictor is not None:
            power_outs = self.power_predictor(encoder_hidden, d_masks.unsqueeze(-1), None, condition=None)
            if mode == "train":
                power_s = power.unsqueeze(-1)
            else:
                power_s = power_outs
            e_embs = self.power_embed(power_s.transpose(1, 2)).transpose(1, 2)
            encoder_hidden_ps = torch.cat((encoder_hidden_ps, e_embs), dim=-1)
            encoder_hidden_ps = self.power_emb_enc_proj(encoder_hidden_ps)

        tilt_s = None
        tilt_outs = None
        if self.tilt_predictor is not None:
            tilt_outs = self.tilt_predictor(encoder_hidden, d_masks.unsqueeze(-1), None, condition=None)
            if mode == "train":
                tilt_s = tilt.unsqueeze(-1)
            else:
                tilt_s = tilt_outs
            e_embs = self.tilt_embed(tilt_s.transpose(1, 2)).transpose(1, 2)
            encoder_hidden_ps = torch.cat((encoder_hidden_ps, e_embs), dim=-1)
            encoder_hidden_ps = self.tilt_emb_enc_proj(encoder_hidden_ps)

        if self.use_singing_feature and self.enable_syllabledurforsinging:
            sdembs = self.syllable_duration_embedding(syllable_duration)
            duration_predictor_input = self.syllable_duration_embedding_proj(
                torch.cat([duration_predictor_input, sdembs], -1)
            )

        # duration prediction
        if mode == "train" or mode == "semi":
            d_outs = self.duration_predictor(
                duration_predictor_input, d_masks, global_zero_cross_rate, condition=spk_rate_level
            )
        else:
            d_outs = self.duration_predictor(duration_predictor_input, d_masks)
            ds = self.duration_predictor.inference_(duration_predictor_input, d_masks)
            olens = torch.sum(ds, dim=1)
            decoder_masks = self._source_mask(olens)
        if self.enable_zeroshot_finegrained:
            yx_masks = self._source_to_target_mask(olens, ilens)
            encoder_hidden_ps = encoder_hidden_ps + self.zeroshot_finegrained.calculate_finegrained_output(encoder_hidden_only_text, mel_shuffle, yx_masks)
        hs, align_mat = self.length_regulator(encoder_hidden_ps, ds)

        if self.speech_inpainting:
            ys = self.refmel_proj(ys)
            for i in range(sp_tgtyseqs.shape[0]):
                hs[i, : sp_tgtyseqs[i, 0], :] = ys[i, : sp_tgtyseqs[i, 0], :]
                hs[i, sp_tgtyseqs[i, 1] + 1 : olens[i], :] = ys[
                    i, sp_tgtyseqs[i, 0] : sp_tgtyseqs[i, 0] + olens[i] - sp_tgtyseqs[i, 1] - 1, :
                ]

        if self.enable_ar_prosody:
            with torch.no_grad():
                ps1 = (f0 * self.pitch_var + self.pitch_mean)
                ps1 = torch.clip(ps1, 0, 999).long()
                ps_in = torch.cat((ps1[:, :1] * 0, ps1[:, :-1]), 1)
                ds1 = torch.clip(ds, 0, 50).long()
                ds_in = torch.cat((ds1[:, :1] * 0, ds1[:, :-1]), 1)
            p_outs1, d_outs1 = self.ar_prosody_predictor(duration_predictor_input, ps_in, ds_in, ~d_masks.unsqueeze(-2))

        if self.enable_diff_prosody:
            noisy_prosody, timesteps, diffp_ref = self.diff_prosody_predictor.prepare_input(f0, ds, self.pitch_mean, self.pitch_var)
            diffp_pred = self.diff_prosody_predictor(noisy_prosody, timesteps, duration_predictor_input, ~d_masks.unsqueeze(1))

        # frame_pitch prediction
        frame_quantpitch_pred = None
        frame_uv_pred = None
        frame_contpitch_pred_norm = None
        if self.frame_pitch_predictor is not None:
            if self.use_singing_feature:
                note_pitch_embedding = self.note_pitch_embedding(note_pitch)
                note_pitch_embedding_exp, _ = self.length_regulator(note_pitch_embedding, ds)
                hs_note_pitch = self.note_pitch_embedding_proj(torch.cat([hs.detach(), note_pitch_embedding_exp], -1))
                frame_pitch_predictor_input = hs_note_pitch
            else:
                frame_pitch_predictor_input = hs.detach()

            frame_pitch_predictor_out, _ = self.frame_pitch_predictor(frame_pitch_predictor_input, decoder_masks)

            if self.enable_dar_prediction:
                quant_pitch_zero = torch.zeros_like(
                    quantized_pitch[:, 0:1, :], dtype=quantized_pitch.dtype, device=quantized_pitch.device
                )
                quant_pitch_ar = torch.cat((quant_pitch_zero, quantized_pitch[:, :-1, :]), dim=1)
                drop_factor = torch.ones_like(quant_pitch_ar, dtype=quant_pitch_ar.dtype, device=quant_pitch_ar.device)
                sample_index = drop_factor[:, :, 0:1] * (1 - self.dar_droprate)
                drop_factor = torch.distributions.bernoulli.Bernoulli(sample_index).sample()
                quant_pitch_ar = quant_pitch_ar * drop_factor
                quant_pitch_ar = torch.cat((frame_pitch_predictor_out, quant_pitch_ar.detach()), dim=-1)
                frame_quantpitch_pred = self.frame_pitch_predictor_dar(quant_pitch_ar, olens)
            else:
                frame_quantpitch_pred = self.quantized_proj(frame_pitch_predictor_out)
            frame_quantpitch_pred = hierarchical_softmax(frame_quantpitch_pred)

            if self.enable_quant2cont_prediction or self.use_pred_pitch_input:
                mean_based_matrix = torch.arange(0.0, 255.0).view(-1, 1).to(frame_quantpitch_pred.device)
                f0_unvoiced, f0_voiced = torch.split(frame_quantpitch_pred, [1, 255], dim=-1)
                f0_voiced = f0_voiced / (1.0 - f0_unvoiced + 1e-10)
                f0_voiced = torch.matmul(f0_voiced, mean_based_matrix)
                f0_voiced = self.mu_law_decode(f0_voiced, quantization_channels=255.0)
                f0_voiced = f0_voiced * (800.0 - self.pitch_mean) + self.pitch_mean
                frame_uv_pred = torch.where(f0_unvoiced > 0.5, 0.0, 1.0)
                frame_contpitch_pred_denorm = torch.where(f0_unvoiced > 0.5, torch.zeros_like(f0_voiced), f0_voiced)
                frame_contpitch_pred_norm = self.pitch_norm(frame_contpitch_pred_denorm)

            pitch_denorm = self.pitch_denorm(interp_pitch) * uv
            pitch_norm = self.pitch_norm(pitch_denorm)

            if self.enable_quant2cont_prediction and self.use_pred_pitch_input:
                frame_cat_pred = torch.cat((frame_contpitch_pred_norm, frame_uv_pred), dim=-1)
                frame_pitch = self.continuous_lut(frame_cat_pred)
            else:
                frame_cat_gt = torch.cat((pitch_norm.unsqueeze(-1), uv.unsqueeze(-1)), dim=-1)
                frame_pitch = self.continuous_lut(frame_cat_gt)
            hs = torch.cat((hs, frame_pitch), dim=-1)
            hs = self.frame_pitch_proj(hs)

        # mel decoder
        gating_features = None
        if self.enable_fmoe:
            gating_features = torch.matmul(align_mat, encoder_hidden_ps)
        zs, unused = self.decoder(
            hs,
            decoder_masks,
            condition=spembs_condition,
            gating_features=gating_features,
            inference=True,
            ys=ys,
        )

        if self.att_constraint:
            encoder_hidden_tuple += (unused,)  # which is att matrix group, now have 3 tuple

        if self.predict_mel:
            outputs = []
            for i in range(self.dec_layers):
                if i < self.predict_mel_layer:
                    outputs.append(None)
                elif i == self.predict_mel_layer:
                    outputs.append(zs[i])
                else:
                    outputs.append(self.output_layers[i](zs[i]))
        elif self.enable_zeroshot_autoregressive:
            outputs = [self.output_layers[i](zs[i]) for i in range(self.dec_layers - 1)]
            xs = self.zeroshot_autoregressive.apply_autoregressive(zs[-1], ys)
            outputs.append(self.output_layers[-1](xs))
        else:
            outputs = [self.output_layers[i](zs[i]) for i in range(self.dec_layers)]

        if self.new_voice_generation:
            mels = outputs[-1]
            spk_emb_cycle = self.spk_encoder(mels, olens, normalize=self.normalize_spk_emb)

        if self.enable_cross_lingual_spk_loss:
            # use the ground-truth durations of the original speakers
            cross_hs, _ = self.length_regulator(cross_encoder_hidden_ps, ds)
            if self.only_update_decoder_in_cross_lingual_loss:
                cross_hs = cross_hs.detach()
            cross_zs, _ = self.decoder(cross_hs, decoder_masks, condition=cross_spembs_condition.detach())
            cross_outputs = [self.output_layers[i](cross_zs[i]) for i in range(self.dec_layers)]
            cross_mels = cross_outputs[-1]
            cross_spk_emb = self.spk_encoder(cross_mels, olens, normalize=False)
            spk_emb_gt = self.spk_encoder(ys[cross_idx], olens, normalize=False)   # [batch, 256]
            spk_emb_gt = spk_emb_gt.detach()

        # decoder online distillation
        soutputs = None
        if self.distil.endswith("_decoder"):
            sgating_features = None
            if self.enable_retrain_phnpred:
                # sph_emb_pred
                sph_emb_predictor_input = sencoder_hidden_ps
                sph_emb_pred = self.phone_emb_predictor(sph_emb_predictor_input, ilens)
                ph_hs_detach = ph_hs.detach()
                sencoder_hidden_ps = torch.cat((sencoder_hidden_ps, ph_hs), dim=-1)
                sencoder_hidden_ps = self.ph_emb_enc_proj(sencoder_hidden_ps)

                # pitch prediction
                if self.pitch_predictor is not None:
                    ps = f0.unsqueeze(-1)
                    p_embs = self.pitch_embed(ps.transpose(1, 2)).transpose(1, 2)
                    sencoder_hidden_ps = torch.cat((sencoder_hidden_ps, p_embs), dim=-1)
                    sencoder_hidden_ps = self.pitch_emb_enc_proj(sencoder_hidden_ps)

                # duration prediction
                shs, salign_mat = self.length_regulator(sencoder_hidden_ps, ds)
                shs = self.sdecoder_proj(shs)
                if self.enable_fmoe:
                    sgating_features = torch.matmul(salign_mat, sencoder_hidden_ps)
                    sgating_features = self.sgating_features_proj(sgating_features)
                szs, _ = self.sdecoder(shs, decoder_masks, gating_features=sgating_features)
                soutputs = [self.soutput_layers[i](szs[i]) for i in range(len(self.soutput_layers))]

                soutputs = (soutputs, sp_outs, sd_outs, sph_emb_pred)
            else:
                if self.sdetach:
                    hs = hs.detach()
                    encoder_hidden_ps = encoder_hidden_ps.detach()
                if self.enable_fmoe:
                    sgating_features = torch.matmul(align_mat, encoder_hidden_ps)
                    sgating_features = self.sgating_features_proj(sgating_features)
                shs = self.sdecoder_proj(hs)
                szs, _ = self.sdecoder(shs, decoder_masks, gating_features=sgating_features)
                soutputs = [self.soutput_layers[i](szs[i]) for i in range(len(self.soutput_layers))]

        # adversarial_training
        disc_fake = None
        loss_adv = None
        if self.enable_adversarial_training:
            if gan_step == "disc_fake":
                disc_fake, _ = self.model_disc(outputs[-1].detach(), olens, window_frame=gan_reltaed)
                return disc_fake, outputs[-1].detach()
            else:
                loss_adv, _ = self.model_disc(outputs[-1], olens, window_frame=gan_reltaed)

        if output_mode == "eval-e2e":
            return outputs[-1], olens
        elif output_mode == "distill":
            return outputs[-1], soutputs, ds
        elif output_mode == "full_distill":
            return outputs[-1], d_outs.detach(), ds
        elif output_mode == "voc_distill":
            return outputs[-1], ds
        elif output_mode == "semi":
            return outputs, d_outs, pred_prosody, ref_gst, ref_f0, p_outs, ref_phemb, ph_emb_pred
        elif output_mode == "train-e2e":
            return outputs, d_outs, pred_prosody, ref_prosody, ps, p_outs, ph_hs, ph_emb_pred
        else:
            retvalue = (
                outputs,
                d_outs,
                pred_prosody,
                ref_prosody,
                ps,
                p_outs,
                ph_hs,
                ph_emb_pred,
                kl_tuple,
                es,
                e_outs,
                soutputs,
                ds,
                encoder_hidden_tuple,
            )
            if self.enable_zeroshot:
                retvalue = retvalue + (pred_global_f0, global_f0)
            elif self.new_voice_generation:
                retvalue = retvalue + (spk_emb, spk_emb_encdec, spk_emb_cycle, attri_gt, attri_relate, log_like)
            elif self.enable_cross_lingual_spk_loss:
                retvalue = retvalue + (spk_emb_gt, cross_spk_emb)
            elif self.enable_adversarial_training:
                retvalue = retvalue + (kl_tuple_style_vae, loss_adv)
            elif self.enable_frame_pitch:
                if self.enable_quant2cont_prediction:
                    frame_contpitch_pred_norm = frame_contpitch_pred_norm.squeeze(-1)
                    retvalue = retvalue + (frame_quantpitch_pred, frame_contpitch_pred_norm, pitch_norm.detach())
                else:
                    retvalue = retvalue + (frame_quantpitch_pred,)
            elif self.use_singing_feature:
                if self.power_predictor is not None or self.tilt_predictor is not None:
                    retvalue = retvalue + (power_s, power_outs, tilt_s, tilt_outs)
            if self.enable_ar_prosody:
                retvalue = retvalue + (ps1, p_outs1, ds1, d_outs1)
            if self.enable_diff_prosody:
                retvalue = retvalue + (diffp_ref, diffp_pred)
            if self.enable_emotion_encoder:
                retvalue = retvalue + (emt_logits, spk_logits, locale_logits)
            return retvalue

    @torch.no_grad()
    def inference_encoder(self, phone_id, speaker_id=None, lang_id=None, style_id=None,
                          style_scale_ratio=None, speaking_rate=1.0, f0_scale_ratio=None,
                          context_phone=None, context_seq=None,
                          note_pitch=None, note_duration=None, syllable_boundary=None,
                          syllable_duration=None, vowel_seq=None, phone_syllable_duration=None,
                          f0_scale_min=0.97, f0_scale_max=1.03, ilens=None,
                          ref_mel=None, attributes=None, attri_unrelate=None, use_mel_attri=False,
                          dump_pred_uv_pitch=False, use_picth_movingaverage=False):
        return self.inference(phone_id, speaker_id, lang_id, style_id, style_scale_ratio, speaking_rate,
                              f0_scale_ratio, context_phone, context_seq, note_pitch, note_duration,
                              syllable_boundary, syllable_duration, vowel_seq, phone_syllable_duration,
                              f0_scale_min, f0_scale_max, ilens,
                              ref_mel, attributes, attri_unrelate, use_mel_attri,
                              dump_pred_uv_pitch, use_picth_movingaverage,
                              mode="inference_encoder")

    @torch.no_grad()
    def inference_decoder(self, hs):
        zs, _ = self.decoder(hs,
                             None,
                             condition=None,
                             gating_features=None)
        zs = self.output_layers[-1](zs[-1])
        zs = zs.transpose(1, 2)
        zs = (zs + 4) / 8
        zs = zs * 2 - 1
        return zs

    @torch.no_grad()
    def inference(
        self,
        phone_id,
        speaker_id=None,
        lang_id=None,
        style_id=None,
        style_scale_ratio=None,
        speaking_rate=1.0,
        f0_scale_ratio=None,
        context_phone=None,
        context_seq=None,
        note_pitch=None,
        note_duration=None,
        syllable_boundary=None,
        syllable_duration=None,
        vowel_seq=None,
        phone_syllable_duration=None,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
        ilens=None,
        ref_mel=None,
        attributes=None,
        attri_unrelate=None,
        use_mel_attri=False,
        sample_from_mdn=False,
        cond_dic=None,
        dump_new_voice_data=False,
        dump_pred_uv_pitch=False,
        use_picth_movingaverage=False,
        l1_spk_id=None,
        use_l1_spk_pitch=False,
        l1_pitch_norm=None,
        pitch_std_scale=None,
        pitch_shift=None,
        use_l1_spk_energy=False,
        l1_energy_norm=None,
        energy_shift=None,
        is_singing_scale=True,
        mode=""
    ):
        """Decoding process."""
        d_masks = None if ilens is None else make_pad_mask(ilens).to(phone_id.device)
        p_masks = None if ilens is None else d_masks.unsqueeze(-1)
        encoder_masks = None if ilens is None else self._source_mask(ilens)
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()

        if self.dump_cross_lingual_v2:
            pitch_std_scale = 1.2
            energy_shift = 0.2

        context_feat = None
        if self.enable_context:
            context_phone = self.prenet_phone(context_phone.transpose(1, 2)).transpose(1, 2)
            context_phone = self.prenet_phone_dense(context_phone)
            context_seq = self.prenet_seq_inproj(context_seq)
            context_cur = context_seq[:, int((context_seq.size(1) - 1) / 2), :]
            self.prenet_seq_gru.flatten_parameters()
            _, memory_context = self.prenet_seq_gru(context_seq)
            context_seq = self.prenet_seq_outproj(torch.cat((context_cur, memory_context.squeeze(0)), -1)).unsqueeze(1)
            context_feat = context_phone + context_seq

        if self.enable_encoder_conditional_layernorm and self.enable_cross_lingual:
            if self.use_encoder_spk_condition:
                encoder_condition = self.get_speaker_condition(speaker_id)
            else:
                encoder_condition = self.get_conditional_embedding(lang_id)
            enc_hs, _ = self.encoder(phone_id, encoder_masks, condition=encoder_condition, context_feat=context_feat)
        elif self.use_singing_feature:
            phone_embedding = self.symbol_embedding(phone_id)
            note_duration_embedding = self.note_duration_embedding(note_duration.squeeze(-1).squeeze(-1))
            if self.enable_frame_pitch:
                xs = phone_embedding + note_duration_embedding
            else:
                note_pitch_embedding = self.note_pitch_embedding(note_pitch.squeeze(-1).squeeze(-1))
                xs = phone_embedding + note_pitch_embedding + note_duration_embedding

            enc_hs, _ = self.encoder(xs, encoder_masks, context_feat=context_feat)
        else:
            enc_hs, _ = self.encoder(phone_id, encoder_masks, context_feat=context_feat)
        enc_hs = enc_hs[-1] if self.encoder_hidden_constraint else enc_hs

        spembs_condition = None
        pitch_level = None
        energy_level = None
        spk_rate_level = None
        if self.new_voice_generation:
            full_attri_lst = self.full_attribute_list.copy()
            attri_in_use = self.attribute_in_use.copy()  # [gender,age,pitch_level,soft,sweet,husky,upbeat,deep,warm]
            if self.use_energy_attri:
                full_attri_lst += ["energy_level"]
                attri_in_use += ["energy_level"]
            pitch_level = torch.index_select(
                attributes, 1, torch.tensor([full_attri_lst.index("pitch_level")]).to(attributes.device)
            ).unsqueeze(
                1
            )  # [batch, 1, 1]
            spk_rate_level = torch.index_select(
                attributes, 1, torch.tensor([full_attri_lst.index("speaking_rate")]).to(attributes.device)
            ).unsqueeze(
                1
            )  # [batch, 1, 1]
            if self.use_energy_condition:
                energy_level = torch.index_select(
                    attributes, 1, torch.tensor([full_attri_lst.index("energy_level")]).to(attributes.device)
                ).unsqueeze(
                    1
                )  # [batch, 1, 1]
            idx = torch.tensor([full_attri_lst.index(item) for item in attri_in_use]).to(attributes.device)
            attri = torch.index_select(attributes, 1, idx)
            if use_mel_attri:
                spk_emb = self.spk_encoder(ref_mel, normalize=self.normalize_spk_emb)  # [batch, 256]
                attri_emb_mel = self.attri_encoder(spk_emb)  # [batch, attri_dim]
                attri = attri_emb_mel[:, : len(attri_in_use)]
                if self.rand_attri_unrelate_feat:
                    attri_unrelate = torch.rand(1, self.unrelate_feat_dim, device=attributes.device) * 2 - 1.0
                else:
                    attri_unrelate = attri_emb_mel[:, len(attri_in_use) :]

                pitch_level = torch.index_select(
                    attri, 1, torch.tensor([attri_in_use.index("pitch_level")]).to(attri.device)
                ).unsqueeze(1)
                if self.use_energy_condition:
                    energy_level = torch.index_select(
                        attri, 1, torch.tensor([attri_in_use.index("energy_level")]).to(attri.device)
                    ).unsqueeze(1)
            elif self.model_attri_distribution and sample_from_mdn:
                attri = self.MDN.sampling(torch.tensor([[1.0]]).to(attri.device), cond_dic)
                pitch_level = torch.index_select(attri, 1, torch.tensor([
                    attri_in_use.index('pitch_level')]).to(attri.device)).unsqueeze(1)
                if self.use_energy_condition:
                    energy_level = torch.index_select(attri, 1, torch.tensor([
                        attri_in_use.index('energy_level')]).to(attri.device)).unsqueeze(1)

            if self.model_attri_distribution:
                log_like = self.MDN(torch.tensor([[1.0]]).to(attri.device), attri)  # [batch, 1]
                logger.info(f'Attributes log-likelihood: {log_like}')

            logger.info(f"attri for infer: {attri}.\nattri_unrelate: {attri_unrelate}")
            if use_mel_attri:
                logger.info(f"attri from mel : {attri_emb_mel}")
            if self.use_energy_condition:
                logger.info(f"pitch_level:{pitch_level}, spk_rate_level:{spk_rate_level}, energy_level:{energy_level}")
            else:
                logger.info(f"pitch_level:{pitch_level}, spk_rate_level:{spk_rate_level}")

            attri_emb = torch.cat([attri, attri_unrelate], -1)
            spk_emb_encdec = self.attri_decoder(attri_emb, normalize=self.normalize_spk_emb)
            spembs_condition = self.emb_act(self.speaker_embeddinglinear(spk_emb_encdec.unsqueeze(1)))
            spembs = spembs_condition.repeat(1, enc_hs.size(1), 1)
            enc_hs = self.speaker_embedding_proj(torch.cat([enc_hs, spembs], -1))
        elif self.enable_multi_speaker and not self.distil == "full_tiny":
            if l1_spk_id is not None:
                if self.enable_encoder_conditional_layernorm and self.use_encoder_spk_condition:
                    encoder_condition = self.get_speaker_condition(l1_spk_id)
                    l1_enc_hs, _ = self.encoder(phone_id, encoder_masks, encoder_condition)
                    l1_enc_hs = l1_enc_hs[-1] if self.encoder_hidden_constraint else l1_enc_hs
                else:
                    l1_enc_hs = enc_hs
                l1_spembs = self.speaker_embedding(l1_spk_id.long())
                if self.enable_concat_lut:
                    l1_spembs = self.emb_act(self.speaker_embeddinglinear(l1_spembs))
                    # l1_spembs_condition = l1_spembs
                    l1_spembs = l1_spembs.repeat(1, l1_enc_hs.size(1), 1)
                    l1_enc_hs = self.speaker_embedding_proj(torch.cat([l1_enc_hs, l1_spembs], -1))
                else:
                    l1_spembs = F.normalize(l1_spembs)
                    l1_spembs = l1_spembs.repeat(1, l1_enc_hs.size(1), 1)
                    l1_enc_hs += l1_spembs

            spembs = self.speaker_embedding(speaker_id.long())
            if self.enable_concat_lut:
                spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
                spembs_condition = spembs
                spembs = spembs.repeat(1, enc_hs.size(1), 1)
                enc_hs = self.speaker_embedding_proj(torch.cat([enc_hs, spembs], -1))
            else:
                spembs = F.normalize(spembs)
                spembs = spembs.repeat(1, enc_hs.size(1), 1)
                enc_hs += spembs

        if self.enable_cross_lingual:
            langs = self.lang_embedding(lang_id.long())
            if self.enable_concat_lut:
                langs = self.emb_act(self.lang_embeddinglinear(langs))
                langs = langs.repeat(1, enc_hs.size(1), 1)
                enc_hs = self.lang_embedding_proj(torch.cat([enc_hs, langs], -1))
            else:
                langs = F.normalize(langs)
                langs = langs.repeat(1, enc_hs.size(1), 1)
                enc_hs += langs

            if l1_spk_id is not None:
                if self.enable_concat_lut:
                    l1_enc_hs = self.lang_embedding_proj(torch.cat([l1_enc_hs, langs], -1))
                else:
                    l1_enc_hs += langs

        if self.enable_multi_style and not self.distil == "full_tiny":
            style_embedding = self.style_embedding(style_id.long().unsqueeze(-1))
            if style_scale_ratio is not None:
                style_embedding = style_embedding * style_scale_ratio

            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))
            style_embedding = style_embedding.repeat(1, enc_hs.size(1), 1)
            enc_hs = self.style_embedding_proj(torch.cat([enc_hs, style_embedding], -1))

            if l1_spk_id is not None:
                l1_enc_hs = self.style_embedding_proj(torch.cat([l1_enc_hs, style_embedding], -1))

        enc_hs_ps = enc_hs
        if l1_spk_id is not None:
            l1_enc_hs_ps = l1_enc_hs

        if self.gst_predictor is not None:
            ref_prosody = self.gst_predictor.inference(enc_hs) if ilens is None else self.gst_predictor(enc_hs, ilens)
            ref_prosody = ref_prosody.unsqueeze(1)
            ref_prosody_exp = ref_prosody.repeat(1, enc_hs.size(1), 1)
            enc_hs_ps = torch.cat((enc_hs, ref_prosody_exp), dim=-1)
            enc_hs_ps = self.gst_proj(enc_hs_ps)

            if l1_spk_id is not None:
                l1_ref_prosody = self.gst_predictor.inference(l1_enc_hs) if ilens is None else self.gst_predictor(l1_enc_hs, ilens)
                l1_ref_prosody = l1_ref_prosody.unsqueeze(1)
                l1_ref_prosody_exp = l1_ref_prosody.repeat(1, l1_enc_hs.size(1), 1)
                l1_enc_hs_ps = torch.cat((l1_enc_hs, l1_ref_prosody_exp), dim=-1)
                l1_enc_hs_ps = self.gst_proj(l1_enc_hs_ps)

        style_vae_embedding = None
        if self.enable_style_vae:
            if len(style_id.size()) == 2:
                style_id = style_id.squeeze(-1)
            style_onehot = F.one_hot(style_id.long(), num_classes=self.style_embedding_size).float()
            if self.enable_style_vae_withspk:
                if len(speaker_id.size()) == 2:
                    speaker_id = speaker_id.squeeze(-1)
                spk_onehot = F.one_hot(speaker_id.long(), num_classes=self.spk_size).float()
                sample_pz, pz_mu, pz_log_sigma2 = self.style_gmvaeLabeled.pz_graph(
                    torch.cat((style_onehot, spk_onehot), dim=-1)
                )
            else:
                sample_pz, pz_mu, pz_log_sigma2 = self.style_gmvaeLabeled.pz_graph(style_onehot)
            style_vae_embedding = pz_mu
            style_vae_embedding = style_vae_embedding.unsqueeze(1).repeat(1, enc_hs.size(1), 1)
            enc_hs_ps = torch.cat((enc_hs_ps, style_vae_embedding), dim=-1)
            enc_hs_ps = self.style_vae_proj(enc_hs_ps)

        if self.enable_retrain_phnpred:
            senc_hs_ps = enc_hs_ps
            # sduration predictor
            sd_outs = self.sduration_predictor.inference(enc_hs, d_masks)
            if speaking_rate is not None:
                sd_outs = sd_outs / speaking_rate
            sd_outs = torch.round(sd_outs).long()
            sd_embs = self.sduration_embed(sd_outs.unsqueeze(-1).float().transpose(1, 2)).transpose(1, 2)
            senc_hs_ps = torch.cat((senc_hs_ps, sd_embs), dim=-1)
            senc_hs_ps = self.sduration_emb_enc_proj(senc_hs_ps)

            # spitch predictor
            p_outs = self.spitch_predictor(enc_hs, p_masks)
            if f0_scale_ratio is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                scaled_f0 = scaled_f0 * f0_scale_ratio
                scaled_f0 = (scaled_f0 - self.pitch_mean) / self.pitch_var
                f0_scale_mean = f0_scale_ratio.mean(1)
                p_outs = torch.where(
                    torch.logical_and(
                        torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)
                    ),
                    p_outs,
                    scaled_f0,
                )
            p_embs = self.spitch_embed(p_outs.transpose(1, 2)).transpose(1, 2)
            senc_hs_ps = torch.cat((senc_hs_ps, p_embs), dim=-1)
            senc_hs_ps = self.spitch_emb_enc_proj(senc_hs_ps)

            # special handler for retrain phnpred to fix dur/pitch contour adjustment issue
            enable_adjust_pitch_dur_flag = torch.logical_or(
                torch.logical_or(torch.greater(f0_scale_mean, f0_scale_max), torch.less(f0_scale_mean, f0_scale_min)),
                torch.any(torch.ne(speaking_rate, 1.0)),
            )
            enc_hs_ps = torch.where(enable_adjust_pitch_dur_flag, senc_hs_ps, enc_hs_ps)

        ph_emb_predictor_input = enc_hs_ps if self.enable_hierarchical_cond else enc_hs
        if l1_spk_id is not None:
            l1_ph_emb_predictor_input = l1_enc_hs_ps if self.enable_hierarchical_cond else l1_enc_hs
        if self.phone_emb_predictor is not None:
            if self.enable_ar_phn_pred:
                if self.export_onnx:
                    ph_hs = self.phone_emb_predictor.ar_onnx_inference(ph_emb_predictor_input)
                else:
                    ph_hs = self.phone_emb_predictor.ar_inference(enc_hs, ph_emb_predictor_input)
            else:
                if ilens is None:
                    ph_hs, _ = self.phone_emb_predictor.inference(ph_emb_predictor_input, None)
                else:
                    ph_hs = self.phone_emb_predictor(ph_emb_predictor_input, ilens)

            enc_hs_ps = torch.cat((enc_hs_ps, ph_hs), dim=-1)
            enc_hs_ps = self.ph_emb_enc_proj(enc_hs_ps)

            if l1_spk_id is not None:
                if self.enable_ar_phn_pred:
                    if self.export_onnx:
                        l1_ph_hs = self.phone_emb_predictor.ar_onnx_inference(l1_ph_emb_predictor_input)
                    else:
                        l1_ph_hs = self.phone_emb_predictor.ar_inference(l1_enc_hs, l1_ph_emb_predictor_input)
                else:
                    if ilens is None:
                        l1_ph_hs, _ = self.phone_emb_predictor.inference(l1_ph_emb_predictor_input, None)
                    else:
                        l1_ph_hs = self.phone_emb_predictor(l1_ph_emb_predictor_input, ilens)
                l1_enc_hs_ps = torch.cat((l1_enc_hs_ps, l1_ph_hs), dim=-1)
                l1_enc_hs_ps = self.ph_emb_enc_proj(l1_enc_hs_ps)

        duration_predictor_input = enc_hs_ps if self.enable_hierarchical_cond else enc_hs
        if l1_spk_id is not None:
            l1_duration_predictor_input = l1_enc_hs_ps if self.enable_hierarchical_cond else l1_enc_hs
        if self.pitch_predictor is not None:
            if self.enable_ar_prosody:
                p_outs = self.ar_prosody_predictor.recognize_pitch(duration_predictor_input, 0, self.pitch_mean, self.pitch_var)
            elif self.enable_diff_prosody:
                p_outs, d_outs_diffp = self.diff_prosody_predictor.recognize(duration_predictor_input, self.pitch_mean, self.pitch_var)
            else:
                p_outs = self.pitch_predictor(enc_hs, p_masks, condition=pitch_level)

            if l1_spk_id is not None and use_l1_spk_pitch:
                logger.debug(f'pitch, {p_outs.reshape(-1)}')
                l1_p_outs = self.pitch_predictor(l1_enc_hs, p_masks, condition=pitch_level)
                logger.debug(f'L1_spk_pitch, {l1_p_outs.reshape(-1)}')
                logger.info(f'L1_pitch_norm: {l1_pitch_norm}')
                if l1_pitch_norm == 'mean_var':
                    p_outs = (l1_p_outs - l1_p_outs.mean()) / l1_p_outs.std() * p_outs.std() + p_outs.mean()
                elif l1_pitch_norm == 'mean':
                    p_outs = l1_p_outs - l1_p_outs.mean() + p_outs.mean()
                elif l1_pitch_norm == 'min':
                    p_outs = l1_p_outs - l1_p_outs.min() + p_outs.min()
                elif l1_pitch_norm == 'copy':
                    p_outs = l1_p_outs
                else:
                    raise Exception(f'Unkown norm type: {l1_pitch_norm}, \
                        please set "l1_pitch_norm" to "mean_var", "mean", "min" or "copy".')

            if pitch_std_scale is not None:
                p_outs = (p_outs - p_outs.mean()) * pitch_std_scale + p_outs.mean()
            if pitch_shift is not None:
                p_outs = p_outs + pitch_shift

            if f0_scale_ratio is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                scaled_f0 = scaled_f0 * f0_scale_ratio
                scaled_f0 = (scaled_f0 - self.pitch_mean) / self.pitch_var

                f0_scale_mean = f0_scale_ratio.mean(1)
                p_outs = torch.where(
                    torch.logical_and(
                        torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)
                    ),
                    p_outs,
                    scaled_f0,
                )

            p_embs = self.pitch_embed(p_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, p_embs), dim=-1)
            enc_hs_ps = self.pitch_emb_enc_proj(enc_hs_ps)

        if self.energy_predictor is not None:
            e_outs = self.energy_predictor(enc_hs, None, condition=energy_level)

            if l1_spk_id is not None and use_l1_spk_energy:
                logger.debug(f'energy, {e_outs.reshape(-1)}')
                l1_e_outs = self.energy_predictor(l1_enc_hs, None, condition=energy_level)
                logger.debug(f'L1_spk_energy, {l1_e_outs.reshape(-1)}')
                logger.info(f'L1_energy_norm: {l1_energy_norm}')
                if l1_energy_norm == "mean_var":
                    e_outs = (l1_e_outs - l1_e_outs.mean()) / l1_e_outs.std() * e_outs.std() + e_outs.mean()
                elif l1_energy_norm == "mean":
                    e_outs = l1_e_outs - l1_e_outs.mean() + e_outs.mean()
                elif l1_energy_norm == 'min':
                    e_outs = l1_e_outs - l1_e_outs.min() + e_outs.min()
                elif l1_energy_norm == 'copy':
                    e_outs = l1_e_outs
                else:
                    raise Exception(f'Unkown norm type: {l1_energy_norm}, \
                        please set "L1_energy_norm" to "mean_var", "mean", "min" or "copy".')

            if energy_shift is not None:
                e_outs = e_outs + energy_shift

            e_embs = self.energy_embed(e_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, e_embs), dim=-1)
            enc_hs_ps = self.energy_emb_enc_proj(enc_hs_ps)

        if self.power_predictor is not None:
            power_outs = self.power_predictor(enc_hs, None, condition=None)
            power_embs = self.power_embed(power_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, power_embs), dim=-1)
            enc_hs_ps = self.power_emb_enc_proj(enc_hs_ps)

        if self.tilt_predictor is not None:
            tilt_outs = self.tilt_predictor(enc_hs, None, condition=None)
            tilt_embs = self.tilt_embed(tilt_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, tilt_embs), dim=-1)
            enc_hs_ps = self.tilt_emb_enc_proj(enc_hs_ps)

        if self.use_singing_feature and self.enable_syllabledurforsinging:
            sdembs = self.syllable_duration_embedding(phone_syllable_duration.squeeze(-1).squeeze(-1))
            duration_predictor_input = self.syllable_duration_embedding_proj(
                torch.cat([duration_predictor_input, sdembs], -1)
            )

        if l1_spk_id is not None:
            d_outs = self.duration_predictor.inference(l1_duration_predictor_input, d_masks, condition=spk_rate_level)
        else:
            d_outs = self.duration_predictor.inference(duration_predictor_input, d_masks, condition=spk_rate_level)

        if self.enable_ar_prosody:
            d_outs = self.ar_prosody_predictor.recognize_dur(duration_predictor_input, 0, d_outs)
        elif self.enable_diff_prosody:
            d_outs = d_outs_diffp

        if speaking_rate is not None:
            d_outs = d_outs / speaking_rate
        d_outs = torch.round(d_outs).long()

        if self.enable_retrain_phnpred:
            d_outs = torch.where(enable_adjust_pitch_dur_flag, sd_outs, d_outs)

        if self.enable_dur_check:
            d_outs_aug = d_outs.float()
            d_outs_avg = d_outs_aug.mean()
            d_outs_aug[0][0] = 1.0
            d_outs_aug = torch.round(d_outs_aug).long()
            d_outs = torch.where(torch.less(d_outs_avg, 1e-6), d_outs_aug, d_outs)

        if self.use_singing_feature and is_singing_scale:
            print("predicted duration:")
            print(d_outs)
            print(len(d_outs))
            for batch_idx in range(len(d_outs)):
                scaled_duration = self.singing_duration_scale(
                    d_outs[batch_idx], syllable_boundary[batch_idx], syllable_duration[batch_idx], vowel_seq[batch_idx]
                )
                if scaled_duration.all() is not None:
                    d_outs[batch_idx] = torch.autograd.Variable((scaled_duration)).long()
            print("scaled duration:")
            print(d_outs)

        hs, align_mat = self.length_regulator(enc_hs_ps, d_outs)
        decoder_masks = None if ilens is None else self._source_mask(torch.sum(d_outs, dim=1))

        # frame_pitch prediction
        frame_quantpitch_pred = None
        frame_uv_pred = None
        frame_contpitch_pred_norm = None
        if self.frame_pitch_predictor is not None:
            if self.use_singing_feature:
                note_pitch_embedding = self.note_pitch_embedding(note_pitch)
                note_pitch_embedding_exp, _ = self.length_regulator(note_pitch_embedding, d_outs)
                note_pitch_exp, _ = self.length_regulator(note_pitch.float().unsqueeze(-1), d_outs)
                note_pitch_exp_rt = self.singing_notepitch_revert(note_pitch_exp)
                hs_note_pitch = self.note_pitch_embedding_proj(torch.cat([hs.detach(), note_pitch_embedding_exp], -1))
                frame_pitch_predictor_input = hs_note_pitch
            else:
                frame_pitch_predictor_input = hs.detach()

            frame_pitch_predictor_out, _ = self.frame_pitch_predictor(frame_pitch_predictor_input, decoder_masks)

            if self.enable_dar_prediction:
                if self.export_onnx:
                    frame_quantpitch_pred = self.frame_pitch_predictor_dar.ar_onnx_inference(
                        frame_pitch_predictor_out, enable_hsoftmax=True
                    )
                else:
                    frame_quantpitch_pred = self.frame_pitch_predictor_dar.ar_inference(
                        frame_pitch_predictor_input, frame_pitch_predictor_out, enable_hsoftmax=True
                    )
            else:
                frame_quantpitch_pred = self.quantized_proj(frame_pitch_predictor_out)

            mean_based_matrix = torch.arange(0.0, 255.0).view(-1, 1).to(frame_quantpitch_pred.device)
            f0_unvoiced, f0_voiced = torch.split(frame_quantpitch_pred, [1, 255], dim=-1)
            f0_voiced = f0_voiced / (1.0 - f0_unvoiced + 1e-10)
            f0_voiced = torch.matmul(f0_voiced, mean_based_matrix)
            f0_voiced = self.mu_law_decode(f0_voiced, quantization_channels=255.0)
            f0_voiced = f0_voiced * (800.0 - self.pitch_mean) + self.pitch_mean
            frame_uv_pred = torch.where(f0_unvoiced > 0.5, 0.0, 1.0)
            frame_contpitch_pred_denorm = torch.where(f0_unvoiced > 0.5, torch.zeros_like(f0_voiced), f0_voiced)
            if use_picth_movingaverage:
                picth_ma = frame_contpitch_pred_denorm.float().squeeze(0).squeeze(-1).data.cpu().numpy()
                note_pitch_ma = (note_pitch_exp_rt * frame_uv_pred).float().squeeze(0).squeeze(-1).data.cpu().numpy()
                frame_contpitch_pred_denorm = self.singing_pitch_movingaverage(
                    pitch=picth_ma, note_pitch=note_pitch_ma, window_size=30
                )
                frame_contpitch_pred_denorm = frame_contpitch_pred_denorm.unsqueeze(0).unsqueeze(-1)
                frame_contpitch_pred_denorm = frame_contpitch_pred_denorm.to(frame_uv_pred.device)
            temp_scale = torch.ones(*frame_contpitch_pred_denorm.size()).to(frame_uv_pred.device)
            frame_contpitch_pred_denorm = frame_contpitch_pred_denorm * temp_scale
            frame_contpitch_pred_norm = self.pitch_norm(frame_contpitch_pred_denorm)
            frame_cat_pred = torch.cat((frame_contpitch_pred_norm, frame_uv_pred), dim=-1)
            frame_pitch = self.continuous_lut(frame_cat_pred)
            hs = torch.cat((hs, frame_pitch), dim=-1)
            hs = self.frame_pitch_proj(hs)

        if mode == "inference_encoder":
            return hs, d_outs.int()

        gating_features = None
        sgating_features = None
        if not self.distil.endswith("_decoder") or not self.enable_sdecoder:
            if self.enable_fmoe:
                gating_features = torch.matmul(align_mat, enc_hs_ps)
            zs, _ = self.decoder(hs, decoder_masks, condition=spembs_condition, gating_features=gating_features)
            zs = self.output_layers[-1](zs[-1])
        else:
            shs = self.sdecoder_proj(hs)
            if self.enable_fmoe:
                sgating_features = torch.matmul(align_mat, enc_hs_ps)
                sgating_features = self.sgating_features_proj(sgating_features)
            szs, _ = self.sdecoder(shs, decoder_masks, gating_features=sgating_features)
            zs = self.soutput_layers[-1](szs[-1])

        if dump_new_voice_data:
            return zs, d_outs.int(), p_outs, e_outs  # mels, duration, pitch, engergy
        elif ilens is None:
            if self.frame_pitch_predictor is not None and self.use_singing_feature and dump_pred_uv_pitch:
                return (zs, frame_contpitch_pred_denorm, frame_uv_pred, temp_scale, note_pitch_exp_rt), d_outs.int()
            else:
                return zs, d_outs.int()
        else:
            return zs, d_outs.int(), p_outs

    @torch.no_grad()
    def dumpencoder(
        self,
        phone_id,
        speaker_id=None,
        lang_id=None,
        style_id=None,
        style_scale_ratio=None,
        speaking_rate=1.0,
        f0_scale_ratio=None,
        note_pitch=None,
        note_duration=None,
        syllable_boundary=None,
        syllable_duration=None,
        phone_syllable_duration=None,
        context_phone=None,
        context_seq=None,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
        ilens=None,
    ):
        """Encoding process."""
        d_masks = None if ilens is None else make_pad_mask(ilens).to(phone_id.device)
        p_masks = None if ilens is None else d_masks.unsqueeze(-1)
        encoder_masks = None if ilens is None else self._source_mask(ilens)
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()
        context_feat = None

        if self.enable_context:
            context_phone = self.prenet_phone(context_phone.transpose(1, 2)).transpose(1, 2)
            context_phone = self.prenet_phone_dense(context_phone)
            context_seq = self.prenet_seq_inproj(context_seq)
            context_cur = context_seq[:, int((context_seq.size(1) - 1) / 2), :]
            self.prenet_seq_gru.flatten_parameters()
            _, memory_context = self.prenet_seq_gru(context_seq)
            context_seq = self.prenet_seq_outproj(torch.cat((context_cur, memory_context.squeeze(0)), -1)).unsqueeze(1)
            context_feat = context_phone + context_seq

        if self.enable_encoder_conditional_layernorm and self.enable_cross_lingual:
            if self.use_encoder_spk_condition:
                encoder_condition = self.get_speaker_condition(speaker_id)
            else:
                encoder_condition = self.get_conditional_embedding(lang_id)
            enc_hs, _ = self.encoder(phone_id, encoder_masks, condition=encoder_condition, context_feat=context_feat)
        elif self.use_singing_feature:
            phone_embedding = self.symbol_embedding(phone_id)
            note_pitch_embedding = self.note_pitch_embedding(note_pitch.squeeze(-1).squeeze(-1))
            note_duration_embedding = self.note_duration_embedding(note_duration.squeeze(-1).squeeze(-1))
            xs = phone_embedding + note_pitch_embedding + note_duration_embedding
            enc_hs, _ = self.encoder(xs, encoder_masks, context_feat=context_feat)
        else:
            enc_hs, _ = self.encoder(phone_id, encoder_masks, context_feat=context_feat)
        enc_hs = enc_hs[-1] if self.encoder_hidden_constraint else enc_hs

        pitch_level = None
        energy_level = None
        spk_rate_level = None
        if self.enable_multi_speaker and not self.distil == "full_tiny":
            spembs = self.speaker_embedding(speaker_id.long())
            if self.enable_concat_lut:
                spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
                spembs = spembs.repeat(1, enc_hs.size(1), 1)
                enc_hs = self.speaker_embedding_proj(torch.cat([enc_hs, spembs], -1))
            else:
                spembs = F.normalize(spembs)
                spembs = spembs.repeat(1, enc_hs.size(1), 1)
                enc_hs += spembs

        if self.enable_cross_lingual:
            langs = self.lang_embedding(lang_id.long())
            if self.enable_concat_lut:
                langs = self.emb_act(self.lang_embeddinglinear(langs))
                langs = langs.repeat(1, enc_hs.size(1), 1)
                enc_hs = self.lang_embedding_proj(torch.cat([enc_hs, langs], -1))
            else:
                langs = F.normalize(langs)
                langs = langs.repeat(1, enc_hs.size(1), 1)
                enc_hs += langs

        if self.enable_multi_style and not self.distil == "full_tiny":
            style_embedding = self.style_embedding(style_id.long().unsqueeze(-1))
            if style_scale_ratio is not None:
                style_embedding = style_embedding * style_scale_ratio

            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))
            style_embedding = style_embedding.repeat(1, enc_hs.size(1), 1)
            enc_hs = self.style_embedding_proj(torch.cat([enc_hs, style_embedding], -1))

        enc_hs_ps = enc_hs

        if self.gst_predictor is not None:
            ref_prosody = self.gst_predictor.inference(enc_hs) if ilens is None else self.gst_predictor(enc_hs, ilens)
            ref_prosody = ref_prosody.unsqueeze(1)
            ref_prosody_exp = ref_prosody.repeat(1, enc_hs.size(1), 1)
            enc_hs_ps = torch.cat((enc_hs, ref_prosody_exp), dim=-1)
            enc_hs_ps = self.gst_proj(enc_hs_ps)

        if self.enable_retrain_phnpred:
            senc_hs_ps = enc_hs_ps
            # sduration predictor
            sd_outs = self.sduration_predictor.inference(enc_hs, d_masks)
            if speaking_rate is not None:
                sd_outs = sd_outs / speaking_rate
            sd_outs = torch.round(sd_outs).long()
            sd_embs = self.sduration_embed(sd_outs.unsqueeze(-1).float().transpose(1, 2)).transpose(1, 2)
            senc_hs_ps = torch.cat((senc_hs_ps, sd_embs), dim=-1)
            senc_hs_ps = self.sduration_emb_enc_proj(senc_hs_ps)

            # spitch predictor
            p_outs = self.spitch_predictor(enc_hs, p_masks)
            if f0_scale_ratio is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                scaled_f0 = scaled_f0 * f0_scale_ratio
                scaled_f0 = (scaled_f0 - self.pitch_mean) / self.pitch_var
                f0_scale_mean = f0_scale_ratio.mean(1)
                p_outs = torch.where(
                    torch.logical_and(
                        torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)
                    ),
                    p_outs,
                    scaled_f0,
                )
            p_embs = self.spitch_embed(p_outs.transpose(1, 2)).transpose(1, 2)
            senc_hs_ps = torch.cat((senc_hs_ps, p_embs), dim=-1)
            senc_hs_ps = self.spitch_emb_enc_proj(senc_hs_ps)

            # special handler for retrain phnpred to fix dur/pitch contour adjustment issue
            enable_adjust_pitch_dur_flag = torch.logical_or(
                torch.logical_or(torch.greater(f0_scale_mean, f0_scale_max), torch.less(f0_scale_mean, f0_scale_min)),
                torch.any(torch.ne(speaking_rate, 1.0)),
            )
            enc_hs_ps = torch.where(enable_adjust_pitch_dur_flag, senc_hs_ps, enc_hs_ps)

        ph_emb_predictor_input = enc_hs_ps if self.enable_hierarchical_cond else enc_hs
        if self.phone_emb_predictor is not None:
            if self.enable_ar_phn_pred:
                if self.export_onnx:
                    ph_hs = self.phone_emb_predictor.ar_onnx_inference(ph_emb_predictor_input)
                else:
                    ph_hs = self.phone_emb_predictor.ar_inference(enc_hs, ph_emb_predictor_input)
            else:
                if ilens is None:
                    ph_hs, _ = self.phone_emb_predictor.inference(ph_emb_predictor_input, None)
                else:
                    ph_hs = self.phone_emb_predictor(ph_emb_predictor_input, ilens)

            enc_hs_ps = torch.cat((enc_hs_ps, ph_hs), dim=-1)
            enc_hs_ps = self.ph_emb_enc_proj(enc_hs_ps)

        duration_predictor_input = enc_hs_ps if self.enable_hierarchical_cond else enc_hs
        if self.pitch_predictor is not None:
            p_outs = self.pitch_predictor(enc_hs, p_masks, condition=pitch_level)

            if f0_scale_ratio is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                scaled_f0 = scaled_f0 * f0_scale_ratio
                scaled_f0 = (scaled_f0 - self.pitch_mean) / self.pitch_var

                f0_scale_mean = f0_scale_ratio.mean(1)
                p_outs = torch.where(
                    torch.logical_and(
                        torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)
                    ),
                    p_outs,
                    scaled_f0,
                )

            p_embs = self.pitch_embed(p_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, p_embs), dim=-1)
            enc_hs_ps = self.pitch_emb_enc_proj(enc_hs_ps)

        if self.energy_predictor is not None:
            e_outs = self.energy_predictor(enc_hs, None, condition=energy_level)
            e_embs = self.energy_embed(e_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, e_embs), dim=-1)
            enc_hs_ps = self.energy_emb_enc_proj(enc_hs_ps)

        if self.use_singing_feature and self.enable_syllabledurforsinging:
            sdembs = self.syllable_duration_embedding(phone_syllable_duration.squeeze(-1).squeeze(-1))
            duration_predictor_input = self.syllable_duration_embedding_proj(
                torch.cat([duration_predictor_input, sdembs], -1)
            )

        d_outs = self.duration_predictor.inference(duration_predictor_input, d_masks, condition=spk_rate_level)
        if speaking_rate is not None:
            d_outs = d_outs / speaking_rate
        d_outs = torch.round(d_outs).long()

        if self.enable_retrain_phnpred:
            d_outs = torch.where(enable_adjust_pitch_dur_flag, sd_outs, d_outs)

        if self.enable_dur_check:
            d_outs_aug = d_outs.float()
            d_outs_avg = d_outs_aug.mean()
            d_outs_aug[0][0] = 1.0
            d_outs_aug = torch.round(d_outs_aug).long()
            d_outs = torch.where(torch.less(d_outs_avg, 1e-6), d_outs_aug, d_outs)

        return enc_hs_ps, d_outs.int()

    @torch.no_grad()
    def dumpdecoder(self, enc_hs_ps, d_outs, ilens=None, spembs_condition=None):
        """Decoding process."""
        hs, _ = self.length_regulator(enc_hs_ps, d_outs)

        decoder_masks = None if ilens is None else self._source_mask(torch.sum(d_outs, dim=1))

        if not self.distil.endswith("_decoder") or not self.enable_sdecoder:
            zs, _ = self.decoder(hs, decoder_masks, condition=spembs_condition)
            zs = self.output_layers[-1](zs[-1])
        else:
            shs = self.sdecoder_proj(hs)
            szs, _ = self.sdecoder(shs, decoder_masks)
            zs = self.soutput_layers[-1](szs[-1])

        return zs

    @torch.no_grad()
    def inference_style_transfer(
        self,
        phone_id,
        speaker_id=None,
        lang_id=None,
        style_id=None,
        style_scale_ratio=None,
        speaking_rate=1.0,
        f0_scale_ratio=None,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
        pitch_dist=None,
        global_zero_cross_rate=None,
        global_energy=None,
        spembsinput=None,
        global_f0=None,
        gst=None,
        mode=None,
        ilens=None,
        finegrainedinput=None,
        preselected_voices_embedding=None,
        pitch_thresholds=None,
    ):
        """Decoding process."""
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()

        d_masks = None if ilens is None else make_pad_mask(ilens).to(phone_id.device)
        p_masks = None if ilens is None else d_masks.unsqueeze(-1)
        encoder_masks = None if ilens is None else self._source_mask(ilens)

        if self.phone_level_localeid:
            lang_id_cond_native = torch.ones(1, phone_id.shape[1], dtype=torch.int) * lang_id[0].int()
            lang_id_cond_enus = torch.ones(1, phone_id.shape[1], dtype=torch.int) * self.enus_loc_id
            lang_id_cond = torch.where(
                sum(phone_id == i for i in self.enus_phone).bool(), lang_id_cond_enus, lang_id_cond_native
            )

        # tune speaking rate
        if self.speaking_rate_tuning:
            assert speaking_rate is not None
            for tuning_style_id, tuning_ratio in self.speaking_rate_tuning.items():
                speaking_rate *= torch.where(torch.eq(style_id, tuning_style_id), tuning_ratio, 1.0)

        # tune f0
        # tunning through self.f0_scale_tuning and and self.f0_auto_scale can work individually or simutaneously
        # where the f0_auto_scale is automaticaly computed which works like k_auto_scale * f0_original + b_auto_scale
        # and the f0_scale_tuning works like f0_scale_tuning * f0_original
        # When they both have values, then final tuned f0 is
        # f0_scale_tuning * (k_auto_scale * f0_original + b_auto_scale)
        if self.f0_scale_tuning:
            assert f0_scale_ratio is not None
            for tuning_style_id, tuning_ratio in self.f0_scale_tuning.items():
                f0_scale_ratio *= torch.where(torch.eq(style_id, tuning_style_id), tuning_ratio, 1.0)
        if self.f0_auto_scale:
            assert f0_scale_ratio is not None
            f0_offset = torch.zeros_like(f0_scale_ratio)
            for scale_style_id, scale_param in self.f0_auto_scale.items():
                f0_offset += f0_scale_ratio * torch.where(torch.eq(style_id, scale_style_id), scale_param[1], 0.0)
                f0_scale_ratio *= torch.where(torch.eq(style_id, scale_style_id), scale_param[0], 1.0)

        # text encoder
        if self.enable_encoder_conditional_layernorm and self.enable_cross_lingual:
            if self.use_encoder_spk_condition:
                encoder_condition = self.get_speaker_condition(speaker_id)
            elif not self.phone_level_localeid:
                encoder_condition = self.get_conditional_embedding(lang_id)
            else:
                encoder_condition = self.get_conditional_embedding(lang_id_cond)

            enc_hs, unused = self.encoder(phone_id, encoder_masks, encoder_condition)
        else:
            enc_hs, unused = self.encoder(phone_id, encoder_masks)

        if self.enable_zeroshot_finegrained:
            encoder_hidden_only_text = enc_hs

        if self.encoder_hidden_constraint:
            encoder_hidden_tuple = enc_hs
            enc_hs = enc_hs[-1]
            if self.dmodel != self.teacher_dmodel:
                encoder_hidden_tuple = [
                    self.enc_constraint_proj_layers[i](ehc) for i, ehc in enumerate(encoder_hidden_tuple)
                ]

        if self.att_constraint:
            encoder_hidden_tuple = (encoder_hidden_tuple, unused) if encoder_hidden_tuple != () else (unused,)

        spembs_condition = None
        if self.enable_multi_speaker:
            if self.speaker_embedding is not None:
                spembs = self.speaker_embedding(speaker_id.long())

                if len(spembs.size()) == 2:
                    spembs = spembs.unsqueeze(1)

            if self.enable_zeroshot:
                spembs = spembsinput / torch.norm(spembsinput, dim=1, keepdim=True)
            spembstarget = spembs
            spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
            spembs_condition = spembs

            spembs = spembs.repeat(1, enc_hs.size(1), 1)
            enc_hsraw = enc_hs
            enc_hs = self.speaker_embedding_proj(torch.cat([enc_hs, spembs], -1))

            spembssrclist = []
            for source_speaker_id in self.transfer_style_mapping.values():
                spembssrc = self.speaker_embedding(
                    torch.tensor([source_speaker_id], dtype=torch.int32).long().to(phone_id.device)
                )
                spembssrclist.append(spembssrc)

            if self.enable_multi_style:
                style_id_exp = style_id.unsqueeze(-1).unsqueeze(-1)
                style_id_exp = style_id_exp.expand(-1, -1, spembstarget.size(-1))

            if pitch_dist is None:
                # If transfer id, then spembssrc is source speaker of corresponding transfer style
                spembssrc = spembstarget
                for transfer_style_id, source_speaker_emb in zip(self.transfer_style_mapping, spembssrclist):
                    spembssrc = torch.where(
                        torch.eq(style_id_exp, torch.tensor(transfer_style_id, dtype=torch.int32)),
                        source_speaker_emb,
                        spembssrc,
                    )
            else:
                source_pitch_mean, source_pitch_var = pitch_dist[0]
                target_pitch_mean, target_pitch_var = pitch_dist[1]

            if self.enable_zeroshot_prosody_selection:
                global_f0_target = global_f0
                spembssrc, global_f0 = zero_shot_tts.select_voice_by_pitch(preselected_voices_embedding, global_f0, pitch_thresholds)

            spembssrc = self.emb_act(self.speaker_embeddinglinear(spembssrc))
            spembssrc = spembssrc.repeat(1, enc_hs.size(1), 1)
            enc_hssrc = self.speaker_embedding_proj(torch.cat([enc_hsraw, spembssrc], -1))

        if self.enable_cross_lingual:
            langs = self.lang_embedding(lang_id.long())

            if len(langs.size()) == 2:
                langs = langs.unsqueeze(1)

            if self.enable_concat_lut:
                langs = self.emb_act(self.lang_embeddinglinear(langs))
                langs = langs.repeat(1, enc_hs.size(1), 1)
                enc_hs = self.lang_embedding_proj(torch.cat([enc_hs, langs], -1))
                enc_hssrc = self.lang_embedding_proj(torch.cat([enc_hssrc, langs], -1))
            else:
                langs = F.normalize(langs)
                langs = langs.repeat(1, enc_hs.size(1), 1)
                enc_hs += langs
                enc_hssrc += langs

        if self.enable_multi_style:
            style_embedding = self.style_embedding(style_id.long().unsqueeze(-1))
            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))

            style_embedding_general = self.style_embedding(
                torch.tensor([0], dtype=torch.int32).long().to(phone_id.device)
            )
            style_embedding_general = style_embedding_general.unsqueeze(1)
            style_embedding_general = self.emb_act(self.style_embeddinglinear(style_embedding_general))

            if style_scale_ratio is not None:
                style_embedding = style_embedding * style_scale_ratio
                style_embedding_general = style_embedding_general * style_scale_ratio

            # If transfer id, then style_embedding_target is general style to keep timbre
            # when the source speaker have only one style
            style_embedding_target = style_embedding
            for transfer_style_id, source_speaker_id in self.transfer_style_mapping.items():
                if list(self.transfer_style_mapping.values()).count(source_speaker_id) == 1:
                    style_embedding_target = torch.where(
                        torch.eq(style_id_exp, torch.tensor(transfer_style_id, dtype=torch.int32)),
                        style_embedding_general,
                        style_embedding_target,
                    )

            enc_hs = torch.cat([enc_hs, style_embedding_target.expand(-1, enc_hs.size(1), -1)], dim=-1)
            enc_hs = self.style_embedding_proj(enc_hs)

            enc_hssrc = torch.cat([enc_hssrc, style_embedding.expand(-1, enc_hs.size(1), -1)], dim=-1)
            enc_hssrc = self.style_embedding_proj(enc_hssrc)

        enc_hs_ps = enc_hs
        enc_hs_pssrc = enc_hssrc
        if self.gst_predictor is not None:
            ref_prosody = self.gst_predictor.inference(enc_hssrc)
            ref_prosody = ref_prosody.unsqueeze(1)
            if self.enable_zeroshot and not self.enable_zeroshot_finegrained:
                ref_prosody = gst.unsqueeze(1)
            ref_prosody_exp = ref_prosody.repeat(1, enc_hs.size(1), 1)
            enc_hs_ps = torch.cat((enc_hs, ref_prosody_exp), dim=-1)
            enc_hs_ps = self.gst_proj(enc_hs_ps)
            enc_hs_pssrc = torch.cat((enc_hssrc, ref_prosody_exp), dim=-1)
            enc_hs_pssrc = self.gst_proj(enc_hs_pssrc)

        style_vae_embedding = None
        if self.enable_style_vae:
            style_onehot_gen = F.one_hot(
                torch.tensor([0], dtype=torch.int32).long(), num_classes=self.style_embedding_size
            ).float()
            if len(style_id.size()) == 2:
                style_id = style_id.squeeze(-1)
            style_onehot_src = F.one_hot(style_id.long(), num_classes=self.style_embedding_size).float()

            if self.enable_style_vae_withspk:
                if len(speaker_id.size()) == 2:
                    speaker_id = speaker_id.squeeze(-1)
                spk_onehot = F.one_hot(speaker_id.long(), num_classes=self.spk_size).float()

                pz_mu_src_list = []
                for source_speaker_id in self.transfer_style_mapping.items()[1]:
                    spk_onehot_src = F.one_hot(
                        torch.tensor([source_speaker_id], dtype=torch.int32).long(), num_classes=self.spk_size
                    ).float()
                    src_cat = torch.cat((style_onehot_src, spk_onehot_src), dim=-1)
                    sample_pz_src, pz_mu_src, pz_log_sigma2_src = self.style_gmvaeLabeled.pz_graph(src_cat)
                    pz_mu_src_list.append(pz_mu_src)
                one_hot_cat = torch.cat((style_onehot_gen, spk_onehot), dim=-1)
                sample_pz_gen, pz_mu_gen, pz_log_sigma2_gen = self.style_gmvaeLabeled.pz_graph(one_hot_cat)
                sample_pz, pz_mu, pz_log_sigma2 = self.style_gmvaeLabeled.pz_graph(
                    torch.cat((style_onehot_src, spk_onehot), dim=-1)
                )
                # If transfer id, then style_embedding_target is general style to keep timbre
                idx = 0
                style_vae_embedding = pz_mu
                style_vae_embedding_src = style_vae_embedding
                style_id_exp_vae = style_id.unsqueeze(-1)
                style_id_exp_vae = style_id_exp_vae.expand(-1, style_vae_embedding.size(-1))
                for transfer_style_id in self.transfer_style_mapping.items()[0]:
                    style_vae_embedding = torch.where(
                        torch.eq(style_id_exp_vae, torch.tensor(transfer_style_id, dtype=torch.int32)),
                        pz_mu_gen,
                        style_vae_embedding,
                    )
                    style_vae_embedding_src = torch.where(
                        torch.eq(style_id_exp_vae, torch.tensor(transfer_style_id, dtype=torch.int32)),
                        pz_mu_src_list[idx],
                        style_vae_embedding_src,
                    )
                    idx += 1
                style_vae_embedding = style_vae_embedding.unsqueeze(1).repeat(1, enc_hs.size(1), 1)
                style_vae_embedding_src = style_vae_embedding_src.unsqueeze(1).repeat(1, enc_hs.size(1), 1)
                enc_hs_ps = torch.cat((enc_hs_ps, style_vae_embedding), dim=-1)
                enc_hs_ps = self.style_vae_proj(enc_hs_ps)
                enc_hs_pssrc = torch.cat((enc_hs_pssrc, style_vae_embedding_src), dim=-1)
                enc_hs_pssrc = self.style_vae_proj(enc_hs_pssrc)
            else:
                sample_pz_gen, pz_mu_gen, pz_log_sigma2_gen = self.style_gmvaeLabeled.pz_graph(style_onehot_gen)
                sample_pz_src, pz_mu_src, pz_log_sigma2_src = self.style_gmvaeLabeled.pz_graph(style_onehot_src)
                # If transfer id, then style_embedding_target is general style to keep timbre
                style_vae_embedding = pz_mu_src
                style_id_exp_vae = style_id.unsqueeze(-1)
                style_id_exp_vae = style_id_exp_vae.expand(-1, style_vae_embedding.size(-1))
                for transfer_style_id in self.transfer_style_mapping.items()[0]:
                    style_vae_embedding = torch.where(
                        torch.eq(style_id_exp_vae, torch.tensor(transfer_style_id, dtype=torch.int32)),
                        pz_mu_gen,
                        style_vae_embedding,
                    )
                style_vae_embedding = style_vae_embedding.unsqueeze(1).repeat(1, enc_hs.size(1), 1)
                pz_mu_src = pz_mu_src.unsqueeze(1).repeat(1, enc_hs.size(1), 1)
                enc_hs_ps = torch.cat((enc_hs_ps, style_vae_embedding), dim=-1)
                enc_hs_ps = self.style_vae_proj(enc_hs_ps)
                enc_hs_pssrc = torch.cat((enc_hs_pssrc, pz_mu_src), dim=-1)
                enc_hs_pssrc = self.style_vae_proj(enc_hs_pssrc)

        duration_predictor_input = enc_hs_pssrc if self.enable_hierarchical_cond else enc_hs
        if self.pitch_predictor is not None:
            p_outs = self.pitch_predictor(enc_hssrc, p_masks, global_f0)
            if self.enable_zeroshot_prosody_selection:
                p_outs_target = self.pitch_predictor(enc_hs, p_masks, global_f0_target)
                p_outs = zero_shot_tts.transfer_pitch(p_outs_target, p_outs, self.pitch_mean, self.pitch_var)
            if pitch_dist is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                source_speaker_id = torch.tensor(list(self.transfer_style_mapping.values())[0], dtype=torch.int32)
                target_mean = torch.where(torch.eq(speaker_id, source_speaker_id), source_pitch_mean, target_pitch_mean)
                target_var = torch.where(torch.eq(speaker_id, source_speaker_id), source_pitch_var, target_pitch_var)
                scaled_f0 = ((scaled_f0 - source_pitch_mean) / source_pitch_var) * target_var + target_mean
                p_outs = (scaled_f0 - self.pitch_mean) / self.pitch_var

            if f0_scale_ratio is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                if self.f0_auto_scale:
                    f0_scale_mean = (f0_scale_ratio + f0_offset / scaled_f0).mean(1)
                    scaled_f0 = scaled_f0 * f0_scale_ratio + f0_offset
                else:
                    f0_scale_mean = f0_scale_ratio.mean(1)
                    scaled_f0 = scaled_f0 * f0_scale_ratio
                scaled_f0 = (scaled_f0 - self.pitch_mean) / self.pitch_var

                p_outs = torch.where(
                    torch.logical_and(
                        torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)
                    ),
                    p_outs,
                    scaled_f0,
                )

            p_embs = self.pitch_embed(p_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, p_embs), dim=-1)
            enc_hs_ps = self.pitch_emb_enc_proj(enc_hs_ps)

        if self.energy_predictor is not None:
            e_outs = self.energy_predictor(enc_hssrc, p_masks, global_energy)
            if self.energy_auto_scale:
                for scale_style_id, scale_param in self.energy_auto_scale.items():
                    e_outs += torch.where(torch.eq(style_id, scale_style_id), scale_param, 0.0)

            e_embs = self.energy_embed(e_outs.transpose(1, 2)).transpose(1, 2)
            enc_hs_ps = torch.cat((enc_hs_ps, e_embs), dim=-1)
            enc_hs_ps = self.energy_emb_enc_proj(enc_hs_ps)

        d_pre = self.duration_predictor(duration_predictor_input, d_masks, global_cross_rate=global_zero_cross_rate)
        d_outs = self.duration_predictor.inference(duration_predictor_input, d_masks, global_cross_rate=global_zero_cross_rate)
        if speaking_rate is not None:
            d_outs = d_outs / speaking_rate
        d_outs = torch.round(d_outs).long()

        decoder_masks = None if ilens is None else self._source_mask(torch.sum(d_outs, dim=1))

        if self.enable_zeroshot_finegrained:
            enc_hs_ps = enc_hs_ps + self.zeroshot_finegrained.calculate_finegrained_output_inference(encoder_hidden_only_text, finegrainedinput)
        hs, align_mat = self.length_regulator(enc_hs_ps, d_outs)

        gating_features = None
        sgating_features = None
        if not self.distil.endswith("_decoder") or not self.enable_sdecoder:
            if self.enable_fmoe:
                gating_features = torch.matmul(align_mat, enc_hs_ps)
            zs, _ = self.decoder(hs, decoder_masks, spembs_condition, gating_features=gating_features)
            if self.enable_zeroshot_autoregressive:
                outputs = [self.output_layers[i](zs[i]) for i in range(self.dec_layers - 1)]
                zs = self.zeroshot_autoregressive.apply_autoregressive_inference(zs[-1], self.output_layers[-1])
                outputs.append(zs)
            else:
                outputs = [self.output_layers[i](zs[i]) for i in range(self.dec_layers)]
                zs = self.output_layers[-1](zs[-1])

            if self.att_constraint:
                encoder_hidden_tuple += (unused,)
        else:
            shs = self.sdecoder_proj(hs)
            if self.enable_fmoe:
                sgating_features = torch.matmul(align_mat, enc_hs_ps)
                sgating_features = self.sgating_features_proj(sgating_features)
            szs, _ = self.sdecoder(shs, decoder_masks, gating_features=sgating_features)
            szs = self.soutput_layers[-1](szs[-1])
            return szs, d_outs.int()

        if mode == "infer":
            ref_prosody = ref_prosody.squeeze(1)
            pred_prosody = ref_prosody
            es = e_outs
            retvalue = (
                outputs,
                d_pre,
                pred_prosody,
                ref_prosody,
                p_outs,
                p_outs,
                None,
                None,
                None,
                es,
                e_outs,
                None,
                d_outs,
                encoder_hidden_tuple,
            )
            return retvalue

        return zs, d_outs.int()

    @torch.no_grad()
    def inference_emotion_encoder(self, input_mel):

        emt_utt_emb = self.emotion_encoder(input_mel)
        emt_logits = self.emt_logits(emt_utt_emb)

        emt_latent = F.gumbel_softmax(emt_logits, tau=1.34, hard=True)
        emt_pre_labels = torch.sum(torch.mul(emt_latent,
                                             torch.range(0, self.style_embedding_size - 1).to(
                                                 emt_logits.device).unsqueeze(0).repeat(
                                                 emt_latent.size(0), 1)), dim=-1).long()

        emt_intensity = torch.sum(torch.mul(emt_latent, torch.pow(self.exponent_alpha, emt_logits)), dim=-1) / \
            torch.sum(torch.pow(self.exponent_alpha, emt_logits), dim=-1)

        return emt_pre_labels, emt_intensity, emt_logits

    def inference_zeroshot_finegrained(self, refmel=None):
        """Decoding process.
        """
        refmel = refmel.reshape(1, -1, 80)
        style_idraw = 0
        style_id = torch.tensor([style_idraw])
        style_embedding = self.style_embedding(style_id.long()).unsqueeze(1)
        style_embedding = F.softsign(self.style_embeddinglinear(style_embedding))
        ref_prosody = self.gst(refmel)
        if not self.enable_zeroshot_finegrained:
            ref_prosodyf0 = torch.cat([ref_prosody, style_embedding.repeat(1, ref_prosody.size(1), 1)], -1)
        else:
            ref_prosodyf0 = ref_prosody
        gstf0 = self.gst_projmeanf0(ref_prosodyf0)
        finegrainedinput = self.zeroshot_finegrained.calculate_finegrained_input_inference(refmel)
        return ref_prosody, gstf0, finegrainedinput

    def _source_mask(self, ilens):
        x_masks = make_non_pad_mask(ilens).to(next(self.parameters()).device)
        return x_masks.unsqueeze(-2) & x_masks.unsqueeze(-1)

    def _source_to_target_mask(self, ilens, olens):
        x_masks = make_non_pad_mask(ilens).to(next(self.parameters()).device)
        y_masks = make_non_pad_mask(olens).to(next(self.parameters()).device)
        return x_masks.unsqueeze(-2) & y_masks.unsqueeze(-1)

    def get_conditional_embedding(self, lang_id):
        langs = self.lang_embedding(lang_id)
        if len(langs.size()) == 2:
            langs = langs.unsqueeze(1)
        if self.enable_concat_lut:
            langs = self.emb_act(self.lang_embeddinglinear(langs))
        else:
            langs = F.normalize(langs)

        return langs

    def singing_duration_scale(self, predicted_duration, syllable_boundry, syllable_duration, is_vowel):
        if len(predicted_duration) != len(syllable_boundry):
            return predicted_duration
        if torch.sum(syllable_boundry) != len(syllable_duration):
            print(torch.sum(syllable_boundry))
            print(len(syllable_duration))
            return predicted_duration

        scaled_duration = []
        for phone_id in range(len(predicted_duration)):
            scaled_duration.append(predicted_duration[phone_id])
        first_phone_of_syllable_idx = 0
        syllable_idx = 0
        for phone_idx in range(len(predicted_duration)):
            if syllable_boundry[phone_idx] == 1:
                pred_syl_dur = 0
                for i in range(first_phone_of_syllable_idx, phone_idx + 1):
                    pred_syl_dur = pred_syl_dur + predicted_duration[i]

                is_scaled = 0
                if pred_syl_dur == 0 or syllable_duration[syllable_idx] == 0:
                    print("warning: duration scale failed!\n")
                    return predicted_duration
                if syllable_duration[syllable_idx] > pred_syl_dur:
                    for i in range(phone_idx, first_phone_of_syllable_idx - 1, -1):
                        if is_vowel[i] == 1:
                            scaled_duration[i] += syllable_duration[syllable_idx] - pred_syl_dur
                            is_scaled = 1
                            break

                if syllable_duration[syllable_idx] < pred_syl_dur or is_scaled == 0:
                    scale_ratio = syllable_duration[syllable_idx] / float(pred_syl_dur)
                    scaled_duration_total = 0
                    for i in range(first_phone_of_syllable_idx, phone_idx + 1):
                        scaled_duration[i] = torch.round(predicted_duration[i] * scale_ratio)
                        scaled_duration_total = scaled_duration_total + scaled_duration[i]

                    while scaled_duration_total != syllable_duration[syllable_idx]:
                        idx_maxdur = first_phone_of_syllable_idx
                        for i in range(first_phone_of_syllable_idx, phone_idx + 1):
                            if scaled_duration[i] > scaled_duration[idx_maxdur]:
                                idx_maxdur = i
                        ori_duration = scaled_duration[idx_maxdur]
                        x = scaled_duration[idx_maxdur] + syllable_duration[syllable_idx] - scaled_duration_total
                        scaled_duration[idx_maxdur] = max(0, x)
                        scaled_duration_total = scaled_duration_total + scaled_duration[idx_maxdur] - ori_duration

                syllable_idx = syllable_idx + 1
                first_phone_of_syllable_idx = phone_idx + 1

        return torch.from_numpy(np.array(scaled_duration, dtype=np.int64))

    def singing_notepitch_revert(self, note_pitch):
        a4 = 440
        c0 = a4 * pow(2, -4.75)
        note_pitch_revert = torch.pow(2, (note_pitch - 12.0) / 12.0) * c0

        return note_pitch_revert

    def singing_pitch_movingaverage(self, pitch, note_pitch, window_size=30):
        post_pitch = []
        cnt = [0 for i in range(window_size)]
        window = [0 for i in range(window_size)]
        assert len(pitch) == len(note_pitch)
        for i in range(len(note_pitch)):
            if note_pitch[i] == 0:
                post_pitch.append(0)
                window = [0 for i in range(window_size)]
                cnt = [0 for i in range(window_size)]
                continue
            else:
                if note_pitch[i] != note_pitch[i - 1]:
                    window = [0 for i in range(window_size)]
                    cnt = [0 for i in range(window_size)]
                window.append(pitch[i])
                cnt.append(1)
                window = window[-window_size:]
                cnt = cnt[-window_size:]
                average_value = sum(window) / sum(cnt)
                delta = 0 if abs(pitch[i] - average_value) >= window_size else (pitch[i] - average_value)
                post_pitch.append(delta + note_pitch[i])
        post_pitch = np.array(post_pitch, dtype=np.float64)

        return torch.from_numpy(post_pitch).float()

    def mu_law_decode(self, output, quantization_channels, shifted=True):
        """Recovers waveform from quantized values."""
        mu = quantization_channels - 1.0
        # Map values back to [-1, 1].
        if shifted:
            signal = 2 * (output / mu) - 1
        else:
            signal = output / mu
        # Perform inverse of mu-law transformation.
        magnitude = (1 / mu) * ((1 + mu) ** torch.abs(signal) - 1)  # inverse equation of mu_law_encode
        return torch.sign(signal) * magnitude

    def pitch_denorm(self, pitch_norm):
        pitch = pitch_norm * self.pitch_var + self.pitch_mean

        return pitch

    def pitch_norm(self, pitch):
        pitch_norm = (pitch - self.pitch_mean) / self.pitch_var

        return pitch_norm

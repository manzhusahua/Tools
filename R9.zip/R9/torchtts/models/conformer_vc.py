"""Conformer TTS."""

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F

from torchtts.nn.modules.conformer.duration_predictor import DurationPredictor
from torchtts.nn.modules.common import LengthRegulator, LayerNorm
from torchtts.nn.modules.common.functional import make_non_pad_mask
from torchtts.nn.modules.conformer.encoder import Encoder as ConformerEncoder
from torchtts.nn.modules.conformer.initializer import initialize
from torchtts.nn.modules.conformer.repeat import repeat
from torchtts.nn.modules.fastspeech import PitchEmbedding
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.modules.style_encoders.acoustic_residual_predictor import GlobalStyleToken
from torchtts.nn.modules.style_encoders.acoustic_residual_predictor import TextPredictedProsody
from torchtts.nn.modules.transformer import RelPositionalEncoding
from torchtts.nn.modules.attention.rel_attention import MultiHeadedAttention
from torchtts.nn.modules.style_encoders.acoustic_residual_predictor import PhoneProsodyPredictor
from torchtts.nn.modules.conformer.variance_predictor import PitchPredictor
logger = logging.getLogger(__name__)


class ConformerVC(torch.nn.Module):
    """Text-to-Speech Conformer module.

    This is a module of text-to-speech Conformer model motivated by
    TransformerTTS, FastSpeech, Conformer.

    """
    def __init__(
        self,
        symbol_size=256,
        spk_size=128,
        dmodel=384,
        odim=80,
        positionwise_conv_kernel_size=3,
        enc_layers=6,
        enc_num_heads=4,
        enc_ffn_dim=1536,
        dec_layers=6,
        dec_num_heads=4,
        dec_ffn_dim=1536,
        cnn_module_kernel=7,
        dropout_rate=0.1,
        enable_multi_speaker=False,
        macaron_style=False,
        enable_cross_lingual=False,
        lang_size=128,
        padding_idx=0,
        enable_multi_style=False,
        style_embedding_size=16,
        enable_concat_lut=False,
        export_onnx=False,
        embedding_activation="softplus",
        enable_moe=False,
        num_moe_experts=16,
        normalize_before=False,
        distil="",
        enable_conditional_layernorm=False,
        enable_decoder_conditional_layernorm=False,
        decoder_normalize_before=False,
        ffn_layer_type="conv1d",
        encoder_hidden_constraint=False,
        att_constraint=False,
        pred_odim=80,
        moe_capacity_factor=1.2,
        enable_singing_vc=False,
        enable_power=False,
        enable_tilt=False,
        singing_vc_f0_embed_dim=64,
        singing_vc_uv_embed_dim=32,
        enable_fmoe=False,
        fmoe_num_expert=64,
        fmoe_hidden_dim=1024,
        fmoe_top_k=2,
        predict_mel=False,
        predict_mel_layer=0,
        dec_use_highwayrnn=False,
        dec_rnn_bidirectional=False,
        dec_rnn_reduce=1,
        dec_hidden_dim=384,
        dec_ffn_groups_batch_size=8,
        style_dim=16,
        gru_layer_num=2,
    ):
        super(ConformerVC, self).__init__()

        self.dec_layers = dec_layers

        self.enable_multi_speaker = enable_multi_speaker
        self.enable_cross_lingual = enable_cross_lingual
        self.enable_multi_style = enable_multi_style
        self.dmodel = dmodel
        self.enable_moe = enable_moe
        self.enable_conditional_layernorm = enable_conditional_layernorm
        self.enable_decoder_conditional_layernorm = enable_decoder_conditional_layernorm
        self.enable_fmoe = enable_fmoe
        self.enc_num_heads = enc_num_heads
        self.style_embedding_size = style_embedding_size
        self.spk_size = spk_size
        self.predict_mel = predict_mel
        self.predict_mel_layer = predict_mel_layer
        self.dec_use_highwayrnn = dec_use_highwayrnn

        self.distil = distil.strip()
        self.ffn_layer_type = ffn_layer_type
        assert self.distil in ["", "online_decoder", "offline_decoder", "full", "full_tiny"]
        self.encoder_hidden_constraint = encoder_hidden_constraint
        self.att_constraint = att_constraint

        self.enable_power = enable_power
        self.enable_tilt = enable_tilt

        if enable_singing_vc:
            self.pitch_embedding = PitchEmbedding(f0_emb_dim=singing_vc_f0_embed_dim,
                                                  uv_emb_dim=singing_vc_uv_embed_dim)
            self.pitch_fuse_layer = nn.Linear(dmodel + singing_vc_f0_embed_dim + singing_vc_uv_embed_dim, dmodel)
            if self.enable_power or self.enable_tilt:
                self.singing_vc_fea_embedding = nn.Sequential(
                    nn.Conv1d(1, 64, 9,
                              padding=4),
                    nn.ReLU())
                self.singing_vc_fea_fuse_layer = nn.Linear(dmodel + 64, dmodel)

        self.enable_concat_lut = enable_concat_lut

        self.symbol_embedding = torch.nn.Embedding(num_embeddings=symbol_size, embedding_dim=dmodel,
                                                   padding_idx=padding_idx)

        self.speaker_embedding = None
        if enable_multi_speaker:
            self.speaker_embedding = torch.nn.Embedding(
                num_embeddings=spk_size, embedding_dim=dmodel, padding_idx=padding_idx
            )
            if self.enable_concat_lut:
                self.speaker_embeddinglinear = torch.nn.Linear(dmodel, dmodel)
                self.speaker_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        self.lang_embedding = None
        if enable_cross_lingual:
            self.lang_embedding = torch.nn.Embedding(
                num_embeddings=lang_size, embedding_dim=dmodel, padding_idx=padding_idx
            )
            if self.enable_concat_lut:
                self.lang_embeddinglinear = torch.nn.Linear(dmodel, dmodel)
                self.lang_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        self.style_embedding = None
        if enable_multi_style:
            self.style_embedding = torch.nn.Embedding(
                num_embeddings=style_embedding_size, embedding_dim=dmodel, padding_idx=padding_idx
            )
            if self.enable_concat_lut:
                self.style_embeddinglinear = torch.nn.Linear(dmodel, dmodel)
                self.style_embedding_proj = torch.nn.Linear(dmodel + dmodel, dmodel)

        if embedding_activation == "softplus":
            self.emb_act = nn.Softplus()
        elif embedding_activation == "softsign":
            self.emb_act = nn.Softsign()

        self.encoder = ConformerEncoder(
            idim=dmodel,
            attention_dim=dmodel,
            attention_heads=enc_num_heads,
            linear_units=enc_ffn_dim,
            num_blocks=enc_layers,
            input_layer=self.symbol_embedding,
            normalize_before=normalize_before,
            dropout_rate=dropout_rate,
            positional_dropout_rate=dropout_rate,
            attention_dropout_rate=dropout_rate,
            positionwise_conv_kernel_size=positionwise_conv_kernel_size,
            macaron_style=macaron_style,
            cnn_module_kernel=cnn_module_kernel,
            use_singing_feature=False,
            enable_moe=enable_moe,
            export_onnx=export_onnx,
            enable_conditional_layernorm=enable_conditional_layernorm,
            condition_dim=dmodel,
            n_experts=num_moe_experts,
            output_all=True if self.encoder_hidden_constraint else False,
            return_att=self.att_constraint,
            moe_capacity_factor=moe_capacity_factor,
        )

        self.length_regulator = LengthRegulator()

        self.decoder = ConformerEncoder(
            attention_dim=dmodel,
            attention_heads=dec_num_heads,
            linear_units=dec_ffn_dim,
            num_blocks=dec_layers,
            input_layer=None,
            normalize_before=decoder_normalize_before,
            dropout_rate=dropout_rate,
            positional_dropout_rate=dropout_rate,
            attention_dropout_rate=dropout_rate,
            positionwise_conv_kernel_size=positionwise_conv_kernel_size,
            macaron_style=macaron_style,
            cnn_module_kernel=cnn_module_kernel,
            output_all=True,
            enable_conditional_layernorm=enable_decoder_conditional_layernorm,
            condition_dim=dmodel,
            return_att=self.att_constraint,
            enable_fmoe=enable_fmoe,
            fmoe_num_expert=fmoe_num_expert,
            fmoe_hidden_dim=fmoe_hidden_dim,
            fmoe_top_k=fmoe_top_k,
            predict_mel=predict_mel,
            predict_mel_layer=predict_mel_layer,
            use_highway_rnn=dec_use_highwayrnn,
            rnn_reduce=dec_rnn_reduce,
            rnn_bidirectional=dec_rnn_bidirectional,
            hidden_dim=dec_hidden_dim,
            ffn_groups_batch_size=dec_ffn_groups_batch_size
        )

        self.output_layers = repeat(
            dec_layers,
            lambda lnum: torch.nn.Linear(dmodel, pred_odim),
        )

        self.export_onnx = export_onnx

        self._reset_parameters("pytorch")
        self.duration_predictor = DurationPredictor(
            idim=dmodel,
            n_layers=2,
            n_chans=256,
            kernel_size=3,
            dropout_rate=0.1,
        )

        self.gst = GlobalStyleToken(dmodel, mel_dim=odim)
        self.gst_proj = torch.nn.Linear(dmodel + style_dim, dmodel, bias=False)
        self.gst_predictor = TextPredictedProsody(dmodel, style_dim)

        self.pos_emb = RelPositionalEncoding(dmodel, dropout_rate=0.1)
        spec_enc_input_dim = odim
        spec_enc_input_dim = (
            spec_enc_input_dim + dmodel
            if enable_multi_speaker
            else spec_enc_input_dim
        )
        spec_enc_input_dim = spec_enc_input_dim + dmodel if enable_cross_lingual else spec_enc_input_dim
        spec_enc_input_dim = spec_enc_input_dim + dmodel if enable_multi_style else spec_enc_input_dim
        self.spec_enc_input_proj = torch.nn.Linear(spec_enc_input_dim, dmodel)
        self.enc_norm = torch.nn.LayerNorm(dmodel)

        att_out_dim = style_dim
        self.ph_spec_att = MultiHeadedAttention(
            n_head=dec_num_heads, n_feat=dmodel, dropout_rate=dropout_rate, n_out=att_out_dim
        )
        self.spec_encoder = ConformerEncoder(
            idim=0,
            attention_dim=dmodel,
            attention_heads=4,
            linear_units=dec_ffn_dim,
            num_blocks=4,
            input_layer=None,
            dropout_rate=dropout_rate,
            positional_dropout_rate=dropout_rate,
            attention_dropout_rate=dropout_rate,
            normalize_before=False,
            concat_after=False,
            positionwise_layer_type="conv1d",
            positionwise_conv_kernel_size=3,
            macaron_style=True,
            pos_enc_layer_type="rel_pos",
            selfattention_layer_type="rel_selfattn",
            activation_type="swish",
            use_cnn_module=True,
            cnn_module_kernel=7,
        )
        self.ph_emb_enc_proj = torch.nn.Linear(dmodel + style_dim, dmodel)
        self.phone_emb_predictor = PhoneProsodyPredictor(
            dmodel, style_dim, gru_layer_num=gru_layer_num, enable_ar_phn_pred=True
        )

        self.pitch_predictor = PitchPredictor(
            idim=dmodel,
            n_layers=3,
            n_chans=384,
            kernel_size=5,
            dropout_rate=0.1,
        )
        self.pitch_embed = torch.nn.Sequential(
            torch.nn.Conv1d(
                in_channels=1,
                out_channels=16,
                kernel_size=3,
                padding=(3 - 1) // 2,
            ),
            torch.nn.ReLU(),
            LayerNorm(16, dim=1),
            torch.nn.Dropout(0.1),
        )
        self.pitch_emb_enc_proj = torch.nn.Linear(dmodel + 16, dmodel)

    def _reset_parameters(self, init_type):
        initialize(self, init_type)

    def forward(self, xs, ilens, ys=None, olens=None, ds=None, speaker_id=None, f0=None, lang_id=None,
                style_id=None, uv=None, power=None, tilt=None, mode="train"):
        """Calculate forward propagation.

        Args:
            xs (Tensor): Batch of padded character ids (B, Tmax).
            ilens (LongTensor): Batch of lengths of each input batch (B,).
            ys (Tensor): Batch of padded target features (B, Lmax, odim).
            olens (LongTensor): Batch of the lengths of each target (B,).
            ds (Tensor): phone level frame number
            speaker_id (Tensor, optional): Batch of speaker id (B,).
            xs (Tensor): Batch of padded phone pitch (B, Tmax).
            lang_id (Tensor, optional): Batch of language id (B,).

        Returns:
            Tensor: Loss value.

        """
        output_mode = mode
        if output_mode == 'eval-e2e':
            mode = 'eval'
        elif output_mode == 'train-e2e':
            mode = 'train'

        if mode == "train" or mode == 'semi':
            max_olen = max(olens)
            if ys is not None and max_olen != ys.shape[1]:
                ys = ys[:, :max_olen]
            if olens is None:
                olens = torch.sum(ds, dim=1)
            decoder_masks = self._source_mask(olens)
        elif mode == "eval":
            ys = None
            olens = None
            ds = None
            f0 = None

        max_ilen = max(ilens)
        if max_ilen != xs.shape[1]:
            xs = xs[:, :max_ilen]
        encoder_masks = self._source_mask(ilens)

        # add context feature
        context_feat = None

        # text encoder
        encoder_hidden, unused = self.encoder(xs, encoder_masks, context_feat=context_feat)

        spembs_condition = None
        # multli speaker
        if self.speaker_embedding is not None:
            spembs = self.speaker_embedding(speaker_id)
            if len(spembs.size()) == 2:
                spembs = spembs.unsqueeze(1)

            spembs = F.normalize(spembs)
            spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden += spembs

        # cross lingual
        if self.lang_embedding is not None:
            langs = self.lang_embedding(lang_id)
            if len(langs.size()) == 2:
                langs = langs.unsqueeze(1)
            langs = F.normalize(langs)
            langs = langs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden += langs

        if self.enable_multi_style:
            style_embedding = self.style_embedding(style_id.long().unsqueeze(-1))
            if len(style_embedding.size()) == 4:
                style_embedding = style_embedding.squeeze(1)
            if len(style_embedding.size()) == 2:
                style_embedding = style_embedding.unsqueeze(1)

            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))

            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], -1))

        encoder_hidden_ps = encoder_hidden

        # duration prediction
        d_outs = torch.log(ds.float() + 1.0)
        hs, align_mat = self.length_regulator(encoder_hidden_ps, ds)

        # pitch info
        f0_embedding, uv_embedding = self.pitch_embedding(f0.unsqueeze(-1), uv.unsqueeze(-1), mask=sequence_mask(olens))
        hs = self.pitch_fuse_layer(torch.cat([hs, f0_embedding, uv_embedding], -1))

        if self.enable_power:
            power = power.unsqueeze(-1)
            power = power * sequence_mask(olens).to(power.dtype).unsqueeze(-1)
            power_embedding = self.singing_vc_fea_embedding(power.permute(0, 2, 1)).permute(0, 2, 1)
            hs = self.singing_vc_fea_fuse_layer(torch.cat([hs, power_embedding], -1))

        if self.enable_tilt:
            tilt = tilt.unsqueeze(-1)
            tilt = tilt * sequence_mask(olens).to(tilt.dtype).unsqueeze(-1)
            tilt_embedding = self.singing_vc_fea_embedding(tilt.permute(0, 2, 1)).permute(0, 2, 1)
            hs = self.singing_vc_fea_fuse_layer(torch.cat([hs, tilt_embedding], -1))
        # mel decoder
        gating_features = None
        zs, unused = self.decoder(hs,
                                  decoder_masks,
                                  condition=spembs_condition,
                                  gating_features=gating_features,
                                  inference=True if mode == 'semi' else False,
                                  ys=ys)

        outputs = [self.output_layers[i](zs[i]) for i in range(self.dec_layers)]

        if output_mode == 'eval-e2e':
            return outputs[-1], olens
        elif output_mode == 'distill':
            return outputs[-1], None, d_outs
        elif output_mode == 'full_distill':
            return outputs[-1], d_outs.detach(), d_outs
        elif output_mode == 'voc_distill':
            return outputs[-1], d_outs
        elif output_mode == 'semi':
            return outputs, d_outs, None, None, None, None, None, None
        elif output_mode == 'train-e2e':
            return outputs, d_outs, None, None, None, None, None, None
        else:
            retvalue = outputs, d_outs, None, None, None, None, None, None, \
                None, None, None, None, ds, None
            return retvalue

    @torch.no_grad()
    def inference(self, phone_id, speaker_id=None, lang_id=None, style_id=None, duration=None,
                  f0=None, uv=None, power=None, tilt=None):
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()

        # text encoder
        encoder_hidden, unused = self.encoder(phone_id, None)

        # multli speaker
        if self.speaker_embedding is not None:
            spembs = self.speaker_embedding(speaker_id)
            if len(spembs.size()) == 2:
                spembs = spembs.unsqueeze(1)

            spembs = F.normalize(spembs)
            spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden += spembs

        # cross lingual
        if self.lang_embedding is not None:
            langs = self.lang_embedding(lang_id)
            if len(langs.size()) == 2:
                langs = langs.unsqueeze(1)
            langs = F.normalize(langs)
            langs = langs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden += langs

        if self.enable_multi_style:
            style_embedding = self.style_embedding(style_id.long().unsqueeze(-1))
            if len(style_embedding.size()) == 4:
                style_embedding = style_embedding.squeeze(1)
            if len(style_embedding.size()) == 2:
                style_embedding = style_embedding.unsqueeze(1)

            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))

            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], -1))

        encoder_hidden_ps = encoder_hidden

        # duration prediction
        decoder_input, align_mat = self.length_regulator(encoder_hidden_ps, duration)

        # pitch info
        f0_embedding, uv_embedding = self.pitch_embedding(f0, uv)
        decoder_input = self.pitch_fuse_layer(torch.cat([decoder_input, f0_embedding, uv_embedding], -1))
        if self.enable_power:
            power = power.unsqueeze(-1)
            power_embedding = self.singing_vc_fea_embedding(power.permute(0, 2, 1)).permute(0, 2, 1)
            decoder_input = self.singing_vc_fea_fuse_layer(torch.cat([decoder_input, power_embedding], -1))

        if self.enable_tilt:
            tilt = tilt.unsqueeze(-1)
            tilt_embedding = self.singing_vc_fea_embedding(tilt.permute(0, 2, 1)).permute(0, 2, 1)
            decoder_input = self.singing_vc_fea_fuse_layer(torch.cat([decoder_input, tilt_embedding], -1))
        zs, unused = self.decoder(decoder_input, None)

        zs = self.output_layers[-1](zs[-1])
        return zs

    def _source_mask(self, ilens):
        x_masks = make_non_pad_mask(ilens).to(next(self.parameters()).device)
        return x_masks.unsqueeze(-2) & x_masks.unsqueeze(-1)

    def _source_to_target_mask(self, ilens, olens):
        x_masks = make_non_pad_mask(ilens).to(next(self.parameters()).device)
        y_masks = make_non_pad_mask(olens).to(next(self.parameters()).device)
        return x_masks.unsqueeze(-2) & y_masks.unsqueeze(-1)

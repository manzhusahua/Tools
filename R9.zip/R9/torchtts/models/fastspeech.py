import torch
import torch.nn as nn

from torchtts.nn.modules.common import GaussianSmoother
from torchtts.nn.modules.common import LayerNorm
from torchtts.nn.modules.common import LengthRegulator
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.modules.fastspeech import DecoderEmbedding
from torchtts.nn.modules.fastspeech import DurationPredictor
from torchtts.nn.modules.fastspeech import PitchEmbedding
from torchtts.nn.modules.fastspeech import PitchPredictor
from torchtts.nn.modules.fastspeech import PositionEmbedding
from torchtts.nn.modules.locale_encoders import LocaleEmbedding
from torchtts.nn.modules.speaker_encoders import SpeakerEmbedding
from torchtts.nn.modules.style_encoders import StyleEmbedding
from torchtts.nn.modules.transformer import PositionalEncoding
from torchtts.nn.modules.transformer import TransformerEncoder
from torchtts.nn.modules.transformer import TransformerEncoderLayer

DEFAULT_MAX_SOURCE_POSITIONS = 1000
DEFAULT_MAX_TARGET_POSITIONS = 10000


class FastSpeech(nn.Module):
    """Feed Forward Transformer for TTS a.k.a. FastSpeech.

    FastSpeech is a feed-forward Transformer with duration predictor described in
    `FastSpeech: Fast, Robust and Controllable Text to Speech`, which does not
    require any auto-regressive processing during inference, resulting in fast
    decoding compared with auto-regressive Transformer.
    """

    def __init__(
        self,
        phone_embedding_size,
        phone_embedding_dim=384,
        out_dim=80,
        enc_layers=4,
        enc_hidden=384,
        enc_num_heads=2,
        enc_ffn_dims=(1536, 384),
        enc_ffn_kernels=(9, 1),
        enc_ffn_dilations=(1, 1),
        use_dec_embedding=True,
        use_dec_pos_embedding=True,
        dec_layers=6,
        dec_hidden=384,
        dec_num_heads=2,
        dec_ffn_dims=(1536, 384),
        dec_ffn_kernels=(9, 1),
        dec_ffn_dilations=(1, 1),
        dropout=0.1,
        t2t_compatible=True,
        smoother_params=None,
        use_multi_speaker=False,
        speaker_embedding_size=50,
        speaker_embedding_dim=128,
        use_multi_locale=False,
        locale_embedding_size=50,
        locale_embedding_dim=128,
        use_multi_style=False,
        style_fusing_op="concat",
        style_embedding_size=16,
        style_embedding_dim=128,
        use_singing_feature=False,
        note_pitch_embedding_size=5000,
        note_duration_embedding_size=5000,
        enable_pitch_contour=False,
        f0_embed_dim=64,
        uv_embed_dim=32,
        dur_pred_layers=2,
        dur_pred_kernel=3,
        dur_pred_filter=256,
        dur_dropout=0.5,
        enable_fmoe=False,
        fmoe_num_expert=64,
        fmoe_hidden_dim=1024,
        fmoe_top_k=2,
    ):
        super(FastSpeech, self).__init__()
        self.enable_fmoe = enable_fmoe
        self.enc_hidden = enc_hidden
        self.dec_hidden = dec_hidden
        self.out_dim = out_dim
        self.use_multi_speaker = use_multi_speaker
        self.use_multi_locale = use_multi_locale
        self.use_multi_style = use_multi_style
        self.style_fusing_op = style_fusing_op
        self.use_singing_feature = use_singing_feature
        self.enable_pitch_contour = enable_pitch_contour
        self.phone_embedding = nn.Embedding(
            num_embeddings=phone_embedding_size, embedding_dim=phone_embedding_dim, padding_idx=0
        )

        embedding_fuse_in_dim = 0
        if use_multi_speaker:
            self.speaker_embedding = SpeakerEmbedding(speaker_embedding_size, speaker_embedding_dim)
            embedding_fuse_in_dim += speaker_embedding_dim

        if use_multi_locale:
            self.locale_embedding = LocaleEmbedding(locale_embedding_size, locale_embedding_dim)
            embedding_fuse_in_dim += locale_embedding_dim

        # embedding fuse layer for duration predictor
        if embedding_fuse_in_dim != 0:
            self.embedding_fuse_layer1 = nn.Linear(embedding_fuse_in_dim + enc_hidden, enc_hidden)
        if use_singing_feature:
            self.note_pitch_embedding = nn.Embedding(
                num_embeddings=note_pitch_embedding_size, embedding_dim=phone_embedding_dim, padding_idx=0
            )

            self.note_duration_embedding = nn.Embedding(
                num_embeddings=note_duration_embedding_size, embedding_dim=phone_embedding_dim, padding_idx=0
            )

        if use_multi_style:
            self.style_embedding = StyleEmbedding(style_embedding_size, style_embedding_dim)
            embedding_fuse_in_dim += style_embedding_dim

        # embedding fuse layer for decoder
        if embedding_fuse_in_dim != 0:
            self.embedding_fuse_layer2 = nn.Linear(embedding_fuse_in_dim + dec_hidden, dec_hidden)

        self.enc_pos_encoding = PositionalEncoding(
            model_dim=phone_embedding_dim, dropout=dropout, max_len=DEFAULT_MAX_SOURCE_POSITIONS
        )

        encoder_layer = TransformerEncoderLayer(
            model_dim=enc_hidden,
            num_heads=enc_num_heads,
            ffn_dims=enc_ffn_dims,
            ffn_kernels=enc_ffn_kernels,
            ffn_dilations=enc_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
        )
        encoder_norm = LayerNorm(enc_hidden)
        self.encoder = TransformerEncoder(encoder_layer=encoder_layer, num_layers=enc_layers, norm=encoder_norm)

        if self.style_fusing_op != "concat":
            self.style_linear = nn.Linear(style_embedding_dim, enc_hidden)
        self.duration_predictor = DurationPredictor(
            in_dim=enc_hidden + style_embedding_dim if use_multi_style and style_fusing_op == "concat" else enc_hidden,
            filter_size=dur_pred_filter,
            kernel=dur_pred_kernel,
            num_layers=dur_pred_layers,
            dropout=dur_dropout,
        )

        if smoother_params is not None:
            self.smoother = GaussianSmoother(**smoother_params)

        self.length_regulator = LengthRegulator(smoother=self.smoother)

        if use_dec_embedding:
            self.dec_embedding = DecoderEmbedding(
                symbol_size=phone_embedding_size, embedding_size=dec_hidden, hidden_size=dec_hidden, dropout=dropout
            )

        self.dec_pos_encoding = PositionalEncoding(
            model_dim=enc_hidden, dropout=dropout, max_len=DEFAULT_MAX_TARGET_POSITIONS
        )

        if use_dec_pos_embedding:
            self.dec_pos_embedding = PositionEmbedding()

        if enable_pitch_contour:
            self.pitch_predictor = PitchPredictor(in_dim=enc_hidden)
            self.pitch_embedding = PitchEmbedding(f0_emb_dim=f0_embed_dim, uv_emb_dim=uv_embed_dim)
            self.pitch_fuse_layer = nn.Linear(enc_hidden + f0_embed_dim + uv_embed_dim, enc_hidden)

        # Note: FastSpeech's decoder is the same as encoder.
        decoder_layer = TransformerEncoderLayer(
            model_dim=dec_hidden,
            num_heads=dec_num_heads,
            ffn_dims=dec_ffn_dims,
            ffn_kernels=dec_ffn_kernels,
            ffn_dilations=dec_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
            enable_fmoe=enable_fmoe,
            fmoe_num_expert=fmoe_num_expert,
            fmoe_hidden_dim=fmoe_hidden_dim,
            fmoe_top_k=fmoe_top_k,
        )
        decoder_norm = LayerNorm(dec_hidden)
        self.decoder = TransformerEncoder(encoder_layer=decoder_layer, num_layers=dec_layers, norm=decoder_norm)

        self.mel_proj = nn.Linear(dec_hidden, out_dim, bias=False)

        self.reset_parameters()

    def forward(
        self,
        phone_id,
        job="tts",
        speaker_id=None,
        locale_id=None,
        style_id=None,
        src_length=None,
        duration=None,
        tgt_length=None,
        f0=None,
        uv=None,
        note_duration=None,
        note_pitch=None,
        need_predict_pitch=False,
    ):
        if "tts" == job:
            return self.tts_forward(
                phone_id,
                speaker_id,
                locale_id,
                style_id,
                src_length,
                duration,
                tgt_length,
                f0,
                uv,
                note_duration,
                note_pitch,
                need_predict_pitch,
            )
        elif "singingvc" == job:
            return self.singing_vc_forward(
                phone_id, speaker_id, locale_id, style_id, src_length, duration, tgt_length, f0, uv
            )
        else:
            raise ValueError("undefined trining job %s" % job)

    def tts_forward(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        style_id=None,
        src_length=None,
        duration=None,
        tgt_length=None,
        f0=None,
        uv=None,
        note_duration=None,
        note_pitch=None,
        need_predict_pitch=False,
    ):
        if src_length is not None:
            src_mask = sequence_mask(src_length)
            tgt_mask = sequence_mask(tgt_length)
        else:
            src_mask = None
            tgt_mask = None

        # Phoneme or character embedding
        phone_embedding = self.phone_embedding(phone_id)
        if self.use_singing_feature:
            note_pitch_embedding = self.note_pitch_embedding(note_pitch)
            note_duration_embedding = self.note_duration_embedding(note_duration)
            phone_embedding = phone_embedding + note_pitch_embedding + note_duration_embedding
        phone_embedding *= self.enc_hidden**0.5
        # Add position encoding to embedding
        encoder_input = self.enc_pos_encoding(phone_embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.unsqueeze(-1))

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.unsqueeze(-1))

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input, src_key_padding_mask=~src_mask)

        style_embedding = None
        if self.use_multi_style:
            style_embedding = self.style_embedding(style_id.unsqueeze(-1))

        # Make up duration predictor inputs. (For historical reasons, style
        # embedding is concatenated after fuse layer. But it's more unified
        # to concatenate all the embeddings before fusing.
        length = encoder_output.size(1)
        dur_pred_input = encoder_output
        if self.use_multi_speaker:
            dur_pred_input = torch.cat([dur_pred_input, speaker_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_locale:
            dur_pred_input = torch.cat([dur_pred_input, locale_embedding.expand(-1, length, -1)], dim=-1)
        if hasattr(self, "embedding_fuse_layer1"):
            dur_pred_input = self.embedding_fuse_layer1(dur_pred_input)

        if self.use_multi_style:
            if self.style_fusing_op == "concat":
                dur_pred_input = torch.cat([dur_pred_input, style_embedding.expand(-1, length, -1)], dim=-1)
            else:
                style_linear = self.style_linear(style_embedding)
                dur_pred_input = dur_pred_input + style_linear
        # Duration prediction in logarithmic domain
        predicted_duration = self.duration_predictor(dur_pred_input, src_mask)

        if duration is None:
            duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0)
            duration = torch.round(duration).long()
            tgt_mask = sequence_mask(torch.sum(duration, dim=1))

        # Expand phone level feats to frame level feats. Use ground truth
        # duration if provided.
        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        # Add position encoding to decoder input
        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration, padding_mask=~tgt_mask)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # Add embedding information to decoder input
        length = decoder_input.size(1)
        if self.use_multi_speaker:
            decoder_input = torch.cat([decoder_input, speaker_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_locale:
            decoder_input = torch.cat([decoder_input, locale_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_style:
            decoder_input = torch.cat([decoder_input, style_embedding.expand(-1, length, -1)], dim=-1)
        if hasattr(self, "embedding_fuse_layer2"):
            decoder_input = self.embedding_fuse_layer2(decoder_input)

        pred_f0 = pred_uv = None
        if hasattr(self, "pitch_predictor"):
            if need_predict_pitch:
                decoder_input, pred_f0, pred_uv = self._fuse_pitch_into_decoder_input(decoder_input, f0, uv, tgt_mask)

        # FFT blocks as decoder
        if not self.enable_fmoe:
            decoder_output = self.decoder(decoder_input, src_key_padding_mask=~tgt_mask)
        else:
            gating_features = torch.matmul(align_mat, encoder_output)
            decoder_output = self.decoder(
                decoder_input, src_key_padding_mask=~tgt_mask, gating_features=gating_features
            )

        # Project output features like mel
        mel_spec = self.mel_proj(decoder_output)
        mel_spec *= tgt_mask.to(mel_spec.dtype).unsqueeze(-1)

        return (mel_spec, predicted_duration, pred_f0, pred_uv, src_mask, tgt_mask)

    def singing_vc_forward(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        style_id=None,
        src_length=None,
        duration=None,
        tgt_length=None,
        f0=None,
        uv=None,
    ):
        if src_length is not None:
            src_mask = sequence_mask(src_length)
            tgt_mask = sequence_mask(tgt_length)
        else:
            src_mask = None
            tgt_mask = None

        # Phoneme or character embedding
        phone_embedding = self.phone_embedding(phone_id)
        phone_embedding *= self.enc_hidden**0.5
        # Add position encoding to embedding
        encoder_input = self.enc_pos_encoding(phone_embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id)

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id)

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input, src_key_padding_mask=~src_mask)

        style_embedding = None
        if self.use_multi_style:
            style_embedding = self.style_embedding(style_id)

        # Expand phone level feats to frame level feats. Use ground truth
        # duration if provided.
        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        # Add position encoding to decoder input
        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration, padding_mask=~tgt_mask)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # Add embedding information to decoder input
        length = decoder_input.size(1)
        if self.use_multi_speaker:
            decoder_input = torch.cat([decoder_input, speaker_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_locale:
            decoder_input = torch.cat([decoder_input, locale_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_style:
            decoder_input = torch.cat([decoder_input, style_embedding.expand(-1, length, -1)], dim=-1)
        if hasattr(self, "embedding_fuse_layer2"):
            decoder_input = self.embedding_fuse_layer2(decoder_input)

        f0_embedding, uv_embedding = self.pitch_embedding(f0.unsqueeze(-1), uv.unsqueeze(-1), mask=tgt_mask)
        decoder_input = self.pitch_fuse_layer(torch.cat([decoder_input, f0_embedding, uv_embedding], -1))

        # FFT blocks as decoder
        decoder_output = self.decoder(decoder_input, src_key_padding_mask=~tgt_mask)

        # Project output features like mel
        mel_spec = self.mel_proj(decoder_output)
        mel_spec *= tgt_mask.to(mel_spec.dtype).unsqueeze(-1)

        return (mel_spec, tgt_mask)

    @torch.no_grad()
    def singing_vc_inference(
        self, phone_id, speaker_id=None, locale_id=None, style_id=None, duration=None, f0=None, uv=None
    ):
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()

        # Phoneme or character embedding
        phone_embedding = self.phone_embedding(phone_id)
        phone_embedding *= self.enc_hidden**0.5
        # Add position encoding to embedding
        encoder_input = self.enc_pos_encoding(phone_embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.long())

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.long())

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input)

        style_embedding = None
        if self.use_multi_style:
            style_embedding = self.style_embedding(style_id.long())

        # Expand phone level feats to frame level feats. Use ground truth
        # duration if provided.
        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        # Add position encoding to decoder input
        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # Add embedding information to decoder input
        length = decoder_input.size(1)
        if self.use_multi_speaker:
            decoder_input = torch.cat([decoder_input, speaker_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_locale:
            decoder_input = torch.cat([decoder_input, locale_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_style:
            decoder_input = torch.cat([decoder_input, style_embedding.expand(-1, length, -1)], dim=-1)
        if hasattr(self, "embedding_fuse_layer2"):
            decoder_input = self.embedding_fuse_layer2(decoder_input)

        f0_embedding, uv_embedding = self.pitch_embedding(f0, uv)
        decoder_input = self.pitch_fuse_layer(torch.cat([decoder_input, f0_embedding, uv_embedding], -1))

        # FFT blocks as decoder
        decoder_output = self.decoder(decoder_input)

        # Project output features like mel
        mel_spec = self.mel_proj(decoder_output)

        return mel_spec

    @torch.no_grad()
    def inference(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        style_id=None,
        style_scale_ratio=None,
        speaking_rate=None,
        f0_scale_ratio=None,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
        note_pitch=None,
        note_duration=None,
    ):
        # Align with t2t which has 4D input for runtime compatibility
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()
        embedding = self.phone_embedding(phone_id)
        if self.use_singing_feature:
            note_pitch = note_pitch.squeeze(-1).squeeze(-1).long()
            note_duration = note_duration.squeeze(-1).squeeze(-1).long()
            note_pitch_embedding = self.note_pitch_embedding(note_pitch)
            note_duration_embedding = self.note_duration_embedding(note_duration)
            embedding = embedding + note_pitch_embedding + note_duration_embedding
        embedding *= self.enc_hidden**0.5
        encoder_input = self.enc_pos_encoding(embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.long())

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.long())

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input)

        style_embedding = None
        if self.use_multi_style:
            style_embedding = self.style_embedding(style_id.long().unsqueeze(-1))
            if style_scale_ratio is not None:
                style_embedding = style_embedding * style_scale_ratio

        # Make up duration predictor inputs. (For historical reasons, style
        # embedding is concatenated after fuse layer. But it's more unified
        # to concatenate all the embeddings before fusing.
        length = encoder_output.size(1)
        dur_pred_input = encoder_output
        if self.use_multi_speaker:
            dur_pred_input = torch.cat([dur_pred_input, speaker_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_locale:
            dur_pred_input = torch.cat([dur_pred_input, locale_embedding.expand(-1, length, -1)], dim=-1)
        if hasattr(self, "embedding_fuse_layer1"):
            dur_pred_input = self.embedding_fuse_layer1(dur_pred_input)

        if self.use_multi_style:
            if self.style_fusing_op == "concat":
                dur_pred_input = torch.cat([dur_pred_input, style_embedding.expand(-1, length, -1)], dim=-1)
            else:
                style_linear = self.style_linear(style_embedding)
                dur_pred_input = dur_pred_input + style_linear
        # Duration prediction in logarithmic domain
        predicted_duration = self.duration_predictor(dur_pred_input)
        duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0)

        if speaking_rate is not None:
            duration = duration / speaking_rate
        duration = torch.round(duration).long()

        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # Add embedding information to decoder input
        length = decoder_input.size(1)
        if self.use_multi_speaker:
            decoder_input = torch.cat([decoder_input, speaker_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_locale:
            decoder_input = torch.cat([decoder_input, locale_embedding.expand(-1, length, -1)], dim=-1)
        if self.use_multi_style:
            decoder_input = torch.cat([decoder_input, style_embedding.expand(-1, length, -1)], dim=-1)
        if hasattr(self, "embedding_fuse_layer2"):
            decoder_input = self.embedding_fuse_layer2(decoder_input)

        if hasattr(self, "pitch_predictor"):
            f0, uv = self.pitch_predictor(decoder_input)
            if f0_scale_ratio is not None:
                f0 = f0 * torch.matmul(align_mat, f0_scale_ratio)
                uv = torch.round(uv)
                f0_embedding, uv_embedding = self.pitch_embedding(f0, uv)
                fused_decoder_input = self.pitch_fuse_layer(torch.cat([decoder_input, f0_embedding, uv_embedding], -1))
                # In inference, pitch contour is disabled to pass binary equality
                # test when the mean of pitch is located in [f0_scale_min, f0_scale_max].
                decoder_input = torch.where(
                    torch.logical_or(
                        torch.greater(f0_scale_ratio.max(), f0_scale_max),
                        torch.less(f0_scale_ratio.min(), f0_scale_min),
                    ),
                    fused_decoder_input,
                    decoder_input,
                )

        gating_features = None
        if self.enable_fmoe:
            gating_features = torch.matmul(align_mat, encoder_output)
        decoder_output = self.decoder(decoder_input, gating_features=gating_features)

        mel_spec = self.mel_proj(decoder_output)

        return mel_spec, duration.int()

    def _fuse_pitch_into_decoder_input(self, decoder_input, f0, uv, tgt_mask):
        pred_f0, pred_uv = self.pitch_predictor(decoder_input)
        f0 = pred_f0 if f0 is None else f0.unsqueeze(-1)
        uv = pred_uv if uv is None else uv.unsqueeze(-1)
        f0_embedding, uv_embedding = self.pitch_embedding(f0, uv, mask=tgt_mask)
        decoder_input = self.pitch_fuse_layer(torch.cat([decoder_input, f0_embedding, uv_embedding], -1))
        return decoder_input, pred_f0, pred_uv

    def reset_parameters(self):
        # Note: parameter initialization is an important part in transformer based models
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            if p.dim() == 1:
                nn.init.zeros_(p)

        for m in self.modules():
            if isinstance(m, nn.LayerNorm):
                m.reset_parameters()

        nn.init.normal_(self.phone_embedding.weight, 0, self.enc_hidden**-0.5)
        nn.init.normal_(self.mel_proj.weight, 0, self.out_dim**-0.5)

        if self.dec_embedding is not None:
            self.dec_embedding.reset_parameters()

import torch
import torch.nn as nn

from torchtts.nn.modules.common import GaussianSmoother
from torchtts.nn.modules.common import LayerNorm
from torchtts.nn.modules.common import LengthRegulator
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.modules.fastspeech import DecoderEmbedding
from torchtts.nn.modules.fastspeech import DurationPredictor
from torchtts.nn.modules.fastspeech import PhonePitchPredictor
from torchtts.nn.modules.fastspeech import PhonePitchEmbedding
from torchtts.nn.modules.fastspeech import PositionEmbedding
from torchtts.nn.modules.locale_encoders import LocaleEmbedding
from torchtts.nn.modules.speaker_encoders import SpeakerEmbedding
from torchtts.nn.modules.style_encoders.fine_grained_encoder import StyleEmbeddingPredictor
from torchtts.nn.modules.style_encoders.fine_grained_encoder import FineGrainedEncoder
from torchtts.nn.modules.transformer import PositionalEncoding
from torchtts.nn.modules.transformer import TransformerEncoder
from torchtts.nn.modules.transformer import TransformerEncoderLayer

DEFAULT_MAX_SOURCE_POSITIONS = 1000
DEFAULT_MAX_TARGET_POSITIONS = 10000


class FastSpeech2(nn.Module):
    """FastSpeech2 variant for UniTTS V3."""

    def __init__(
        self,
        phone_embedding_size,
        phone_embedding_dim=384,
        out_dim=80,
        enc_layers=4,
        enc_hidden=384,
        enc_num_heads=2,
        enc_ffn_dims=(1536, 384),
        enc_ffn_kernels=(9, 1),
        enc_ffn_dilations=(1, 1),
        use_dec_embedding=True,
        use_dec_pos_embedding=True,
        dec_layers=6,
        dec_hidden=384,
        dec_num_heads=2,
        dec_ffn_dims=(1536, 384),
        dec_ffn_kernels=(9, 1),
        dec_ffn_dilations=(1, 1),
        dropout=0.1,
        t2t_compatible=True,
        smoother_params=None,
        use_multi_speaker=False,
        speaker_embedding_size=50,
        speaker_embedding_dim=128,
        use_multi_locale=False,
        locale_embedding_size=50,
        locale_embedding_dim=128,
        dur_pred_layers=2,
        dur_pred_kernel=3,
        dur_pred_filter=256,
        dur_dropout=0.5,
        enable_conditional_layer_norm=False,
        use_separate_style_encoder=False,
        separate_style_enc_layers=2,
        use_separate_duration_encoder=False,
        separate_dur_enc_layers=2,
    ):
        super(FastSpeech2, self).__init__()
        self.enc_hidden = enc_hidden
        self.dec_hidden = dec_hidden
        self.out_dim = out_dim
        self.use_multi_speaker = use_multi_speaker
        self.use_multi_locale = use_multi_locale
        self.use_separate_style_encoder = use_separate_style_encoder
        self.use_separate_duration_encoder = use_separate_duration_encoder

        self.phone_embedding = nn.Embedding(
            num_embeddings=phone_embedding_size, embedding_dim=phone_embedding_dim, padding_idx=0
        )

        embedding_fuse_in_dim = enc_hidden
        if use_multi_speaker:
            self.speaker_embedding = SpeakerEmbedding(speaker_embedding_size, speaker_embedding_dim)
            embedding_fuse_in_dim += speaker_embedding_dim

        if use_multi_locale:
            self.locale_embedding = LocaleEmbedding(locale_embedding_size, locale_embedding_dim)
            embedding_fuse_in_dim += locale_embedding_dim

        # Fine grained style encoder (phone level)
        self.fine_grained_style_encoder = FineGrainedEncoder(
            in_dim=out_dim,
            speaker_embedding_dim=speaker_embedding_dim,
            locale_embedding_dim=locale_embedding_dim,
            model_dim=enc_hidden,
        )
        embedding_fuse_in_dim += enc_hidden
        self.style_embedding_predictor = StyleEmbeddingPredictor(
            in_dim=enc_hidden,
            out_dim=enc_hidden,
            speaker_embedding_dim=speaker_embedding_dim,
            locale_embedding_dim=locale_embedding_dim,
        )

        self.embedding_fuse_layer1 = nn.Linear(embedding_fuse_in_dim, enc_hidden)
        self.embedding_fuse_layer2 = nn.Linear(embedding_fuse_in_dim, enc_hidden)

        self.enc_pos_encoding = PositionalEncoding(
            model_dim=phone_embedding_dim, dropout=dropout, max_len=DEFAULT_MAX_SOURCE_POSITIONS
        )

        # Encoder layers
        cond_dim = locale_embedding_dim if use_multi_locale and enable_conditional_layer_norm else -1
        encoder_layer = TransformerEncoderLayer(
            model_dim=enc_hidden,
            num_heads=enc_num_heads,
            ffn_dims=enc_ffn_dims,
            ffn_kernels=enc_ffn_kernels,
            ffn_dilations=enc_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
            layer_norm_condition_dim=cond_dim,
        )
        encoder_norm = LayerNorm(enc_hidden, condition_dim=cond_dim)
        self.encoder = TransformerEncoder(encoder_layer=encoder_layer, num_layers=enc_layers, norm=encoder_norm)

        if use_separate_duration_encoder:
            encoder_layer = TransformerEncoderLayer(
                model_dim=enc_hidden,
                num_heads=enc_num_heads,
                ffn_dims=enc_ffn_dims,
                ffn_kernels=enc_ffn_kernels,
                ffn_dilations=enc_ffn_dilations,
                t2t_compatible=t2t_compatible,
                dropout=dropout,
                layer_norm_condition_dim=cond_dim,
            )
            encoder_norm = LayerNorm(enc_hidden, condition_dim=cond_dim)
            self.separate_duration_encoder = TransformerEncoder(
                encoder_layer=encoder_layer, num_layers=separate_dur_enc_layers, norm=encoder_norm
            )

        if use_separate_style_encoder:
            encoder_layer = TransformerEncoderLayer(
                model_dim=enc_hidden,
                num_heads=enc_num_heads,
                ffn_dims=enc_ffn_dims,
                ffn_kernels=enc_ffn_kernels,
                ffn_dilations=enc_ffn_dilations,
                t2t_compatible=t2t_compatible,
                dropout=dropout,
                layer_norm_condition_dim=cond_dim,
            )
            encoder_norm = LayerNorm(enc_hidden, condition_dim=cond_dim)
            self.separate_style_encoder = TransformerEncoder(
                encoder_layer=encoder_layer, num_layers=separate_style_enc_layers, norm=encoder_norm
            )

        self.duration_predictor = DurationPredictor(
            in_dim=enc_hidden,
            filter_size=dur_pred_filter,
            kernel=dur_pred_kernel,
            num_layers=dur_pred_layers,
            dropout=dur_dropout,
        )

        if smoother_params is not None:
            self.smoother = GaussianSmoother(**smoother_params)

        self.length_regulator = LengthRegulator(smoother=self.smoother)

        if use_dec_embedding:
            self.dec_embedding = DecoderEmbedding(
                symbol_size=phone_embedding_size, embedding_size=dec_hidden, hidden_size=dec_hidden, dropout=dropout
            )

        self.dec_pos_encoding = PositionalEncoding(
            model_dim=enc_hidden, dropout=dropout, max_len=DEFAULT_MAX_TARGET_POSITIONS
        )

        if use_dec_pos_embedding:
            self.dec_pos_embedding = PositionEmbedding()

        # Enable phone level pitch condition
        cond_dim = speaker_embedding_dim if self.use_multi_speaker and enable_conditional_layer_norm else -1
        self.phone_pitch_predictor = PhonePitchPredictor(
            in_dim=enc_hidden, filter_size=256, kernel=3, num_layers=2, dropout=0.5, layer_norm_condition_dim=cond_dim
        )
        self.phone_pitch_embedding = PhonePitchEmbedding(out_dim=enc_hidden)

        # Note: FastSpeech's decoder is the same as encoder.
        cond_dim = speaker_embedding_dim if self.use_multi_speaker and enable_conditional_layer_norm else -1
        decoder_layer = TransformerEncoderLayer(
            model_dim=dec_hidden,
            num_heads=dec_num_heads,
            ffn_dims=dec_ffn_dims,
            ffn_kernels=dec_ffn_kernels,
            ffn_dilations=dec_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
            layer_norm_condition_dim=cond_dim,
        )
        decoder_norm = LayerNorm(dec_hidden, condition_dim=cond_dim)
        self.decoder = TransformerEncoder(encoder_layer=decoder_layer, num_layers=dec_layers, norm=decoder_norm)

        self.mel_proj = nn.Linear(dec_hidden, out_dim, bias=False)

        self.reset_parameters()

    def forward(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        src_length=None,
        duration=None,
        tgt_length=None,
        reference=None,
        phone_f0=None,
    ):
        if src_length is not None:
            src_mask = sequence_mask(src_length)
            tgt_mask = sequence_mask(tgt_length)
        else:
            src_mask = None
            tgt_mask = None

        # Phoneme or character embedding
        phone_embedding = self.phone_embedding(phone_id)
        phone_embedding *= self.enc_hidden**0.5
        # Add position encoding to embedding
        encoder_input = self.enc_pos_encoding(phone_embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.unsqueeze(-1))

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.unsqueeze(-1))

        # FFT blocks as encoder
        encoder_output = self.encoder(
            encoder_input, layer_norm_condition=locale_embedding, src_key_padding_mask=~src_mask
        )

        style_input = encoder_output
        if self.use_separate_style_encoder:
            style_input = self.separate_style_encoder(
                encoder_input, layer_norm_condition=locale_embedding, src_key_padding_mask=~src_mask
            )

        # Style embedding predictor which can run independently during inference.
        pred_style_embedding = self.style_embedding_predictor(
            style_input, speaker_embedding=speaker_embedding, locale_embedding=locale_embedding, mask=src_mask
        )

        if reference is not None:
            style_embedding = self.fine_grained_style_encoder(
                encoder_output,
                reference,
                style_input_padding_mask=~src_mask,
                reference_padding_mask=~tgt_mask,
                speaker_embedding=speaker_embedding,
                locale_embedding=locale_embedding,
            )
        else:
            style_embedding = pred_style_embedding

        target_style_embedding = style_embedding.detach()

        duration_input = encoder_output
        if self.use_separate_duration_encoder:
            duration_input = self.separate_duration_encoder(
                encoder_input, layer_norm_condition=locale_embedding, src_key_padding_mask=~src_mask
            )

        # Make up inputs for duration predictor
        length = duration_input.size(1)
        embeddings = [duration_input]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding)
        duration_input = self.embedding_fuse_layer1(torch.cat(embeddings, dim=-1))

        # Duration prediction in logarithmic domain
        predicted_duration = self.duration_predictor(duration_input, src_mask)

        # Make up inputs for phone pitch predictor and transformer decoder.
        length = encoder_output.size(1)
        embeddings = [encoder_output]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding)
        encoder_output = self.embedding_fuse_layer2(torch.cat(embeddings, dim=-1))

        # Phone-level pitch predictor
        pred_phone_f0 = self.phone_pitch_predictor(encoder_output, condition=speaker_embedding)
        phone_f0 = pred_phone_f0 if phone_f0 is None else phone_f0.unsqueeze(-1)
        phone_f0_embedding = self.phone_pitch_embedding(phone_f0)
        encoder_output = encoder_output + phone_f0_embedding

        if duration is None:
            duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0)
            duration = torch.round(duration).long()
            tgt_mask = sequence_mask(torch.sum(duration, dim=1))

        # Expand phone level feats to frame level feats. Use ground truth
        # duration if provided.
        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        # Add position encoding to decoder input
        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration, padding_mask=~tgt_mask)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # FFT blocks as decoder
        decoder_output = self.decoder(
            decoder_input, layer_norm_condition=speaker_embedding, src_key_padding_mask=~tgt_mask
        )

        # Project output features like mel
        mel_spec = self.mel_proj(decoder_output)
        mel_spec *= tgt_mask.to(mel_spec.dtype).unsqueeze(-1)
        return (
            mel_spec,
            predicted_duration,
            pred_phone_f0,
            pred_style_embedding,
            target_style_embedding,
            src_mask,
            tgt_mask,
        )

    @torch.no_grad()
    def inference(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        speaking_rate=None,
        f0_scale_ratio=None,
        f0_mean=178.47,
        f0_var=53.47,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
    ):
        # Align with t2t which has 4D input for runtime compatibility
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()

        embedding = self.phone_embedding(phone_id)
        embedding *= self.enc_hidden**0.5
        encoder_input = self.enc_pos_encoding(embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.long())

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.long())

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input, layer_norm_condition=locale_embedding)

        style_input = encoder_output
        if self.use_separate_style_encoder:
            style_input = self.separate_style_encoder(encoder_input, layer_norm_condition=locale_embedding)

        # Style embedding predictor which can run independently during inference.
        style_embedding = self.style_embedding_predictor(
            style_input, speaker_embedding=speaker_embedding, locale_embedding=locale_embedding
        )

        duration_input = encoder_output
        if self.use_separate_duration_encoder:
            duration_input = self.separate_duration_encoder(encoder_input, layer_norm_condition=locale_embedding)

        # Make up inputs for duration predictor
        length = duration_input.size(1)
        embeddings = [duration_input]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding)
        duration_input = self.embedding_fuse_layer1(torch.cat(embeddings, dim=-1))

        # Duration prediction in logarithmic domain
        log_duration = self.duration_predictor(duration_input)
        duration = torch.clamp(torch.exp(log_duration) - 1.0, min=0.0)

        if speaking_rate is not None:
            duration = duration / speaking_rate
        duration = torch.round(duration).long()

        # Make up inputs for phone pitch predictor and transformer decoder.
        length = encoder_output.size(1)
        embeddings = [encoder_output]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding)
        encoder_output = self.embedding_fuse_layer2(torch.cat(embeddings, dim=-1))

        # Phone-level pitch predictor
        phone_f0 = self.phone_pitch_predictor(encoder_output, condition=speaker_embedding)

        if f0_scale_ratio is not None:
            scaled_f0 = phone_f0 * f0_var + f0_mean
            scaled_f0 = scaled_f0 * f0_scale_ratio
            scaled_f0 = (scaled_f0 - f0_mean) / f0_var

            f0_scale_mean = f0_scale_ratio.mean()
            phone_f0 = torch.where(
                torch.logical_and(torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)),
                phone_f0,
                scaled_f0,
            )

        phone_f0_embedding = self.phone_pitch_embedding(phone_f0)
        encoder_output = encoder_output + phone_f0_embedding

        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        decoder_output = self.decoder(decoder_input, layer_norm_condition=speaker_embedding)

        mel_spec = self.mel_proj(decoder_output)

        return mel_spec, duration.int()

    def reset_parameters(self):
        # Note: parameter initialization is an important part in transformer based models
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            if p.dim() == 1:
                nn.init.zeros_(p)

        for m in self.modules():
            if isinstance(m, nn.LayerNorm):
                m.reset_parameters()

        nn.init.normal_(self.phone_embedding.weight, 0, self.enc_hidden**-0.5)
        nn.init.normal_(self.mel_proj.weight, 0, self.out_dim**-0.5)

        if self.dec_embedding is not None:
            self.dec_embedding.reset_parameters()

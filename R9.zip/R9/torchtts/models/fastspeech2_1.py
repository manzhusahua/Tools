import torch
import torch.nn as nn

from torchtts.nn.modules.common import GaussianSmoother
from torchtts.nn.modules.common import LayerNorm
from torchtts.nn.modules.common import LengthRegulator
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.modules.fastspeech import DecoderEmbedding
from torchtts.nn.modules.fastspeech import DurationPredictor
from torchtts.nn.modules.fastspeech import PhonePitchPredictor
from torchtts.nn.modules.fastspeech import PhonePitchEmbedding
from torchtts.nn.modules.fastspeech import PositionEmbedding
from torchtts.nn.modules.locale_encoders import LocaleEmbedding
from torchtts.nn.modules.speaker_encoders import SpeakerEmbedding
from torchtts.nn.modules.style_encoders import StyleEmbeddingV2
from torchtts.nn.modules.style_encoders.fine_grained_encoder import FineGrainedLatentEncoder
from torchtts.nn.modules.style_encoders.fine_grained_encoder import FineGrainedLatentPredictor
from torchtts.nn.modules.transformer import PositionalEncoding
from torchtts.nn.modules.transformer import TransformerEncoder
from torchtts.nn.modules.transformer import TransformerEncoderLayer

DEFAULT_MAX_SOURCE_POSITIONS = 1000
DEFAULT_MAX_TARGET_POSITIONS = 10000


class FastSpeech2_1(nn.Module):  # noqa: N801
    """FastSpeech2_1 variant for JointSpeech v1."""

    def __init__(
        self,
        phone_embedding_size,
        phone_embedding_dim=384,
        out_dim=80,
        enc_layers=4,
        enc_hidden=384,
        enc_num_heads=2,
        enc_ffn_dims=(1536, 384),
        enc_ffn_kernels=(9, 1),
        enc_ffn_dilations=(1, 1),
        use_dec_embedding=True,
        use_dec_pos_embedding=True,
        dec_layers=6,
        dec_hidden=384,
        dec_num_heads=2,
        dec_ffn_dims=(1536, 384),
        dec_ffn_kernels=(9, 1),
        dec_ffn_dilations=(1, 1),
        dropout=0.1,
        t2t_compatible=True,
        smoother_params=None,
        use_multi_speaker=False,
        speaker_embedding_size=50,
        speaker_embedding_dim=128,
        use_multi_locale=False,
        locale_embedding_size=50,
        locale_embedding_dim=128,
        use_multi_style=False,
        style_embedding_size=32,
        style_embedding_dim=128,
        use_fine_grained_vae=True,
        use_phone_pitch=True,
        pitch_emb_dim=16,
        dur_pred_layers=2,
        dur_pred_kernel=3,
        dur_pred_filter=256,
        dur_dropout=0.5,
        enable_conditional_layer_norm=False,
    ):
        super(FastSpeech2_1, self).__init__()
        self.enc_hidden = enc_hidden
        self.dec_hidden = dec_hidden
        self.out_dim = out_dim
        self.use_multi_speaker = use_multi_speaker
        self.use_multi_locale = use_multi_locale
        self.use_multi_style = use_multi_style
        self.use_fine_grained_vae = use_fine_grained_vae
        self.use_phone_pitch = use_phone_pitch

        self.phone_embedding = nn.Embedding(
            num_embeddings=phone_embedding_size, embedding_dim=phone_embedding_dim, padding_idx=0
        )

        emb_fuse_in_dim, ref_fuse_in_dim = enc_hidden, out_dim
        if use_multi_speaker:
            self.speaker_embedding = SpeakerEmbedding(speaker_embedding_size, speaker_embedding_dim,
                                                      activation="softsign")
            emb_fuse_in_dim += speaker_embedding_dim
            ref_fuse_in_dim += speaker_embedding_dim

        if use_multi_locale:
            self.locale_embedding = LocaleEmbedding(locale_embedding_size, locale_embedding_dim,
                                                    activation="softsign")
            emb_fuse_in_dim += locale_embedding_dim
            ref_fuse_in_dim += locale_embedding_dim

        if use_multi_style:
            self.style_embedding = StyleEmbeddingV2(style_embedding_size, style_embedding_dim,
                                                    activation="softsign")
            emb_fuse_in_dim += style_embedding_dim
            ref_fuse_in_dim += style_embedding_dim

        self.emb_fuse_layer = nn.Linear(emb_fuse_in_dim, enc_hidden)

        self.enc_pos_encoding = PositionalEncoding(
            model_dim=phone_embedding_dim, dropout=dropout, max_len=DEFAULT_MAX_SOURCE_POSITIONS
        )

        # Encoder layers
        cond_dim = locale_embedding_dim if use_multi_locale and enable_conditional_layer_norm else -1
        encoder_layer = TransformerEncoderLayer(
            model_dim=enc_hidden,
            num_heads=enc_num_heads,
            ffn_dims=enc_ffn_dims,
            ffn_kernels=enc_ffn_kernels,
            ffn_dilations=enc_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
            layer_norm_condition_dim=cond_dim,
        )
        encoder_norm = LayerNorm(enc_hidden, condition_dim=cond_dim)
        self.encoder = TransformerEncoder(encoder_layer=encoder_layer, num_layers=enc_layers, norm=encoder_norm)

        # Fine grained latent encoder (phone level)
        if use_fine_grained_vae:
            self.ref_fuse_layer = nn.Linear(ref_fuse_in_dim, enc_hidden)
            self.ref_pos_encoding = PositionalEncoding(
                model_dim=enc_hidden, dropout=dropout, max_len=DEFAULT_MAX_TARGET_POSITIONS
            )
            self.fine_grained_latent_encoder = FineGrainedLatentEncoder(in_dim=enc_hidden, model_dim=enc_hidden)
            self.fine_grained_latent_predictor = FineGrainedLatentPredictor(in_dim=enc_hidden, out_dim=enc_hidden)
            self.fine_grained_latent_fuse_proj = nn.Linear(enc_hidden + enc_hidden, enc_hidden)

        # Enable phone level pitch condition
        if use_phone_pitch:
            cond_dim = speaker_embedding_dim if self.use_multi_speaker and enable_conditional_layer_norm else -1
            self.phone_pitch_predictor = PhonePitchPredictor(
                in_dim=enc_hidden,
                filter_size=256,
                kernel=3,
                num_layers=2,
                dropout=0.5,
                layer_norm_condition_dim=cond_dim,
            )
            self.phone_pitch_embedding = PhonePitchEmbedding(out_dim=pitch_emb_dim)
            self.phone_pitch_fuse_proj = nn.Linear(enc_hidden + pitch_emb_dim, enc_hidden)

        # Predict duration
        self.duration_predictor = DurationPredictor(
            in_dim=enc_hidden,
            filter_size=dur_pred_filter,
            kernel=dur_pred_kernel,
            num_layers=dur_pred_layers,
            dropout=dur_dropout,
        )

        if smoother_params is not None:
            self.smoother = GaussianSmoother(**smoother_params)

        self.length_regulator = LengthRegulator(smoother=self.smoother)

        if use_dec_embedding:
            self.dec_embedding = DecoderEmbedding(
                symbol_size=phone_embedding_size, embedding_size=dec_hidden, hidden_size=dec_hidden, dropout=dropout
            )

        self.dec_pos_encoding = PositionalEncoding(
            model_dim=enc_hidden, dropout=dropout, max_len=DEFAULT_MAX_TARGET_POSITIONS
        )

        if use_dec_pos_embedding:
            self.dec_pos_embedding = PositionEmbedding()

        # Note: FastSpeech's decoder is the same as encoder.
        cond_dim = speaker_embedding_dim if self.use_multi_speaker and enable_conditional_layer_norm else -1
        decoder_layer = TransformerEncoderLayer(
            model_dim=dec_hidden,
            num_heads=dec_num_heads,
            ffn_dims=dec_ffn_dims,
            ffn_kernels=dec_ffn_kernels,
            ffn_dilations=dec_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
            layer_norm_condition_dim=cond_dim,
        )
        decoder_norm = LayerNorm(dec_hidden, condition_dim=cond_dim)
        self.decoder = TransformerEncoder(encoder_layer=decoder_layer, num_layers=dec_layers, norm=decoder_norm)

        self.mel_proj = nn.Linear(dec_hidden, out_dim, bias=False)

        self.reset_parameters()

    def forward(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        style_id=None,
        src_length=None,
        duration=None,
        tgt_length=None,
        reference=None,
        phone_f0=None,
    ):
        if src_length is not None:
            src_mask = sequence_mask(src_length)
            tgt_mask = sequence_mask(tgt_length)
        else:
            src_mask = None
            tgt_mask = None

        # Phoneme or character embedding
        phone_embedding = self.phone_embedding(phone_id)
        phone_embedding *= self.enc_hidden**0.5
        # Add position encoding to embedding
        encoder_input = self.enc_pos_encoding(phone_embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.unsqueeze(-1))

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.unsqueeze(-1))

        style_embedding = None
        if self.use_multi_style:
            style_embedding = self.style_embedding(style_id.unsqueeze(-1))

        # FFT blocks as encoder
        src_key_padding_mask = ~src_mask if src_mask is not None else None
        encoder_output = self.encoder(
            encoder_input, layer_norm_condition=locale_embedding, src_key_padding_mask=src_key_padding_mask
        )

        # Fuse speaker, locale and style embeddings with encoder output
        length = encoder_output.size(1)
        embeddings = [encoder_output]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding.expand(-1, length, -1))
        encoder_output = self.emb_fuse_layer(torch.cat(embeddings, dim=-1))

        # Style embedding predictor which can run independently during inference.
        pred_fine_grained_latent = target_fine_grained_latent = None
        if self.use_fine_grained_vae:
            pred_fine_grained_latent = self.fine_grained_latent_predictor(encoder_output, mask=src_mask)

            if reference is not None:
                # Fuse speaker, locale and style embeddings with reference
                length = reference.size(1)
                embeddings = [reference]
                if speaker_embedding is not None:
                    embeddings.append(speaker_embedding.expand(-1, length, -1))
                if locale_embedding is not None:
                    embeddings.append(locale_embedding.expand(-1, length, -1))
                if style_embedding is not None:
                    embeddings.append(style_embedding.expand(-1, length, -1))
                reference = self.ref_fuse_layer(torch.cat(embeddings, dim=-1))
                reference = self.ref_pos_encoding(reference)

                tgt_key_padding_mask = ~tgt_mask if tgt_mask is not None else None
                fine_grained_latent = self.fine_grained_latent_encoder(
                    encoder_output,
                    reference,
                    inputs_padding_mask=src_key_padding_mask,
                    reference_padding_mask=tgt_key_padding_mask,
                )
            else:
                fine_grained_latent = pred_fine_grained_latent

            encoder_output = self.fine_grained_latent_fuse_proj(
                torch.cat([encoder_output, fine_grained_latent], dim=-1)
            )

            target_fine_grained_latent = fine_grained_latent.detach()

        # Phone-level pitch predictor
        pred_phone_f0 = None
        if self.use_phone_pitch:
            pred_phone_f0 = self.phone_pitch_predictor(encoder_output, condition=speaker_embedding)
            phone_f0 = pred_phone_f0 if phone_f0 is None else phone_f0.unsqueeze(-1)
            phone_f0_embedding = self.phone_pitch_embedding(phone_f0)
            encoder_output = self.phone_pitch_fuse_proj(torch.cat([encoder_output, phone_f0_embedding], dim=-1))

        # Duration prediction in logarithmic domain
        predicted_duration = self.duration_predictor(encoder_output, src_mask)

        if duration is None:
            duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0)
            duration = torch.round(duration).long()
        tgt_mask = sequence_mask(torch.sum(duration, dim=1))

        # Expand phone level feats to frame level feats. Use ground truth
        # duration if provided.
        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        # Add position encoding to decoder input
        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration, padding_mask=~tgt_mask)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # FFT blocks as decoder
        decoder_output = self.decoder(
            decoder_input, layer_norm_condition=speaker_embedding, src_key_padding_mask=~tgt_mask
        )

        # Project output features like mel
        mel_spec = self.mel_proj(decoder_output)
        mel_spec *= tgt_mask.to(mel_spec.dtype).unsqueeze(-1)
        return (
            mel_spec,
            predicted_duration,
            pred_phone_f0,
            pred_fine_grained_latent,
            target_fine_grained_latent,
            src_mask,
            tgt_mask,
        )

    @torch.no_grad()
    def inference(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        speaking_rate=None,
        f0_scale_ratio=None,
        f0_mean=178.47,
        f0_var=53.47,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
    ):
        # Align with t2t which has 4D input for runtime compatibility
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()

        embedding = self.phone_embedding(phone_id)
        embedding *= self.enc_hidden**0.5
        encoder_input = self.enc_pos_encoding(embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.long())

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.long())

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input, layer_norm_condition=locale_embedding)

        style_input = encoder_output
        if self.use_separate_style_encoder:
            style_input = self.separate_style_encoder(encoder_input, layer_norm_condition=locale_embedding)

        # Style embedding predictor which can run independently during inference.
        style_embedding = self.fine_grained_latent_predictor(
            style_input, speaker_embedding=speaker_embedding, locale_embedding=locale_embedding
        )

        duration_input = encoder_output
        if self.use_separate_duration_encoder:
            duration_input = self.separate_duration_encoder(encoder_input, layer_norm_condition=locale_embedding)

        # Make up inputs for duration predictor
        length = duration_input.size(1)
        embeddings = [duration_input]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding)
        duration_input = self.embedding_fuse_layer1(torch.cat(embeddings, dim=-1))

        # Duration prediction in logarithmic domain
        log_duration = self.duration_predictor(duration_input)
        duration = torch.clamp(torch.exp(log_duration) - 1.0, min=0.0)

        if speaking_rate is not None:
            duration = duration / speaking_rate
        duration = torch.round(duration).long()

        # Make up inputs for phone pitch predictor and transformer decoder.
        length = encoder_output.size(1)
        embeddings = [encoder_output]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding)
        encoder_output = self.embedding_fuse_layer2(torch.cat(embeddings, dim=-1))

        # Phone-level pitch predictor
        phone_f0 = self.phone_pitch_predictor(encoder_output, condition=speaker_embedding)

        if f0_scale_ratio is not None:
            scaled_f0 = phone_f0 * f0_var + f0_mean
            scaled_f0 = scaled_f0 * f0_scale_ratio
            scaled_f0 = (scaled_f0 - f0_mean) / f0_var

            f0_scale_mean = f0_scale_ratio.mean()
            phone_f0 = torch.where(
                torch.logical_and(torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)),
                phone_f0,
                scaled_f0,
            )

        phone_f0_embedding = self.phone_pitch_embedding(phone_f0)
        encoder_output = encoder_output + phone_f0_embedding

        decoder_input, align_mat = self.length_regulator(encoder_output, duration)

        decoder_input = self.dec_pos_encoding(decoder_input)

        if hasattr(self, "dec_embedding"):
            decoder_embedding = self.dec_embedding(phone_id, duration)
            if hasattr(self, "smoother"):
                decoder_embedding = self.smoother(decoder_embedding)
            decoder_input = decoder_input + decoder_embedding

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        decoder_output = self.decoder(decoder_input, layer_norm_condition=speaker_embedding)

        mel_spec = self.mel_proj(decoder_output)

        return mel_spec, duration.int()

    def reset_parameters(self):
        # Note: parameter initialization is an important part in transformer based models
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            if p.dim() == 1:
                nn.init.zeros_(p)

        for m in self.modules():
            if isinstance(m, nn.LayerNorm):
                m.reset_parameters()

        nn.init.normal_(self.phone_embedding.weight, 0, self.enc_hidden**-0.5)
        nn.init.normal_(self.mel_proj.weight, 0, self.out_dim**-0.5)

        if hasattr(self, "dec_embedding"):
            self.dec_embedding.reset_parameters()

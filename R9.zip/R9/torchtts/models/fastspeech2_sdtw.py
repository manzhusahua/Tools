import torch
import torch.nn as nn

from torchtts.nn.modules.common import LayerNorm
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.modules.locale_encoders import LocaleEmbedding
from torchtts.nn.modules.speaker_encoders import SpeakerEmbedding
from torchtts.nn.modules.style_encoders.fine_grained_encoder import StyleEmbeddingPredictor
from torchtts.nn.modules.style_encoders.fine_grained_encoder import FineGrainedEncoder
from torchtts.nn.modules.transformer import PositionalEncoding
from torchtts.nn.modules.transformer import TransformerEncoder
from torchtts.nn.modules.transformer import TransformerEncoderLayer
from torchtts.nn.modules.transformer import TransformerSoftEncoder
from torchtts.nn.modules.transformer import TransformerSoftEncoderLayer
from torchtts.nn.modules.soft_dtw.learned_upsampling import SoftLengthRegulator

DEFAULT_MAX_SOURCE_POSITIONS = 1000
DEFAULT_MAX_TARGET_POSITIONS = 10000


class FastSpeech2SDTW(nn.Module):
    """FastSpeech2 variant for UniTTS V3."""

    def __init__(
        self,
        phone_embedding_size,
        phone_embedding_dim=384,
        out_dim=80,
        enc_layers=4,
        enc_hidden=384,
        enc_num_heads=2,
        enc_ffn_dims=(1536, 384),
        enc_ffn_kernels=(9, 1),
        enc_ffn_dilations=(1, 1),
        dec_layers=6,
        dec_hidden=384,
        dec_num_heads=2,
        dec_ffn_dims=(1536, 384),
        dec_ffn_kernels=(9, 1),
        dec_ffn_dilations=(1, 1),
        dropout=0.1,
        t2t_compatible=True,
        use_multi_speaker=False,
        speaker_embedding_size=50,
        speaker_embedding_dim=128,
        use_multi_locale=False,
        locale_embedding_size=50,
        locale_embedding_dim=128,
        enable_conditional_layer_norm=False,
        use_separate_style_encoder=False,
        separate_style_enc_layers=2,
        use_separate_duration_encoder=False,
        separate_dur_enc_layers=2,
        enable_soft_decoder=False,
        enable_phone_vae=False,
        vae_style_dim=16,
        vae_tau=0.5,
    ):
        super(FastSpeech2SDTW, self).__init__()
        self.enc_hidden = enc_hidden
        self.dec_hidden = dec_hidden
        self.out_dim = out_dim
        self.use_multi_speaker = use_multi_speaker
        self.use_multi_locale = use_multi_locale
        self.use_separate_style_encoder = use_separate_style_encoder
        self.use_separate_duration_encoder = use_separate_duration_encoder
        self.enable_soft_decoder = enable_soft_decoder
        self.dec_layers = dec_layers
        self.enable_phone_vae = enable_phone_vae
        self.vae_style_dim = vae_style_dim

        if self.enable_phone_vae:
            self.tau = vae_tau
            self.vae_bn_mean = nn.BatchNorm1d(vae_style_dim, affine=False, eps=1e-08)
            self.vae_bn_std = nn.BatchNorm1d(vae_style_dim, affine=False, eps=1e-08)
            self.scale = nn.Parameter(torch.FloatTensor(vae_style_dim).zero_())

        self.phone_embedding = nn.Embedding(
            num_embeddings=phone_embedding_size, embedding_dim=phone_embedding_dim, padding_idx=0
        )

        embedding_fuse_in_dim = enc_hidden
        if use_multi_speaker:
            self.speaker_embedding = SpeakerEmbedding(speaker_embedding_size, speaker_embedding_dim)
            embedding_fuse_in_dim += speaker_embedding_dim

        if use_multi_locale:
            self.locale_embedding = LocaleEmbedding(locale_embedding_size, locale_embedding_dim)
            embedding_fuse_in_dim += locale_embedding_dim

        # Fine grained style encoder (phone level)
        fine_grained_encoder_out_dim = vae_style_dim * 2 if enable_phone_vae else enc_hidden
        self.fine_grained_style_encoder = FineGrainedEncoder(
            in_dim=out_dim,
            speaker_embedding_dim=speaker_embedding_dim,
            locale_embedding_dim=locale_embedding_dim,
            model_dim=enc_hidden,
            out_dim=fine_grained_encoder_out_dim,
        )

        embedding_fuse_in_dim += enc_hidden if not enable_phone_vae else vae_style_dim
        style_embedding_predictor_out_dim = vae_style_dim if enable_phone_vae else enc_hidden
        self.style_embedding_predictor = StyleEmbeddingPredictor(
            in_dim=enc_hidden,
            out_dim=style_embedding_predictor_out_dim,
            speaker_embedding_dim=speaker_embedding_dim,
            locale_embedding_dim=locale_embedding_dim,
        )

        self.embedding_fuse_layer1 = nn.Linear(embedding_fuse_in_dim, enc_hidden)

        self.enc_pos_encoding = PositionalEncoding(
            model_dim=phone_embedding_dim, dropout=dropout, max_len=DEFAULT_MAX_SOURCE_POSITIONS
        )

        # Encoder layers
        cond_dim = locale_embedding_dim if use_multi_locale and enable_conditional_layer_norm else -1
        encoder_layer = TransformerEncoderLayer(
            model_dim=enc_hidden,
            num_heads=enc_num_heads,
            ffn_dims=enc_ffn_dims,
            ffn_kernels=enc_ffn_kernels,
            ffn_dilations=enc_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
            layer_norm_condition_dim=cond_dim,
        )
        encoder_norm = LayerNorm(enc_hidden, condition_dim=cond_dim)
        self.encoder = TransformerEncoder(encoder_layer=encoder_layer, num_layers=enc_layers, norm=encoder_norm)

        if use_separate_duration_encoder:
            encoder_layer = TransformerEncoderLayer(
                model_dim=enc_hidden,
                num_heads=enc_num_heads,
                ffn_dims=enc_ffn_dims,
                ffn_kernels=enc_ffn_kernels,
                ffn_dilations=enc_ffn_dilations,
                t2t_compatible=t2t_compatible,
                dropout=dropout,
                layer_norm_condition_dim=cond_dim,
            )
            encoder_norm = LayerNorm(enc_hidden, condition_dim=cond_dim)
            self.separate_duration_encoder = TransformerEncoder(
                encoder_layer=encoder_layer, num_layers=separate_dur_enc_layers, norm=encoder_norm
            )

        if use_separate_style_encoder:
            encoder_layer = TransformerEncoderLayer(
                model_dim=enc_hidden,
                num_heads=enc_num_heads,
                ffn_dims=enc_ffn_dims,
                ffn_kernels=enc_ffn_kernels,
                ffn_dilations=enc_ffn_dilations,
                t2t_compatible=t2t_compatible,
                dropout=dropout,
                layer_norm_condition_dim=cond_dim,
            )
            encoder_norm = LayerNorm(enc_hidden, condition_dim=cond_dim)
            self.separate_style_encoder = TransformerEncoder(
                encoder_layer=encoder_layer, num_layers=separate_style_enc_layers, norm=encoder_norm
            )

        self.soft_lengthregulator = SoftLengthRegulator(
            in_dim=enc_hidden,
            num_heads=enc_num_heads,
            ffn_dims=enc_ffn_dims,
            enc_ffn_kernels=enc_ffn_kernels,
            enc_ffn_dilations=enc_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
            cond_dim=cond_dim,
        )

        self.dec_pos_encoding = PositionalEncoding(
            model_dim=enc_hidden, dropout=dropout, max_len=DEFAULT_MAX_TARGET_POSITIONS
        )

        # Note: FastSpeech's decoder is the same as encoder.
        cond_dim = speaker_embedding_dim if self.use_multi_speaker and enable_conditional_layer_norm else -1
        if enable_soft_decoder:
            decoder_layer = TransformerSoftEncoderLayer(
                model_dim=dec_hidden,
                num_heads=dec_num_heads,
                ffn_dims=dec_ffn_dims,
                ffn_kernels=dec_ffn_kernels,
                ffn_dilations=dec_ffn_dilations,
                t2t_compatible=t2t_compatible,
                dropout=dropout,
                layer_norm_condition_dim=cond_dim,
                enable_soft_dtw=True,
            )
            decoder_norm = LayerNorm(dec_hidden, condition_dim=cond_dim)
            self.decoder = TransformerSoftEncoder(
                encoder_layer=decoder_layer, num_layers=dec_layers, norm=decoder_norm, enable_soft_dtw=True
            )
        else:
            decoder_layer = TransformerEncoderLayer(
                model_dim=dec_hidden,
                num_heads=dec_num_heads,
                ffn_dims=dec_ffn_dims,
                ffn_kernels=dec_ffn_kernels,
                ffn_dilations=dec_ffn_dilations,
                t2t_compatible=t2t_compatible,
                dropout=dropout,
                layer_norm_condition_dim=cond_dim,
            )
            decoder_norm = LayerNorm(dec_hidden, condition_dim=cond_dim)
            self.decoder = TransformerEncoder(encoder_layer=decoder_layer, num_layers=dec_layers, norm=decoder_norm)

        self.mel_proj = nn.Linear(dec_hidden, out_dim, bias=False)

        self.reset_parameters()

    def forward(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        src_length=None,
        duration=None,
        tgt_length=None,
        reference=None,
        phone_f0=None,
        use_pred_style_embedding=False,
    ):
        if src_length is not None:
            src_mask = sequence_mask(src_length)
            tgt_mask = sequence_mask(tgt_length)
        else:
            src_mask = None
            tgt_mask = None

        # Phoneme or character embedding
        phone_embedding = self.phone_embedding(phone_id)
        phone_embedding *= self.enc_hidden**0.5
        # Add position encoding to embedding
        encoder_input = self.enc_pos_encoding(phone_embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.unsqueeze(-1))

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.unsqueeze(-1))

        # FFT blocks as encoder
        encoder_output = self.encoder(
            encoder_input, layer_norm_condition=locale_embedding, src_key_padding_mask=~src_mask
        )

        style_input = encoder_output
        if self.use_separate_style_encoder:
            style_input = self.separate_style_encoder(
                encoder_input, layer_norm_condition=locale_embedding, src_key_padding_mask=~src_mask
            )

        # Style embedding predictor which can run independently during inference.
        pred_style_embedding = self.style_embedding_predictor(
            style_input, speaker_embedding=speaker_embedding, locale_embedding=locale_embedding, mask=src_mask
        )

        if reference is not None:
            style_embedding = self.fine_grained_style_encoder(
                encoder_output,
                reference,
                style_input_padding_mask=~src_mask,
                reference_padding_mask=~tgt_mask,
                speaker_embedding=speaker_embedding,
                locale_embedding=locale_embedding,
            )
            if self.enable_phone_vae:
                ph_z_mu = style_embedding[:, :, : self.vae_style_dim]
                ph_z_log_sigma2 = style_embedding[:, :, self.vae_style_dim :]
                ph_z_mu = self.vae_bn_mean(ph_z_mu.transpose(1, 2)).transpose(1, 2)
                ph_z_mu = self.vae_bn_normalized(ph_z_mu, model="positive")
                ph_z_log_sigma2 = self.vae_bn_std(ph_z_log_sigma2.transpose(1, 2)).transpose(1, 2)
                ph_z_log_sigma2 = self.vae_bn_normalized(ph_z_log_sigma2, model="negative")
                style_embedding = self.reparameterize(ph_z_mu, ph_z_log_sigma2)
                kl_tuple = (ph_z_mu, ph_z_log_sigma2)
            else:
                kl_tuple = None
        else:
            style_embedding = pred_style_embedding

        target_style_embedding = style_embedding.detach() if not self.enable_phone_vae else ph_z_mu.detach()

        duration_input = encoder_output
        if self.use_separate_duration_encoder:
            duration_input = self.separate_duration_encoder(
                encoder_input, layer_norm_condition=locale_embedding, src_key_padding_mask=~src_mask
            )

        # Make up inputs for duration predictor
        length = duration_input.size(1)
        embeddings = [duration_input]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            if not use_pred_style_embedding:
                embeddings.append(style_embedding)
            else:
                embeddings.append(pred_style_embedding)
        duration_input = self.embedding_fuse_layer1(torch.cat(embeddings, dim=-1))

        decoder_input, pred_dur, cross_attention = self.soft_lengthregulator(
            duration_input,
            phs_mask=src_mask,
            layer_norm_condition=speaker_embedding,
            total_duration_groundtruth=tgt_length,
        )

        # Add position encoding to decoder input
        decoder_input = self.dec_pos_encoding(decoder_input)

        # FFT blocks as decoder
        if self.enable_soft_decoder:
            decoder_output, pred_dur_list, cross_attention_list = self.decoder(
                decoder_input,
                encoder_output=duration_input,
                layer_norm_condition=speaker_embedding,
                src_key_padding_mask=~tgt_mask,
                phs_mask=src_mask,
                tgt_length=tgt_length,
            )
            pred_dur_list.insert(0, pred_dur)
            cross_attention_list.insert(0, cross_attention)
        else:
            decoder_output = self.decoder(
                decoder_input, layer_norm_condition=speaker_embedding, src_key_padding_mask=~tgt_mask
            )

        # Project output features like mel
        mel_spec = self.mel_proj(decoder_output)
        mel_spec *= tgt_mask.to(mel_spec.dtype).unsqueeze(-1)

        if not self.enable_soft_decoder:
            pred_dur_list = [pred_dur]
            cross_attention_list = [cross_attention]

        return (
            mel_spec,
            pred_dur_list,
            cross_attention_list,
            pred_style_embedding,
            target_style_embedding,
            src_mask,
            tgt_mask,
            kl_tuple,
        )

    @torch.no_grad()
    def inference(
        self,
        phone_id,
        speaker_id=None,
        locale_id=None,
        speaking_rate=None,
        f0_scale_ratio=None,
        f0_mean=178.47,
        f0_var=53.47,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
        reference=None,
        export_onnx=True,
    ):
        # Align with t2t which has 4D input for runtime compatibility
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()

        embedding = self.phone_embedding(phone_id)
        embedding *= self.enc_hidden**0.5
        encoder_input = self.enc_pos_encoding(embedding)

        speaker_embedding = None
        if self.use_multi_speaker:
            speaker_embedding = self.speaker_embedding(speaker_id.long())

        locale_embedding = None
        if self.use_multi_locale:
            locale_embedding = self.locale_embedding(locale_id.long())

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input, layer_norm_condition=locale_embedding)

        style_input = encoder_output
        if self.use_separate_style_encoder:
            style_input = self.separate_style_encoder(encoder_input, layer_norm_condition=locale_embedding)

            # Style embedding predictor which can run independently during inference.
        if reference is not None:
            style_embedding = self.fine_grained_style_encoder(
                encoder_output,
                reference,
                style_input_padding_mask=None,
                reference_padding_mask=None,
                speaker_embedding=speaker_embedding,
                locale_embedding=locale_embedding,
            )
        else:
            style_embedding = self.style_embedding_predictor(
                style_input, speaker_embedding=speaker_embedding, locale_embedding=locale_embedding
            )

        duration_input = encoder_output
        if self.use_separate_duration_encoder:
            duration_input = self.separate_duration_encoder(encoder_input, layer_norm_condition=locale_embedding)

        # Make up inputs for duration predictor
        length = duration_input.size(1)
        embeddings = [duration_input]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding)
        duration_input = self.embedding_fuse_layer1(torch.cat(embeddings, dim=-1))

        cross_attention = None

        decoder_input, duration, cross_attention = self.soft_lengthregulator(
            duration_input, layer_norm_condition=speaker_embedding, speaking_rate=speaking_rate
        )

        decoder_input = self.dec_pos_encoding(decoder_input)

        cross_attention_list = [cross_attention]
        if self.enable_soft_decoder:
            total_duration = torch.ceil(torch.sum(duration, dim=-1))
            total_duration = torch.clamp(total_duration, min=1.0, max=DEFAULT_MAX_TARGET_POSITIONS)
            decoder_output, _, cross_attention_list_decoder = self.decoder(
                decoder_input,
                encoder_output=duration_input,
                layer_norm_condition=speaker_embedding,
                speaking_rate=speaking_rate,
                tgt_length=total_duration,
            )
            cross_attention_list.extend(cross_attention_list_decoder)
        else:
            decoder_output = self.decoder(decoder_input, layer_norm_condition=speaker_embedding)

        mel_spec = self.mel_proj(decoder_output)

        if export_onnx:
            return mel_spec, duration.int()
        else:
            return mel_spec, duration.int(), cross_attention_list

    def reset_parameters(self):
        # Note: parameter initialization is an important part in transformer based models
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            if p.dim() == 1:
                nn.init.zeros_(p)

        for m in self.modules():
            if isinstance(m, nn.LayerNorm):
                m.reset_parameters()

        nn.init.normal_(self.phone_embedding.weight, 0, self.enc_hidden**-0.5)
        nn.init.normal_(self.mel_proj.weight, 0, self.out_dim**-0.5)

    def reparameterize(self, mu, log_var):
        std = torch.exp(log_var / 2)
        eps = torch.randn_like(std)
        return mu + eps * std

    def vae_bn_normalized(self, inputs, model="positive"):
        if model == "positive":
            scale = self.tau + (1 - self.tau) * torch.sigmoid(self.scale)
        else:
            scale = (1 - self.tau) * torch.sigmoid(-self.scale)

        return inputs * torch.sqrt(scale)

import copy
import logging

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchaudio.transforms import Resample

from torchtts.nn.modules.common.functional import stft
from torchtts.models.hifinet.discriminator_layers import NLayerDiscriminator
from torchtts.models.hifinet.discriminator_layers import NLayerSpecDiscriminator
from torchtts.models.hifinet.discriminator_layers import NLayerMPDiscriminator

from torchtts.nn.modules.codec.dwt import Dwt1D
from torch.nn import Conv1d


class HiFiGANPeriodDiscriminator(torch.nn.Module):
    """HiFiGAN period discriminator module."""

    def __init__(
        self,
        in_channels=1,
        out_channels=1,
        period=3,
        kernel_sizes=(5, 3),
        channels=32,
        downsample_scales=(3, 3, 3, 3, 1),
        max_downsample_channels=512,
        bias=True,
        nonlinear_activation="LeakyReLU",
        nonlinear_activation_params=None,
        use_weight_norm=True,
        use_spectral_norm=False,
    ):
        """Initialize HiFiGANPeriodDiscriminator module.
        Args:
            in_channels (int): Number of input channels.
            out_channels (int): Number of output channels.
            period (int): Period.
            kernel_sizes (list): Kernel sizes of initial conv layers and the final conv layer.
            channels (int): Number of initial channels.
            downsample_scales (list): List of downsampling scales.
            max_downsample_channels (int): Number of maximum downsampling channels.
            use_additional_convs (bool): Whether to use additional conv layers in residual blocks.
            bias (bool): Whether to add bias parameter in convolution layers.
            nonlinear_activation (str): Activation function module name.
            nonlinear_activation_params (dict): Hyperparameters for activation function.
            use_weight_norm (bool): Whether to use weight norm.
                If set to true, it will be applied to all of the conv layers.
            use_spectral_norm (bool): Whether to use spectral norm.
                If set to true, it will be applied to all of the conv layers.
        """
        super().__init__()
        assert len(kernel_sizes) == 2
        assert kernel_sizes[0] % 2 == 1, "Kernel size must be odd number."
        assert kernel_sizes[1] % 2 == 1, "Kernel size must be odd number."

        self.period = period
        self.convs = torch.nn.ModuleList()
        in_chs = in_channels
        out_chs = channels
        for downsample_scale in downsample_scales:
            self.convs += [
                torch.nn.Sequential(
                    torch.nn.Conv2d(
                        in_chs,
                        out_chs,
                        (kernel_sizes[0], 1),
                        (downsample_scale, 1),
                        padding=((kernel_sizes[0] - 1) // 2, 0),
                    ),
                    getattr(torch.nn, nonlinear_activation)(**nonlinear_activation_params),
                )
            ]
            in_chs = out_chs
            # NOTE(kan-bayashi): Use downsample_scale + 1?
            out_chs = min(out_chs * 4, max_downsample_channels)
        self.output_conv = torch.nn.Conv2d(
            out_chs,
            out_channels,
            (kernel_sizes[1] - 1, 1),
            1,
            padding=((kernel_sizes[1] - 1) // 2, 0),
        )

        if use_weight_norm and use_spectral_norm:
            raise ValueError("Either use use_weight_norm or use_spectral_norm.")

        # apply weight norm
        if use_weight_norm:
            self.apply_weight_norm()

        # apply spectral norm
        if use_spectral_norm:
            self.apply_spectral_norm()

    def forward(self, x):
        """Calculate forward propagation.
        Args:
            c (Tensor): Input tensor (B, in_channels, T).
        Returns:
            list: List of each layer's tensors.
        """
        # transform 1d to 2d -> (B, C, T/P, P)
        b, c, t = x.shape
        if t % self.period != 0:
            n_pad = self.period - (t % self.period)
            x = F.pad(x, (0, n_pad), "reflect")
            t += n_pad
        x = x.view(b, c, t // self.period, self.period)

        # forward conv
        outs = []
        for layer in self.convs:
            x = layer(x)
            outs += [x]
        x = self.output_conv(x)
        x = torch.flatten(x, 1, -1)
        outs += [x]

        return outs

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, torch.nn.Conv2d):
                torch.nn.utils.weight_norm(m)
                logging.debug(f"Weight norm is applied to {m}.")

        self.apply(_apply_weight_norm)

    def apply_spectral_norm(self):
        """Apply spectral normalization module from all of the layers."""

        def _apply_spectral_norm(m):
            if isinstance(m, torch.nn.Conv2d):
                torch.nn.utils.spectral_norm(m)
                logging.debug(f"Spectral norm is applied to {m}.")

        self.apply(_apply_spectral_norm)


class HiFiGANMultiPeriodDiscriminator(torch.nn.Module):
    """HiFiGAN multi-period discriminator module."""

    def __init__(
        self,
        periods=(2, 3, 5, 7, 11),
        discriminator_params=None,
    ):
        """Initialize HiFiGANMultiPeriodDiscriminator module.
        Args:
            periods (list): List of periods.
            discriminator_params (dict): Parameters for hifi-gan period discriminator module.
                The period parameter will be overwritten.
        """
        super().__init__()
        self.discriminators = torch.nn.ModuleList()
        for period in periods:
            params = copy.deepcopy(discriminator_params)
            params["period"] = period
            self.discriminators += [HiFiGANPeriodDiscriminator(**params)]

    def forward(self, x):
        """Calculate forward propagation.
        Args:
            x (Tensor): Input noise signal (B, 1, T).
        Returns:
            List: List of list of each discriminator outputs, which consists of each layer output tensors.
        """
        outs = []
        for f in self.discriminators:
            outs += [f(x)]

        return outs


class TimeDiscriminator(nn.Module):
    def __init__(
        self,
        num_disc=3,
        in_channels=1,
        out_channels=1,
        kernel_sizes=(5, 3),
        channels=16,
        max_downsample_channels=1024,
        downsample_scales=(4, 4, 4, 4),
        downsample_method="avg_pool",
        use_weight_norm=True,
        use_dwt=False,
        hierachical_dwt=False,
    ):
        super().__init__()

        self.model = nn.ModuleDict()
        self.use_dwt = use_dwt
        self.hierachical_dwt = hierachical_dwt

        if hierachical_dwt:
            self.dwt1d = Dwt1D()
            for i in range(num_disc):
                self.model["disc_" + str(i)] = NLayerDiscriminator(
                    in_channels=in_channels * 2**i,
                    out_channels=out_channels,
                    kernel_sizes=kernel_sizes,
                    channels=channels,
                    max_downsample_channels=max_downsample_channels,
                    downsample_scales=downsample_scales,
                )
        else:
            if use_dwt and not hierachical_dwt:
                self.dwt1d = Dwt1D()
                self.dwt_convs = nn.ModuleDict()

            for i in range(num_disc):
                self.model["disc_" + str(i)] = NLayerDiscriminator(
                    in_channels=in_channels,
                    out_channels=out_channels,
                    kernel_sizes=kernel_sizes,
                    channels=channels,
                    max_downsample_channels=max_downsample_channels,
                    downsample_scales=downsample_scales,
                )

                if use_dwt and not hierachical_dwt and i != num_disc - 1:
                    self.dwt_convs["disc_" + str(i)] = Conv1d(2, 1, 1)

        if downsample_method == "avg_pool":
            self.downsample = nn.AvgPool1d(4, stride=2, padding=1, count_include_pad=False)
        elif downsample_method == "resample":
            self.downsample = Resample(orig_freq=2, new_freq=1)
        else:
            raise ValueError("Only avg_pool and resample can be specified as downsample_method")

        if use_weight_norm:
            self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, x):
        results = []

        if self.hierachical_dwt:
            prev = [x]
            for i, disc in enumerate(self.model.values()):
                results.append(disc(x))
                if i < len(self.model) - 1:
                    tmp = []
                    for elem in prev:
                        y_hi, y_lo = self.dwt1d(elem)
                        tmp.extend([y_hi, y_lo])
                    x = torch.cat(tmp, dim=1)
                    prev = tmp
        else:
            for name, disc in self.model.items():
                results.append(disc(x))

                if self.use_dwt and name in self.dwt_convs:
                    y_hi, y_lo = self.dwt1d(x)
                    x = self.dwt_convs[name](torch.cat([y_hi, y_lo], dim=1))
                else:
                    x = self.downsample(x)
        return results

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):
        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)

        self.apply(_reset_parameters)


class SpecDiscriminator(nn.Module):
    def __init__(
        self,
        stft_params=None,
        in_channels=1,
        out_channels=1,
        kernel_sizes=(7, 3),
        channels=32,
        max_downsample_channels=512,
        downsample_scales=(2, 2, 2),
        use_weight_norm=True,
    ):
        super().__init__()

        if stft_params is None:
            stft_params = {
                "fft_sizes": [1024, 2048, 512],
                "hop_sizes": [120, 240, 50],
                "win_lengths": [600, 1200, 240],
                "window": "hann_window",
            }

        self.stft_params = stft_params

        self.model = nn.ModuleDict()
        for i in range(len(stft_params["fft_sizes"])):
            self.model["disc_" + str(i)] = NLayerSpecDiscriminator(
                in_channels=in_channels,
                out_channels=out_channels,
                kernel_sizes=kernel_sizes,
                channels=channels,
                max_downsample_channels=max_downsample_channels,
                downsample_scales=downsample_scales,
            )

        if use_weight_norm:
            self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, x):
        results = []
        i = 0
        x = x.squeeze(1)
        for _, disc in self.model.items():
            spec = stft(
                x,
                self.stft_params["fft_sizes"][i],
                self.stft_params["hop_sizes"][i],
                self.stft_params["win_lengths"][i],
                window=getattr(torch, self.stft_params["window"])(self.stft_params["win_lengths"][i]),
            )
            spec = spec.transpose(1, 2).unsqueeze(1)
            results.append(disc(spec))
            i += 1
        return results

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):
        """Reset parameters."""

        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)

        self.apply(_reset_parameters)


# Refer to HiFi-GAN: Generative Adversarial Networks for Efficient and High Fidelity Speech Synthesis
# Introduced MPD (Multi-Period Discriminator)
# https://arxiv.org/abs/2010.05646
# https://github.com/jik876/hifi-gan/blob/master/models.py
class MultiPeriodDiscriminator(nn.Module):
    def __init__(
        self,
        period_params=(2, 3, 5, 7, 11),
        kernel_size=5,
        stride=3,
        in_channels=1,
        out_channels=1,
        channels=32,
        max_downsample_channels=1024,
        downsample_scales=(4, 4, 2, 1),
        use_weight_norm=True,
    ):
        super().__init__()

        self.model = nn.ModuleDict()
        for i in range(len(period_params)):
            self.model["mpd_" + str(i)] = NLayerMPDiscriminator(
                period_params[i],
                kernel_size=kernel_size,
                stride=stride,
                in_channels=in_channels,
                out_channels=out_channels,
                channels=channels,
                max_downsample_channels=max_downsample_channels,
                downsample_scales=downsample_scales,
            )

        if use_weight_norm:
            self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, y, y_hat):
        y_d_rs = []
        y_d_gs = []
        fmap_rs = []
        fmap_gs = []

        for _i, d in self.model.items():
            y_d_r, fmap_r = d(y)
            y_d_g, fmap_g = d(y_hat)
            y_d_rs.append(y_d_r)
            fmap_rs.append(fmap_r)
            y_d_gs.append(y_d_g)
            fmap_gs.append(fmap_g)

        return y_d_rs, y_d_gs, fmap_rs, fmap_gs

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):
        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)

        self.apply(_reset_parameters)

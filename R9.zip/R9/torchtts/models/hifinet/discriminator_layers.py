import torch.nn as nn
import torch.nn.functional as F
import torch
import numpy as np


class NLayerDiscriminator(nn.Module):
    def __init__(
        self,
        in_channels=1,
        out_channels=1,
        kernel_sizes=(5, 3),
        channels=16,
        max_downsample_channels=512,
        downsample_scales=(4, 4, 4),
    ):
        super().__init__()

        # check kernel size is valid
        assert len(kernel_sizes) == 2
        assert kernel_sizes[0] % 2 == 1
        assert kernel_sizes[1] % 2 == 1

        model = nn.ModuleDict()

        model["layer_0"] = nn.Sequential(
            nn.Conv1d(
                in_channels, channels, kernel_size=np.prod(kernel_sizes), padding=(np.prod(kernel_sizes) - 1) // 2
            ),
            nn.LeakyReLU(0.2, True),
        )

        in_chs = channels
        for i, downsample_scale in enumerate(downsample_scales):
            out_chs = min(in_chs * downsample_scale, max_downsample_channels)

            model["layer_%d" % (i + 1)] = nn.Sequential(
                nn.Conv1d(
                    in_chs,
                    out_chs,
                    kernel_size=downsample_scale * 10 + 1,
                    stride=downsample_scale,
                    groups=in_chs // 4,
                ),
                nn.LeakyReLU(0.2, True),
            )
            in_chs = out_chs

        out_chs = min(in_chs * 2, max_downsample_channels)
        model["layer_%d" % (len(downsample_scales) + 2)] = nn.Sequential(
            nn.Conv1d(in_chs, out_chs, kernel_size=kernel_sizes[0], padding=(kernel_sizes[0] - 1) // 2),
            nn.LeakyReLU(0.2, True),
        )

        model["layer_%d" % (len(downsample_scales) + 3)] = nn.Conv1d(
            out_chs, out_channels, kernel_size=kernel_sizes[1], padding=(kernel_sizes[1] - 1) // 2
        )

        self.model = model

    def forward(self, x):
        results = []
        for _, layer in self.model.items():
            x = layer(x)
            results.append(x)
        return results


class NLayerSpecDiscriminator(nn.Module):
    def __init__(
        self,
        in_channels=1,
        out_channels=1,
        kernel_sizes=(5, 3),
        channels=32,
        max_downsample_channels=512,
        downsample_scales=(2, 2, 2),
    ):
        super().__init__()

        # check kernel size is valid
        assert kernel_sizes[0] % 2 == 1
        assert kernel_sizes[1] % 2 == 1

        model = nn.ModuleDict()

        model["layer_0"] = nn.Sequential(
            nn.Conv2d(in_channels, channels, kernel_size=kernel_sizes[0], stride=2, padding=kernel_sizes[0] // 2),
            nn.LeakyReLU(0.2, True),
        )

        in_chs = channels
        for i, downsample_scale in enumerate(downsample_scales):
            out_chs = min(in_chs * downsample_scale, max_downsample_channels)

            model[f"layer_{i + 1}"] = nn.Sequential(
                nn.Conv2d(
                    in_chs,
                    out_chs,
                    kernel_size=downsample_scale * 2 + 1,
                    stride=downsample_scale,
                ),
                nn.LeakyReLU(0.2, True),
            )
            in_chs = out_chs

        out_chs = min(in_chs * 2, max_downsample_channels)
        model[f"layer_{len(downsample_scales) + 1}"] = nn.Sequential(
            nn.Conv2d(in_chs, out_chs, kernel_size=kernel_sizes[1], padding=kernel_sizes[1] // 2),
            nn.LeakyReLU(0.2, True),
        )

        model[f"layer_{len(downsample_scales) + 2}"] = nn.Conv2d(
            out_chs, out_channels, kernel_size=kernel_sizes[1], padding=kernel_sizes[1] // 2
        )

        self.model = model

    def forward(self, x):
        results = []
        for _, layer in self.model.items():
            x = layer(x)
            results.append(x)
        return results


class NLayerMPDiscriminator(nn.Module):
    def __init__(
        self,
        period,
        kernel_size=5,
        stride=3,
        in_channels=1,
        out_channels=1,
        channels=32,
        max_downsample_channels=1024,
        downsample_scales=(4, 4, 2, 1),
    ):
        super().__init__()

        self.period = period
        model = nn.ModuleDict()
        in_chs = in_channels
        out_chs = channels

        pad_f = (self.get_padding(5, 1), 0)

        # layer_0 (1,32)
        model["layer_0"] = nn.Sequential(
            nn.Conv2d(
                in_chs,
                out_chs,
                kernel_size=(kernel_size, 1),
                stride=(stride, 1),
                padding=pad_f,
            ),
        )

        in_chs = channels
        # layer_ 1-4 (32,128) (128,512) (512,1024) (1024,1024)
        for i, downsample_scale in enumerate(downsample_scales):
            out_chs = min(in_chs * downsample_scale, max_downsample_channels)

            if (i + 1) == len(downsample_scales):  # last layer
                pad_f = (2, 0)
            model[f"layer_{i + 1}"] = nn.Sequential(
                nn.Conv2d(
                    in_chs,
                    out_chs,
                    kernel_size=(kernel_size, 1),
                    stride=(stride, 1),
                    padding=pad_f,
                ),
                nn.LeakyReLU(0.1, True),
            )
            in_chs = out_chs

        # post layer as layer_5 (1024, 1)
        model[f"layer_{len(downsample_scales) + 1}"] = nn.Sequential(
            nn.Conv2d(in_chs, 1, (3, 1), 1, padding=(1, 0)),
        )

        self.model = model

    def forward(self, x):
        fmap = []

        # 1d to 2d
        b, c, t = x.shape
        if t % self.period != 0:  # pad first
            n_pad = self.period - (t % self.period)
            x = F.pad(x, (0, n_pad), "reflect")
            t = t + n_pad
        x = x.view(b, c, t // self.period, self.period)

        for _, layer in self.model.items():
            x = layer(x)
            fmap.append(x)
        x = torch.flatten(x, 1, -1)

        return x, fmap

    def get_padding(self, kernel_size, dilation=1):
        return int((kernel_size * dilation - dilation) / 2)

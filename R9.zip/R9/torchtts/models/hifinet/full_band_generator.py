import numpy as np
import torch
import torch.nn as nn

from torchtts.nn.modules.hifinet.gru import GRU
from torchtts.nn.modules.hifinet.resnet_block import ResnetBlock


class FullBandGenerator(nn.Module):
    def __init__(
        self,
        in_channels=80,
        ngf=32,
        n_residual_layers=(3, 3, 3, 3),
        dropout=0.1,
        use_rnn=True,
        rnn_bidirectional=True,
        rnn_num_layers=1,
        rnn_dropout=0.0,
        up_ratios=(3, 4, 5, 5),
        use_weight_norm=True,
    ):
        super().__init__()
        self.hop_length = np.prod(up_ratios)
        self.ngf = ngf
        self.up_ratios = up_ratios
        mul = int(2 ** len(up_ratios))

        self.model = nn.ModuleDict()

        pre_model = [
            nn.ReflectionPad1d(3),
            nn.Conv1d(in_channels, mul * ngf, kernel_size=7),
            nn.LeakyReLU(0.2),
        ]

        if use_rnn:
            pre_model += [
                nn.Dropout(dropout),
                GRU(
                    in_size=mul * ngf,
                    out_size=mul * ngf,
                    num_layers=rnn_num_layers,
                    bidirectional=rnn_bidirectional,
                    dropout=rnn_dropout,
                ),
            ]

        self.model["pre_model"] = nn.Sequential(*pre_model)

        # Upsample to raw audio scale
        for i, r in enumerate(up_ratios):
            upsample_model = [
                nn.ConvTranspose1d(
                    in_channels=mul * ngf,
                    out_channels=mul * ngf // 2,
                    kernel_size=r * 2,
                    stride=r,
                    padding=r // 2 + r % 2,
                    output_padding=r % 2,
                ),
            ]

            for j in range(n_residual_layers[i]):
                upsample_model += [ResnetBlock(mul * ngf // 2, dilation=3 ** j)]

            upsample_model += [nn.LeakyReLU(0.2)]

            mul //= 2

            self.model[f"upsample_{i}"] = nn.Sequential(*upsample_model)

        self.model["post_model"] = nn.Sequential(
            nn.ReflectionPad1d(3),
            nn.Conv1d(ngf, 1, kernel_size=7),
            nn.Tanh(),
        )

        if use_weight_norm:
            self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, x):
        for _, layer in self.model.items():
            x = layer(x)
        return x

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):
        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)

        self.apply(_reset_parameters)

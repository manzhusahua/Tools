import numpy as np
import torch
import torch.nn as nn

from torchtts.models.hifinet.pqmf import PQMF


class GRU(nn.Module):
    def __init__(self, in_size, out_size, num_layers=1, bidirectional=True, dropout=0.):
        super().__init__()
        self.model = nn.GRU(in_size, out_size // 2 if bidirectional else out_size,
                            num_layers=num_layers, batch_first=True,
                            bidirectional=bidirectional,
                            dropout=dropout)

    def forward(self, x):
        predict = x.transpose(1, 2)
        predict, _ = self.model(predict)
        predict = predict.transpose(1, 2)
        return predict

    def forward_streaming(self, x, state):
        predict = x.transpose(1, 2)
        predict, new_state = self.model(predict, state)
        predict = predict.transpose(1, 2)
        return predict, new_state


class ResnetBlock(nn.Module):
    def __init__(self, channels, kernel_size=3, dilation=1, pad_method='ReflectionPad1d', dropout=0., use_rezero=True,
                 causal=False):
        super().__init__()
        assert kernel_size % 2 == 1
        self.padding = (kernel_size - 1) * dilation // 2

        self.block = nn.Sequential(
            nn.LeakyReLU(0.2),
            getattr(nn, pad_method)(self.padding),
            nn.Conv1d(channels, channels, kernel_size=kernel_size, dilation=dilation),
            nn.LeakyReLU(0.2),
            nn.Conv1d(channels, channels, kernel_size=1),
        )
        self.shortcut = nn.Conv1d(channels, channels, kernel_size=1)
        self.dropout = nn.Dropout(dropout)

        self.use_rezero = use_rezero
        if use_rezero:
            self.alpha = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        if self.use_rezero:
            return self.shortcut(x) + self.dropout(self.block(x) * self.alpha)
        else:
            return self.shortcut(x) + self.dropout(self.block(x))


class TGRU(nn.Module):
    def __init__(self, in_size, out_size, num_layers=1, bidirectional=True, dropout=0.):
        super().__init__()
        self.model = nn.GRU(in_size, out_size // 2 if bidirectional else out_size,
                            num_layers=num_layers, batch_first=True,
                            bidirectional=bidirectional,
                            dropout=dropout)

    def forward(self, x):
        predict = x.transpose(1, 2)
        predict, _ = self.model(predict)
        predict = predict.transpose(1, 2)
        return predict

    def forward_streaming(self, x, state):
        predict = x.transpose(1, 2)
        predict, new_state = self.model(predict, state)
        predict = predict.transpose(1, 2)
        return predict, new_state


class ScaledSoftSign(nn.Module):

    def __init__(self):
        super(ScaledSoftSign, self).__init__()
        self.register_parameter('a', nn.Parameter(torch.ones(1)))
        self.register_parameter('b', nn.Parameter(torch.ones(1)))

    def forward(self, inputs):
        return self.a * inputs / (1 + (inputs * self.b).abs())


class MultiBandGenerator(nn.Module):
    def __init__(self,
                 in_channels=128,
                 out_channels=1,
                 kernel_sizes=(7, 7),
                 channels=384,
                 use_rnn=True,
                 rnn_size=192,
                 rnn_bidirectional=True,
                 rnn_num_layers=2,
                 rnn_dropout=0.5,
                 upsample_scales=(3, 5, 5),
                 n_resnet=(3, 4, 5),
                 dropout=0.5,
                 pad_method='ReplicationPad1d',
                 resnet_kernel_size=3,
                 resnet_dropout=0.1,
                 resnet_use_rezero=True,
                 use_weight_norm=True,
                 use_multiband=True,
                 final_act_type='scaled_softsign',
                 n_subband=4,
                 taps=62,
                 beta=9.0,
                 cutoff_ratio=0.142
                 ):
        super().__init__()
        assert kernel_sizes[0] % 2 == 1
        assert kernel_sizes[1] % 2 == 1
        self.use_multiband = use_multiband

        first_conv_channels = channels
        if use_rnn:
            first_conv_channels = 2 * rnn_size if rnn_bidirectional else rnn_size

        model = [
            getattr(nn, pad_method)(kernel_sizes[0] // 2),
            nn.Conv1d(in_channels, first_conv_channels, kernel_size=kernel_sizes[0]),
            nn.LeakyReLU(0.2),
        ]

        if dropout > 0.:
            model += [nn.Dropout(dropout)]

        if use_rnn:
            model += [TGRU(first_conv_channels,
                           channels,
                           bidirectional=rnn_bidirectional,
                           num_layers=rnn_num_layers,
                           dropout=rnn_dropout)]

        model_24 = []
        # Upsample to raw audio scale
        for i, upsample_scale in enumerate(upsample_scales):
            model_24 += [
                nn.ConvTranspose1d(
                    channels // (2 ** i),
                    channels // (2 ** (i + 1)),
                    kernel_size=upsample_scale * 2,
                    stride=upsample_scale,
                    padding=upsample_scale // 2 + upsample_scale % 2,
                    output_padding=upsample_scale % 2
                )
            ]

            for j in range(n_resnet[i]):
                model_24 += [ResnetBlock(channels=channels // (2 ** (i + 1)),
                                         kernel_size=resnet_kernel_size,
                                         dilation=resnet_kernel_size ** j,
                                         pad_method=pad_method,
                                         dropout=resnet_dropout,
                                         use_rezero=resnet_use_rezero)]

            model_24 += [nn.LeakyReLU(0.2)]

        model_24 += [
            getattr(nn, pad_method)(kernel_sizes[1] // 2),
            nn.Conv1d(channels // (2 ** (i + 1)), channels // (2 ** (i + 1)), kernel_size=kernel_sizes[1]),
            nn.LeakyReLU(0.2)
        ]

        model_24_48 = []
        # Upsample to raw audio scale
        for i, upsample_scale in enumerate(upsample_scales):
            model_24_48 += [
                nn.ConvTranspose1d(
                    channels // (2 ** i),
                    channels // (2 ** (i + 1)),
                    kernel_size=upsample_scale * 2,
                    stride=upsample_scale,
                    padding=upsample_scale // 2 + upsample_scale % 2,
                    output_padding=upsample_scale % 2
                )
            ]

            for j in range(n_resnet[i]):
                model_24_48 += [ResnetBlock(channels=channels // (2 ** (i + 1)),
                                            kernel_size=resnet_kernel_size,
                                            dilation=resnet_kernel_size ** j,
                                            pad_method=pad_method,
                                            dropout=resnet_dropout,
                                            use_rezero=resnet_use_rezero)]

            model_24_48 += [nn.LeakyReLU(0.2)]

        model_24_48 += [
            getattr(nn, pad_method)(kernel_sizes[1] // 2),
            nn.Conv1d(channels // (2 ** (i + 1)), channels // (2 ** (i + 1)), kernel_size=kernel_sizes[1]),
            nn.LeakyReLU(0.2)
        ]

        self.band_linear_layer = nn.ModuleList([nn.Sequential(
            nn.Linear(channels // (2 ** (i + 1)), 1, bias=False),
            nn.Tanh() if final_act_type == 'tanh' else ScaledSoftSign()
        ) for _ in range(n_subband)])

        # self.pqmf_3 = PQMF(n_subband=3, taps=32, cutoff_ratio=0.19974999, beta=beta)
        # self.pqmf_6= PQMF(n_subband=6, taps=40, cutoff_ratio=0.1096, beta=beta)
        self.pqmf_4 = PQMF(n_subband=4, taps=32, cutoff_ratio=0.1579, beta=beta)
        self.pqmf_2 = PQMF(n_subband=2, taps=32, cutoff_ratio=0.283000000, beta=beta)

        self.model = nn.Sequential(*model)
        self.model_24 = nn.Sequential(*model_24)
        self.model_24_48 = nn.Sequential(*model_24_48)

        if use_weight_norm:
            self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, x):
        y = self.model(x)
        y_24 = self.model_24(y).transpose(1, 2)
        y_24_48 = self.model_24_48(y).transpose(1, 2)
        band_outs_0_24k = []
        band_outs_24_48k = []
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
                band_outs_0_24k.append(band_out)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
                band_outs_24_48k.append(band_out)
            band_outs.append(band_out)

        y_0_24k = torch.cat(band_outs_0_24k, dim=-1).transpose(1, 2)
        y_24_48k = torch.cat(band_outs_24_48k, dim=-1).transpose(1, 2)
        y_merge = torch.cat([self.pqmf_4.synthesis(y_0_24k), self.pqmf_4.synthesis(y_24_48k)], dim=1)
        return self.pqmf_4.synthesis(y_0_24k), self.pqmf_2.synthesis(y_merge)

    def inference(self, x):
        y = self.model(x)
        y_24 = self.model_24(y).transpose(1, 2)
        y_24_48 = self.model_24_48(y).transpose(1, 2)
        band_outs_0_24k = []
        band_outs_24_48k = []
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
                band_outs_0_24k.append(band_out)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
                band_outs_24_48k.append(band_out)
            band_outs.append(band_out)
        y_0_24k = torch.cat(band_outs_0_24k, dim=-1).transpose(1, 2)
        y_24_48k = torch.cat(band_outs_24_48k, dim=-1).transpose(1, 2)
        y_merge = torch.cat([self.pqmf_3.synthesis(y_0_24k), self.pqmf_3.synthesis(y_24_48k)], dim=1)
        return self.pqmf_3.synthesis(y_0_24k), self.pqmf_2.synthesis(y_merge)

    def onnx_forward(self, x):
        y = self.model(x)
        y_24 = self.model_24(y).transpose(1, 2)
        y_24_48 = self.model_24_48(y).transpose(1, 2)
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
            band_outs.append(band_out)
        y = torch.cat(band_outs, dim=-1).transpose(1, 2)
        return self.pqmf.synthesis(y)

    def onnx_dump_prenet(self, x):
        y = self.model(x)
        return y

    def onnx_dump_ups_48k(self, x):
        y_24 = self.model_24(x).transpose(1, 2)
        y_24_48 = self.model_24_48(x).transpose(1, 2)
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
            band_outs.append(band_out)
        y = torch.cat(band_outs, dim=-1).transpose(1, 2)
        return self.pqmf.synthesis(y)

    def onnx_dump_ups_24k(self, x):
        y_24 = self.model_24(x).transpose(1, 2)
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
            else:
                band_out = torch.zeros_like(band_out)
            band_outs.append(band_out)
        y = torch.cat(band_outs, dim=-1).transpose(1, 2)
        return self.pqmf.synthesis(y)

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):

        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)

        self.apply(_reset_parameters)

    def num_params(self):
        parameters = filter(lambda p: p.requires_grad, self.parameters())
        parameters = sum([np.prod(p.size()) for p in parameters]) / 1_000_000
        print('Trainable Parameters of Generator: %.3fM' % parameters)


class MultiBandGeneratorDumper(nn.Module):
    def __init__(self,
                 in_channels=80,
                 out_channels=1,
                 kernel_sizes=(7, 7),
                 channels=384,
                 use_rnn=True,
                 rnn_size=192,
                 rnn_bidirectional=True,
                 rnn_num_layers=2,
                 rnn_dropout=0.5,
                 upsample_scales=(3, 5, 5),
                 n_resnet=(3, 4, 5),
                 dropout=0.5,
                 pad_method='ReplicationPad1d',
                 resnet_kernel_size=3,
                 resnet_dropout=0.1,
                 resnet_use_rezero=True,
                 use_weight_norm=True,
                 use_multiband=True,
                 final_act_type='scaled_softsign',
                 n_subband=4,
                 taps=62,
                 beta=9.0,
                 cutoff_ratio=0.142
                 ):
        super().__init__()
        assert kernel_sizes[0] % 2 == 1
        assert kernel_sizes[1] % 2 == 1
        self.use_multiband = use_multiband

        first_conv_channels = channels
        if use_rnn:
            first_conv_channels = 2 * rnn_size if rnn_bidirectional else rnn_size

        model_prenet = [
            getattr(nn, pad_method)(kernel_sizes[0] // 2),
            nn.Conv1d(in_channels, first_conv_channels, kernel_size=kernel_sizes[0]),
            nn.LeakyReLU(0.2),
        ]

        if dropout > 0.:
            model_prenet += [nn.Dropout(dropout)]

        if use_rnn:
            model_prenet += [TGRU(first_conv_channels,
                                  channels,
                                  bidirectional=rnn_bidirectional,
                                  num_layers=rnn_num_layers,
                                  dropout=rnn_dropout)]

        model_24 = []
        # Upsample to raw audio scale
        for i, upsample_scale in enumerate(upsample_scales):
            model_upsampling = [
                nn.ConvTranspose1d(
                    channels // (2 ** i),
                    channels // (2 ** (i + 1)),
                    kernel_size=upsample_scale * 2,
                    stride=upsample_scale,
                    padding=upsample_scale // 2 + upsample_scale % 2,
                    output_padding=upsample_scale % 2
                )
            ]

            for j in range(n_resnet[i]):
                model_upsampling += [ResnetBlock(channels=channels // (2 ** (i + 1)),
                                                 kernel_size=resnet_kernel_size,
                                                 dilation=resnet_kernel_size ** j,
                                                 pad_method=pad_method,
                                                 dropout=resnet_dropout,
                                                 use_rezero=resnet_use_rezero)]

            model_upsampling += [nn.LeakyReLU(0.2)]
            if i == len(upsample_scales) - 1:
                model_upsampling += [
                    getattr(nn, pad_method)(kernel_sizes[1] // 2),
                    nn.Conv1d(channels // (2 ** (i + 1)), channels // (2 ** (i + 1)), kernel_size=kernel_sizes[1]),
                    nn.LeakyReLU(0.2)
                ]

            model_24.append(model_upsampling)

        model_24_48 = []
        # Upsample to raw audio scale
        for i, upsample_scale in enumerate(upsample_scales):
            model_upsampling = [
                nn.ConvTranspose1d(
                    channels // (2 ** i),
                    channels // (2 ** (i + 1)),
                    kernel_size=upsample_scale * 2,
                    stride=upsample_scale,
                    padding=upsample_scale // 2 + upsample_scale % 2,
                    output_padding=upsample_scale % 2
                )
            ]

            for j in range(n_resnet[i]):
                model_upsampling += [ResnetBlock(channels=channels // (2 ** (i + 1)),
                                                 kernel_size=resnet_kernel_size,
                                                 dilation=resnet_kernel_size ** j,
                                                 pad_method=pad_method,
                                                 dropout=resnet_dropout,
                                                 use_rezero=resnet_use_rezero)]

            model_upsampling += [nn.LeakyReLU(0.2)]

            if i == len(upsample_scales) - 1:
                model_upsampling += [
                    getattr(nn, pad_method)(kernel_sizes[1] // 2),
                    nn.Conv1d(channels // (2 ** (i + 1)), channels // (2 ** (i + 1)), kernel_size=kernel_sizes[1]),
                    nn.LeakyReLU(0.2)
                ]

            model_24_48.append(model_upsampling)

        self.band_linear_layer = nn.ModuleList([nn.Sequential(
            nn.Linear(channels // (2 ** (i + 1)), 1, bias=False),
            nn.Tanh() if final_act_type == 'tanh' else ScaledSoftSign()
        ) for _ in range(n_subband)])

        self.pqmf_4 = PQMF(n_subband=4, taps=32, cutoff_ratio=0.1579, beta=beta)
        self.pqmf_2 = PQMF(n_subband=2, taps=32, cutoff_ratio=0.283000000, beta=beta)

        self.model_prenet = model_prenet
        self.model_24_up0 = model_24[0]
        self.model_24_up1 = model_24[1]
        self.model_24_up2 = model_24[2]
        self.model_24_48_up0 = model_24_48[0]
        self.model_24_48_up1 = model_24_48[1]
        self.model_24_48_up2 = model_24_48[2]
        model = self.model_prenet
        model_24 = self.model_24_up0 + self.model_24_up1 + self.model_24_up2
        model_24_48 = self.model_24_48_up0 + self.model_24_48_up1 + self.model_24_48_up2
        self.model = nn.Sequential(*model)
        self.model_prenet = nn.Sequential(*model_prenet)
        self.model_24 = nn.Sequential(*model_24)
        self.model_24_48 = nn.Sequential(*model_24_48)
        self.model_24_up0 = nn.Sequential(*self.model_24_up0)
        self.model_24_up1 = nn.Sequential(*self.model_24_up1)
        self.model_24_up2 = nn.Sequential(*self.model_24_up2)
        self.model_24_48_up0 = nn.Sequential(*self.model_24_48_up0)
        self.model_24_48_up1 = nn.Sequential(*self.model_24_48_up1)
        self.model_24_48_up2 = nn.Sequential(*self.model_24_48_up2)

    def forward(self, x, spk):
        y = self.model(x)
        y_24 = self.model_24(y).transpose(1, 2)
        y_24_48 = self.model_24_48(y).transpose(1, 2)
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
            band_outs.append(band_out)
        y = torch.cat(band_outs, dim=-1).transpose(1, 2)
        return self.pqmf.synthesis(y), y

    def onnx_forward(self, x):
        y = self.model(x)
        y_24 = self.model_24(y).transpose(1, 2)
        y_24_48 = self.model_24_48(y).transpose(1, 2)
        band_outs_0_24k = []
        band_outs_24_48k = []
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
                band_outs_0_24k.append(band_out)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
                band_outs_24_48k.append(band_out)
            band_outs.append(band_out)
        y_0_24k = torch.cat(band_outs_0_24k, dim=-1).transpose(1, 2)
        y_24_48k = torch.cat(band_outs_24_48k, dim=-1).transpose(1, 2)
        y_merge = torch.cat([self.pqmf_4.synthesis(y_0_24k), self.pqmf_4.synthesis(y_24_48k)], dim=1)
        return self.pqmf_2.synthesis(y_merge)

    def onnx_dump_prenet(self, x):
        y = self.model_prenet(x)
        return y

    def onnx_dump_ups_48k(self, x):
        y_24 = self.model_24(x).transpose(1, 2)
        y_24_48 = self.model_24_48(x).transpose(1, 2)
        band_outs_0_24k = []
        band_outs_24_48k = []
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
                band_outs_0_24k.append(band_out)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
                band_outs_24_48k.append(band_out)
            band_outs.append(band_out)
        y_0_24k = torch.cat(band_outs_0_24k, dim=-1).transpose(1, 2)
        y_24_48k = torch.cat(band_outs_24_48k, dim=-1).transpose(1, 2)
        y_merge = torch.cat([self.pqmf_4.synthesis(y_0_24k), self.pqmf_4.synthesis(y_24_48k)], dim=1)
        return self.pqmf_4.synthesis(y_0_24k), self.pqmf_2.synthesis(y_merge)

    def onnx_dump_ups_24k(self, x):
        y_24 = self.model_24(x).transpose(1, 2)
        band_outs_0_24k = []

        for i in range(4):
            band_out = self.band_linear_layer[i](y_24)
            band_outs_0_24k.append(band_out)
        y_0_24k = torch.cat(band_outs_0_24k, dim=-1).transpose(1, 2)
        return self.pqmf_4.synthesis(y_0_24k)

    def onnx_dump_last_conv_48k(self, x_24, x_24_48):
        y_24 = x_24.transpose(1, 2)
        y_24_48 = x_24_48.transpose(1, 2)
        band_outs_0_24k = []
        band_outs_24_48k = []
        band_outs = []
        for i in range(len(self.band_linear_layer)):
            if i < len(self.band_linear_layer) / 2:
                band_out = self.band_linear_layer[i](y_24)
                band_outs_0_24k.append(band_out)
            else:
                band_out = self.band_linear_layer[i](y_24_48)
                band_outs_24_48k.append(band_out)
            band_outs.append(band_out)
        y_0_24k = torch.cat(band_outs_0_24k, dim=-1).transpose(1, 2)
        y_24_48k = torch.cat(band_outs_24_48k, dim=-1).transpose(1, 2)
        return y_0_24k, y_24_48k

    def onnx_dump_pqmf_48k(self, x_24, x_24_48):
        y_merge = torch.cat([self.pqmf_4.synthesis(x_24), self.pqmf_4.synthesis(x_24_48)], dim=1)
        return self.pqmf_2.synthesis(y_merge)

    def onnx_dump_pqmf_24k(self, x_24):
        y_24 = x_24.transpose(1, 2)
        band_outs_0_24k = []
        for i in range(4):
            band_out = self.band_linear_layer[i](y_24)
            band_outs_0_24k.append(band_out)
        y_0_24k = torch.cat(band_outs_0_24k, dim=-1).transpose(1, 2)
        return self.pqmf_4.synthesis(y_0_24k)

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

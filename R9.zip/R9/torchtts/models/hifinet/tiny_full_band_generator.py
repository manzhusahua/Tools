import numpy as np
import torch
import torch.nn as nn
from torchtts.models.hifinet.pqmf import PQMF


class TGRU(nn.Module):
    def __init__(self, in_size, out_size, num_layers=1, bidirectional=True, dropout=0.0):
        super().__init__()
        self.model = nn.GRU(
            in_size,
            out_size // 2 if bidirectional else out_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=bidirectional,
            dropout=dropout,
        )

    def forward(self, x):
        predict = x.transpose(1, 2)
        predict, _ = self.model(predict)
        predict = predict.transpose(1, 2)
        return predict


class ResnetBlockTiny(nn.Module):
    def __init__(self, dim, dilation=1):
        super().__init__()
        self.block = nn.Sequential(
            nn.LeakyReLU(0.2),
            nn.ReflectionPad1d(dilation),
            nn.Conv1d(dim, dim, kernel_size=3, dilation=dilation),
            nn.LeakyReLU(0.2),
            nn.Conv1d(dim, dim, kernel_size=1),
        )

        self.shortcut = nn.Conv1d(dim, dim, kernel_size=1)
        self.alpha = nn.Parameter(torch.Tensor(dim, 1))
        with torch.no_grad():
            self.alpha.fill_(0)

    def forward(self, x):
        return self.shortcut(x) + self.block(x) * self.alpha


class FullBandGeneratorTiny(nn.Module):
    def __init__(
            self,
            in_channels=80,
            ngf=32,
            n_residual_layers="3_3_3_3",
            dropout=0.1,
            use_rnn=True,
            rnn_bidirectional=True,
            rnn_num_layers=1,
            rnn_dropout=0.0,
            str_up_ratios="3_4_5_5",
            input_condition=None,
            embed_channels=128,
            subband_model=False,
    ):
        super().__init__()
        self.embed_features = input_condition
        self.embed_channels = embed_channels
        self.subband_model = subband_model
        if subband_model:
            self.pqmf = PQMF(n_subband=2, taps=32, cutoff_ratio=0.2829)

        ratios = [int(s) for s in str_up_ratios.split("_")]
        n_residual_layers = [int(s) for s in n_residual_layers.split("_")]
        self.hop_length = np.prod(ratios)
        mult = int(2 ** len(ratios))

        if use_rnn:
            rnn = TGRU(
                mult * ngf, mult * ngf, num_layers=rnn_num_layers, bidirectional=rnn_bidirectional, dropout=rnn_dropout
            )
        # concatenate one voice embedding feature
        if self.embed_features == "concat":
            # in_channels = 336
            in_channels = in_channels + embed_channels
        elif self.embed_features == "add":
            in_channels = in_channels
            self.proj = nn.Conv1d(embed_channels, in_channels, kernel_size=1)

        model = [nn.ReflectionPad1d(3), nn.Conv1d(in_channels, mult * ngf, kernel_size=7), nn.LeakyReLU(0.2)]

        if use_rnn:
            model += [nn.Dropout(dropout)]
            model += [rnn]

        # Upsample to raw audio scale
        for i, r in enumerate(ratios):
            model += [
                nn.ConvTranspose1d(
                    mult * ngf,
                    mult * ngf // 2,
                    kernel_size=r * 2,
                    stride=r,
                    padding=r // 2 + r % 2,
                    output_padding=r % 2,
                ),
            ]

            for j in range(n_residual_layers[i]):
                model += [ResnetBlockTiny(mult * ngf // 2, dilation=3 ** j)]

            model += [nn.LeakyReLU(0.2)]

            mult //= 2

        model += [
            nn.ReflectionPad1d(3),
            nn.Conv1d(ngf, 1, kernel_size=7),
            nn.Tanh(),
        ]

        self.model = nn.Sequential(*model)
        self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, x):
        x = self.model(x)
        return None, x

    def inference(self, x):
        x = self.model(x)
        return None, x

    def voice_feature(self, x, spk):
        if self.embed_features == "concat":
            # duplicate voice feature vector and concatenate with input Mel
            mel_len = x.shape[2]
            tile_spk = spk.tile([1, 1, mel_len])
            x = torch.cat((x, tile_spk), dim=1)
        return x

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):
        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)

        self.apply(_reset_parameters)

    def num_params(self):
        parameters = filter(lambda p: p.requires_grad, self.parameters())
        parameters = sum([np.prod(p.size()) for p in parameters]) / 1_000_000
        print("Trainable Parameters of Generator: %.3fM" % parameters)


class TinyFullBandONNXDumper(nn.Module):
    def __init__(self,
                 in_channels=80,
                 ngf=32,
                 n_residual_layers='3_3_3_3',
                 drop=0.1,
                 use_rnn=True,
                 rnn_bidirectional=True,
                 rnn_num_layers=1,
                 rnn_dropout=0.,
                 str_up_ratios='3_4_5_5',
                 input_condition=None,
                 embed_channels=128,
                 subband_model=False
                 ):
        super().__init__()
        self.embed_features = input_condition
        self.embed_channels = embed_channels
        self.subband_model = subband_model
        if subband_model:
            self.pqmf = PQMF(n_subband=2, taps=32, cutoff_ratio=0.2829)
            # self.pqmf_2_32 = PQMF(n_subband=2, taps=32, cutoff_ratio=0.2829)

        ratios = [int(s) for s in str_up_ratios.split('_')]
        n_residual_layers = [int(s) for s in n_residual_layers.split('_')]
        self.hop_length = np.prod(ratios)
        mult = int(2 ** len(ratios))

        if use_rnn:
            rnn = TGRU(mult * ngf, mult * ngf,
                       num_layers=rnn_num_layers,
                       bidirectional=rnn_bidirectional,
                       dropout=rnn_dropout)
        # concatenate one voice embedding feature
        if self.embed_features == "concat":
            # in_channels = 336
            in_channels = in_channels + embed_channels
        elif self.embed_features == "add":
            in_channels = in_channels
            self.proj = nn.Conv1d(embed_channels, in_channels, kernel_size=1)

        model_prenet = [
            nn.ReflectionPad1d(3),
            nn.Conv1d(in_channels, mult * ngf, kernel_size=7),
            nn.LeakyReLU(0.2)
        ]

        if use_rnn:
            model_prenet += [nn.Dropout(drop)]
            model_prenet += [rnn]

        model_ups = []
        # Upsample to raw audio scale
        for i, r in enumerate(ratios):
            model_upsampling = [
                nn.ConvTranspose1d(
                    mult * ngf,
                    mult * ngf // 2,
                    kernel_size=r * 2,
                    stride=r,
                    padding=r // 2 + r % 2,
                    output_padding=r % 2,
                ),
            ]

            for j in range(n_residual_layers[i]):
                model_upsampling += [ResnetBlockTiny(mult * ngf // 2, dilation=3 ** j)]

            model_upsampling += [nn.LeakyReLU(0.2)]

            mult //= 2
            model_ups.append(model_upsampling)

        model_ups.append([
            nn.ReflectionPad1d(3),
            nn.Conv1d(ngf, 1, kernel_size=7),
            nn.Tanh(),
        ])

        self.modelPrenet = model_prenet
        self.modelUpSampling0 = model_ups[0]
        self.modelUpSampling1 = model_ups[1]
        self.modelUpSampling2 = model_ups[2]
        self.modelUpSampling3 = model_ups[3]
        self.modelLastconv = model_ups[4]
        model = self.modelPrenet + self.modelUpSampling0 + self.modelUpSampling1 + self.modelUpSampling2 + self.modelUpSampling3 + self.modelLastconv
        model_up_samplings = self.modelUpSampling0 + self.modelUpSampling1 + self.modelUpSampling2 + self.modelUpSampling3

        self.model = nn.Sequential(*model)
        self.modelPrenet = nn.Sequential(*model_prenet)
        self.modelUpSamplings = nn.Sequential(*model_up_samplings)
        self.modelUpSampling0 = nn.Sequential(*self.modelUpSampling0)
        self.modelUpSampling1 = nn.Sequential(*self.modelUpSampling1)
        self.modelUpSampling2 = nn.Sequential(*self.modelUpSampling2)
        self.modelUpSampling3 = nn.Sequential(*self.modelUpSampling3)
        self.modelLastConv = nn.Sequential(*self.modelLastconv)

    def forward(self, x, spk):
        x = self.model(x)
        return None, x, None

    def pqmf_forward(self, x1, x2):
        x = torch.cat([x1, x2], dim=1)
        x = self.pqmf.synthesis(x)
        return x

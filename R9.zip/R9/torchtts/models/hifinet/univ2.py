import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from torchtts.nn.modules.hifinet.gru import GRU
from torchtts.nn.modules.hifinet import Activation1d
from torchtts.nn.modules.common import SnakeBeta


class ResnetBlock(nn.Module):
    def __init__(self, dim, dilation=1, kernel_size=3, causal=False, use_rnn=False, rnn_reduce=1, rnn_sample_ratio=1.):
        super().__init__()

        if kernel_size == 3:
            pad_dilation = dilation
        elif kernel_size == 5:
            pad_dilation = 2 * dilation
        elif kernel_size == 7:
            pad_dilation = 3 * dilation

        if causal is True:
            pad_dilation = (2 * pad_dilation, 0)

        self.use_rnn = use_rnn
        if use_rnn is True:
            self.drop = nn.Dropout(p=0.5)
            self.rnn = GRU(
                in_size=dim, out_size=dim // rnn_reduce, bidirectional=False)
            self.rnnReduce = rnn_reduce
            self.rnn_sample_ratio = rnn_sample_ratio
            self.outProj = nn.Sequential(nn.Conv1d(dim + dim // rnn_reduce, dim, 1), nn.ReLU())
            if self.rnn_sample_ratio > 1:
                self.rnn_down_sample = nn.AvgPool1d(self.rnn_sample_ratio * 2 + 1, self.rnn_sample_ratio, padding=self.rnn_sample_ratio // 2 + 1, count_include_pad=False)

        self.block = nn.Sequential(
            Activation1d(activation=SnakeBeta(dim, alpha_logscale=True)),
            nn.ReflectionPad1d(pad_dilation),
            nn.Conv1d(dim, dim, kernel_size=kernel_size, dilation=dilation),
            Activation1d(activation=SnakeBeta(dim, alpha_logscale=True)),
            nn.Conv1d(dim, dim, kernel_size=1),
        )

        self.shortcut = nn.Conv1d(dim, dim, kernel_size=1)
        self.alpha = nn.Parameter(torch.Tensor(dim, 1))
        with torch.no_grad():
            self.alpha.fill_(0)

    def forward(self, x):
        output = self.block(x) * self.alpha
        if self.use_rnn:
            x_rnn = self.drop(x)
            if self.rnn_sample_ratio > 1:
                x_rnn = self.rnn_down_sample(x_rnn)

            rnn_out = self.rnn(x_rnn)

            if self.rnn_sample_ratio > 1:
                rnn_out = F.interpolate(rnn_out, scale_factor=self.rnn_sample_ratio, mode='linear', align_corners=True)

            output = self.outProj(torch.cat([output, rnn_out], dim=1))

        return self.shortcut(x) + output


class Universal2Generator(nn.Module):
    def __init__(self,
                 in_channels=80,
                 ngf=32,
                 n_residual_layers=(3, 3, 3, 3),
                 dropout=0.1,
                 use_rnn=True,
                 rnn_bidirectional=True,
                 rnn_num_layers=1,
                 rnn_dropout=0.,
                 up_ratios=(3, 4, 5, 5),
                 use_weight_norm=True):
        super().__init__()
        self.hop_length = np.prod(up_ratios)
        self.ngf = ngf
        self.up_ratios = up_ratios
        mul = int(2 ** len(up_ratios))

        self.model = nn.ModuleDict()

        pre_model = [
            nn.ReflectionPad1d(3),
            nn.Conv1d(in_channels, mul * ngf, kernel_size=7),
            Activation1d(activation=SnakeBeta(mul * ngf, alpha_logscale=True))
        ]

        if use_rnn:
            pre_model += [
                nn.Dropout(dropout),
                GRU(in_size=mul * ngf,
                    out_size=mul * ngf,
                    num_layers=rnn_num_layers,
                    bidirectional=rnn_bidirectional,
                    dropout=rnn_dropout)
            ]

        self.model['pre_model'] = nn.Sequential(*pre_model)

        # Upsample to raw audio scale
        t_r = 1
        for i, r in enumerate(up_ratios):
            t_r *= r
            upsample_model = [
                nn.ConvTranspose1d(
                    in_channels=mul * ngf,
                    out_channels=mul * ngf // 2,
                    kernel_size=r * 2,
                    stride=r,
                    padding=r // 2 + r % 2,
                    output_padding=r % 2,
                ),
            ]

            for j in range(n_residual_layers[i]):
                upsample_model += [ResnetBlock(mul * ngf // 2, dilation=3 ** j,
                                               use_rnn=(i < 3 and j == n_residual_layers[i] - 1),
                                               rnn_sample_ratio=t_r, rnn_reduce=2)]

            upsample_model += [Activation1d(activation=SnakeBeta(mul * ngf // 2, alpha_logscale=True))]

            mul //= 2

            self.model[f'upsample_{i}'] = nn.Sequential(*upsample_model)

        self.model['post_model'] = nn.Sequential(
            nn.ReflectionPad1d(3),
            nn.Conv1d(ngf, 1, kernel_size=7),
            nn.Tanh(),
        )

        if use_weight_norm:
            self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, x):
        for _, layer in self.model.items():
            x = layer(x)
        return x

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):
        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)
        self.apply(_reset_parameters)

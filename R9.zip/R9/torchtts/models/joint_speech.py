import torch
import torch.nn as nn

from torchtts.nn.modules.common.functional import sequence_mask


class JointSpeech(nn.Module):
    def __init__(
        self,
        text_encoder,
        posterior_encoder,
        flow,
        acoustic_encoder,
        reconstructor,
        wave_decoder,
        prosody_predictor,
        pitch_predictor,
        pitch_embedding,
        duration_predictor,
        length_regulator,
        duration_pos_embedding,
        speaker_encoder,
        locale_encoder,
        style_encoder,
        embedding_fuse_layer,
    ):
        super().__init__()
        self.text_encoder = text_encoder
        self.posterior_encoder = posterior_encoder
        self.flow = flow
        self.acoustic_encoder = acoustic_encoder
        self.reconstructor = reconstructor
        self.wave_decoder = wave_decoder
        self.prosody_predictor = prosody_predictor
        self.pitch_predictor = pitch_predictor
        self.pitch_embedding = pitch_embedding
        self.duration_predictor = duration_predictor
        self.length_regulator = length_regulator
        self.duration_pos_embedding = duration_pos_embedding
        self.speaker_encoder = speaker_encoder
        self.locale_encoder = locale_encoder
        self.style_encoder = style_encoder
        self.embedding_fuse_layer = embedding_fuse_layer

    def forward(
        self,
        phone_ids,
        phone_ids_lengths,
        durations,
        acoustic_feats,
        acoustic_feats_lengths,
        phone_pitch,
        speaker_id=None,
        locale_id=None,
        style_id=None,
        windows=None,
    ):
        phone_mask = sequence_mask(phone_ids_lengths)
        frame_mask = sequence_mask(acoustic_feats_lengths)

        embeddings = []
        if speaker_id is not None and self.speaker_encoder is not None:
            speaker_embedding = self.speaker_encoder(speaker_id.unsqueeze(-1))
        else:
            speaker_embedding = None

        if locale_id is not None and self.locale_encoder is not None:
            locale_embedding = self.locale_encoder(locale_id.unsqueeze(-1))
        else:
            locale_embedding = None

        if style_id is not None and self.style_encoder is not None:
            style_embedding = self.style_encoder(style_id.unsqueeze(-1))
        else:
            style_embedding = None

        # Stage 1: forward text encoder for linguistic feature
        text_feats = self.text_encoder(phone_ids=phone_ids, phone_mask=phone_mask, locale_embedding=locale_embedding)

        # Optional: speaker/locale/style embeddings
        length = text_feats.size(1)

        embeddings = []
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding.expand(-1, length, -1))

        if embeddings:
            text_feats = self.embedding_fuse_layer(torch.cat([text_feats] + embeddings, dim=-1))

        # Stage 2: pitch variance adaptor
        pred_pitch = self.pitch_predictor(text_feats)

        # Phone-level variance adaptor (pitch + enenry? + ...)
        # We use unsqueeze and permute to deprecate this warning in DDP training
        # https://github.com/pytorch/pytorch/issues/47163
        pitch_embedding = self.pitch_embedding(phone_pitch.unsqueeze(1).permute(0, 2, 1))
        text_feats = text_feats + pitch_embedding

        # Stage 3: posterior encoder condition on text/audio pair for modelling prosody (VAE encoder)
        frame_pos_embedding = self.duration_pos_embedding(durations)

        text_frame_feats, _ = self.length_regulator(text_feats, durations)
        text_frame_feats += frame_pos_embedding
        text_frame_feats *= frame_mask.to(text_frame_feats.dtype).unsqueeze(-1)

        latent_dist = self.posterior_encoder(
            feats=acoustic_feats,
            feats_mask=frame_mask,
            durations=durations,
            durations_mask=phone_mask,
            local_conditions=text_frame_feats,
        )

        latents = latent_dist.rsample()

        # Stage 4: use flow to enhance capability of prior/posterior distribution
        if self.flow is not None:
            pred_prior = self.flow(x=latents, x_mask=phone_mask, c=text_feats)
        else:
            pred_prior = None

        # Stage 5: prosody (latents) prediction
        pred_prosody_dist = self.prosody_predictor(text_feats, phone_mask)

        # Stage 6: duration prediction with text and latents
        dur_input = torch.cat([text_feats, latents], dim=-1)
        pred_duration = self.duration_predictor(dur_input, phone_mask)

        # Stage 7: forward acoustic encoder to recover acoustic feats (VAE decoder)
        frame_latents, _ = self.length_regulator(latents, durations)
        frame_latents = frame_latents + frame_pos_embedding
        frame_latents *= frame_mask.to(frame_latents.dtype).unsqueeze(-1)

        acoustic_ir = self.acoustic_encoder(
            latents=frame_latents,
            latents_mask=frame_mask,
            local_conditions=text_frame_feats,
        )

        # Reconstruct acoustic features with branch
        if self.reconstructor is not None:
            pred_acoustic_feats = self.reconstructor(acoustic_ir)
        else:
            pred_acoustic_feats = None

        # Stage 8: Wave generation
        if windows is not None:
            batch_idx, frame_windows = windows
            # Only generate a chunk of frames to waveform
            batches = torch.index_select(acoustic_ir, 0, batch_idx)
            chunks = torch.stack(
                [batches[i, s:e] for i, (s, e) in enumerate(frame_windows)],
                dim=0,
            )
            audio = self.wave_decoder(chunks.permute(0, 2, 1))
        else:
            audio = self.wave_decoder(acoustic_ir.permute(0, 2, 1))

        return {
            "prosody_dist": latent_dist,
            "pred_prior": pred_prior,
            "pred_prosody_dist": pred_prosody_dist,
            "pred_duration": pred_duration,
            "pred_pitch": pred_pitch,
            "pred_acoustic_feats": pred_acoustic_feats,
            "audio": audio,
        }

    @torch.no_grad()
    def inference(
        self,
        phone_ids,
        speaker_id=None,
        locale_id=None,
        style_id=None,
    ):
        embeddings = []
        if speaker_id is not None and self.speaker_encoder is not None:
            speaker_embedding = self.speaker_encoder(speaker_id.unsqueeze(-1))
        else:
            speaker_embedding = None

        if locale_id is not None and self.locale_encoder is not None:
            locale_embedding = self.locale_encoder(locale_id.unsqueeze(-1))
        else:
            locale_embedding = None

        if style_id is not None and self.style_encoder is not None:
            style_embedding = self.style_encoder(style_id.unsqueeze(-1))
        else:
            style_embedding = None

        # Stage 1: forward text encoder for linguistic feature
        text_feats = self.text_encoder(phone_ids=phone_ids, locale_embedding=locale_embedding)

        # Optional: speaker/locale/style embeddings
        length = text_feats.size(1)

        embeddings = []
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, length, -1))
        if style_embedding is not None:
            embeddings.append(style_embedding.expand(-1, length, -1))

        if embeddings:
            text_feats = self.embedding_fuse_layer(torch.cat([text_feats] + embeddings, dim=-1))

        # Stage 2: pitch prediction and fusing
        phone_pitch = self.pitch_predictor(text_feats).squeeze(-1)
        pitch_embedding = self.pitch_embedding(phone_pitch.unsqueeze(1).permute(0, 2, 1))
        text_feats = text_feats + pitch_embedding

        # Stage 3: get prosody latents
        # Method 1: prosody predictor
        prosody_dist = self.prosody_predictor(text_feats)
        latents = prosody_dist.rsample()

        # Method 2: sampling with flow
        # from torch.distributions import Normal
        # latents = self.flow(Normal(torch.zeros_like(text_feats),
        #                           torch.ones_like(text_feats)).sample(),
        #                    sequence_mask(torch.tensor([phone_ids.size(-1)])),
        #                    c=text_feats,
        #                    inverse=True)
        # from torch.distributions import Normal
        # latents = Normal(torch.zeros_like(text_feats), torch.ones_like(text_feats)).sample()

        # Stage 4: duration prediction
        dur_input = torch.cat([text_feats, latents], dim=-1)
        log_durations = self.duration_predictor(dur_input)
        durations = torch.clamp(torch.exp(log_durations) - 1.0, min=0.0)
        durations = torch.round(durations).long()

        # Stage 5: phone to frame expansion
        frame_pos_embedding = self.duration_pos_embedding(durations)

        text_frame_feats, _ = self.length_regulator(text_feats, durations)
        text_frame_feats = text_frame_feats + frame_pos_embedding

        frame_latents, _ = self.length_regulator(latents, durations)
        frame_latents = frame_latents + frame_pos_embedding

        # Stage 6: Acoustic encoder
        acoustic_ir = self.acoustic_encoder(
            latents=frame_latents,
            local_conditions=text_frame_feats,
        )

        audio = self.wave_decoder(acoustic_ir.permute(0, 2, 1))

        return {
            "audio": audio,
        }

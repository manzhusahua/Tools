import torch
import torch.nn as nn

from torchtts.nn.modules.common import GaussianSmoother
from torchtts.nn.modules.common import LengthRegulator, LayerNorm
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.modules.common.rnn_warpper import ConvLSTM, HighwayRNN
from torchtts.nn.modules.fastspeech import PositionEmbedding

# from torchtts.nn.modules.fastspeech import PitchEmbedding
# from torchtts.nn.modules.fastspeech import PitchPredictor
from torchtts.nn.modules.conformer.variance_predictor import PitchPredictor
from torchtts.nn.modules.fastspeech import MemoryLayer


class LeanSpeech(nn.Module):
    """LeanSpeech, A Simplified TTS model from Tacotron + FastSpeech for streaming device"""

    def __init__(
        self,
        symbol_size,
        spk_size=128,
        lang_size=128,
        embedding_dim=256,
        spk_embed_dim=256,
        lang_embed_dim=256,
        use_style=False,
        style_size=16,
        style_embed_dim=256,
        out_dim=80,
        enc_rnn_num_layers=3,
        enc_dropout=0.1,
        enc_size=256,
        dur_pred_dropout=0.5,
        dur_pred_dim=256,
        dur_rnn_reduce=2,
        smoother_params=None,
        use_dec_pos_embedding=True,
        enable_pitch_contour=False,
        f0_embed_dim=64,
        uv_embed_dim=32,
        dec_size=256,
        dec_rnn_num_layers=2,
        dec_rnn_reduce=2,
        use_memory=False,
        memory_bank_nums=1000,
        pitch_predictor_layers=3,
        pitch_predictor_chans=256,
        pitch_predictor_kernel_size=5,
        pitch_predictor_dropout=0.1,
        pitch_dim=16,
        pitch_embed_kernel_size=3,
        pitch_embed_dropout=0.1,
        pitch_mean=178.47,
        pitch_var=53.47,
        enable_multi_speaker=False,
        enable_cross_lingual=False,
        embedding_activation="softsign",
        **kwargs,
    ):
        super(LeanSpeech, self).__init__()

        self.use_style = use_style
        self.embedding_dim = embedding_dim
        self.out_dim = out_dim
        self.enc_rnn_num_layers = enc_rnn_num_layers
        self.dec_rnn_num_layers = dec_rnn_num_layers
        self.use_memory = use_memory
        self.embedding = nn.Embedding(num_embeddings=symbol_size, embedding_dim=embedding_dim, padding_idx=0)
        self.pitch_mean = pitch_mean
        self.pitch_var = pitch_var
        self.enable_pitch_contour = enable_pitch_contour
        self.enable_multi_speaker = enable_multi_speaker
        self.enable_cross_lingual = enable_cross_lingual

        self.speaker_embedding = None
        if self.enable_multi_speaker:
            self.speaker_embedding = nn.Embedding(num_embeddings=spk_size, embedding_dim=spk_embed_dim, padding_idx=0)
            self.speaker_embeddinglinear = torch.nn.Linear(spk_embed_dim, spk_embed_dim)
            self.speaker_embedding_proj = torch.nn.Linear(enc_size + spk_embed_dim, enc_size)

        self.lang_embedding = None
        if self.enable_cross_lingual:
            self.lang_embedding = nn.Embedding(num_embeddings=lang_size, embedding_dim=lang_embed_dim, padding_idx=0)
            self.lang_embeddinglinear = torch.nn.Linear(lang_embed_dim, lang_embed_dim)
            self.lang_embedding_proj = torch.nn.Linear(enc_size + lang_embed_dim, enc_size)
        self.style_embedding = None
        if self.use_style:
            self.style_embedding = nn.Embedding(num_embeddings=style_size, embedding_dim=style_embed_dim, padding_idx=0)
            self.style_embeddinglinear = torch.nn.Linear(style_embed_dim, style_embed_dim)
            self.style_embedding_proj = torch.nn.Linear(enc_size + style_embed_dim, enc_size)

        if embedding_activation == "softplus":
            self.emb_act = nn.Softplus()
        elif embedding_activation == "softsign":
            self.emb_act = nn.Softsign()

        for i in range(enc_rnn_num_layers):
            enc_in_chan = embedding_dim if i == 0 else enc_size
            enc_out_chan = enc_size
            self.add_module(
                f"enc_{i}",
                HighwayRNN(ConvLSTM(enc_in_chan, enc_out_chan, enc_out_chan,
                                    bi_direction=True),
                           enc_out_chan, drop=enc_dropout),
            )

        self.dur_pre_proj = None
        if enc_size != dur_pred_dim:
            self.dur_pre_proj = nn.Linear(enc_size, dur_pred_dim)
        self.duration_rnn = HighwayRNN(
            ConvLSTM(dur_pred_dim, dur_pred_dim, dur_pred_dim,
                     bi_direction=True, rnn_reduce=dur_rnn_reduce),
            dur_pred_dim,
            drop=dur_pred_dropout,
        )
        self.duration_post_layer = nn.Sequential(nn.Linear(dur_pred_dim, 1), nn.ReLU())

        if use_memory:
            self.memory = MemoryLayer(
                enc_size,
                num_heads=2,
                dropout=0.2,
                attention_dropout=0.0,
                relu_dropout=0.2,
                kernel_size=9,
                padding="SAME",
                memory_bank_nums=memory_bank_nums,
            )

        if self.enable_pitch_contour:
            self.pitch_predictor = PitchPredictor(
                idim=enc_size,
                n_layers=pitch_predictor_layers,
                n_chans=pitch_predictor_chans,
                kernel_size=pitch_predictor_kernel_size,
                dropout_rate=pitch_predictor_dropout,
            )
            self.pitch_embed = torch.nn.Sequential(
                torch.nn.Conv1d(
                    in_channels=1,
                    out_channels=pitch_dim,
                    kernel_size=pitch_embed_kernel_size,
                    padding=(pitch_embed_kernel_size - 1) // 2,
                ),
                torch.nn.ReLU(),
                LayerNorm(pitch_dim, dim=1),
                torch.nn.Dropout(pitch_embed_dropout),
            )
            self.pitch_emb_enc_proj = torch.nn.Linear(enc_size + pitch_dim, enc_size)
            # do not use pitch_fuse_layer for now.
            # self.pitch_fuse_layer = nn.Linear(enc_size + f0_embed_dim + uv_embed_dim,
            #                                   enc_size)

        self.smoother = GaussianSmoother(**smoother_params) if smoother_params is not None else None
        if enc_size != dec_size:
            self.encdec_mapping = nn.Sequential(nn.Linear(enc_size, dec_size), nn.ReLU())
        self.length_regulator = LengthRegulator(smoother=self.smoother)

        for i in range(dec_rnn_num_layers):
            self.add_module(f"dec_{i}", HighwayRNN(ConvLSTM(dec_size, dec_size, dec_size,
                                                            rnn_reduce=dec_rnn_reduce), dec_size))
        if use_dec_pos_embedding:
            self.dec_pos_embedding = PositionEmbedding(hidden_size=dec_size)
        self.mel_proj = nn.Linear(dec_size, out_dim, bias=True)

    @torch.no_grad()
    def forward_before_memory(
        self, phone_id, length=None, duration=None, f0=None, uv=None, style_id=None, spk_id=None, lang_id=None
    ):
        if length is not None:
            src_mask = sequence_mask(length)
        else:
            src_mask = None

        # Phoneme or character embedding
        embedding = self.embedding(phone_id)

        # encoder
        encoder_output = embedding
        for i in range(self.enc_rnn_num_layers):
            encoder_output, _ = self.__getattr__(f"enc_{i}")(encoder_output, mask=src_mask)
        encoder_output = encoder_output * src_mask.unsqueeze(-1)
        encoder_hidden = encoder_output

        # speaker embedding
        if self.speaker_embedding is not None and spk_id is not None:
            spembs = self.speaker_embedding(spk_id)
            if len(spembs.size()) == 2:
                spembs = spembs.unsqueeze(1)
            spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
            spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.speaker_embedding_proj(torch.cat([encoder_hidden, spembs], dim=-1))

        # language embedding
        if self.lang_embedding is not None and lang_id is not None:
            langs = self.lang_embedding(lang_id)
            if len(langs.size()) == 2:
                langs = langs.unsqueeze(1)
            langs = self.emb_act(self.lang_embeddinglinear(langs))
            langs = langs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.lang_embedding_proj(torch.cat([encoder_hidden, langs], dim=-1))

        # style embedding
        if self.style_embedding is not None and style_id is not None:
            style_embedding = self.style_embedding(style_id)
            if len(style_embedding.size()) == 2:
                style_embedding = style_embedding.unsqueeze(1)
            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))
            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], dim=-1))

        duration_predictor_input = encoder_hidden
        if self.dur_pre_proj is not None:
            duration_predictor_input = self.dur_pre_proj(duration_predictor_input)

        # pitch prediction
        ps, p_outs = None, None
        if hasattr(self, "pitch_predictor"):
            p_outs = self.pitch_predictor(encoder_hidden, ~src_mask.unsqueeze(-1))
            ps = p_outs if f0 is None else f0.unsqueeze(-1)
            p_embs = self.pitch_embed(ps.transpose(1, 2)).transpose(1, 2)
            encoder_hidden = torch.cat((encoder_hidden, p_embs), dim=-1)
            encoder_hidden = self.pitch_emb_enc_proj(encoder_hidden)

        # Duration prediction in logarithmic domain
        predicted_duration, _ = self.duration_rnn(duration_predictor_input, mask=src_mask)
        predicted_duration = self.duration_post_layer(predicted_duration).squeeze(-1)
        predicted_duration = predicted_duration * src_mask

        # Expand phone level feats to frame level feats. Use ground truth
        # duration if provided.
        if duration is None:
            duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0)
            duration = torch.round(duration).long()
        decoder_input, align_mat = self.length_regulator(encoder_hidden, duration)
        return decoder_input

    def forward(self, phone_id, length=None, duration=None, f0=None, uv=None, style_id=None, spk_id=None, lang_id=None):
        if length is not None:
            src_mask = sequence_mask(length)
        else:
            src_mask = None

        # Phoneme or character embedding
        embedding = self.embedding(phone_id)

        # encoder
        encoder_output = embedding
        for i in range(self.enc_rnn_num_layers):
            encoder_output, _ = self.__getattr__(f"enc_{i}")(encoder_output, mask=src_mask)
        encoder_output = encoder_output * src_mask.unsqueeze(-1)
        encoder_hidden = encoder_output

        # speaker embedding
        if self.speaker_embedding is not None and spk_id is not None:
            spembs = self.speaker_embedding(spk_id)
            if len(spembs.size()) == 2:
                spembs = spembs.unsqueeze(1)
            spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
            spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.speaker_embedding_proj(torch.cat([encoder_hidden, spembs], dim=-1))

        # language embedding
        if self.lang_embedding is not None and lang_id is not None:
            langs = self.lang_embedding(lang_id)
            if len(langs.size()) == 2:
                langs = langs.unsqueeze(1)
            langs = self.emb_act(self.lang_embeddinglinear(langs))
            langs = langs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.lang_embedding_proj(torch.cat([encoder_hidden, langs], dim=-1))

        # style embedding
        if self.style_embedding is not None and style_id is not None:
            style_embedding = self.style_embedding(style_id)
            if len(style_embedding.size()) == 2:
                style_embedding = style_embedding.unsqueeze(1)
            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))
            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], dim=-1))

        duration_predictor_input = encoder_hidden
        if self.dur_pre_proj is not None:
            duration_predictor_input = self.dur_pre_proj(duration_predictor_input)

        # pitch prediction
        ps, p_outs = None, None
        if hasattr(self, "pitch_predictor"):
            p_outs = self.pitch_predictor(encoder_hidden, ~src_mask.unsqueeze(-1))
            ps = p_outs if f0 is None else f0.unsqueeze(-1)
            p_embs = self.pitch_embed(ps.transpose(1, 2)).transpose(1, 2)
            encoder_hidden = torch.cat((encoder_hidden, p_embs), dim=-1)
            encoder_hidden = self.pitch_emb_enc_proj(encoder_hidden)

        # Duration prediction in logarithmic domain
        predicted_duration, _ = self.duration_rnn(duration_predictor_input, mask=src_mask)
        predicted_duration = self.duration_post_layer(predicted_duration).squeeze(-1)
        predicted_duration = predicted_duration * src_mask

        # Expand phone level feats to frame level feats. Use ground truth
        # duration if provided.
        if duration is None:
            duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0)
            duration = torch.round(duration).long()
        decoder_input, align_mat = self.length_regulator(encoder_hidden, duration)
        tgt_mask = sequence_mask(torch.sum(duration, dim=1))

        if self.use_memory:
            decoder_input = self.memory(decoder_input.transpose(0, 1), ~tgt_mask).transpose(0, 1)

        if hasattr(self, "encdec_mapping"):
            decoder_input = self.encdec_mapping(decoder_input)

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # RNN Decoder
        decoder_output = decoder_input
        for i in range(self.dec_rnn_num_layers):
            decoder_output, _ = self.__getattr__(f"dec_{i}")(decoder_output)

        mel_spec = self.mel_proj(decoder_output)
        mel_spec *= tgt_mask.to(mel_spec.dtype).unsqueeze(-1)

        return mel_spec, predicted_duration, p_outs, None, src_mask, tgt_mask, None

    @torch.no_grad()
    def inference(
        self,
        phone_id,
        speaking_rate=1.0,
        f0_scale_ratio=None,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
        style_id=None,
        spk_id=None,
        lang_id=None,
    ):
        # Align with t2t which has 4D input for runtime compatibility
        # this is different when dump each part
        phone_id = phone_id.squeeze(-1).squeeze(-1).long()
        if style_id is not None:
            style_id = style_id.unsqueeze(0).long()

        # Phoneme or character embedding
        embedding = self.embedding(phone_id)
        # encoder
        encoder_output = embedding
        for i in range(self.enc_rnn_num_layers):
            encoder_output, _ = self.__getattr__(f"enc_{i}")(encoder_output)
        encoder_hidden = encoder_output

        # speaker embedding
        if self.enable_multi_speaker and spk_id is not None:
            spembs = self.speaker_embedding(spk_id.long())
            spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
            spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.speaker_embedding_proj(torch.cat([encoder_hidden, spembs], dim=-1))

        # language embedding
        if self.enable_cross_lingual and lang_id is not None:
            langs = self.lang_embedding((lang_id).long())
            langs = self.emb_act(self.lang_embeddinglinear(langs))
            langs = langs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.lang_embedding_proj(torch.cat([encoder_hidden, langs], dim=-1))

        # style embedding
        if self.use_style and style_id is not None:
            style_embedding = self.style_embedding(style_id.long())
            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))
            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], dim=-1))

        duration_predictor_input = encoder_hidden
        if self.dur_pre_proj is not None:
            duration_predictor_input = self.dur_pre_proj(duration_predictor_input)

        # pitch prediction
        p_outs = None
        if hasattr(self, "pitch_predictor"):
            p_outs = self.pitch_predictor(encoder_hidden)
            if f0_scale_ratio is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                scaled_f0 = scaled_f0 * f0_scale_ratio
                scaled_f0 = (scaled_f0 - self.pitch_mean) / self.pitch_var

                f0_scale_mean = f0_scale_ratio.mean(1)
                p_outs = torch.where(
                    torch.logical_and(
                        torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)
                    ),
                    p_outs,
                    scaled_f0,
                )

            p_embs = self.pitch_embed(p_outs.transpose(1, 2)).transpose(1, 2)
            encoder_hidden = torch.cat((encoder_hidden, p_embs), dim=-1)
            encoder_hidden = self.pitch_emb_enc_proj(encoder_hidden)

        # Duration prediction in logarithmic domain
        predicted_duration, _ = self.duration_rnn(duration_predictor_input)
        predicted_duration = self.duration_post_layer(predicted_duration).squeeze(-1)

        duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0) / speaking_rate
        duration = torch.round(duration).long()
        decoder_input, align_mat = self.length_regulator(encoder_hidden, duration)

        src_mask = decoder_input.new_ones(1, decoder_input.shape[1])
        if self.use_memory:
            decoder_input = self.memory(decoder_input.transpose(0, 1), 1 - src_mask).transpose(0, 1)

        if hasattr(self, "encdec_mapping"):
            decoder_input = self.encdec_mapping(decoder_input)

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        # RNN Decoder
        decoder_output = decoder_input
        for i in range(self.dec_rnn_num_layers):
            decoder_output, _ = self.__getattr__(f"dec_{i}")(decoder_output)

        mel_spec = self.mel_proj(decoder_output)

        return mel_spec, duration.int()

    @torch.no_grad()
    def export_encoder(
        self,
        phone_id,
        speaking_rate=1.0,
        f0_scale_ratio=None,
        f0_scale_min=0.97,
        f0_scale_max=1.03,
        style_id=None,
        spk_id=None,
        lang_id=None,
    ):
        # Important, Leanspeech has remove the useless dimension
        phone_id = phone_id.long()
        if style_id is not None:
            style_id = style_id.unsqueeze(0).long()

        # Phoneme or character embedding
        embedding = self.embedding(phone_id)

        # encoder
        encoder_output = embedding
        for i in range(self.enc_rnn_num_layers):
            encoder_output, _ = self.__getattr__(f"enc_{i}")(encoder_output)
        encoder_hidden = encoder_output

        # speaker embedding
        if self.enable_multi_speaker and spk_id is not None:
            spembs = self.speaker_embedding(spk_id.long())
            spembs = self.emb_act(self.speaker_embeddinglinear(spembs))
            spembs = spembs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.speaker_embedding_proj(torch.cat([encoder_hidden, spembs], dim=-1))

        # language embedding
        if self.enable_cross_lingual and lang_id is not None:
            langs = self.lang_embedding((lang_id).long())
            langs = self.emb_act(self.lang_embeddinglinear(langs))
            langs = langs.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.lang_embedding_proj(torch.cat([encoder_hidden, langs], dim=-1))

        # style embedding
        if self.use_style and style_id is not None:
            style_embedding = self.style_embedding(style_id.long()).unsqueeze(1)
            style_embedding = self.emb_act(self.style_embeddinglinear(style_embedding))
            style_embedding = style_embedding.repeat(1, encoder_hidden.size(1), 1)
            encoder_hidden = self.style_embedding_proj(torch.cat([encoder_hidden, style_embedding], dim=-1))

        duration_predictor_input = encoder_hidden
        if self.dur_pre_proj is not None:
            duration_predictor_input = self.dur_pre_proj(duration_predictor_input)

        # pitch prediction
        p_outs = None
        if hasattr(self, "pitch_predictor"):
            p_outs = self.pitch_predictor(encoder_hidden)
            if f0_scale_ratio is not None:
                scaled_f0 = p_outs * self.pitch_var + self.pitch_mean
                scaled_f0 = scaled_f0 * f0_scale_ratio
                scaled_f0 = (scaled_f0 - self.pitch_mean) / self.pitch_var

                f0_scale_mean = f0_scale_ratio.mean(1)
                p_outs = torch.where(
                    torch.logical_and(
                        torch.greater(f0_scale_mean, f0_scale_min), torch.less(f0_scale_mean, f0_scale_max)
                    ),
                    p_outs,
                    scaled_f0,
                )

            p_embs = self.pitch_embed(p_outs.transpose(1, 2)).transpose(1, 2)
            encoder_hidden = torch.cat((encoder_hidden, p_embs), dim=-1)
            encoder_hidden = self.pitch_emb_enc_proj(encoder_hidden)

        # Duration prediction in logarithmic domain
        predicted_duration, _ = self.duration_rnn(duration_predictor_input)
        predicted_duration = self.duration_post_layer(predicted_duration).squeeze(-1)

        duration = torch.clamp(torch.exp(predicted_duration) - 1.0, min=0.0) / speaking_rate
        duration = torch.round(duration).long()
        decoder_input, align_mat = self.length_regulator(encoder_hidden, duration)

        src_mask = decoder_input.new_ones(1, decoder_input.shape[1])
        if self.use_memory:
            decoder_input = self.memory(decoder_input.transpose(0, 1), 1 - src_mask).transpose(0, 1)

        if hasattr(self, "encdec_mapping"):
            decoder_input = self.encdec_mapping(decoder_input)

        if hasattr(self, "dec_pos_embedding"):
            decoder_pos_embedding = self.dec_pos_embedding(duration)
            decoder_input = decoder_input + decoder_pos_embedding

        return decoder_input, duration.int()

    @torch.no_grad()
    def export_decoder(self, decoder_input, hidden_seq):
        # RNN Decoder
        if len(hidden_seq) != 2 * self.dec_rnn_num_layers:
            raise NotImplementedError(
                f"Input hidden sequence {len(hidden_seq)} \
                should match number of decoder layers {self.dec_rnn_num_layers})"
            )

        out_hidden_seq = []
        decoder_output = decoder_input
        for i in range(self.dec_rnn_num_layers):
            decoder_output, hi_ = self.__getattr__(f"dec_{i}")(decoder_output, state=hidden_seq[2 * i : 2 * (i + 1)])
            out_hidden_seq.append(hi_)

        mel_spec = self.mel_proj(decoder_output)
        return mel_spec, out_hidden_seq

    def reset_parameters(self):
        # Note: parameter initialization is an important part in transformer based models
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            if p.dim() == 1:
                nn.init.zeros_(p)

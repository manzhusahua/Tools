import torch
import torch.nn as nn

from torchtts.nn.modules.attention import MultiheadAttention
from torchtts.nn.modules.common import GaussianSmoother
from torchtts.nn.modules.common.functional import make_stop_token
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.modules.common.functional import tril_mask
from torchtts.nn.modules.fastspeech import DecoderEmbedding
from torchtts.nn.modules.fastspeech import PositionEmbedding
from torchtts.nn.modules.transformer import DecoderPrenet
from torchtts.nn.modules.transformer import EncoderPrenet
from torchtts.nn.modules.transformer import PositionalEncoding
from torchtts.nn.modules.transformer import TransformerDecoder
from torchtts.nn.modules.transformer import TransformerDecoderLayer
from torchtts.nn.modules.transformer import TransformerEncoder
from torchtts.nn.modules.transformer import TransformerEncoderLayer

DEFAULT_MAX_SOURCE_POSITIONS = 1000
DEFAULT_MAX_TARGET_POSITIONS = 10000


class Transformer(nn.Module):
    """Feed Forward Transformer for TTS a.k.a. TransformerTTS.

    TransformerTTS is a neural TTS model based on Tacotron2 and
    Transformer, which requires an auto-regressive processing
    during inference stage.
    """

    def __init__(
        self,
        symbol_size,
        embedding_dim=384,
        out_dim=80,
        enc_layers=4,
        enc_hidden=384,
        enc_num_heads=2,
        enc_ffn_dims=(1536, 384),
        enc_ffn_kernels=(9, 1),
        enc_ffn_dilations=(1, 1),
        use_dec_embedding=False,
        use_dec_pos_embedding=True,
        dec_layers=6,
        dec_hidden=384,
        dec_num_heads=2,
        dec_ffn_dims=(1536, 384),
        dec_ffn_kernels=(9, 1),
        dec_ffn_dilations=(1, 1),
        t2t_compatible=True,
        smoother_params=None,
        dropout=0.1,
        dropout_prenet=0.5,
        layers_prenet_decoder=2,
        layers_prenet_encoder=3,
    ):
        super(Transformer, self).__init__()
        self.enc_hidden = enc_hidden
        self.dec_hidden = dec_hidden
        self.out_dim = out_dim

        self.embedding = nn.Embedding(num_embeddings=symbol_size, embedding_dim=embedding_dim, padding_idx=0)

        self.enc_pos_encoding = PositionalEncoding(
            model_dim=embedding_dim, dropout=dropout, max_len=DEFAULT_MAX_SOURCE_POSITIONS
        )

        encoder_layer = TransformerEncoderLayer(
            model_dim=enc_hidden,
            num_heads=enc_num_heads,
            ffn_dims=enc_ffn_dims,
            ffn_kernels=enc_ffn_kernels,
            ffn_dilations=enc_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
        )
        encoder_norm = nn.LayerNorm(enc_hidden)
        self.encoder = TransformerEncoder(encoder_layer=encoder_layer, num_layers=enc_layers, norm=encoder_norm)

        if smoother_params is not None:
            self.smoother = GaussianSmoother(**smoother_params)
        else:
            self.smoother = None

        self.dec_embedding = None
        if use_dec_embedding:
            self.dec_embedding = DecoderEmbedding(
                symbol_size=symbol_size, embedding_size=dec_hidden, hidden_size=dec_hidden, dropout=dropout
            )

        self.dec_pos_encoding = PositionalEncoding(
            model_dim=dec_hidden, dropout=dropout, max_len=DEFAULT_MAX_TARGET_POSITIONS
        )

        self.dec_pos_embedding = None
        if use_dec_pos_embedding:
            self.dec_pos_embedding = PositionEmbedding()

        self.dec_prenet = DecoderPrenet(
            out_dim, n_layers=layers_prenet_decoder, model_dim=dec_hidden, dropout_rate=dropout_prenet
        )

        # Note: FastSpeech's decoder is the same as encoder.
        decoder_layer = TransformerDecoderLayer(
            model_dim=dec_hidden,
            num_heads=dec_num_heads,
            ffn_dims=dec_ffn_dims,
            ffn_kernels=dec_ffn_kernels,
            ffn_dilations=dec_ffn_dilations,
            t2t_compatible=t2t_compatible,
            dropout=dropout,
        )
        decoder_norm = nn.LayerNorm(dec_hidden)
        self.decoder = TransformerDecoder(decoder_layer=decoder_layer, num_layers=dec_layers, norm=decoder_norm)

        self.mel_proj = nn.Linear(dec_hidden, out_dim, bias=False)
        self.prob_out = nn.Linear(dec_hidden, 1, bias=False)  # whether to use reduction_factor?

        self.reset_parameters()

        # special init
        self.enc_prenet = EncoderPrenet(
            embed_dim=embedding_dim, econv_layers=layers_prenet_encoder, econv_chans=enc_hidden
        )

    def forward(self, phone_id, mels, length=None, length_out=None, duration=None):
        if length is not None:
            src_mask = sequence_mask(length)
            src_padding_mask = ~src_mask
        else:
            src_mask = None
            src_padding_mask = None

        # phone_id -> (B, Tx)
        # Phoneme or character embedding
        embedding = self.embedding(phone_id)

        embedding *= self.enc_hidden**0.5
        # Go through decoder prenet
        encoder_input = self.enc_prenet(embedding)  # input mask

        # Add position encoding to embedding
        encoder_input = self.enc_pos_encoding(encoder_input)

        # FFT blocks as encoder
        encoder_output = self.encoder(encoder_input, src_key_padding_mask=src_padding_mask)

        # generate mask and stop token
        tgt_mask = sequence_mask(length_out)
        tgt_tril_mask = tril_mask(length_out)
        tgt_tril_padding_mask = ~tgt_tril_mask
        tgt_stop_token = make_stop_token(length_out)

        # make auto-regressive
        mels = self._add_first_frame_and_remove_last_frame(mels)

        # Go through decoder prenet
        decoder_input = self.dec_prenet(mels)

        # Add position encoding to decoder input
        decoder_input = self.dec_pos_encoding(decoder_input)

        # FFT blocks as decoder
        decoder_output, attn_cross_list = self.decoder(
            encoder_output,
            decoder_input,
            attn_mask=None,
            src_key_padding_mask=src_padding_mask,
            mel_tril_mask=tgt_tril_padding_mask,
            mel_mask=~tgt_mask,
        )
        # Project output features like mel
        mel_spec = self.mel_proj(decoder_output)
        mel_spec *= tgt_mask.to(mel_spec.dtype).unsqueeze(-1)
        stop_token = self.prob_out(decoder_output).view(decoder_output.size(0), -1)

        stop_token *= tgt_mask.to(stop_token.dtype)

        tgt_stop_token *= tgt_mask.to(tgt_stop_token.dtype)

        return mel_spec, stop_token, tgt_stop_token, tgt_mask, attn_cross_list

    @torch.no_grad()
    def inference(
        self, phone_id, speaking_rate=1.0, maxlenratio=50, minlenratio=1, threshold=0.5, attention_constrain=False
    ):
        embedding = self.embedding(phone_id)
        embedding *= self.enc_hidden**0.5

        encoder_input = self.enc_prenet(embedding)

        encoder_input = self.enc_pos_encoding(encoder_input)

        encoder_output = self.encoder(encoder_input)

        # set limits of length
        maxlen = int(encoder_output.size(1) * maxlenratio)
        minlen = int(encoder_output.size(1) * minlenratio)

        # initialize
        idx = 0
        mels = encoder_output.new_zeros(1, 1, self.out_dim)  # (1,1,80)

        outs, probs = [], []

        # forward decoder step-by-step
        cache = self.decoder.init_state()  # [None,None,None,None,None,None], just for the first time step

        # while True:
        for _ in range(maxlen + 1):
            # update index
            idx += 1
            decoder_input = self.dec_prenet(mels)
            decoder_input = self.dec_pos_encoding(decoder_input)

            mel_tril_mask = sequence_mask(torch.arange(1, idx + 1, device=encoder_output.device)).unsqueeze(
                0
            )  # for onnx

            one_mel, cache = self.decoder.inference(
                encoder_output,
                decoder_input,
                attn_mask=None,
                src_key_padding_mask=None,
                mel_tril_mask=~mel_tril_mask,
                mel_mask=None,
                cache=cache,
                attention_constrain=attention_constrain,
            )  # (B, adim)
            outs += [self.mel_proj(one_mel).view(1, self.out_dim)]  # [(1, odim), ...]
            probs += [torch.sigmoid(self.prob_out(one_mel))[0]]  # [(1), ...]

            # update next inputs using last reduction
            mels = torch.cat((mels, outs[-1][-1].view(1, 1, self.out_dim)), dim=1)  # (1, idx + 1, odim)

            # get attention weights
            att_ws_ = []
            for name, m in self.named_modules():
                if isinstance(m, MultiheadAttention) and "cross" in name:
                    att_ws_ += [
                        m.attn[0, :, -1].unsqueeze(1)
                    ]  # [(batch, head, 1, time2),...] -> [(head, time2),...] -> [(#heads, 1, T),...]
            if idx == 1:
                att_ws = att_ws_
            else:
                # [(#heads, l, T), ...]
                att_ws = [torch.cat([att_w, att_w_], dim=1) for att_w, att_w_ in zip(att_ws, att_ws_)]

            # check whether to finish generation
            if int(sum(probs[-1] >= threshold)) > 0 or idx >= maxlen:
                # check mininum length
                if idx < minlen:
                    continue
                outs = torch.cat(outs, dim=0).unsqueeze(0).transpose(1, 2)  # (L, odim) -> (1, L, odim) -> (1, odim, L)
                outs = outs.transpose(2, 1).squeeze(0)  # (L, odim)
                probs = torch.cat(probs, dim=0)
                break

        # concatenate attention weights -> (#layers, #heads, L, T)
        att_ws = torch.stack(att_ws, dim=0)

        return outs, probs, att_ws

    def reset_parameters(self):
        # Note: parameter initialization is an important part in transformer based models
        for p in self.parameters():
            # weight init
            if p.dim() > 1:
                nn.init.xavier_uniform_(p.data)
            # bias init
            if p.dim() == 1:
                p.data.zero_()

        for m in self.modules():
            if isinstance(m, (torch.nn.Embedding, torch.nn.LayerNorm)):
                m.reset_parameters()

        nn.init.normal_(self.embedding.weight, 0, self.enc_hidden**-0.5)

        if self.dec_embedding is not None:
            self.dec_embedding.reset_parameters()

    def _add_first_frame_and_remove_last_frame(self, ys):
        ys_in = torch.cat([-4 * ys.new_ones((ys.shape[0], 1, ys.shape[2])), ys[:, :-1]], dim=1)
        return ys_in

import torch
import torch.nn as nn
import torch.nn.functional as F


class GANLoss(nn.Module):
    def __init__(self, mode="lsgan"):
        super(GANLoss, self).__init__()
        assert mode in ["lsgan", "lsgan_std", "hinge"]
        self.mode = mode

    def disc_loss(self, real, fake):
        if self.mode == "lsgan":
            real_loss = F.mse_loss(real, torch.ones_like(real))
            fake_loss = F.mse_loss(fake, torch.zeros_like(fake))
        elif self.mode == "lsgan_std":
            real = (real - 1.0).pow(2)
            fake = (fake - 0.0).pow(2)
            real_loss = real.mean() + real.std()
            fake_loss = fake.mean() + fake.std()
        elif self.mode == "hinge":
            real_loss = torch.relu(1.0 - real).mean()
            fake_loss = torch.relu(1.0 + fake).mean()
        else:
            raise ValueError(f"no such mode {self.mode}")

        return real_loss, fake_loss

    def gen_loss(self, fake):
        if self.mode == "lsgan":
            gen_loss = F.mse_loss(fake, torch.ones_like(fake))
        elif self.mode == "lsgan_std":
            fake = (fake - 1.0).pow(2)
            gen_loss = fake.mean() + fake.std()
        elif self.mode == "hinge":
            gen_loss = -fake.mean()
        else:
            raise ValueError(f"no such mode {self.mode}")

        return gen_loss

    def disc_fake_loss(self, fake):
        if self.mode == "lsgan":
            fake_loss = F.mse_loss(fake, torch.zeros_like(fake))
        elif self.mode == "lsgan_std":
            fake = (fake - 0.0).pow(2)
            fake_loss = fake.mean() + fake.std()
        elif self.mode == "hinge":
            fake_loss = torch.relu(1.0 + fake).mean()
        else:
            raise ValueError(f"no such mode {self.mode}")

        return fake_loss

    def feature_loss(self, fmap_r, fmap_g):
        loss = 0
        for dr, dg in zip(fmap_r, fmap_g):
            for rl, gl in zip(dr, dg):
                loss += torch.mean(torch.abs(rl - gl))

        return loss * 2

import torch
import torch.nn as nn


class SequenceLoss(nn.Module):
    """Masked loss for sequence tasks."""

    def __init__(self, criterion_type, use_masking=True):
        super(SequenceLoss, self).__init__()
        self.use_masking = use_masking

        reduction = "none" if use_masking else "mean"
        if criterion_type == "l1_loss":
            self.criterion = nn.L1Loss(reduction=reduction)
        elif criterion_type == "mse_loss":
            self.criterion = nn.MSELoss(reduction=reduction)
        elif criterion_type == "bce_loss":
            self.criterion = nn.BCEWithLogitsLoss(reduction=reduction)
        else:
            raise ValueError(f"Criterion {criterion_type} is not supported yet")

    def forward(self, input_seq, target_seq, mask=None):
        loss = self.criterion(input_seq, target_seq)

        if self.use_masking:
            # TODO: use masked_select once the issue that masked_select CUDA kernel uses
            # too much memory is fixed (https://github.com/pytorch/pytorch/issues/30246).
            mask = mask.expand_as(input_seq)
            loss *= mask
            loss = torch.sum(loss) / torch.sum(mask)

        return loss

from torchtts.nn.metrics.accuracy import Accuracy
from torchtts.nn.metrics.accuracy import SparseCategoricalAccuracy
from torchtts.nn.metrics.reduce import Mean
from torchtts.nn.metrics.reduce import Sum

from torchtts.nn.metrics import functional as metric_fn
from torchtts.nn.metrics.reduce import MeanMetricWrapper


class Accuracy(MeanMetricWrapper):
    def __init__(self, dtype=None):
        super().__init__(metric_fn.accuracy, dtype=dtype)


class SparseCategoricalAccuracy(MeanMetricWrapper):
    def __init__(self, dtype=None):
        super().__init__(metric_fn.sparse_categorical_accuracy, dtype=dtype)

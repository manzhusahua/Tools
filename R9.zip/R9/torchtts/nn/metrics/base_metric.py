from abc import ABC
from abc import abstractmethod

import torch
import torch.nn as nn

from torchtts.utils.torch_utils import recursive_detach


class Metric(nn.Module, ABC):
    """Base class for all metrics."""

    def __init__(self, dtype=None):
        super(Metric, self).__init__()
        self.dtype = torch.float32 if dtype is None else dtype

    def update_state(self, *args, **kwargs):
        with torch.no_grad():
            self._update_state(*recursive_detach(args), **recursive_detach(kwargs))

    def result(self):
        with torch.no_grad():
            return self._result()

    @abstractmethod
    def _update_state(self, *args, **kwargs):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def _result(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    def reset_states(self):
        for v in self.buffers():
            nn.init.zeros_(v)

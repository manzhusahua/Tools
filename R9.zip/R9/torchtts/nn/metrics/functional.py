import torch


def accuracy(y_pred, y_true):
    # Force the types predicted output and actual output to match.
    if y_pred.dtype != y_true.dtype:
        y_pred = y_pred.type(y_true.dtype)

    return torch.eq(y_pred, y_true).float()


def sparse_categorical_accuracy(y_pred, y_true):
    # If the shape of y_true is (num_samples, 1), squeeze to (num_samples,)
    if y_pred.ndim == y_true.ndim:
        y_true = y_true.squeeze(-1)
    y_pred = y_pred.argmax(dim=-1)

    # Force the types predicted output and actual output to match.
    if y_pred.dtype != y_true.dtype:
        y_pred = y_pred.type(y_true.dtype)

    return torch.eq(y_pred, y_true).float()

from enum import Enum
import torch

from torchtts.nn.metrics.base_metric import Metric


class Reduction(Enum):
    """Types of metrics reduction."""

    SUM = "sum"
    MEAN = "mean"


class Reduce(Metric):
    def __init__(self, reduction, dtype=None):
        super(Reduce, self).__init__(dtype=dtype)
        if reduction not in Reduction:
            raise NotImplementedError(f"reduction [{self.reduction}] not implemented")
        self.reduction = reduction
        self.register_buffer("total", torch.tensor(0, dtype=self.dtype))
        if reduction == Reduction.MEAN:
            self.register_buffer("count", torch.tensor(0, dtype=self.dtype))

    def _update_state(self, values):
        if not torch.isfinite(values).all():
            raise ValueError("Detect nan and/or inf values in metrics")
        values = values.type(self.dtype)
        self.total.add_(values.sum())
        if self.reduction == Reduction.MEAN:
            self.count.add_(values.numel())

    def _result(self):
        if self.reduction == Reduction.SUM:
            return self.total.item()
        elif self.reduction == Reduction.MEAN:
            return torch.nan_to_num(torch.div(self.total, self.count), posinf=0.0, neginf=0.0).item()


class Sum(Reduce):
    """Compute the sum of given values."""

    def __init__(self, dtype=None):
        super(Sum, self).__init__(reduction=Reduction.SUM, dtype=dtype)


class Mean(Reduce):
    """Compute the mean of given values."""

    def __init__(self, dtype=None):
        super(Mean, self).__init__(reduction=Reduction.MEAN, dtype=dtype)


class MeanMetricWrapper(Mean):
    """Wraps a stateless metric function with the Mean metric."""

    def __init__(self, fn, dtype=None, **kwargs):
        super(MeanMetricWrapper, self).__init__(dtype=dtype)
        self._fn = fn
        self._fn_kwargs = kwargs

    def _update_state(self, y_pred, y_true):
        y_pred = y_pred.type(self.dtype)
        y_true = y_true.type(self.dtype)
        matches = self._fn(y_pred, y_true)
        return super(MeanMetricWrapper, self)._update_state(matches)

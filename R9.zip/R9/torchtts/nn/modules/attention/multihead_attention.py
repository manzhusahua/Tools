from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from torchtts.nn.modules.common.functional import attention_constrain_mask


class MultiheadAttention(torch.nn.Module):
    r"""Multi-head attention.

    Args:
        embed_dim: total dimension of the model.
        num_heads: parallel attention heads.
        dropout: a Dropout layer on attn_output_weights. Default: 0.0.
        k_dim: total number of features in key. Default: None.
        v_dim: total number of features in value. Default: None.

    Note:
        if k_dim and v_dim are None, they will be set to embed_dim such that
        query, key, and value have the same number of features.
    """

    def __init__(
        self,
        embed_dim,
        num_heads,
        dropout=0.0,
        bias=True,
        k_dim=None,
        v_dim=None,
        q_in_dim=None,
        k_in_dim=None,
        v_in_dim=None,
        out_dim=None,
    ):
        super(MultiheadAttention, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.dropout = dropout
        self.prev_max_attentions = torch.LongTensor([0 for i in range(num_heads)])
        self.attention_win_size = 3
        self.k_dim = k_dim if k_dim is not None else embed_dim
        self.v_dim = v_dim if v_dim is not None else embed_dim
        self.q_in_dim = q_in_dim if q_in_dim is not None else embed_dim
        self.k_in_dim = k_in_dim if k_in_dim is not None else embed_dim
        self.v_in_dim = v_in_dim if v_in_dim is not None else embed_dim
        self.out_dim = out_dim if out_dim is not None else embed_dim
        assert self.k_dim // num_heads * num_heads == self.k_dim, "k_dim must be divisible by num_heads"
        assert self.v_dim // num_heads * num_heads == self.v_dim, "v_dim must be divisible by num_heads"

        self.query_proj = nn.Linear(self.q_in_dim, self.k_dim, bias=bias)
        self.key_proj = nn.Linear(self.k_in_dim, self.k_dim, bias=bias)
        self.value_proj = nn.Linear(self.v_in_dim, self.v_dim, bias=bias)

        self.out_proj = nn.Linear(self.v_dim, self.out_dim, bias=bias)

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        key_padding_mask: Optional[torch.Tensor] = None,
        attn_mask: Optional[torch.Tensor] = None,
        bias_k: Optional[torch.Tensor] = None,
        bias_v: Optional[torch.Tensor] = None,
        attention_constrain: Optional[bool] = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""
        Args:
            query, key, value (Tensor): map a query and a set of key-value pairs to an output.
                See "Attention Is All You Need" for more details.
            key_padding_mask, attn_mask, bias_k and bias_v (Tensor, optional): keyword arguments
                passed to the attention layer. See the definitions in the attention.
        Shape:
            - Inputs:
            - query: :math:`(..., N, L, E)`
            - key: :math:`(..., N, S, E)`
            - value: :math:`(..., N, S, E)`
            - attn_mask, bias_k and bias_v: same with the shape of the corresponding args in attention layer.
            - Outputs:
            - attn_output: :math:`(..., N, L, E)`
            - attn_output_weights: :math:`(N, H, L, S)`
            Note: It's optional to have the query/key/value inputs with more than three dimensions.
                The MultiheadAttentionContainer module will operate on the last three dimensions.
            where where L is the target length, S is the sequence length, H is the number of attention heads,
                N is the batch size, and E is the embedding dimension.
        """
        bsz = query.size(0)
        q, k, v = self.query_proj(query), self.key_proj(key), self.value_proj(value)

        q = q.view(bsz, -1, self.num_heads, self.k_dim // self.num_heads)
        k = k.view(bsz, -1, self.num_heads, self.k_dim // self.num_heads)
        v = v.view(bsz, -1, self.num_heads, self.v_dim // self.num_heads)
        q, k, v = q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2)

        attn_output, attn_output_weights = self.compute_attention(
            q,
            k,
            v,
            attn_mask=attn_mask,
            key_padding_mask=key_padding_mask,
            bias_k=bias_k,
            bias_v=bias_v,
            attention_constrain=attention_constrain,
        )
        attn_output = attn_output.transpose(1, 2).reshape(bsz, -1, self.v_dim)
        attn_output = self.out_proj(attn_output)
        return attn_output, attn_output_weights

    def compute_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        key_padding_mask: Optional[torch.Tensor] = None,
        attn_mask: Optional[torch.Tensor] = None,
        bias_k: Optional[torch.Tensor] = None,
        bias_v: Optional[torch.Tensor] = None,
        attention_constrain: Optional[bool] = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Uses a scaled dot product with the projected key-value pair to update
        the projected query.
        Args:
            query (Tensor): Projected query
            key (Tensor): Projected key
            value (Tensor): Projected value
            key_padding_mask (Tensor): if provided, specified padding elements in the key will
                be ignored by the attention.
            attn_mask (BoolTensor, optional): 3D mask that prevents attention to certain positions.
            bias_k: (Tensor, optional): one more key and value sequence to be added at
                sequence dim (dim=-3). Those are used for incremental decoding. Users should provide
                non-None to both bias_k and bias_v in order to activate them.
            bias_v: (Tensor, optional): the same as bias_k.
        Shape:
            - query: :math:`(N, H, L, E / H)`
            - key: :math:`(N, H, S, E / H)`
            - value: :math:`(N, H, S, E / H)`
            - key_padding_mask: :math:`(N, S)`, positions with ``True`` are not allowed to attend
            - attn_mask: :math:`(N, H, L, S)`, positions with ``True`` are not allowed to attend
                while ``False`` values will be unchanged.
            - bias_k and bias_v:bias: :math:`(N, H, 1, E / H)`
            - Output: :math:`(N, H, L, E / H)`, :math:`(N, H, L, S)`
            where L is the target length, S is the source length, H is the number
            of attention heads, N is the batch size, and E is the embedding dimension.
        """
        if bias_k is not None and bias_v is not None:
            assert key.size() == bias_k.size(), "Shape of bias_k is not supported"
            assert value.size() == bias_v.size(), "Shape of bias_v is not supported"
            key = torch.cat([key, bias_k])
            value = torch.cat([value, bias_v])
            if key_padding_mask is not None:
                key_padding_mask = F.pad(attn_mask, (0, 1))
            if attn_mask is not None:
                attn_mask = F.pad(attn_mask, (0, 1))

        tgt_len, src_len = query.size(-2), key.size(-2)

        # Scale query
        query = query * (float(self.k_dim // self.num_heads) ** -0.5)

        if key_padding_mask is not None:
            if key_padding_mask.dim() != 2:
                raise RuntimeError("key_padding_mask must be a 2D tensor.")
            if key_padding_mask.size(-1) != src_len:
                raise RuntimeError("The size of the attn_mask is not correct.")
            if key_padding_mask.dtype != torch.bool:
                raise RuntimeError("Only bool tensor is supported for key_padding_mask")

        if attn_mask is not None:
            if attn_mask.dim() != 3:
                raise RuntimeError("attn_mask must be a 3D tensor.")
            if attn_mask.size(-1) != src_len or attn_mask.size(-2) != tgt_len:
                raise RuntimeError("The size of the attn_mask is not correct.")
            if attn_mask.dtype != torch.bool:
                raise RuntimeError("Only bool tensor is supported for attn_mask")

        # Dot product of q, k
        attn_output_weights = torch.matmul(query, key.transpose(-2, -1))
        if key_padding_mask is not None:
            attn_output_weights.masked_fill_(key_padding_mask.unsqueeze(1).unsqueeze(2), float("-inf"))
        if attn_mask is not None:
            attn_output_weights.masked_fill_(attn_mask.unsqueeze(1), float("-inf"))

        if attention_constrain:
            tx = attn_output_weights.size(-1)  # attn_output_weights.size = (1, head, 1, time2)
            key_masks = attention_constrain_mask(
                self.prev_max_attentions, xs=torch.zeros(self.num_heads, tx)
            )  # (self.num_heads, Tx)
            reverse_masks = torch.flip(
                attention_constrain_mask(
                    tx - self.attention_win_size - self.prev_max_attentions, xs=torch.zeros(self.num_heads, tx)
                ),
                dims=[-1],
            )  # (self.num_heads, Tx)
            constrain_masks = torch.logical_or(key_masks, reverse_masks)  # (self.num_heads, Tx)
            constrain_masks = constrain_masks.unsqueeze(0).unsqueeze(2)  # (1, self.num_heads, 1, Tx)
            attn_output_weights_constrained = attn_output_weights.masked_fill(constrain_masks, float("-inf"))
            attn_output_weights_constrained_softmax = F.softmax(attn_output_weights_constrained, dim=-1)
            focus_rate = torch.max(F.softmax(attn_output_weights_constrained_softmax, -1), -1)[0] > 0.6
            focus_rate = focus_rate.unsqueeze(-1).expand_as(constrain_masks)
            attn = attn_output_weights_constrained_softmax * focus_rate.int() + F.softmax(
                attn_output_weights, dim=-1
            ) * (
                (~focus_rate).int()
            )  # to compare two score
            current_max_attentions = torch.argmax(attn.squeeze(0).squeeze(1), dim=-1)  # (head,)
            jump = torch.gt(current_max_attentions, self.prev_max_attentions)
            self.prev_max_attentions += jump.int()  # to jump only one step based on prev_max_attentions
        else:
            attn_output_weights = F.softmax(attn_output_weights, dim=-1)
            attn = attn_output_weights
        attn_output_weights = F.dropout(attn_output_weights, p=self.dropout, training=self.training)
        attn_output = torch.matmul(attn_output_weights, value)

        return attn_output, attn

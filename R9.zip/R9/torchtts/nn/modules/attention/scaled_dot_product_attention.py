import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


class ScaledDotProductAttention(nn.Module):
    r"""Apply scaled dot product attention with a projected query and key-value pair.

    Args:
        dropout (float): probability of dropping an attention weight.
    """

    def __init__(self, dropout=0.0):
        super(ScaledDotProductAttention, self).__init__()
        self.dropout = dropout

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        key_padding_mask: Optional[torch.Tensor] = None,
        attn_mask: Optional[torch.Tensor] = None,
        bias_k: Optional[torch.Tensor] = None,
        bias_v: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        r"""Uses a scaled dot product with the projected key-value pair to update
        the projected query.
        Args:
            query (Tensor): Projected query
            key (Tensor): Projected key
            value (Tensor): Projected value
            key_padding_mask (Tensor): if provided, specified padding elements in the key will
                be ignored by the attention.
            attn_mask (BoolTensor, optional): 3D mask that prevents attention to certain positions.
            bias_k: (Tensor, optional): one more key and value sequence to be added at
                sequence dim (dim=-3). Those are used for incremental decoding. Users should provide
                non-None to both bias_k and bias_v in order to activate them.
            bias_v: (Tensor, optional): the same as bias_k.
        Shape:
            - query: :math:`(..., N * H, L, E / H)`
            - key: :math:`(..., N * H, S, E / H)`
            - value: :math:`(..., N * H, S, E / H)`
            - key_padding_mask: :math:`(N * H, S)`, positions with ``True`` are not allowed to attend
            - attn_mask: :math:`(N * H, L, S)`, positions with ``True`` are not allowed to attend
                while ``False`` values will be unchanged.
            - bias_k and bias_v:bias: :math:`(N * H, 1, E / H)`
            - Output: :math:`(..., N * H, L, E / H)`, :math:`(N * H, L, S)`
            Note: It's optional to have the q/k/v with more than three dimensions (for broadcast purpose).
                The ScaledDotProduct module will operate on the last three dimensions.
            where L is the target length, S is the source length, H is the number
            of attention heads, N is the batch size, and E is the embedding dimension.
        """
        if bias_k is not None and bias_v is not None:
            assert key.shape[-3:] == bias_k.shape[-3:], "Shape of bias_k is not supported"
            assert value.shape[-3:] == bias_v.shape[-3:], "Shape of bias_v is not supported"
            key = torch.cat([key, bias_k])
            value = torch.cat([value, bias_v])
            if key_padding_mask is not None:
                key_padding_mask = F.pad(attn_mask, (0, 1))
            if attn_mask is not None:
                attn_mask = F.pad(attn_mask, (0, 1))

        tgt_len, head_dim = query.size(-2), query.size(-1)
        assert query.size(-1) == key.size(-1) == value.size(-1), "The feature dim of query, key, value must be equal."
        assert key.size() == value.size(), "Shape of key, value must match"
        src_len = key.size(-2)
        batch_heads = max(query.size(-3), key.size(-3))

        # Scale query
        query = query * (float(head_dim) ** -0.5)

        if key_padding_mask is not None:
            if key_padding_mask.dim() != 2:
                raise RuntimeError("key_padding_mask must be a 2D tensor.")
            if (key_padding_mask.size(-1) != src_len) or (
                key_padding_mask.size(-2) != 1 and key_padding_mask.size(-2) != batch_heads
            ):
                raise RuntimeError("The size of the key_padding_mask is not correct.")
            if key_padding_mask.dtype != torch.bool:
                raise RuntimeError("Only bool tensor is supported for key_padding_mask")

        if attn_mask is not None:
            if attn_mask.dim() != 3:
                raise RuntimeError("attn_mask must be a 3D tensor.")
            if (
                (attn_mask.size(-1) != src_len)
                or (attn_mask.size(-2) != tgt_len)
                or (attn_mask.size(-3) != 1 and attn_mask.size(-3) != batch_heads)
            ):
                raise RuntimeError("The size of the attn_mask is not correct.")
            if attn_mask.dtype != torch.bool:
                raise RuntimeError("Only bool tensor is supported for attn_mask")

        # Dot product of q, k
        attn_output_weights = torch.matmul(query, key.transpose(-2, -1))
        if key_padding_mask is not None:
            attn_output_weights.masked_fill_(key_padding_mask.unsqueeze(1), float("-inf"))
        if attn_mask is not None:
            attn_output_weights.masked_fill_(attn_mask, float("-inf"))
        attn_output_weights = F.softmax(attn_output_weights, dim=-1)
        attn_output_weights = F.dropout(attn_output_weights, p=self.dropout, training=self.training)
        attn_output = torch.matmul(attn_output_weights, value)

        return attn_output, attn_output_weights

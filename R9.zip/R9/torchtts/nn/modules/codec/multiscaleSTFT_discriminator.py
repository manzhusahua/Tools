import torch
import torch.nn as nn


def get_2d_padding(kernel_size, dilation=(1, 1)):
    return (((kernel_size[0] - 1) * dilation[0]) // 2, ((kernel_size[1] - 1) * dilation[1]) // 2)


class STFTDiscriminator(nn.Module):
    """STFT discriminator."""
    def __init__(
        self,
        filters=16,
        in_channels=1,
        out_channels=1,
        kernel_size=(3, 9),
        max_filters=1024,
        filters_scale=2,
        dilations=(1, 2, 4),
        stride=(1, 2)
    ):
        super().__init__()
        self.filters = filters
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.activation = nn.LeakyReLU(0.2, True)
        spec_channels = 2 * self.in_channels

        self.model = nn.ModuleDict()
        self.model['layer_0'] = nn.Conv2d(
            spec_channels,
            self.filters,
            kernel_size=kernel_size,
            padding=get_2d_padding(kernel_size)
        )

        in_chs = self.filters
        for i, dilation in enumerate(dilations):
            out_chs = min((filters_scale ** (i + 1)) * self.filters, max_filters)
            self.model[f"layer_{i + 1}"] = torch.nn.utils.weight_norm(
                nn.Conv2d(
                    in_chs,
                    out_chs,
                    kernel_size=kernel_size,
                    stride=stride,
                    dilation=(dilation, 1),
                    padding=get_2d_padding(kernel_size, (dilation, 1)))
            )
            in_chs = out_chs

        out_chs = min((filters_scale ** (len(dilations) + 1)) * self.filters, max_filters)
        self.model[f"layer_{len(dilations) + 1}"] = torch.nn.utils.weight_norm(
            nn.Conv2d(
                in_chs,
                out_chs,
                kernel_size=(kernel_size[0], kernel_size[0]),
                padding=get_2d_padding((kernel_size[0], kernel_size[0]))
            )
        )

        self.post_model = torch.nn.utils.weight_norm(
            nn.Conv2d(
                out_chs,
                self.out_channels,
                kernel_size=(kernel_size[0], kernel_size[0]),
                padding=get_2d_padding((kernel_size[0], kernel_size[0]))
            )
        )

    def forward(self, x):
        fmap = []
        x = x.unsqueeze(1)
        x = torch.cat([x.real, x.imag], dim=1)
        x = x.permute(0, 1, 3, 2)
        for _, layer in self.model.items():
            x = layer(x)
            x = self.activation(x)
            fmap.append(x)
        x = self.post_model(x)
        return x, fmap


class MSSTFTDiscriminator(nn.Module):
    """Multi scale STFT discriminator."""
    def __init__(
        self,
        stft_params=None,
        filters=16,
        in_channels=1,
        out_channels=1
    ):
        super().__init__()
        if stft_params is None:
            stft_params = {
                'fft_sizes': [1024, 2048, 512, 256],
                'hop_sizes': [256, 512, 128, 64],
                'win_lengths': [1024, 2048, 512, 256],
                'window': 'hann_window'
            }
        self.stft_params = stft_params

        self.model = nn.ModuleDict()
        for i in range(len(stft_params['fft_sizes'])):
            self.model["disc_" + str(i)] = STFTDiscriminator(
                filters=filters,
                in_channels=in_channels,
                out_channels=out_channels
            )
        self.reset_parameters()

    def forward(self, x, ret_logits=True, ret_fmaps=True):
        logits = []
        fmaps = []
        i = 0
        x = x.squeeze(1)
        for _, disc in self.model.items():
            spec = torch.stft(
                x,
                n_fft=self.stft_params['fft_sizes'][i],
                hop_length=self.stft_params['hop_sizes'][i],
                win_length=self.stft_params['win_lengths'][i],
                window=getattr(torch, self.stft_params['window'])(self.stft_params['win_lengths'][i]).to(x.device),
                center=False,
                pad_mode=None,
                normalized=True,
                onesided=True,
                return_complex=True
            )

            logit, fmap = disc(spec)
            logits.append(logit)
            fmaps.append(fmap)
            i += 1

        if ret_logits is False:
            logits = None
        if ret_fmaps is False:
            fmaps = None
        return logits, fmaps

    def reset_parameters(self):
        """Reset parameters."""
        def _reset_parameters(m):
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                m.weight.data.normal_(0.0, 0.02)
        self.apply(_reset_parameters)

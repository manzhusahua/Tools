import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from torchtts.nn.modules.common.layer_norm import LayerNorm


class SeparableConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding=0, scale_factor=1):
        super(SeparableConv1d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.padding = padding

        self.W_depthwise = nn.Parameter(torch.Tensor(in_channels * scale_factor, 1, self.kernel_size))
        self.W_pointwise = nn.Parameter(torch.Tensor(out_channels, in_channels * scale_factor, 1))
        self.bias = nn.Parameter(torch.Tensor(out_channels))

        self.reset_parameters()

    def reset_parameters(self):
        std = math.sqrt(4.0 / (self.kernel_size * self.out_channels))
        nn.init.normal_(self.W_depthwise, mean=0, std=std)
        nn.init.normal_(self.W_pointwise, mean=0, std=std)
        nn.init.constant_(self.bias, 0)

    def forward(self, x):
        x = F.conv1d(x.contiguous(), self.W_depthwise, padding=self.padding, groups=self.in_channels)
        x = F.conv1d(x, self.W_pointwise, bias=self.bias)
        return x

    def extra_repr(self):
        return "in_channels={}, out_channels={}, kernel_size={}, padding={}".format(
            self.in_channels, self.out_channels, self.kernel_size, self.padding
        )


class ConvActNorm(nn.Module):
    def __init__(self, idim, odim, kernel_size=1, act=None, conv_scale_factor=1):
        super(ConvActNorm, self).__init__()

        if kernel_size % 2 != 0:
            padding = (kernel_size - 1) // 2
        else:
            padding = ((kernel_size - 1) // 2, (kernel_size - 1) // 2 + 1)

        self.pad = nn.ConstantPad1d(padding, value=0.0)  # for same padding
        self.conv = SeparableConv1d(idim, odim, kernel_size, scale_factor=conv_scale_factor)
        self.act = act
        self.norm = LayerNorm(odim, dim=1)

    def forward(self, x):
        x = self.pad(x)
        x = self.conv(x)
        if self.act is not None:
            x = self.act(x)
        x = self.norm(x)
        return x


class HighWay(nn.Module):
    def __init__(self, idim):
        super(HighWay, self).__init__()

        self.H = torch.nn.Linear(idim, idim)
        self.H.bias.data.zero_()

        self.T = torch.nn.Linear(idim, idim)
        self.T.bias.data.fill_(-1)

    def forward(self, x):
        h = self.H(x).relu()
        t = self.T(x).sigmoid()
        outputs = h * t + x * (1 - t)
        return outputs


class CBHG(nn.Module):
    def __init__(
        self,
        idim=256,
        odim=256,
        conv_bank_kernel_sizes=(3, 5, 7, 9, 11, 13, 15, 17, 21, 23),
        conv_dim=128,
        conv_scale_factor=1,
        proj_dim=256,
        proj_kernel_size=3,
        highway_layers=2,
    ):
        super(CBHG, self).__init__()

        half_dim = odim // 2

        self.conv_banks = nn.ModuleList()
        for k in conv_bank_kernel_sizes:
            self.conv_banks.append(ConvActNorm(idim, conv_dim, k, F.relu, conv_scale_factor))

        self.pool = nn.Sequential(nn.ConstantPad1d((0, 1), value=0.0), nn.AvgPool1d(kernel_size=2, stride=1))

        self.conv_proj1 = ConvActNorm(conv_dim, proj_dim, proj_kernel_size, F.relu, conv_scale_factor)
        self.conv_proj2 = ConvActNorm(proj_dim, idim, proj_kernel_size, conv_scale_factor=conv_scale_factor)

        self.highways = []
        if idim != half_dim:
            self.highways.append(nn.Linear(idim, half_dim, bias=False))
        for _ in range(highway_layers):
            self.highways.append(HighWay(half_dim))
        self.highways = nn.Sequential(*self.highways)

        self.rnn = nn.LSTM(half_dim, half_dim, batch_first=True, bidirectional=True)

    def forward(self, x):
        x = x.transpose(1, 2)

        residual = x
        conv_bank_outputs = []
        for conv_bank in self.conv_banks:
            conv_bank_outputs.append(conv_bank(x))
        conv_bank_outputs = sum(conv_bank_outputs) / len(conv_bank_outputs)

        pool_outputs = self.pool(conv_bank_outputs)

        conv_proj1_outputs = self.conv_proj1(pool_outputs)
        conv_proj2_outputs = self.conv_proj2(conv_proj1_outputs)

        highway_inputs = conv_proj2_outputs + residual
        highway_inputs = highway_inputs.transpose(1, 2)
        highway_outputs = self.highways(highway_inputs)

        rnn_outputs, _ = self.rnn(highway_outputs)

        return rnn_outputs

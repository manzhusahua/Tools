import torch
import torch.nn as nn


class DilatedCNNEncoder(nn.Module):
    def __init__(
        self, num_layers, hidden_size, kernel_size, dilation, local_condition_channels=-1, global_condition_channels=-1
    ):
        super().__init__()

        self.dilated_cnns = nn.ModuleList()
        for _ in range(num_layers):
            self.dilated_cnns.append(
                GatedDilatedConv1d(
                    filter_width=kernel_size,
                    dilation=dilation,
                    residual_channels=hidden_size,
                    dilation_channels=hidden_size,
                    skip_channels=hidden_size,
                    local_condition_channels=local_condition_channels,
                    global_condition_channels=global_condition_channels,
                )
            )

    def forward(self, feats, feats_masks=None, local_conditions=None, global_conditions=None, permute=True):
        if permute:
            residual = feats.permute(0, 2, 1).contiguous()
        else:
            residual = feats

        skip_outputs = []
        for dilated_cnn in self.dilated_cnns:
            residual, skip_output = dilated_cnn(
                residual, feats_masks, local_condition=local_conditions, global_condition=global_conditions
            )
            skip_outputs.append(skip_output)

        output = sum(skip_outputs)

        if feats_masks is not None:
            output *= feats_masks.to(feats.dtype).unsqueeze(1)

        if permute:
            output = output.permute(0, 2, 1).contiguous()

        return output


class GatedDilatedConv1d(nn.Module):
    """Creates a single causal dilated convolution layer.
    The layer contains a gated filter that connects to dense output
    and to a skip connection:
           |-> [gate]   -|        |-> 1x1 conv -> skip output
           |             |-> (*) -|
    input -|-> [filter] -|        |-> 1x1 conv -|
           |                                    |-> (+) -> dense output
           |------------------------------------|
    Where `[gate]` and `[filter]` are causal convolutions with a
    non-linear activation at the output. Biases and global conditioning
    are omitted due to the limits of ASCII art.
    """

    def __init__(
        self,
        filter_width,
        dilation,
        residual_channels,
        dilation_channels,
        skip_channels,
        local_condition_channels=-1,
        global_condition_channels=-1,
    ):
        """Initializes the GatedDilatedConv1d.
        Args:
            filter_width:
            dilation:
            residual_channels:
            dilation_channels:
            skip_channels:
            local_condition_channels:
        """
        super().__init__()
        self.residual_channels = residual_channels
        self.skip_channels = skip_channels
        self.dilation_channels = dilation_channels

        if filter_width % 2 == 0:
            raise ValueError(
                "You must specify an odd number to filter_width " "to make sure the shape is invariant after conv."
            )
        padding = (filter_width - 1) // 2 * dilation
        self.conv_filter_gate = nn.Conv1d(
            residual_channels, dilation_channels * 2, filter_width, padding=padding, dilation=dilation
        )

        if local_condition_channels > 0:
            self.conv_lc_filter_gate = nn.Conv1d(local_condition_channels, dilation_channels * 2, 1, bias=False)

        if global_condition_channels > 0:
            self.conv_gc_filter_gate = nn.Conv1d(global_condition_channels, dilation_channels * 2, 1, bias=False)

        # The 1x1 conv to produce the residual and skip output
        self.conv_dense = nn.Conv1d(dilation_channels, residual_channels + skip_channels, 1)

    def forward(self, feats, masks=None, local_condition=None, global_condition=None):
        """
        Args:
            feats: Shape: [batch_size, channels, time].
            local_condition: Shape: [batch_size, channels, time].
        """
        feats_filter_gate = self.conv_filter_gate(feats)

        if hasattr(self, "conv_lc_filter_gate"):
            lc_filter_gate = self.conv_lc_filter_gate(local_condition)
            feats_filter_gate += lc_filter_gate

        if hasattr(self, "conv_gc_filter_gate"):
            gc_filter_gate = self.conv_gc_filter_gate(global_condition.unsqueeze(-1))
            feats_filter_gate += gc_filter_gate

        feats_filter, feats_gate = torch.split(feats_filter_gate, self.dilation_channels, 1)
        gated_feats_batch = torch.tanh(feats_filter) * torch.sigmoid(feats_gate)

        # The 1x1 conv to produce the residual and skip output
        transformed = self.conv_dense(gated_feats_batch)
        if masks is not None:
            transformed *= masks.to(feats.dtype).unsqueeze(1)

        residual_output, skip_output = transformed.split([self.residual_channels, self.skip_channels], dim=1)

        residual_output = residual_output + feats

        return residual_output, skip_output

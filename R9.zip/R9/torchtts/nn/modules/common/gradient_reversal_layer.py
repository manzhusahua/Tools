from torch.autograd import Function


class GRL(Function):
    @staticmethod
    def forward(self, x):
        return x

    @staticmethod
    def backward(self, grad_output):
        grad_input = grad_output.neg()
        return grad_input

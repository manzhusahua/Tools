import numbers
import torch.nn as nn


class LayerNorm(nn.LayerNorm):
    r"""Variant of Layer Normalization which supports condition as described in
    the paper `AdaSpeech: Adaptive Text to Speech for Custom Voice`"""

    def __init__(self, normalized_shape, condition_dim=-1, eps=1e-5, elementwise_affine=True, dim=-1):
        self.enable_condition = condition_dim != -1
        elementwise_affine = False if self.enable_condition else elementwise_affine
        super(LayerNorm, self).__init__(normalized_shape, eps, elementwise_affine)
        if self.enable_condition:
            assert isinstance(normalized_shape, numbers.Integral)
            self.weight_proj = nn.Linear(condition_dim, normalized_shape)
            self.bias_proj = nn.Linear(condition_dim, normalized_shape)
        self.dim = dim

    def forward(self, x, condition=None):
        x = x.transpose(self.dim, -1)
        if self.enable_condition and condition is not None:
            weight = self.weight_proj(condition)
            bias = self.bias_proj(condition)
            x = super(LayerNorm, self).forward(x) * weight + bias
        else:
            x = super(LayerNorm, self).forward(x)
        return x.transpose(self.dim, -1)

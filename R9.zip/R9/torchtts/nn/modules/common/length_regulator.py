import logging
import torch
import torch.nn as nn

from torchtts.nn.modules.common.functional import duration_to_alignment_matrix

logger = logging.getLogger(__name__)


class LengthRegulator(nn.Module):
    """Length regulator module for duration expansion.

    Args:
        rate_scale: the scale to control the speed of speech
    """

    def __init__(self, rate_scale=1.0, smoother=None):
        super(LengthRegulator, self).__init__()
        self.rate_scale = rate_scale
        self.smoother = smoother

    def forward(self, phone_feats, durations):
        if self.rate_scale != 1.0:
            phone_feats = torch.round(phone_feats.float() * self.rate_scale).long()

        align_mat = duration_to_alignment_matrix(durations)
        if self.smoother is not None:
            smoothed_align_mat = self.smoother(align_mat)
        else:
            smoothed_align_mat = align_mat

        frame_feats = torch.matmul(smoothed_align_mat, phone_feats)

        return frame_feats, align_mat


class InverseLengthRegulator(nn.Module):
    """Inverse length regulator module for duration compression."""

    def __init__(self):
        super().__init__()

    def forward(self, frame_feats, durations):
        align_mat = duration_to_alignment_matrix(durations).transpose(1, 2)

        scale = align_mat.sum(dim=-1)
        scale[scale == 0] = 1
        align_mat /= scale.unsqueeze(-1)

        phone_feats = torch.matmul(align_mat, frame_feats)

        return phone_feats, align_mat

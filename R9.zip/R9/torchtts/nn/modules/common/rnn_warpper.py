import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class PackedWrapper(nn.Module):
    def __init__(self, module_inner):
        super(PackedWrapper, self).__init__()
        self.module_inner = module_inner

    def forward(self, x, state=None, mask=None):
        if mask is None:
            output, state_new = self.module_inner(x, state)
        else:
            x_ = pack_padded_sequence(x, mask.sum(dim=1).cpu(), batch_first=True, enforce_sorted=False)
            output_, state_new = self.module_inner(x_, state)
            output, _ = pad_packed_sequence(output_, batch_first=True)
        return output, state_new


class HighwayRNN(nn.Module):
    def __init__(self, rnn_module, dim, drop=0):
        super(HighwayRNN, self).__init__()
        self.rnn_module = rnn_module
        self.drop = nn.Dropout(drop)
        self.alpha = nn.Parameter(torch.Tensor(dim))
        with torch.no_grad():
            self.alpha.fill_(1)

    def forward(self, x, state=None, mask=None):
        y = x * self.alpha
        output, state_new = self.rnn_module(x, state, mask)
        return self.drop(output + y), state_new


class ConvLSTM(nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim, bi_direction=False, rnn_reduce=1, ffn_groups_batch_size=8):
        super(ConvLSTM, self).__init__()
        if bi_direction:
            self.lstm = nn.LSTM(
                input_size=in_dim, hidden_size=out_dim // rnn_reduce // 2, batch_first=True, bidirectional=bi_direction
            )
        else:
            self.lstm = nn.LSTM(
                input_size=in_dim, hidden_size=out_dim // rnn_reduce, batch_first=True, bidirectional=bi_direction
            )

        self.rnnReduce = rnn_reduce
        self.ffn = nn.Sequential(
            nn.Conv1d(in_dim, hidden_dim * 2, 3, groups=in_dim // ffn_groups_batch_size, padding=1),
            nn.GLU(-2),
            nn.Conv1d(hidden_dim, hidden_dim * 2, 3, groups=in_dim // ffn_groups_batch_size, padding=1),
            nn.GLU(-2),
            nn.Conv1d(hidden_dim, out_dim * 2, 3, groups=in_dim // ffn_groups_batch_size, padding=1),
            nn.GLU(-2),
        )

    def forward(self, x, state=None, mask=None):
        if mask is None:
            lstm_out, state_new = self.lstm(x, state)
        else:
            x_ = pack_padded_sequence(x, mask.sum(dim=1).cpu(), batch_first=True, enforce_sorted=False)
            lstm_out, state_new = self.lstm(x_, state)
            lstm_out, _ = pad_packed_sequence(lstm_out, batch_first=True)

        if self.rnnReduce > 1:
            lstm_out = lstm_out.repeat(1, 1, self.rnnReduce)

        output = self.ffn(x.transpose(1, 2)).transpose(1, 2) + lstm_out
        return output, state_new

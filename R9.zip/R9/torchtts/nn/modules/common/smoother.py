import torch
import torch.nn as nn
import torch.nn.functional as F


class GaussianSmoother(nn.Module):
    def __init__(self, kernel_size=3):
        super(GaussianSmoother, self).__init__()

        assert kernel_size % 2 == 1

        self.kernel_size = kernel_size
        self.size = kernel_size // 2
        dist = torch.distributions.Normal(0.0, self.size)
        kernel = torch.arange(start=-self.size, end=self.size + 1)
        kernel = torch.exp(dist.log_prob(kernel))
        kernel /= torch.sum(kernel)
        kernel = kernel.unsqueeze(0).unsqueeze(0).unsqueeze(-1)

        self.register_buffer("kernel", kernel)

        self.padding = (kernel_size // 2, 0)

    def forward(self, x):
        x = F.conv2d(x.unsqueeze(1), self.kernel, padding=self.padding).squeeze(1)
        return x

    def extra_repr(self):
        return "kernel_size={}".format(self.kernel_size)

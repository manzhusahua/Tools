import torch.nn as nn
import torch.nn.functional as F


class Conv1d(nn.Module):
    """Version of conv1d that is compatible with T2t."""

    def __init__(self, in_channels, out_channels, kernel_size, dilation=1, bias=True):
        super(Conv1d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.dilated_size = int(kernel_size + (kernel_size - 1) * (dilation - 1))
        self.conv1d_dense = nn.ModuleList()
        for i in range(kernel_size):
            self.conv1d_dense.append(nn.Linear(in_channels, out_channels, bias=(bias and i == 0)))

    def forward(self, inputs):
        first_offset = -((self.dilated_size - 1) // 2)
        last_offset = first_offset + self.dilated_size - 1
        padded = F.pad(inputs, (0, 0, -first_offset, last_offset), "constant", 0)
        results = []
        for i in range(self.kernel_size):
            start_index = i * self.dilation
            shifted = padded[:, start_index : start_index + inputs.size(1)] if i else inputs
            results.append(self.conv1d_dense[i](shifted))
        ret = sum(results)
        return ret

    def extra_repr(self):
        return "in_channels={}, out_channels={}, kernel_size={}, dilation={}".format(
            self.in_channels, self.out_channels, self.kernel_size, self.dilation
        )

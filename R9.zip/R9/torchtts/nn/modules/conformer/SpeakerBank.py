import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class StaticSelfAttn(nn.Module):
    def __init__(self, n_pos, d_model, nhead):
        super(StaticSelfAttn, self).__init__()
        # Kaiming Initialize
        self.weight = nn.Parameter(torch.randn(1, 1, nhead, n_pos, n_pos) * np.sqrt(2 / n_pos), requires_grad=True)
        self.value_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        self.nhead = nhead
        self.d_model = d_model
        assert self.d_model % self.nhead == 0

    def forward(self, x):
        """
        :param x: T x B x C
        :return: T x B x C
        """
        xt, xb, xc = x.shape
        x = self.value_proj(x).reshape(xt, xb, self.nhead, xc // self.nhead).permute((3, 1, 2, 0)).unsqueeze(-2)  # c B H 1 T
        x = torch.matmul(x, self.weight).squeeze(-2).permute((3, 1, 2, 0)).reshape(xt, xb, xc)
        return self.out_proj(x)


def _get_activation_fn(activation):
    if activation == "relu":
        return F.relu
    elif activation == "gelu":
        return F.gelu

    raise RuntimeError("activation should be relu/gelu, not {}".format(activation))


class CrossSelfAttnBlock(nn.Module):
    def __init__(self, n_pos, d_model, nhead, dim_feedforward=2048, dropout=0.1, activation="relu", **kwargs):
        super(CrossSelfAttnBlock, self).__init__()
        self.self_attn = StaticSelfAttn(n_pos, d_model, nhead)
        self.multihead_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)
        # Implementation of Feedforward model
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)

        self.activation = _get_activation_fn(activation)

    def forward(self, tgt, memory, memory_mask=None, memory_key_padding_mask=None, cross_res=True, return_attn=False):
        """
        This module is different from transformer decoder layer in the below aspects:
        1. Do cross attention first, then do self attention
        2. Self attention is implemented with static self attention.
        3. Cross attention don't have residue connection when this module is used as the first layer.
        """
        attn_maps = {}
        tgt2, attn_map = self.multihead_attn(tgt, memory, memory, attn_mask=memory_mask,
                                             key_padding_mask=memory_key_padding_mask)
        if return_attn:
            attn_maps['cross_attn'] = attn_map.detach().cpu().numpy()
        if cross_res:
            tgt = tgt + self.dropout1(tgt2)
        else:
            tgt = self.dropout1(tgt2)
        tgt = self.norm1(tgt)

        tgt2 = self.self_attn(tgt)
        tgt = tgt + self.dropout2(tgt2)
        tgt = self.norm2(tgt)

        tgt2 = self.linear2(self.dropout(self.activation(self.linear1(tgt))))
        tgt = tgt + self.dropout3(tgt2)
        tgt = self.norm3(tgt)

        return tgt, attn_maps


class Conv1dResBlock(nn.Module):
    def __init__(self, dim_in, kernel_size, stride=4):
        super(Conv1dResBlock, self).__init__()
        padding = (kernel_size - 1) // 2
        self.conv1 = nn.Conv1d(dim_in, dim_in // 2, kernel_size, padding=padding)
        self.norm1 = nn.LayerNorm(dim_in // 2)
        self.conv2 = nn.Conv1d(dim_in // 2, dim_in, kernel_size, padding=padding, stride=stride)
        self.norm2 = nn.LayerNorm(dim_in)
        self.conv_shortcut = nn.Conv1d(dim_in, dim_in, kernel_size, padding=padding, stride=stride)
        self.norm_shortcut = nn.LayerNorm(dim_in)
        self.activation = nn.ReLU()

    def forward(self, x):
        x_res = self.conv1(x)  # B C T
        x_res = self.norm1(x_res.permute(0, 2, 1)).permute(0, 2, 1)
        x_res = self.activation(x_res)
        x_res = self.conv2(x_res)  # B C T
        x_res = self.norm2(x_res.permute(0, 2, 1)).permute(0, 2, 1)
        x_res = self.activation(x_res)

        x_shortcut = self.conv_shortcut(x)
        x_shortcut = self.norm_shortcut(x_shortcut.permute(0, 2, 1)).permute(0, 2, 1)
        return self.activation(x_res + x_shortcut)


class FeaturePyramid(nn.Module):
    def __init__(self, dim_in, n_stages=2, kernel_size=5, stride=4):
        super(FeaturePyramid, self).__init__()
        self.stages = nn.ModuleList([
            Conv1dResBlock(dim_in, kernel_size, stride) for _ in range(n_stages)
        ])

    def forward(self, x):
        """
        Args:
            x: B x C x T
        Returns:
            features: B x C x T'
            lens: [t0, t1, ..., tn]
        """
        features = [x]
        out = x.clone()
        for stage in self.stages:
            out = stage(out)
            features.append(out.clone())
        lens = [f.shape[-1] for f in features]
        features = torch.cat(features, dim=-1)
        return features, lens


def mask_from_lens(lens, max_len=None):
    if max_len is None:
        max_len = lens.max()
    ids = torch.arange(0, max_len, device=lens.device, dtype=lens.dtype)
    mask = torch.lt(ids, lens.unsqueeze(1))
    return mask


class SpeakerBankExtractor(nn.Module):
    def __init__(self, dim_in, n_layers, n_emb, d_model, nhead, dim_feedforward=2048, dropout=0.1, activation="relu", fpn_stages=2, fpn_stride=4):
        super(SpeakerBankExtractor, self).__init__()
        self.prototype = nn.Parameter(torch.randn(n_emb, d_model))
        self.proj_in = nn.Linear(dim_in, d_model)
        self.ms_feature_extractor = FeaturePyramid(d_model, n_stages=fpn_stages, stride=fpn_stride)
        self.fpn_stages = fpn_stages
        self.fpn_stride = fpn_stride
        self.layers = nn.ModuleList([CrossSelfAttnBlock(n_emb, d_model, nhead, dim_feedforward, dropout, activation) for _ in range(n_layers)])

    def forward(self, memory, return_attn=False, lens=None):

        padding_mask = mask_from_lens(lens) == 0

        _, xb, _ = memory.shape
        m = self.proj_in(memory)
        # perform multi-scale feature extraction
        m, feature_lens = self.ms_feature_extractor(m.permute(1, 2, 0))  # B C T
        m = m.permute(2, 0, 1)  # T B C
        # calculate multi-scale feature padding mask
        if padding_mask is None:
            ms_padding_mask = None
        else:
            ms_padding_mask = torch.zeros((xb, m.shape[0])).type(padding_mask.dtype).to(padding_mask.device)
            start = 0
            end = 0
            for i in range(self.fpn_stages + 1):
                start = end
                end = start + feature_lens[i]
                if i > 0:
                    stage_padding_mask = nn.functional.interpolate((padding_mask + 0.0).unsqueeze(1), size=feature_lens[i], mode='linear') == 1
                    stage_padding_mask = stage_padding_mask.squeeze(1)
                    ms_padding_mask[:, start:end] = stage_padding_mask
                else:
                    ms_padding_mask[:, start:end] = padding_mask

        output = self.prototype.unsqueeze(1).repeat((1, xb, 1))
        attn_maps = {}
        for idx, mod in enumerate(self.layers):
            if idx == 0:
                cross_res = False
            else:
                cross_res = True
            output, attn_map = mod(output, m, cross_res=cross_res, return_attn=return_attn, memory_key_padding_mask=ms_padding_mask)
            attn_maps[idx] = attn_map
        return F.normalize(output, dim=-1), attn_maps

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import copy
from torch.autograd import Variable


def subsequent_mask(size):
    # Mask out subsequent positions.
    attn_shape = (1, size, size)
    subsequent_mask = np.triu(np.ones(attn_shape), k=1).astype('uint8')
    return torch.from_numpy(subsequent_mask) == 0


def make_std_mask(tgt, pad):
    # Create a mask to hide padding and future words.
    tgt_mask = (tgt != pad).unsqueeze(-2)
    tgt_mask = tgt_mask & Variable(
        subsequent_mask(tgt.size(-1)).type_as(tgt_mask.data))
    return tgt_mask


def clones(module, n):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(n)])


class Generator(nn.Module):
    def __init__(self, d_model, vocab):
        super(Generator, self).__init__()
        self.proj = nn.Linear(d_model, vocab)

    def forward(self, x):
        return self.proj(x)


class LayerNorm(nn.Module):
    def __init__(self, features, eps=1e-6):
        super(LayerNorm, self).__init__()
        self.a_2 = nn.Parameter(torch.ones(features))
        self.b_2 = nn.Parameter(torch.zeros(features))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a_2 * (x - mean) / (std + self.eps) + self.b_2


class SublayerConnection(nn.Module):
    def __init__(self, size, dropout):
        super(SublayerConnection, self).__init__()
        self.norm = LayerNorm(size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, sublayer):
        return x + self.dropout(sublayer(self.norm(x)))


class Embeddings(nn.Module):
    def __init__(self, d_model, vocab):
        super(Embeddings, self).__init__()
        self.lut = nn.Embedding(vocab, d_model)
        self.d_model = d_model

    def forward(self, x):
        return self.lut(x) * math.sqrt(self.d_model)


class PositionwiseFeedForward(nn.Module):
    def __init__(self, d_model, d_ff, dropout=0.1):
        super(PositionwiseFeedForward, self).__init__()
        self.w_1 = nn.Linear(d_model, d_ff)
        self.w_2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        return self.w_2(self.dropout(F.relu(self.w_1(x))))


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) *
                             -(math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + Variable(self.pe[:, :x.size(1)], requires_grad=False)
        return self.dropout(x)


def attention(query, key, value, mask=None, dropout=None, att_sigmoid=False):
    d_k = query.size(-1)
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k)
    if att_sigmoid:
        scores = scores * torch.sigmoid(scores)
    if mask is not None:
        scores = scores.masked_fill(mask == 0, -1e9)
    p_attn = F.softmax(scores, dim=-1)
    if dropout is not None:
        p_attn = dropout(p_attn)
    return torch.matmul(p_attn, value), p_attn


class MultiHeadedAttention(nn.Module):
    def __init__(self, h, d_model, dropout):
        super(MultiHeadedAttention, self).__init__()
        assert d_model % h == 0
        self.d_k = d_model // h
        self.h = h
        self.linears = clones(nn.Linear(d_model, d_model), 4)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value, mask=None):
        if mask is not None:
            mask = mask.unsqueeze(1)
        nbatches = query.size(0)
        query = self.linears[0](query).view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
        key = self.linears[1](key).view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
        value = self.linears[2](value).view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
        x, self.attn = attention(query, key, value, mask=mask, dropout=self.dropout)
        x = x.transpose(1, 2).contiguous().view(nbatches, -1, self.h * self.d_k)
        return self.linears[-1](x)


class DecoderLayer(nn.Module):
    def __init__(self, size, self_attn, feed_forward, dropout):
        super(DecoderLayer, self).__init__()
        self.size = size
        self.self_attn = self_attn
        self.feed_forward = feed_forward
        self.sublayer = clones(SublayerConnection(size, dropout), 2)

    def forward(self, x, mask):
        x = self.sublayer[0](x, lambda x: self.self_attn(x, x, x, mask))
        return self.sublayer[1](x, self.feed_forward)

    def forward_one_step(self, tgt, tgt_mask, cache=None):
        if cache is None:
            tgt_q = tgt
            tgt_q_mask = tgt_mask
        else:
            assert cache.shape == (
                tgt.shape[0],
                tgt.shape[1] - 1,
                tgt.shape[2],
            ), f"{cache.shape} == {(tgt.shape[0], tgt.shape[1] - 1, self.size)}"
            tgt_q = tgt[:, -1:, :]
            tgt_q_mask = None
            if tgt_mask is not None:
                tgt_q_mask = tgt_mask[:, -1:, :]

        x = self.sublayer[0].norm(tgt)
        x = tgt_q + self.sublayer[0].dropout(self.self_attn(x[:, -1:, :], x, x, tgt_q_mask))
        x = self.sublayer[1](x, self.feed_forward)
        if cache is not None:
            x = torch.cat([cache, x], dim=1)
        return x


class Decoder(nn.Module):
    def __init__(self, layer, n):
        super(Decoder, self).__init__()
        self.layers = clones(layer, n)
        self.norm = LayerNorm(layer.size)
        d_model = layer.size
        self.emb_linear2 = nn.Linear(d_model, d_model)
        self.emb_act = nn.Softplus()
        self.emb_proj = nn.Linear(d_model + d_model, d_model)

    def forward(self, h, x1, mask):
        x = self.emb_act(self.emb_linear2(x1))
        x = self.emb_proj(torch.cat((h, x), -1))
        for layer in self.layers:
            x = layer(x, mask)
        return self.norm(x)

    def forward_one_step(self, h, x1, mask, cache=None):
        if cache is None:
            cache = [None] * len(self.layers)
        new_cache = []
        x = self.emb_act(self.emb_linear2(x1))
        x = self.emb_proj(torch.cat((h[:, :x.shape[1], :], x), -1))
        cnt = 0
        for c, layer in zip(cache, self.layers):
            cnt += 1
            x = layer.forward_one_step(x, mask, cache=c)
            new_cache.append(x)
        x = self.norm(x[:, -1])
        return x, new_cache


class ARPitchPredictor(nn.Module):
    def __init__(self, p_vocab, d_vocab, n=3, d_model=512, dropout=0.1):
        super(ARPitchPredictor, self).__init__()
        d_ff = d_model * 4
        h = 4
        c = copy.deepcopy
        attn = MultiHeadedAttention(h, d_model, dropout)
        ff = PositionwiseFeedForward(d_model, d_ff, dropout)
        position = PositionalEncoding(d_model, dropout)
        self.pdecoder = Decoder(DecoderLayer(d_model, c(attn), c(ff), dropout), n)
        self.ddecoder = Decoder(DecoderLayer(d_model, c(attn), c(ff), dropout), n)
        self.ptgt_embed = nn.Sequential(Embeddings(d_model, p_vocab), c(position))
        self.dtgt_embed = nn.Sequential(Embeddings(d_model, d_vocab), c(position))
        self.pgenerator = Generator(d_model, p_vocab)
        self.dgenerator = Generator(d_model, d_vocab)
        self.logzero = -10000000000.0
        self.psampler = TopPLogitsWarper(1.0, 1.0)
        self.dsampler = TopPLogitsWarper(0.5, 1.0)

        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform(p)

    def forward(self, h, ptgt, dtgt, tgt_mask):
        tgt_mask = tgt_mask & Variable(subsequent_mask(ptgt.size(-1)).type_as(tgt_mask.data))
        return self.decode(h, ptgt, dtgt, tgt_mask)

    def decode(self, h, ptgt, dtgt, tgt_mask):
        pout = self.pdecoder(h, self.ptgt_embed(ptgt), tgt_mask)
        dout = self.ddecoder(h, self.dtgt_embed(dtgt), tgt_mask)
        return self.pgenerator(pout), self.dgenerator(dout)

    def recognize_pitch(self, h, sos, pmean, pvar):
        maxlen = h.shape[1]
        pseq = torch.LongTensor([[sos]]).to(h.device)
        pcache = None
        for _ in range(maxlen):
            px, pcache = self.pdecoder.forward_one_step(h, self.ptgt_embed(pseq), None, cache=pcache)
            pout = self.pgenerator(px)
            pout = self.psampler.sample(None, pout)
            pprobs = F.softmax(pout, dim=-1)
            pix = torch.multinomial(pprobs, num_samples=1)
            pseq = torch.cat((pseq, pix), -1)
        pseq = pseq[:, 1:].unsqueeze(-1).float()
        pseq = (pseq - pmean) / pvar
        return pseq

    def recognize_dur(self, h, sos, dseq0):
        maxlen = h.shape[1]
        dseq = torch.LongTensor([[sos]]).to(h.device)
        dcache = None
        for i in range(maxlen):
            dx, dcache = self.ddecoder.forward_one_step(h, self.dtgt_embed(dseq), None, cache=dcache)
            dout = self.dgenerator(dx)
            dout = self.dsampler.sample(None, dout)
            dprobs = F.softmax(dout, dim=-1)
            dix = torch.multinomial(dprobs, num_samples=1)
            # avoid too large/small duration values
            if dseq0[0, i] > 0:
                r = dix[0, 0] / dseq0[0, i]
                if r < 0.5 or r > 2.0:
                    dix[0, 0] = dseq0[0, i]
            dseq = torch.cat((dseq, dix), -1)
        dseq = dseq[:, 1:].float()
        return dseq


class TopPLogitsWarper():
    def __init__(self, top_p, temperature=1.0, filter_value=-float("Inf"), min_tokens_to_keep=1):
        top_p = float(top_p)
        if top_p < 0 or top_p > 1.0:
            raise ValueError(f"`top_p` has to be a float > 0 and < 1, but is {top_p}")
        self.top_p = top_p
        self.temperature = temperature
        self.filter_value = filter_value
        self.min_tokens_to_keep = min_tokens_to_keep

    def sample(self, input_ids, scores):
        scores = scores / self.temperature
        sorted_logits, sorted_indices = torch.sort(scores, descending=False)
        cumulative_probs = sorted_logits.softmax(dim=-1).cumsum(dim=-1)

        sorted_indices_to_remove = cumulative_probs <= (1 - self.top_p)
        if self.min_tokens_to_keep > 1:
            sorted_indices_to_remove[..., -self.min_tokens_to_keep:] = 0

        indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
        scores = scores.masked_fill(indices_to_remove, self.filter_value)
        return scores

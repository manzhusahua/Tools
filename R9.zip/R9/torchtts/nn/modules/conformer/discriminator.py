"""ConformerV4x discriminator."""

import torch
import torch.nn.functional as F
import torch.autograd as autograd

from torch import nn
from torch.autograd import Variable
from torchtts.nn.modules.common.functional import make_non_pad_mask
from torchtts.nn.modules.attention import MultiheadAttention
from torchtts.nn.modules.common import LayerNorm
from timm.models.layers import trunc_normal_


class GP(torch.nn.Module):
    def __init__(self, gp_beata):
        super(GP, self).__init__()
        self.gp_beata = gp_beata

    def forward(self, net_disc, real_data, fake_data, olens, window_frame=None):
        alpha = torch.rand(real_data.size(0), 1, 1)
        alpha = alpha.expand(real_data.size())
        alpha = alpha.to(fake_data.device)

        interpolates = alpha * real_data + ((1 - alpha) * fake_data)

        interpolates = interpolates.to(fake_data.device)
        interpolates = Variable(interpolates, requires_grad=True)

        disc_interpolates, _ = net_disc(interpolates, olens, window_frame=window_frame)

        gradients = autograd.grad(
            outputs=disc_interpolates,
            inputs=interpolates,
            grad_outputs=torch.ones(disc_interpolates.size()).to(fake_data.device),
            create_graph=True,
            retain_graph=True,
            only_inputs=True,
        )[0]
        gradient_penalty = (((torch.sum(gradients**2, dim=(-2, -1))) ** 0.5 - 1) ** 2).mean() * self.gp_beata
        return gradient_penalty


class ConformerDiscriminator(torch.nn.Module):
    """docstring for ConformerDiscriminator"""

    def __init__(self, out_dim, num_heads, window_sizes, channels, dropout_rate=0.1):
        super(ConformerDiscriminator, self).__init__()
        self.window_sizes = window_sizes
        self.channels = channels
        self.convs = torch.nn.ModuleList()
        self.smooth_dense_layer = torch.nn.ModuleList()
        self.smooth_dense_layer_first = torch.nn.ModuleList()

        for k in range(len(channels)):
            self.convs_k = torch.nn.Sequential(ConvolutionModuleLayerNorm(channels[k], kernel_size=7))
            self.dense_k = torch.nn.Linear(channels[k], 32)
            self.dense_k_first = torch.nn.Linear(out_dim, channels[k])
            self.convs.append(self.convs_k)
            self.smooth_dense_layer.append(self.dense_k)
            self.smooth_dense_layer_first.append(self.dense_k_first)

        self.multihead_attention = MultiheadAttention(32, num_heads, dropout=dropout_rate, bias=False)
        self.smooth_dense_layer_final = torch.nn.Linear(32, 1)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=0.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0.0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0.0)
            nn.init.constant_(m.weight, 1.0)

    def discriminator_factory(self, convs, input, layer_number):
        discrim_final_output = None
        input = self.smooth_dense_layer_first[layer_number](input)  # (B,T,128)
        discrim_output = self.convs[layer_number](input)  # (B,T,128)
        discrim_output = self.smooth_dense_layer[layer_number](discrim_output)  # (B,T,32)
        discrim_output = self.multihead_attention(
            query=discrim_output, key=discrim_output, value=discrim_output
        )  # (B,T,32)
        discrim_output = self.smooth_dense_layer_final(discrim_output[0]).squeeze(-1)  # (B,T)
        discrim_final_output = torch.mean(discrim_output, -1)  # (B,)

        return discrim_final_output

    def forward(self, gen_output, olens, window_frame=None):  # (B,T,80)
        out_masks = make_non_pad_mask(olens).unsqueeze(-1).to(gen_output.device)
        gen_output = gen_output.masked_fill(out_masks.eq(0), 0.0)

        if window_frame is None:
            window_frame = []
            for win_size in self.window_sizes:
                maxv = 1 if (gen_output.size(1) - win_size) < 1 else (gen_output.size(1) - win_size)
                start_idx = int(torch.distributions.uniform.Uniform(0, maxv).sample())
                if (start_idx + win_size) < gen_output.size(1) - 1:
                    end_idx = start_idx + win_size
                else:
                    end_idx = gen_output.size(1) - 1

                window_frame.append((start_idx, end_idx))

        discrim_gen_output = self.discriminator_factory(convs=self.convs, input=gen_output, layer_number=0)
        layer_num = 1
        for frame in window_frame:
            discrim_gen_output_new = self.discriminator_factory(
                convs=self.convs, input=gen_output[:, frame[0] : frame[1], :], layer_number=layer_num
            )
            discrim_gen_output += discrim_gen_output_new
            layer_num += 1

        return discrim_gen_output, window_frame


class ConvolutionModuleLayerNorm(nn.Module):
    """ConvolutionModuleLayerNorm in Conformer model.

    :param int channels: channels of cnn
    :param int kernel_size: kernerl size of cnn

    """

    def __init__(self, channels, kernel_size, activation=F.relu, bias=True):
        """Construct an ConvolutionModuleLayerNorm object."""
        super(ConvolutionModuleLayerNorm, self).__init__()
        assert (kernel_size - 1) % 2 == 0

        self.pointwise_conv1 = nn.Conv1d(
            channels,
            2 * channels,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=bias,
        )
        self.depthwise_conv = nn.Conv1d(
            channels,
            channels,
            kernel_size,
            stride=1,
            padding=(kernel_size - 1) // 2,
            groups=channels,
            bias=bias,
        )
        self.norm = LayerNorm(channels, dim=1)
        self.pointwise_conv2 = nn.Conv1d(
            channels,
            channels,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=bias,
        )
        self.activation = activation

    def forward(self, x):
        """Compute convolution module.

        :param torch.Tensor x: (batch, time, size)
        :return torch.Tensor: convoluted `value` (batch, time, d_model)
        """
        x = x.transpose(1, 2)

        #  GLU mechanism
        x = self.pointwise_conv1(x)  # (batch, 2*channel, dim)
        x = nn.functional.glu(x, dim=1)  # (batch, channel, dim)

        #  1D Depth-wise Conv
        x = self.depthwise_conv(x)
        x = self.activation(self.norm(x))

        x = self.pointwise_conv2(x)

        return x.transpose(1, 2)

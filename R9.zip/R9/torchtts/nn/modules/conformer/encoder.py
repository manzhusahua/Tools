"""Encoder definition."""

import torch

from torchtts.nn.modules.transformer import PositionalEncoding
from torchtts.nn.modules.transformer import ScaledPositionalEncoding
from torchtts.nn.modules.transformer import RelPositionalEncoding

from torchtts.nn.modules.conformer.convolution import ConvolutionModule
from torchtts.nn.modules.conformer.encoder_layer import EncoderLayer

from torchtts.nn.modules.attention import MultiheadAttention
from torchtts.nn.modules.attention.rel_attention import RelPositionMultiHeadedAttention

from torchtts.nn.modules.conformer.multi_layer_conv import Conv1dLinear
from torchtts.nn.modules.conformer.multi_layer_conv import MultiLayeredConv1d, SwitchFeedForward, FeedForward
from torchtts.nn.modules.conformer.multi_layer_conv import (
    SingleLayeredConv1d,
    SeparableConv1dLayer,
    MultiLayeredSepConv1d,
)
from torchtts.nn.modules.conformer.multi_layer_conv import MultiLayeredConvGlu, MultiLayeredGlu

from torchtts.nn.modules.conformer.repeat import repeat
from torchtts.nn.modules.conformer.subsampling import Conv2dSubsampling

from torchtts.nn.modules.transformer.ffn_layer import LinearPositionwiseFeedForward
from torchtts.utils.import_utils import _FMOE_AVAILABLE

from torchtts.nn.modules.common.rnn_warpper import HighwayRNN, ConvLSTM

if _FMOE_AVAILABLE:
    from fmoe.transformer import FMoETransformerMLP


class Encoder(torch.nn.Module):
    """Conformer encoder module.

    :param int idim: input dim
    :param int attention_dim: dimention of attention
    :param int attention_heads: the number of heads of multi head attention
    :param int linear_units: the number of units of position-wise feed forward
    :param int num_blocks: the number of decoder blocks
    :param float dropout_rate: dropout rate
    :param float attention_dropout_rate: dropout rate in attention
    :param float positional_dropout_rate: dropout rate after adding positional encoding
    :param str or torch.nn.Module input_layer: input layer type
    :param bool normalize_before: whether to use layer_norm before the first block
    :param bool concat_after: whether to concat attention layer's input and output
        if True, additional linear will be applied.
        i.e. x -> x + linear(concat(x, att(x)))
        if False, no additional linear will be applied. i.e. x -> x + att(x)
    :param str positionwise_layer_type: linear of conv1d
    :param int positionwise_conv_kernel_size: kernel size of positionwise conv1d layer
    :param str encoder_pos_enc_layer_type: encoder positional encoding layer type
    :param str encoder_attn_layer_type: encoder attention layer type
    :param str activation_type: encoder activation function type
    :param bool macaron_style: whether to use macaron style for positionwise layer
    :param bool use_cnn_module: whether to use convolution module
    :param int cnn_module_kernel: kernerl size of convolution module
    :param int padding_idx: padding_idx for input_layer=embed
    """

    def __init__(
        self,
        idim=0,
        attention_dim=256,
        attention_heads=4,
        linear_units=2048,
        num_blocks=6,
        dropout_rate=0.1,
        positional_dropout_rate=0.1,
        attention_dropout_rate=0.0,
        input_layer="conv2d",
        normalize_before=False,
        concat_after=False,
        positionwise_layer_type="conv1d",
        positionwise_conv_kernel_size=1,
        macaron_style=False,
        pos_enc_layer_type="rel_pos",
        selfattention_layer_type="rel_selfattn",
        activation_type="relu",
        use_cnn_module=True,
        cnn_module_kernel=31,
        padding_idx=-1,
        use_singing_feature=False,
        output_all=False,
        enable_moe=False,
        export_onnx=False,
        enable_conditional_layernorm=False,
        condition_dim=-1,
        n_experts=16,
        enable_fmoe=False,
        fmoe_num_expert=64,
        fmoe_hidden_dim=1024,
        fmoe_top_k=2,
        return_att=False,
        moe_capacity_factor=1.2,
        predict_mel=False,
        predict_mel_layer=0,
        use_highway_rnn=False,
        rnn_reduce=1,
        rnn_bidirectional=False,
        hidden_dim=384,
        ffn_groups_batch_size=8,
        enable_crossattn=False,
    ):
        """Construct an Encoder object."""
        super(Encoder, self).__init__()
        self.return_att = return_att

        activation = self._get_activation(activation_type)
        if pos_enc_layer_type == "abs_pos":
            pos_enc_class = PositionalEncoding
        elif pos_enc_layer_type == "scaled_abs_pos":
            pos_enc_class = ScaledPositionalEncoding
        elif pos_enc_layer_type == "rel_pos":
            assert selfattention_layer_type == "rel_selfattn"
            pos_enc_class = RelPositionalEncoding
        else:
            raise ValueError("unknown pos_enc_layer: " + pos_enc_layer_type)

        if input_layer == "linear":
            self.embed = torch.nn.Sequential(
                torch.nn.Linear(idim, attention_dim),
                torch.nn.LayerNorm(attention_dim),
                torch.nn.Dropout(dropout_rate),
                pos_enc_class(attention_dim, positional_dropout_rate),
            )
        elif input_layer == "conv2d":
            self.embed = Conv2dSubsampling(
                idim,
                attention_dim,
                dropout_rate,
                pos_enc_class(attention_dim, positional_dropout_rate),
            )
        elif input_layer == "embed":
            self.embed = torch.nn.Sequential(
                torch.nn.Embedding(idim, attention_dim, padding_idx=padding_idx),
                pos_enc_class(attention_dim, positional_dropout_rate),
            )
        elif isinstance(input_layer, torch.nn.Module):
            self.rel_pos_emb = pos_enc_class(attention_dim, positional_dropout_rate)
            if use_singing_feature:
                self.embed = torch.nn.Sequential(self.rel_pos_emb)
            else:
                self.embed = torch.nn.Sequential(input_layer, self.rel_pos_emb)
        elif input_layer is None:
            self.embed = torch.nn.Sequential(pos_enc_class(attention_dim, positional_dropout_rate))
        else:
            raise ValueError("unknown input_layer: " + input_layer)
        self.normalize_before = normalize_before

        positionwise_layer = None
        positionwise_layer_args = None
        if enable_fmoe:
            positionwise_layer = FMoETransformerMLP
        elif positionwise_layer_type == "linear":
            positionwise_layer = LinearPositionwiseFeedForward
            positionwise_layer_args = (attention_dim, linear_units, dropout_rate)
        elif positionwise_layer_type == "single-conv1d":
            positionwise_layer = SingleLayeredConv1d
            positionwise_layer_args = (
                attention_dim,
                linear_units,
                positionwise_conv_kernel_size,
                dropout_rate,
            )
        elif positionwise_layer_type == "single-sep-conv1d":
            positionwise_layer = SeparableConv1dLayer
            positionwise_layer_args = (
                attention_dim,
                attention_dim,
                positionwise_conv_kernel_size,
                dropout_rate,
            )
        elif positionwise_layer_type == "multi-sep-conv1d":
            positionwise_layer = MultiLayeredSepConv1d
            positionwise_layer_args = (
                attention_dim,
                attention_dim * 4,
                positionwise_conv_kernel_size,
                dropout_rate,
            )
        elif positionwise_layer_type == "conv1d":
            positionwise_layer = MultiLayeredConv1d
            positionwise_layer_args = (
                attention_dim,
                linear_units,
                positionwise_conv_kernel_size,
                dropout_rate,
            )
        elif positionwise_layer_type == "conv1d-linear":
            positionwise_layer = Conv1dLinear
            positionwise_layer_args = (
                attention_dim,
                linear_units,
                positionwise_conv_kernel_size,
                dropout_rate,
            )
        elif positionwise_layer_type != "glu":
            raise NotImplementedError("Support only linear or conv1d or glu.")

        positionwise_layer_1 = positionwise_layer
        positionwise_layer_2 = positionwise_layer
        if positionwise_layer_type == "glu":
            positionwise_layer_1 = MultiLayeredGlu
            positionwise_layer_2 = MultiLayeredConvGlu
            positionwise_layer_args = (
                attention_dim,
                linear_units,
                positionwise_conv_kernel_size,
                dropout_rate,
            )

        if selfattention_layer_type == "selfattn":
            encoder_selfattn_layer = MultiheadAttention
            encoder_selfattn_layer_args = (
                attention_dim,
                attention_heads,
                attention_dropout_rate,
            )
        elif selfattention_layer_type == "rel_selfattn":
            assert pos_enc_layer_type == "rel_pos"
            encoder_selfattn_layer = RelPositionMultiHeadedAttention
            encoder_selfattn_layer_args = (
                attention_heads,
                attention_dim,
                attention_dropout_rate,
                return_att,
            )
        else:
            raise ValueError("unknown encoder_attn_layer: " + selfattention_layer_type)

        if enable_crossattn:
            encoder_crossattn_layer = MultiheadAttention
            encoder_crossattn_layer_args = (
                attention_dim,
                attention_heads,
                attention_dropout_rate,
            )
        else:
            encoder_crossattn_layer = None
            encoder_crossattn_layer_args = None

        convolution_layer = ConvolutionModule
        convolution_layer_args = (attention_dim, cnn_module_kernel, activation)
        self.use_highway_rnn = use_highway_rnn
        self.rnn_bidirectional = rnn_bidirectional

        if not self.use_highway_rnn:
            self.encoders = repeat(
                num_blocks,
                lambda lnum: EncoderLayer(
                    attention_dim,
                    encoder_selfattn_layer(*encoder_selfattn_layer_args),
                    positionwise_layer_2(*positionwise_layer_args)
                    if not enable_fmoe
                    else positionwise_layer(
                        num_expert=fmoe_num_expert,
                        d_model=attention_dim,
                        d_hidden=fmoe_hidden_dim,
                        top_k=fmoe_top_k,
                        dropout=dropout_rate,
                    ),
                    positionwise_layer_1(*positionwise_layer_args) if macaron_style else None,
                    convolution_layer(*convolution_layer_args) if use_cnn_module else None,
                    dropout_rate,
                    normalize_before,
                    concat_after,
                    enable_conditional_layernorm,
                    condition_dim,
                    SwitchFeedForward(
                        capacity_factor=moe_capacity_factor,
                        drop_tokens=True,
                        is_scale_prob=False,
                        n_experts=n_experts,
                        expert=FeedForward(attention_dim, 32, dropout_rate),
                        d_model=attention_dim,
                        export_onnx=export_onnx,
                    )
                    if enable_moe
                    else None,
                    encoder_crossattn_layer(*encoder_crossattn_layer_args)
                    if enable_crossattn
                    else None,
                ),
            )
        else:
            self.encoders = repeat(
                num_blocks,
                lambda lnum: HighwayRNN(ConvLSTM(attention_dim, hidden_dim, attention_dim, rnn_bidirectional,
                                                 rnn_reduce, ffn_groups_batch_size), attention_dim, dropout_rate)
            )

        self.output_all = output_all
        self.num_blocks = num_blocks

        self.predict_mel = predict_mel
        self.predict_mel_layer = predict_mel_layer
        if predict_mel:
            self.mel_proj = torch.nn.Linear(attention_dim, 80, bias=False)
            self.mel_comb = torch.nn.Linear(attention_dim + 80, attention_dim, bias=False)

    def _get_activation(self, act):
        """Return activation function."""
        # Lazy load to avoid unused import

        class Swish(torch.nn.Module):
            """Construct an Swish object."""

            def forward(self, x):
                """Return Swich activation function."""
                return x * torch.sigmoid(x)

        activation_funcs = {
            "hardtanh": torch.nn.Hardtanh,
            "relu": torch.nn.ReLU,
            "selu": torch.nn.SELU,
            "swish": Swish,
        }

        return activation_funcs[act]()

    def forward(self, xs, masks, condition=None, context_feat=None, gating_features=None, inference=True, ys=None, sty_inp=None, sty_inp_mask=None):
        """Encode input sequence.

        :param torch.Tensor xs: input tensor
        :param torch.Tensor masks: input mask
        :return: position embedded tensor and mask
        :rtype Tuple[torch.Tensor, torch.Tensor]:
        """
        xs = self.embed(xs)
        if context_feat is not None:
            if isinstance(xs, tuple):
                xs = list(xs)
                xs[0] += context_feat
                xs = tuple(xs)
            else:
                xs += context_feat

        result = []
        att_result = []
        for i in range(self.num_blocks):
            if not self.use_highway_rnn:
                xs, masks = self.encoders[i](xs, masks, condition=condition, gating_features=gating_features,
                                             sty_inp=sty_inp, sty_inp_mask=sty_inp_mask)
            else:
                xs0, _ = self.encoders[i](xs[0], mask=(masks if self.rnn_bidirectional else None))
                xs = (xs0, xs[1])

            # added to get the attention matrix
            if self.return_att:
                xs, att_matrix = xs
                att_result.append(att_matrix)

            if isinstance(xs, tuple):
                if self.output_all is True and self.predict_mel and i == self.predict_mel_layer:
                    xs_, pos = xs
                    mel_ = self.mel_proj(xs_)
                    if inference:
                        xs_ = self.mel_comb(torch.cat([mel_, xs_], dim=-1))
                    else:
                        xs_ = self.mel_comb(torch.cat([ys, xs_], dim=-1))
                    result.append(mel_)
                    xs = (xs_, pos)
                else:
                    result.append(xs[0])
            else:
                result.append(xs)

        if self.output_all is False:
            result = result[-1]

        if self.return_att is False:
            return result, masks
        else:
            return result, att_result

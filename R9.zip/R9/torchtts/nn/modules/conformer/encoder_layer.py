"""Encoder self-attention layer definition."""

import torch

from torch import nn
from torchtts.nn.modules.common import LayerNorm as CondLayerNorm


class EncoderLayer(nn.Module):
    """Encoder layer module."""

    def __init__(
        self,
        size,
        self_attn,
        feed_forward,
        feed_forward_macaron,
        conv_module,
        dropout_rate,
        normalize_before=True,
        concat_after=False,
        enable_conditional_layernorm=False,
        condition_dim=-1,
        switch_feed_forward=None,
        cross_attn=None,
    ):
        """Construct an EncoderLayer object."""
        super(EncoderLayer, self).__init__()
        self.self_attn = self_attn
        self.feed_forward = feed_forward
        self.feed_forward_macaron = feed_forward_macaron
        self.conv_module = conv_module
        self.switch_feed_forward = switch_feed_forward
        self.enable_conditional_layernorm = enable_conditional_layernorm
        self.cross_attn = cross_attn

        if switch_feed_forward is not None:
            self.norm_ffswit = (
                CondLayerNorm(size, condition_dim=condition_dim, eps=1e-12)
                if enable_conditional_layernorm
                else torch.nn.LayerNorm(size, eps=1e-12)
            )

        self.norm_ff = (
            CondLayerNorm(size, condition_dim=condition_dim, eps=1e-12)
            if enable_conditional_layernorm
            else torch.nn.LayerNorm(size, eps=1e-12)
        )

        self.norm_mha = (
            CondLayerNorm(size, condition_dim=condition_dim, eps=1e-12)
            if enable_conditional_layernorm
            else torch.nn.LayerNorm(size, eps=1e-12)
        )

        if self.cross_attn is not None:
            self.norm_mha_cross = (
                CondLayerNorm(size, condition_dim=condition_dim, eps=1e-12)
                if enable_conditional_layernorm
                else torch.nn.LayerNorm(size, eps=1e-12)
            )

        if feed_forward_macaron is not None:
            self.norm_ff_macaron = torch.nn.LayerNorm(size, eps=1e-12)
            self.ff_scale = 0.5
        else:
            self.ff_scale = 1.0
        if self.conv_module is not None:
            # for the CNN module
            self.norm_conv = (
                CondLayerNorm(size, condition_dim=condition_dim, eps=1e-12)
                if enable_conditional_layernorm
                else torch.nn.LayerNorm(size, eps=1e-12)
            )
            # for the final output of the block
            self.norm_final = (
                CondLayerNorm(size, condition_dim=condition_dim, eps=1e-12)
                if enable_conditional_layernorm
                else torch.nn.LayerNorm(size, eps=1e-12)
            )

        self.dropout = nn.Dropout(dropout_rate)
        self.size = size
        self.normalize_before = normalize_before
        self.concat_after = concat_after
        if self.concat_after:
            self.concat_linear = nn.Linear(size + size, size)

    def forward(self, x_input, mask, cache=None, condition=None, gating_features=None, sty_inp=None, sty_inp_mask=None):
        """Compute encoded features.

        :param torch.Tensor x_input: encoded source features, w/o pos_emb
        tuple((batch, max_time_in, size), (1, max_time_in, size))
        or (batch, max_time_in, size)
        :param torch.Tensor mask: mask for x (batch, max_time_in)
        :param torch.Tensor cache: cache for x (batch, max_time_in - 1, size)
        :rtype: Tuple[torch.Tensor, torch.Tensor]
        """
        if isinstance(x_input, tuple):
            x, pos_emb = x_input[0], x_input[1]
        else:
            x, pos_emb = x_input, None

        if self.switch_feed_forward is not None:
            residual = x
            if self.normalize_before:
                x = (
                    self.norm_ffswit(x, condition=condition)
                    if self.enable_conditional_layernorm
                    else self.norm_ffswit(x)
                )
            x = self.switch_feed_forward(x)
            if not self.normalize_before:
                x = residual + self.norm_ff(x)
            else:
                x = residual + x

        # whether to use macaron style
        if self.feed_forward_macaron is not None:
            residual = x
            if self.normalize_before:
                x = (
                    self.norm_ff_macaron(x, condition=condition)
                    if self.enable_conditional_layernorm
                    else self.norm_ff_macaron(x)
                )
            x = residual + self.ff_scale * self.dropout(self.feed_forward_macaron(x))
            if not self.normalize_before:
                x = self.norm_ff_macaron(x)

        # convolution module
        if self.conv_module is not None:
            residual = x
            if self.normalize_before:
                x = self.norm_conv(x, condition=condition) if self.enable_conditional_layernorm else self.norm_conv(x)
            x = residual + self.dropout(self.conv_module(x))
            if not self.normalize_before:
                x = self.norm_conv(x)

        # multi-headed self-attention module
        residual = x
        if self.normalize_before:
            x = self.norm_mha(x, condition=condition) if self.enable_conditional_layernorm else self.norm_mha(x)

        if cache is None:
            x_q = x
        else:
            assert cache.shape == (x.shape[0], x.shape[1] - 1, self.size)
            x_q = x[:, -1:, :]
            residual = residual[:, -1:, :]
            mask = None if mask is None else mask[:, -1:, :]

        if pos_emb is not None:
            x_att = self.self_attn(x_q, x, x, pos_emb, mask)
        else:
            x_att = self.self_attn(x_q, x, x, mask)

        # decompose att_matrix from x_att
        att_matrix = None
        if isinstance(x_att, list):
            x_att, att_matrix = x_att

        if self.concat_after:
            x_concat = torch.cat((x, x_att), dim=-1)
            x = residual + self.concat_linear(x_concat)
        else:
            x = residual + self.dropout(x_att)
        if not self.normalize_before:
            x = self.norm_mha(x)

        # multi-headed cross-attention module
        if self.cross_attn is not None:
            residual = x
            if self.normalize_before:
                x = self.norm_mha_cross(x, condition=condition) if self.enable_conditional_layernorm else self.norm_mha_link(x)
            x_q = x
            x_att = self.link_attn(x_q, sty_inp, sty_inp, sty_inp_mask)
            x = residual + self.dropout(x_att)
            if not self.normalize_before:
                x = self.norm_mha_cross(x)

        # feed forward module
        residual = x
        if self.normalize_before:
            x = self.norm_ff(x, condition=condition) if self.enable_conditional_layernorm else self.norm_ff(x)
        if gating_features is not None:
            x = residual + self.ff_scale * self.dropout(self.feed_forward(x, gating_features))
        else:
            x = residual + self.ff_scale * self.dropout(self.feed_forward(x))
        if not self.normalize_before:
            x = self.norm_ff(x)

        if self.conv_module is not None:
            x = self.norm_final(x, condition=condition) if self.enable_conditional_layernorm else self.norm_final(x)

        if cache is not None:
            x = torch.cat([cache, x], dim=1)

        if pos_emb is not None:
            if att_matrix is not None:
                return ((x, pos_emb), att_matrix), mask
            else:
                return (x, pos_emb), mask

        # group att matrix into x, to make pipeline happy
        if att_matrix is not None:
            x = (x, att_matrix)

        return x, mask

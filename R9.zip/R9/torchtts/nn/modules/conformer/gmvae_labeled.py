"""GM-VAE modules."""

import torch
import torch.nn as nn


class GMVAELabeled(torch.nn.Module):
    def __init__(self, vae_dim_qz_graph, vae_dim_pz_graph, vae_dim_hidden=128, vae_dim_latent=32, style_dim=16):
        super(GMVAELabeled, self).__init__()

        self.style_dim = style_dim

        self.qz_graph_layers = nn.Sequential(
            nn.Linear(vae_dim_qz_graph, vae_dim_hidden),
            nn.Linear(vae_dim_hidden, vae_dim_latent),
        )

        self.pz_graph_layers = nn.Sequential(
            nn.Linear(vae_dim_pz_graph, vae_dim_hidden),
            nn.Linear(vae_dim_hidden, vae_dim_latent),
        )

    def reparameterize(self, mu, log_var):
        std = torch.exp(log_var / 2)
        eps = torch.randn_like(std)
        return mu + eps * std

    def qz_graph(self, xy):
        qz = self.qz_graph_layers(xy)
        qz_mu = qz[:, : self.style_dim]
        qz_log_sigma2 = qz[:, self.style_dim :]
        qz_sample = self.reparameterize(qz_mu, qz_log_sigma2)

        return qz_sample, qz_mu, qz_log_sigma2

    def pz_graph(self, y):
        pz = self.pz_graph_layers(y)
        pz_mu = pz[:, : self.style_dim]
        pz_log_sigma2 = pz[:, self.style_dim :]
        pz_sample = self.reparameterize(pz_mu, pz_log_sigma2)

        return pz_sample, pz_mu, pz_log_sigma2

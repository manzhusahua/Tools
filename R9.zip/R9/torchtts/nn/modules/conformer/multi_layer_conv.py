"""Multi layer conv Layer modules"""

import copy
from typing import Any, TypeVar, Iterator, Iterable, Generic

import torch
import torch.nn.functional as F
from torch import nn


class Module(torch.nn.Module):
    r"""
    Wraps ``torch.nn.Module`` to overload ``__call__`` instead of
    ``forward`` for better type checking.

    `PyTorch Github issue for clarification <https://github.com/pytorch/pytorch/issues/44605>`_
    """

    def _forward_unimplemented(self, *input: Any) -> None:
        # To stop PyTorch from giving abstract methods warning
        pass

    def __init_subclass__(cls, **kwargs):
        if cls.__dict__.get("__call__", None) is None:
            return

        setattr(cls, "forward", cls.__dict__["__call__"])  # noqa: B010
        delattr(cls, "__call__")

    @property
    def device(self):
        params = self.parameters()
        try:
            sample_param = next(params)
            return sample_param.device
        except StopIteration:
            raise RuntimeError(f"Unable to determine" f" device of {self.__class__.__name__}") from None


M = TypeVar("M", bound=torch.nn.Module)
T = TypeVar("T")


class TypedModuleList(torch.nn.ModuleList, Generic[M]):
    def __getitem__(self, idx: int) -> M:
        return super().__getitem__(idx)

    def __setitem__(self, idx: int, module: M) -> None:
        return super().__setitem__(idx, module)

    def __iter__(self) -> Iterator[M]:
        return super().__iter__()

    def __iadd__(self: T, modules: Iterable[M]) -> T:
        return super().__iadd__(modules)

    def insert(self, index: int, module: M) -> None:
        super().insert(index, module)

    def append(self: T, module: M) -> T:
        return super().append(module)

    def extend(self: T, modules: Iterable[M]) -> T:
        return super().extend(modules)

    def forward(self):
        raise NotImplementedError()


def clone_module_list(module: M, n: int) -> TypedModuleList[M]:
    """
    ## Clone Module
    Make a `nn.ModuleList` with clones of a given module
    """
    return TypedModuleList([copy.deepcopy(module) for _ in range(n)])


class FeedForward(torch.nn.Module):
    """
    ## FFN module
    """

    def __init__(
        self,
        d_model: int,
        d_ff: int,
        dropout: float = 0.1,
        activation=F.relu,
        is_gated: bool = False,
        bias1: bool = True,
        bias2: bool = True,
        bias_gate: bool = True,
    ):
        """
        * `d_model` is the number of features in a token embedding
        * `d_ff` is the number of features in the hidden layer of the FFN
        * `dropout` is dropout probability for the hidden layer
        * `is_gated` specifies whether the hidden layer is gated
        * `bias1` specified whether the first fully connected layer should have a learnable bias
        * `bias2` specified whether the second fully connected layer should have a learnable bias
        * `bias_gate` specified whether the fully connected layer for the gate should have a learnable bias
        """
        super().__init__()
        # Layer one parameterized by weight $W_1$ and bias $b_1$
        self.layer1 = nn.Linear(d_model, d_ff, bias=bias1)
        # Layer one parameterized by weight $W_1$ and bias $b_1$
        self.layer2 = nn.Linear(d_ff, d_model, bias=bias2)
        # Hidden layer dropout
        self.dropout = nn.Dropout(dropout)
        # Activation function $f$
        self.activation = activation
        # Whether there is a gate
        self.is_gated = is_gated
        if is_gated:
            # If there is a gate the linear layer to transform inputs to
            # be multiplied by the gate, parameterized by weight $V$ and bias $c$
            self.linear_v = nn.Linear(d_model, d_ff, bias=bias_gate)

    def forward(self, x: torch.Tensor):
        # $f(x W_1 + b_1)$
        g = self.activation(self.layer1(x))
        # If gated, $f(x W_1 + b_1) \otimes (x V + b) $
        if self.is_gated:
            x = g * self.linear_v(x)
        # Otherwise
        else:
            x = g
        # Apply dropout
        x = self.dropout(x)
        # $(f(x W_1 + b_1) \otimes (x V + b)) W_2 + b_2$ or $f(x W_1 + b_1) W_2 + b_2$
        # depending on whether it is gated
        return self.layer2(x)


class SwitchFeedForward(torch.nn.Module):
    """
    ## Routing among multiple FFNs
    """

    def __init__(
        self,
        *,
        capacity_factor: float,
        drop_tokens: bool,
        is_scale_prob: bool,
        n_experts: int,
        expert: torch.nn.Module,
        d_model: int,
        export_onnx: bool,
    ):
        """
        * `capacity_factor` is the capacity of each expert as a factor relative to ideally balanced load
        * `drop_tokens` specifies whether to drop tokens if more tokens are routed to an expert than the capacity
        * `is_scale_prob` specifies whether to multiply the input to the FFN by the routing probability
        * `n_experts` is the number of experts
        * `expert` is the expert layer, a [FFN module](../feed_forward.html)
        * `d_model` is the number of features in a token embedding
        * `d_ff` is the number of features in the hidden layer of the FFN
        * `dropout` is dropout probability in the FFN
        """
        super().__init__()

        self.capacity_factor = capacity_factor
        self.is_scale_prob = is_scale_prob
        self.n_experts = n_experts
        self.drop_tokens = drop_tokens
        self.export_onnx = export_onnx

        # make copies of the FFNs
        self.experts = clone_module_list(expert, n_experts)
        # Routing layer and softmax
        self.switch = nn.Linear(d_model, n_experts)
        self.softmax = nn.Softmax(dim=-1)
        self.switch_weights = []
        for name in self.named_parameters():
            self.switch_weights.append(name[1])

    def forward(self, x: torch.Tensor):
        """
        * `x` is the input to the switching module with shape `[seq_len, batch_size, d_model]`
        """
        x = x.transpose(0, 1)
        switch_weights = self.switch_weights
        n_experts = self.n_experts
        dropout = False if self.export_onnx else True
        exw1 = switch_weights[0].t().unsqueeze(0)

        for i in range(1, n_experts):
            exw1 = torch.cat([exw1, switch_weights[4 * i].t().unsqueeze(0)], 0)

        exb1 = switch_weights[1].unsqueeze(0)
        for i in range(1, n_experts):
            exb1 = torch.cat([exb1, switch_weights[4 * i + 1].unsqueeze(0)], 0)

        exw2 = switch_weights[2].t().unsqueeze(0)
        for i in range(1, n_experts):
            exw2 = torch.cat([exw2, switch_weights[4 * i + 2].t().unsqueeze(0)], 0)

        exb2 = switch_weights[3].unsqueeze(0)
        for i in range(1, n_experts):
            exb2 = torch.cat([exb2, switch_weights[4 * i + 3].unsqueeze(0)], 0)

        seq_len, batch_size, d_model = x.shape
        x = x.contiguous().view(-1, d_model)

        sw = torch.mm(x, switch_weights[-2].t()) + switch_weights[-1]
        route_prob = torch.nn.functional.softmax(sw, -1)

        topkval, topkidx = torch.topk(route_prob, 3)
        route_prob_max = topkval[:, 0:1]
        route_prob_max_top2 = topkval[:, 1:2]
        route_prob_max_top3 = topkval[:, 2:3]
        routes_top1 = topkidx[:, 0]
        routes_top2 = topkidx[:, 1]
        routes_top3 = topkidx[:, 2]

        xraw = x
        x = x.unsqueeze(1)
        bat_size = x.shape[0]
        x = torch.cat([x, x, x], 0)
        routes = torch.cat([routes_top1, routes_top2, routes_top3], 0)

        routesw1 = exw1[routes]
        routesb1 = exb1[routes]
        tmp1 = torch.bmm(x, routesw1) + routesb1.unsqueeze(1)
        tmp1 = torch.nn.functional.relu(tmp1)

        if dropout:
            tmp1 = torch.nn.functional.dropout(tmp1, 0.1)

        routesw2 = exw2[routes]
        routesb2 = exb2[routes]
        final_output = torch.bmm(tmp1, routesw2) + routesb2.unsqueeze(1)
        final_output = final_output.squeeze(1)

        route_prob_max = route_prob_max.expand([-1, final_output.shape[1]])
        route_prob_max_top2 = route_prob_max_top2.expand([-1, final_output.shape[1]])
        route_prob_max_top3 = route_prob_max_top3.expand([-1, final_output.shape[1]])

        final_output = (
            final_output[0:bat_size] * route_prob_max
            + final_output[bat_size : 2 * bat_size] * route_prob_max_top2
            + final_output[2 * bat_size :] * route_prob_max_top3
        )

        capacity = int(self.capacity_factor * len(x) / n_experts)

        dropped = []
        if dropout:
            for i in range(n_experts):
                indx = torch.eq(routes_top1, i).nonzero(as_tuple=True)[0]

                if len(indx) <= capacity:
                    continue
                indx = indx[torch.randperm(len(indx))]
                # Collect the tokens over capacity as dropped tokens
                dropped.append(indx[capacity:])

        if dropped:
            dropped = torch.cat(dropped)
            final_output[dropped, :] = xraw[dropped, :]

        final_output = final_output.contiguous().view(seq_len, batch_size, d_model)
        final_output = final_output.transpose(0, 1)
        return final_output


class SeparableConv1dLayer(nn.Module):

    """Single-layered separable conv1d for Transformer block.
    which use depthwise cnn and pointwise cnn to replace the normal 1 layer cnn to reduce the model size.
    normal cnn parameter size: k * idim * odim
    separable cnn parameter size: k * idim  * 1 +  1 * odim * idim
    (k for kernel size)
    when idim = odim = 384,
    normal cnn size: k * 384 * 384, separable cnn size: k * 384 + 384 * 384

    """

    def __init__(self, in_channels, out_channels, kernel_size, dropout_rate=0.0, scale_factor=1, padding=0):
        """Initialize SingleLayeredConv1d module.

        Args:
            in_chans (int): Number of input channels.
            hidden_chans (int): Number of hidden channels. # not used
            kernel_size (int): Kernel size of conv1d.
            dropout_rate (float): Dropout rate.

        """
        super(SeparableConv1dLayer, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.padding = (kernel_size - 1) // 2

        self.W_depthwise = nn.Parameter(torch.Tensor(in_channels * scale_factor, 1, self.kernel_size))
        self.W_pointwise = nn.Parameter(torch.Tensor(out_channels, in_channels * scale_factor, 1))
        self.bias = nn.Parameter(torch.Tensor(out_channels))

        if self.training:
            self.reset_parameters()

    def reset_parameters(self):
        import math

        std = math.sqrt(4.0 / (self.kernel_size * self.out_channels))
        nn.init.normal_(self.W_depthwise, mean=0, std=std)
        nn.init.normal_(self.W_pointwise, mean=0, std=std)
        nn.init.constant_(self.bias, 0)

    def forward(self, x):
        x = F.conv1d(x.contiguous().transpose(-1, 1), self.W_depthwise, padding=self.padding, groups=self.in_channels)
        x = F.conv1d(x, self.W_pointwise, bias=self.bias).transpose(-1, 1)
        return x

    def extra_repr(self):
        return "in_channels={}, out_channels={}, kernel_size={}, padding={}".format(
            self.in_channels, self.out_channels, self.kernel_size, self.padding
        )


class SingleLayeredConv1d(torch.nn.Module):
    """Single-layered seperable conv1d for Transformer block."""

    def __init__(self, in_chans, hidden_chans, kernel_size, dropout_rate):
        """Initialize SingleLayeredConv1d module.

        Args:
            in_chans (int): Number of input channels.
            hidden_chans (int): Number of hidden channels. # not used
            kernel_size (int): Kernel size of conv1d.
            dropout_rate (float): Dropout rate.

        """
        super(SingleLayeredConv1d, self).__init__()
        self.sw_2 = torch.nn.Conv1d(
            in_chans,
            in_chans,
            kernel_size,
            stride=1,
            padding=(kernel_size - 1) // 2,
        )

    def forward(self, x):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., in_chans).

        Returns:
            Tensor: Batch of output tensors (B, ..., hidden_chans).

        """
        return self.sw_2(x.transpose(-1, 1)).transpose(-1, 1)


class MultiLayeredSepConv1d(torch.nn.Module):
    """Multi-layered seperable conv1d for Transformer block."""

    def __init__(self, in_chans, hidden_chans, kernel_size, dropout_rate):
        """Initialize MultiLayeredSeperableConv1d module.

        Args:
            in_chans (int): Number of input channels.
            hidden_chans (int): Number of hidden channels.
            kernel_size (int): Kernel size of conv1d.
            dropout_rate (float): Dropout rate.

        """
        super(MultiLayeredSepConv1d, self).__init__()
        self.w_1 = SeparableConv1dLayer(
            in_chans,
            hidden_chans,
            kernel_size,
        )
        self.w_2 = SeparableConv1dLayer(
            hidden_chans,
            in_chans,
            kernel_size,
        )
        self.dropout = torch.nn.Dropout(dropout_rate)

    def forward(self, x):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., in_chans).

        Returns:
            Tensor: Batch of output tensors (B, ..., hidden_chans).

        """
        x = torch.relu(self.w_1(x))
        return self.w_2(self.dropout(x))


class MultiLayeredConv1d(torch.nn.Module):
    """Multi-layered conv1d for Transformer block."""

    def __init__(self, in_chans, hidden_chans, kernel_size, dropout_rate):
        """Initialize MultiLayeredConv1d module.

        Args:
            in_chans (int): Number of input channels.
            hidden_chans (int): Number of hidden channels.
            kernel_size (int): Kernel size of conv1d.
            dropout_rate (float): Dropout rate.

        """
        super(MultiLayeredConv1d, self).__init__()
        self.w_1 = torch.nn.Conv1d(
            in_chans,
            hidden_chans,
            kernel_size,
            stride=1,
            padding=(kernel_size - 1) // 2,
        )
        self.w_2 = torch.nn.Conv1d(
            hidden_chans,
            in_chans,
            kernel_size,
            stride=1,
            padding=(kernel_size - 1) // 2,
        )
        self.dropout = torch.nn.Dropout(dropout_rate)

    def forward(self, x):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., in_chans).

        Returns:
            Tensor: Batch of output tensors (B, ..., hidden_chans).

        """
        x = torch.relu(self.w_1(x.transpose(-1, 1))).transpose(-1, 1)
        return self.w_2(self.dropout(x).transpose(-1, 1)).transpose(-1, 1)


class Conv1dLinear(torch.nn.Module):
    """Conv1D + Linear for Transformer block.

    A variant of MultiLayeredConv1d, which replaces second conv-layer to linear.

    """

    def __init__(self, in_chans, hidden_chans, kernel_size, dropout_rate):
        """Initialize Conv1dLinear module.

        Args:
            in_chans (int): Number of input channels.
            hidden_chans (int): Number of hidden channels.
            kernel_size (int): Kernel size of conv1d.
            dropout_rate (float): Dropout rate.

        """
        super(Conv1dLinear, self).__init__()
        self.w_1 = torch.nn.Conv1d(
            in_chans,
            hidden_chans,
            kernel_size,
            stride=1,
            padding=(kernel_size - 1) // 2,
        )
        self.w_2 = torch.nn.Linear(hidden_chans, in_chans)
        self.dropout = torch.nn.Dropout(dropout_rate)

    def forward(self, x):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., in_chans).

        Returns:
            Tensor: Batch of output tensors (B, ..., hidden_chans).

        """
        x = torch.relu(self.w_1(x.transpose(-1, 1))).transpose(-1, 1)
        return self.w_2(self.dropout(x))


class GLU(nn.Module):
    """GLU component."""

    def __init__(self, dim_in, dim_out):
        super().__init__()
        self.proj = nn.Linear(dim_in, dim_out * 2)

    def forward(self, x):
        x, gate = self.proj(x).chunk(2, dim=-1)
        return x * F.gelu(gate)


class MultiLayeredGlu(nn.Module):
    """Multi-layered linear with glu block."""

    def __init__(self, dim, inner_dim, kenel_size, dropout=0.0):
        super().__init__()
        project_in = GLU(dim, inner_dim)

        self.net = nn.Sequential(project_in, nn.Dropout(dropout), nn.Linear(inner_dim, dim))

    def forward(self, x):
        return self.net(x)


class MultiLayeredConvGlu(torch.nn.Module):
    """Multi-layered conv1d with glu block."""

    def __init__(self, in_chans, hidden_chans, kernel_size, dropout_rate):
        """Initialize MultiLayeredConv1d module.

        Args:
            in_chans (int): Number of input channels.
            hidden_chans (int): Number of hidden channels.
            kernel_size (int): Kernel size of conv1d.
            dropout_rate (float): Dropout rate.

        """
        super(MultiLayeredConvGlu, self).__init__()
        self.w_1 = GLU(in_chans, hidden_chans)
        self.w_2 = torch.nn.Conv1d(
            hidden_chans,
            in_chans,
            kernel_size,
            stride=1,
            padding=(kernel_size - 1) // 2,
        )
        self.dropout = torch.nn.Dropout(dropout_rate)

    def forward(self, x):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., in_chans).

        Returns:
            Tensor: Batch of output tensors (B, ..., hidden_chans).

        """
        x = self.w_1(x)
        return self.w_2(self.dropout(x).transpose(-1, 1)).transpose(-1, 1)

import torch
import torch.nn.functional as F
from torch.distributions import Normal, OneHotCategorical


class SpeakerEncoder(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.lstm = torch.nn.LSTM(80, 256, 2, batch_first=True)
        self.linear = torch.nn.Linear(256, 256)

    def forward(self, mels, mels_len=None, normalize=True):
        if mels_len is not None:
            mels_spk = torch.nn.utils.rnn.pack_padded_sequence(
                mels, mels_len.cpu(), batch_first=True, enforce_sorted=False
            )
            self.lstm.flatten_parameters()
        else:
            mels_spk = mels
        _, (hidden, _) = self.lstm(mels_spk)
        if normalize:
            spk_emb = F.relu(self.linear(hidden[-1]))
            spk_emb = spk_emb / torch.norm(spk_emb, dim=1, keepdim=True)
        else:
            spk_emb = F.softsign(self.linear(hidden[-1]))

        return spk_emb


class AttributesEncoder(torch.nn.Module):
    # attributes encoder module
    def __init__(self, idim=256, odim=10):
        super().__init__()
        self.mlp = torch.nn.Sequential(
            torch.nn.Linear(idim, 256),
            torch.nn.ReLU(),
            torch.nn.Linear(256, 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, 64),
            torch.nn.ReLU(),
            torch.nn.Linear(64, 32),
            torch.nn.ReLU(),
            torch.nn.Linear(32, odim),
            torch.nn.Softsign(),
        )

    def forward(self, vecs):
        attri = self.mlp(vecs)
        return attri


class AttributesDecoder(torch.nn.Module):
    # attributes decoder module
    def __init__(self, attributes_dim=10, unrelate_feat_dim=6, odim=256):
        super().__init__()
        idim = attributes_dim + unrelate_feat_dim
        self.mlp = torch.nn.Sequential(
            torch.nn.Linear(idim, 32),
            torch.nn.ReLU(),
            torch.nn.Linear(32, 64),
            torch.nn.ReLU(),
            torch.nn.Linear(64, 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, 256),
            torch.nn.ReLU(),
            torch.nn.Linear(256, odim),
        )

    def forward(self, attri, normalize=True):
        vecs = self.mlp(attri)
        if normalize:
            spk_emb = F.relu(vecs)
            spk_emb = spk_emb / torch.norm(spk_emb, dim=1, keepdim=True)
        else:
            spk_emb = F.softsign(vecs)

        return spk_emb


class MixtureDensityNetwork(torch.nn.Module):
    # Gaussian mixute density network
    def __init__(
        self,
        in_dim=1,
        model_dim=128,
        mixture_num=12,
        feature_dim=10
    ):
        super().__init__()
        self.mdn = torch.nn.Sequential(
            torch.nn.Linear(in_dim, model_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(model_dim, model_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(model_dim, model_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(model_dim, model_dim),
            torch.nn.ReLU(),
            torch.nn.Linear(model_dim, model_dim),
            torch.nn.ReLU()
        )
        self.weights = torch.nn.Linear(model_dim, mixture_num)
        self.means = torch.nn.Linear(model_dim, mixture_num * feature_dim)
        self.stds = torch.nn.Linear(model_dim, mixture_num * feature_dim)
        self.mixture_num = mixture_num
        self.feature_dim = feature_dim

    def forward(self, x, y):
        # x: network inputs, with size [b', dim], b'=1 or b
        # y: data, [b, dim]
        params = self.mdn(x)
        log_wei = self.weights(params)
        wei_dist = OneHotCategorical(logits=log_wei)

        means = self.means(params)
        stds = self.stds(params)
        stds = F.elu(stds) + 1.0 + 1e-7
        # reshape
        means = means.reshape(x.shape[0], self.mixture_num, self.feature_dim)  # [b', m, dim]
        stds = stds.reshape(x.shape[0], self.mixture_num, self.feature_dim)
        norm_dist = Normal(means, stds)

        torch.set_printoptions(precision=3, sci_mode=False)
        # print('weights','means', 'stds', wei_dist.probs, means, stds)
        # print('weights','means', wei_dist.probs, means)
        # print('weights', wei_dist.probs)

        log_like = norm_dist.log_prob(y.unsqueeze(1))  # y:[b, dim]->[b, 1, dim] out:[b, m, dim]
        log_like = torch.sum(log_like, dim=2)  # [b, m]
        log_like = torch.logsumexp(wei_dist.logits + log_like, dim=1)  # logits:[b', m] out:[b]

        return log_like

    def sampling(self, x, cond_dic=None):
        # only for inference
        # x: network inputs, with size [b, dim]
        # cond_dic: when sampling from the conditional distribution, the conditions are given as
        #           a dictionary: {index: sample_value, ... ...}
        params = self.mdn(x)
        log_wei = self.weights(params)  # [b, m]
        wei_dist = OneHotCategorical(logits=log_wei)

        means = self.means(params)
        stds = self.stds(params)
        stds = F.elu(stds) + 1.0 + 1e-7
        # reshape
        means = means.reshape(x.shape[0], self.mixture_num, self.feature_dim)  # [b, m, dim]
        stds = stds.reshape(x.shape[0], self.mixture_num, self.feature_dim)
        norm_dist = Normal(means, stds)

        if cond_dic is not None:
            cond = torch.tensor(list(cond_dic.values()))
            cond_means = torch.index_select(means, -1, torch.tensor(list(cond_dic.keys())))
            cond_stds = torch.index_select(stds, -1, torch.tensor(list(cond_dic.keys())))
            dims = torch.tensor([i for i in range(means.shape[-1]) if i not in cond_dic.keys()])
            new_means = torch.index_select(means, -1, dims)
            new_stds = torch.index_select(stds, -1, dims)

            cond_log_val = Normal(cond_means, cond_stds).log_prob(cond).sum(-1)  # [b, m]
            new_log_wei = wei_dist.logits + cond_log_val
            new_wei_dist = OneHotCategorical(logits=new_log_wei)
            new_norm_dist = Normal(new_means, new_stds)

            # print('new_weights:', new_wei_dist.probs)

            samples = torch.sum(new_wei_dist.sample().unsqueeze(-1) * new_norm_dist.sample(), dim=1)
            cond = cond.repeat(means.shape[0], 1)  # [b, cond_dim]
            samples = torch.cat([cond, samples], -1)
            idx = list(cond_dic.keys()) + [i for i in range(means.shape[-1]) if i not in cond_dic.keys()]
            order = torch.tensor([idx.index(i) for i in range(len(idx))])
            samples = torch.index_select(samples, -1, order)  # [b, dim]
            return samples
        else:
            samples = torch.sum(wei_dist.sample().unsqueeze(-1) * norm_dist.sample(), dim=1)  # [b, dim]
            return samples

"""Pitch predictor."""

import torch
import torch.nn.functional as F

from torchtts.nn.modules.common.layer_norm import LayerNorm


class PitchPredictor(torch.nn.Module):
    """Pitch predictor module."""

    def __init__(
        self,
        idim,
        n_layers=2,
        n_chans=384,
        kernel_size=3,
        bias=True,
        dropout_rate=0.5,
        enable_global_pitch=False,
        use_condition=False,
        condition_dim=-1,
    ):
        """Initilize duration predictor module.

        Args:
            idim (int): Input dimension.
            n_layers (int, optional): Number of convolutional layers.
            n_chans (int, optional): Number of channels of convolutional layers.
            kernel_size (int, optional): Kernel size of convolutional layers.
            dropout_rate (float, optional): Dropout rate.

        """
        # assert check_argument_types()
        super().__init__()
        self.conv = torch.nn.ModuleList()
        for idx in range(n_layers):
            in_chans = idim if idx == 0 else n_chans
            self.conv += [
                torch.nn.ModuleList(
                    [
                        torch.nn.Conv1d(
                            in_chans,
                            n_chans,
                            kernel_size,
                            stride=1,
                            padding=(kernel_size - 1) // 2,
                            bias=bias,
                        ),
                        torch.nn.ReLU(),
                        LayerNorm(n_chans, condition_dim=condition_dim, eps=1e-12, dim=1)
                        if use_condition
                        else LayerNorm(n_chans, eps=1e-12, dim=1),
                        torch.nn.Dropout(dropout_rate),
                    ]
                )
            ]
        self.linear = torch.nn.Linear(n_chans, 1)
        if enable_global_pitch:
            self.pit_embedding = torch.nn.Embedding(num_embeddings=200, embedding_dim=in_chans)
            self.pit_embeddinglinear = torch.nn.Linear(in_chans, in_chans)
            self.pit_proj = torch.nn.Linear(in_chans + idim, idim)
        self.enable_global_pitch = enable_global_pitch
        self.use_condition = use_condition

    def forward(self, xs, x_masks=None, global_pitch=None, condition=None):
        """Calculate forward propagation.

        Args:
            xs (Tensor): Batch of input sequences (B, Tmax, idim).
            x_masks (ByteTensor, optional):
                Batch of masks indicating padded part (B, Tmax).

        Returns:
            Tensor: Batch of predicted sequences (B, Tmax, 1).

        """

        if global_pitch is not None and self.enable_global_pitch:
            global_pitch = torch.clip(global_pitch, 1, 199)
            global_pitch = self.pit_embedding(global_pitch)
            global_pitch = F.softsign(self.pit_embeddinglinear(global_pitch))
            global_pitch = global_pitch.unsqueeze(1)
            global_pitch = global_pitch.repeat(1, xs.size(1), 1)
            xs = torch.cat([xs, global_pitch], -1)
            xs = self.pit_proj(xs)

        xs = xs.transpose(1, -1)  # (B, idim, Tmax)
        for f in self.conv:
            xs = f[0](xs)  # (B, C, Tmax)
            xs = f[1](xs)
            xs = f[2](xs, condition=condition) if self.use_condition else f[2](xs)
            xs = f[3](xs)

        xs = self.linear(xs.transpose(1, 2))  # (B, Tmax, 1)

        if x_masks is not None:
            xs = xs.masked_fill(x_masks, 0.0)

        return xs


class EnergyPredictor(torch.nn.Module):
    """Energy predictor module."""

    def __init__(
        self,
        idim,
        n_layers=2,
        n_chans=384,
        kernel_size=3,
        bias=True,
        dropout_rate=0.5,
        enable_global_energy=False,
        use_condition=False,
        condition_dim=-1,
    ):
        """Initilize energy predictor module.

        Args:
            idim (int): Input dimension.
            n_layers (int, optional): Number of convolutional layers.
            n_chans (int, optional): Number of channels of convolutional layers.
            kernel_size (int, optional): Kernel size of convolutional layers.
            dropout_rate (float, optional): Dropout rate.

        """
        super().__init__()
        self.conv = torch.nn.ModuleList()
        for idx in range(n_layers):
            in_chans = idim if idx == 0 else n_chans
            self.conv += [
                torch.nn.ModuleList(
                    [
                        torch.nn.Conv1d(
                            in_chans,
                            n_chans,
                            kernel_size,
                            stride=1,
                            padding=(kernel_size - 1) // 2,
                            bias=bias,
                        ),
                        torch.nn.ReLU(),
                        LayerNorm(n_chans, condition_dim=condition_dim, eps=1e-12, dim=1)
                        if use_condition
                        else LayerNorm(n_chans, eps=1e-12, dim=1),
                        torch.nn.Dropout(dropout_rate),
                    ]
                )
            ]
        self.linear = torch.nn.Linear(n_chans, 1)

        if enable_global_energy:
            self.ener_embedding = torch.nn.Embedding(num_embeddings=200, embedding_dim=in_chans)
            self.ener_embeddinglinear = torch.nn.Linear(in_chans, in_chans)
            self.ener_proj = torch.nn.Linear(in_chans + idim, idim)
        self.enable_global_energy = enable_global_energy
        self.use_condition = use_condition

    def forward(self, xs, x_masks=None, global_energy=None, condition=None):
        """Calculate forward propagation.

        Args:
            xs (Tensor): Batch of input sequences (B, Tmax, idim).
            x_masks (ByteTensor, optional):
                Batch of masks indicating padded part (B, Tmax).

        Returns:
            Tensor: Batch of predicted sequences (B, Tmax, 1).

        """

        if global_energy is not None and self.enable_global_energy:
            global_energy = torch.clip(global_energy, 1, 199)
            global_energy = self.ener_embedding(global_energy)
            global_energy = F.softsign(self.ener_embeddinglinear(global_energy))
            global_energy = global_energy.unsqueeze(1)
            global_energy = global_energy.repeat(1, xs.size(1), 1)
            xs = torch.cat([xs, global_energy], -1)
            xs = self.ener_proj(xs)

        xs = xs.transpose(1, -1)  # (B, idim, Tmax)
        for f in self.conv:
            xs = f[0](xs)  # (B, C, Tmax)
            xs = f[1](xs)
            xs = f[2](xs, condition=condition) if self.use_condition else f[2](xs)
            xs = f[3](xs)

        xs = self.linear(xs.transpose(1, 2))  # (B, Tmax, 1)

        if x_masks is not None:
            xs = xs.masked_fill(x_masks, 0.0)

        return xs

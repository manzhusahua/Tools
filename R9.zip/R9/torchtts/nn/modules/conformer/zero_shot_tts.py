import torch
import torch.nn as nn
import numpy as np
from torchtts.nn.modules.conformer.zero_shot_tts_modules import AttentionOnRawValue, PrenetManualSeedInference


class ZeroshotFineGrained(nn.Module):
    """Multi-Head Attention layer.

    :param int n_head: the number of head s
    :param int n_feat: the number of features
    :param float dropout_rate: dropout rate

    """

    def __init__(self, dmodel, dec_num_heads, dropout_rate, meldim=80, featdim=32):
        super(ZeroshotFineGrained, self).__init__()
        self.ph_spec_attin = nn.Linear(dmodel, featdim)
        self.ph_spec_attbottle = nn.Linear(meldim, featdim)
        self.ph_spec_att = AttentionOnRawValue(n_head=dec_num_heads, n_feat=featdim, dropout_rate=dropout_rate, n_out=featdim)
        self.ph_spec_attout = nn.Linear(featdim, dmodel)
        self.ave_pool = nn.AvgPool1d(6, stride=6)

    def calculate_finegrained_output(self, encoder_hiddenraw, refmel, attmask=None, need_ave_pool=False):
        encoder_hiddenraw = self.ph_spec_attin(encoder_hiddenraw)
        if need_ave_pool:
            refmel = self.ave_pool(refmel.transpose(-2, -1))
            refmel = refmel.transpose(-2, -1)
        fineggrainedinput = self.ph_spec_attbottle(refmel)
        ph_hs = self.ph_spec_att(query=encoder_hiddenraw, key=fineggrainedinput.squeeze(1), value=fineggrainedinput.squeeze(1), mask=attmask)
        ph_hs = self.ph_spec_attout(ph_hs)
        return ph_hs

    def calculate_finegrained_input_inference(self, refmel):
        refmel = self.ave_pool(refmel.transpose(-2, -1))
        refmel = refmel.transpose(-2, -1)
        fineggrainedinput = self.ph_spec_attbottle(refmel)
        return fineggrainedinput

    def calculate_finegrained_output_inference(self, encoder_hiddenraw, fineggrainedinput):
        encoder_hiddenraw = self.ph_spec_attin(encoder_hiddenraw)
        ph_hs = self.ph_spec_att(query=encoder_hiddenraw, key=fineggrainedinput.squeeze(1), value=fineggrainedinput.squeeze(1), mask=None)
        ph_hs = self.ph_spec_attout(ph_hs)
        return ph_hs


class AutoregressiveDecoder(nn.Module):
    def __init__(self, dmodel, meldim=80, prenet_layers=2, lstm_layers=3):
        super(AutoregressiveDecoder, self).__init__()
        self.dec_prenet = PrenetManualSeedInference(meldim, n_layers=prenet_layers, model_dim=meldim, dropout_rate=0.5)
        self.lstmdec = nn.LSTM(dmodel + meldim, dmodel, lstm_layers, batch_first=True)
        self.lstm_layers = lstm_layers
        self.dmodel = dmodel
        self.meldim = meldim

    def apply_autoregressive(self, zs, ys):
        mel24kpad = ys[:, :-1, :]
        mel24kpad = self.dec_prenet(mel24kpad)
        mel24kpad = nn.functional.pad(mel24kpad, (0, 0, 1, 0))
        xs = self.lstmdec(torch.cat([zs, mel24kpad], -1))[0]
        return xs

    def apply_autoregressive_inference(self, zs, output_layer_transform):
        h0 = torch.zeros(self.lstm_layers, 1, self.dmodel)
        c0 = torch.zeros(self.lstm_layers, 1, self.dmodel)

        s0 = torch.zeros(1, 1, self.meldim)
        outputs = []
        idxx = 0

        # for 80 dim mel manual seed, dropout rate 0.5
        manualseed = torch.tensor(np.array([0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1])).unsqueeze(0).unsqueeze(0)
        while idxx < zs.size(1):
            s0, (h0, c0) = self.lstmdec(torch.cat([zs[:, idxx:idxx + 1], s0], -1), (h0, c0))
            s0 = output_layer_transform(s0)
            outputs.append(s0)
            s0, manualseed = self.dec_prenet.forward_inference(s0, manualseed)
            idxx += 1
        return torch.stack(outputs, 0).transpose(0, 1).squeeze(-2)


def select_voice_by_pitch(preselected_voices_embedding, global_f0, pitch_thresholds):
    spembs_prosody_trans = preselected_voices_embedding[0][0]
    gstf0_prosody_trans = preselected_voices_embedding[0][1]

    idx = 1
    for threshold in pitch_thresholds:
        spembs_prosody_trans = torch.where(
            torch.gt(global_f0 * 5.0, torch.tensor(threshold, dtype=torch.float32)),
            preselected_voices_embedding[idx][0],
            spembs_prosody_trans
        )
        gstf0_prosody_trans = torch.where(
            torch.gt(global_f0 * 5.0, torch.tensor(threshold, dtype=torch.float32)),
            preselected_voices_embedding[idx][1],
            gstf0_prosody_trans
        )

        idx += 1

    return spembs_prosody_trans, gstf0_prosody_trans


def transfer_pitch(p_outs_target, p_outs_src, pitch_mean, pitch_var):

    p_outs_targetmean = (p_outs_target * pitch_var + pitch_mean).mean()
    p_outs_srcmean = (p_outs_src * pitch_var + pitch_mean).mean()

    p_outs_src = (p_outs_src * pitch_var + pitch_mean)
    p_outs_src = p_outs_src - (p_outs_srcmean - p_outs_targetmean)
    p_outs_src = (p_outs_src - pitch_mean) / pitch_var

    return p_outs_src

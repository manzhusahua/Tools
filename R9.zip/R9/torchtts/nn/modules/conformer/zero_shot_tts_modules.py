import torch
import torch.nn.functional as F
import torch.nn as nn
import math
import numpy


class AttentionOnRawValue(nn.Module):
    """Multi-Head Attention layer.

    :param int n_head: the number of head s
    :param int n_feat: the number of features
    :param float dropout_rate: dropout rate

    """

    def __init__(self, n_head, n_feat, dropout_rate, n_out=0):
        """Construct an MultiHeadedAttention object."""
        super(AttentionOnRawValue, self).__init__()
        assert n_feat % n_head == 0
        n_head = 1
        self.d_k = n_feat // n_head
        self.h = n_head
        self.linear_q = nn.Linear(n_feat, n_feat)
        self.linear_k = nn.Linear(n_feat, n_feat)
        self.linear_v = nn.Linear(n_feat, n_feat)
        n_out = n_out if n_out > 0 else n_feat
        self.linear_out = nn.Linear(n_feat, n_out)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout_rate)

    def forward_qkv(self, query, key, value):

        n_batch = query.size(0)
        q = self.linear_q(query).view(n_batch, -1, self.h, self.d_k)
        k = self.linear_k(key).view(n_batch, -1, self.h, self.d_k)
        q = q.transpose(1, 2)  # (batch, head, time1, d_k)
        k = k.transpose(1, 2)  # (batch, head, time2, d_k)

        return q, k

    def forward_attention(self, value, scores, mask):

        n_batch = value.size(0)
        if mask is not None:
            mask = mask.unsqueeze(1).eq(0)  # (batch, 1, *, time2)
            min_value = float(
                numpy.finfo(torch.tensor(0, dtype=scores.dtype).numpy().dtype).min
            )
            scores = scores.masked_fill(mask, min_value)
            self.attn = torch.softmax(scores, dim=-1).masked_fill(
                mask, 0.0
            )  # (batch, head, time1, time2)
        else:
            self.attn = torch.softmax(scores, dim=-1)  # (batch, head, time1, time2)

        p_attn = self.dropout(self.attn)

        x = torch.matmul(p_attn, value)  # (batch, head, time1, d_k)
        x = (
            x.transpose(1, 2).contiguous().view(n_batch, -1, self.h * self.d_k)
        )  # (batch, time1, d_model)

        return x

    def forward(self, query, key, value, mask):

        q, k = self.forward_qkv(query, key, value)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_k)

        return self.forward_attention(value.unsqueeze(1), scores, mask)


class PrenetManualSeedInference(nn.Module):
    def __init__(self, idim, n_layers=2, model_dim=256, dropout_rate=0.5):
        """Initialize prenet module.

        Args:
            idim (int): Dimension of the inputs.
            odim (int): Dimension of the outputs.
            n_layers (int, optional): The number of prenet layers.
            model_dim (int, optional): The number of prenet units.

        """
        super(PrenetManualSeedInference, self).__init__()
        self.dropout_rate = dropout_rate
        self.prenet = nn.ModuleList()
        for layer in range(n_layers):
            n_inputs = idim if layer == 0 else model_dim
            self.prenet += [nn.Sequential(nn.Linear(n_inputs, model_dim), nn.ReLU())]
        self.linear_dec_prenet = nn.Linear(model_dim, model_dim)

    def forward(self, x):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., idim).

        Returns:
            Tensor: Batch of output tensors (B, ..., odim).

        """
        for i in range(len(self.prenet)):
            preout = self.prenet[i](x)
            x = F.dropout(preout, self.dropout_rate)
        return self.linear_dec_prenet(x)

    def forward_inference(self, x, randomint=None):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., idim).

        Returns:
            Tensor: Batch of output tensors (B, ..., odim).

        """
        for i in range(len(self.prenet)):
            preout = self.prenet[i](x)
            # 13, 20, 60 are for 80 dim mel manual seed shuffle
            randomint = torch.cat([randomint[:, :, -13:], randomint[:, :, :-13]], -1)
            randomint = torch.cat([randomint[:, :, 20:60], randomint[:, :, :20], randomint[:, :, 60:]], -1)
            preout = randomint * preout
            x = preout * 2
        return self.linear_dec_prenet(x), randomint

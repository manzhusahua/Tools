import torch
import torch.nn as nn

from torchtts.nn.modules.common.functional import alignment_matrix_to_relative_position
from torchtts.nn.modules.common.functional import duration_to_alignment_matrix
from torchtts.nn.modules.common import LayerNorm


class DecoderEmbedding(nn.Module):
    """Relative position aware embeddings for decoder."""

    def __init__(
        self,
        symbol_size,
        symbol_size_multiplier=3,
        embedding_size=384,
        n_layers=2,
        hidden_size=384,
        kernel_size=5,
        dropout=0.1,
    ):
        super(DecoderEmbedding, self).__init__()

        self.embedding_size = embedding_size
        self.symbol_size_multiplier = symbol_size_multiplier

        self.embedding = nn.Embedding(symbol_size * symbol_size_multiplier, embedding_size)

        self.layers = nn.ModuleList()
        for i in range(n_layers):
            self.layers.append(
                nn.Conv1d(
                    embedding_size if i == 0 else hidden_size, hidden_size, kernel_size, padding=(kernel_size - 1) // 2
                )
            )
            self.layers.append(nn.ReLU())
            self.layers.append(LayerNorm(hidden_size, dim=1))
            self.layers.append(nn.Dropout(dropout))

        self.linear = nn.Sequential(nn.Linear(hidden_size, hidden_size, bias=False), nn.ReLU())

        self.reset_parameters()

    def forward(self, symbol_ids, durations, padding_mask=None):
        align_mat = duration_to_alignment_matrix(durations)
        position_ids = torch.matmul(align_mat, symbol_ids.unsqueeze(-1).float())
        position_ids = position_ids * self.symbol_size_multiplier

        relative_pos = alignment_matrix_to_relative_position(align_mat)

        left = (relative_pos < (1 / self.symbol_size_multiplier)).long()
        right = (relative_pos > (2 / self.symbol_size_multiplier)).long()
        middle = (
            (relative_pos >= (1 / self.symbol_size_multiplier)) & (relative_pos <= (2 / self.symbol_size_multiplier))
        ).long()

        relative_offsets = 0 * left + 1 * middle + 2 * right
        position_ids = position_ids.squeeze(-1).long() + relative_offsets

        dec_embedding_outputs = self.embedding(position_ids)
        dec_embedding_outputs *= self.embedding_size**0.5

        x = dec_embedding_outputs.permute(0, 2, 1)
        for layer in self.layers:
            x = layer(x)

        x = self.linear(x.permute(0, 2, 1))

        if padding_mask is not None:
            x *= (~padding_mask).to(x.dtype).unsqueeze(-1)

        return x

    def reset_parameters(self):
        nn.init.normal_(self.embedding.weight, 0, self.embedding_size**-0.5)

import torch.nn as nn

from torchtts.nn.modules.common import LayerNorm


class DurationPredictor(nn.Module):
    """Duration Predictor

    Args:
        in_dim: the number of expected size of input.
        filter_size: the filter size (channels) of convolution.
        kernel: the kernel size of convolution.
        num_layers: the number of layers of conv, relu, norm and dropout.
        dropout: the dropout value.
    """

    def __init__(self, in_dim, filter_size, kernel=3, num_layers=2, dropout=0.1):
        super(DurationPredictor, self).__init__()

        self.layers = nn.ModuleList()
        for i in range(num_layers):
            self.layers.append(
                nn.Conv1d(in_dim if i == 0 else filter_size, filter_size, kernel_size=kernel, padding=(kernel - 1) // 2)
            )
            self.layers.append(nn.ReLU())
            self.layers.append(LayerNorm(filter_size, dim=1))
            self.layers.append(nn.Dropout(dropout))

        self.linear = nn.Sequential(nn.Linear(filter_size, 1), nn.ReLU())

    def forward(self, x, mask=None):
        x = x.permute(0, 2, 1)
        for layer in self.layers:
            x = layer(x)
        x = x.permute(0, 2, 1)

        x = self.linear(x)

        if mask is not None:
            x = x * mask.to(x.dtype).unsqueeze(-1)

        return x.squeeze(-1)

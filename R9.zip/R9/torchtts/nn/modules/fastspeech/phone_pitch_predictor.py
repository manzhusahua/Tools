import torch.nn as nn

from torchtts.nn.modules.common import LayerNorm


class PhonePitchPredictor(nn.Module):
    """Phone-level pitch predictor."""

    def __init__(self, in_dim, filter_size=256, kernel=3, num_layers=2, dropout=0.5, layer_norm_condition_dim=-1):
        super(PhonePitchPredictor, self).__init__()
        self.layers = nn.ModuleList()
        for i in range(num_layers):
            self.layers.append(
                nn.Conv1d(in_dim if i == 0 else filter_size, filter_size, kernel_size=kernel, padding=(kernel - 1) // 2)
            )
            self.layers.append(nn.ReLU())
            self.layers.append(LayerNorm(filter_size, condition_dim=layer_norm_condition_dim, dim=1))
            self.layers.append(nn.Dropout(dropout))

        self.linear = nn.Linear(filter_size, 1)

    def forward(self, x, condition=None, mask=None):
        x = x.permute(0, 2, 1)
        for layer in self.layers:
            if isinstance(layer, LayerNorm):
                x = layer(x, condition=condition)
            else:
                x = layer(x)

        x = x.permute(0, 2, 1)
        x = self.linear(x)

        if mask is not None:
            x = x * mask.to(x.dtype).unsqueeze(-1)

        return x


class PhonePitchEmbedding(nn.Module):
    """Phone-level pitch embedding"""

    def __init__(self, out_dim=384, kernel_size=3):
        super(PhonePitchEmbedding, self).__init__()
        self.f0_embedding = nn.Conv1d(1, out_dim, kernel_size, padding=(kernel_size - 1) // 2)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        return self.f0_embedding(x).permute(0, 2, 1)

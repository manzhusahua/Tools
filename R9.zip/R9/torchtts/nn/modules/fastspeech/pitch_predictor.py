import torch.nn as nn


class PitchPredictor(nn.Module):
    def __init__(self, in_dim):
        super(PitchPredictor, self).__init__()
        self.f0_predictor = nn.Linear(in_dim, 1)
        self.uv_predictor = nn.Linear(in_dim, 1)

    def forward(self, x):
        return self.f0_predictor(x), self.uv_predictor(x)


class PitchEmbedding(nn.Module):
    def __init__(self, f0_emb_dim=64, kernel_size=9, uv_emb_dim=32):
        super(PitchEmbedding, self).__init__()
        self.f0_embedding = nn.Sequential(
            nn.Conv1d(1, f0_emb_dim, kernel_size, padding=(kernel_size - 1) // 2), nn.ReLU()
        )
        self.uv_embedding = nn.Linear(1, uv_emb_dim)

    def forward(self, f0, uv, mask=None):
        if mask is not None:
            f0 = f0 * mask.to(f0.dtype).unsqueeze(-1)
            uv = uv * mask.to(uv.dtype).unsqueeze(-1)

        f0_embedding = self.f0_embedding(f0.permute(0, 2, 1)).permute(0, 2, 1)
        uv_embedding = self.uv_embedding(uv)

        return f0_embedding, uv_embedding

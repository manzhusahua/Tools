import torch
import torch.nn as nn

from torchtts.nn.modules.common.functional import alignment_matrix_to_position
from torchtts.nn.modules.common.functional import duration_to_alignment_matrix


class PositionEmbedding(nn.Module):
    def __init__(self, max_position=16, hidden_size=384):
        super(PositionEmbedding, self).__init__()
        self.fw_pos_embedding = nn.Embedding(max_position, hidden_size)
        self.bw_pos_embedding = nn.Embedding(max_position, hidden_size)
        self.register_buffer("max_position", torch.tensor(max_position))

    def forward(self, duration):
        align_mat = duration_to_alignment_matrix(duration)

        position = alignment_matrix_to_position(align_mat)
        position = torch.clamp_max(position, self.max_position - 1)
        fw_embedding = self.fw_pos_embedding(position)

        position = alignment_matrix_to_position(align_mat, reverse=True)
        position = torch.clamp_max(position, self.max_position - 1)
        bw_embedding = self.bw_pos_embedding(position)

        pos_embedding = fw_embedding + bw_embedding

        return pos_embedding

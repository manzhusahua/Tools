from torchtts.nn.modules.hifinet.discriminator import TimeDiscriminator
from torchtts.nn.modules.hifinet.discriminator import SpecDiscriminator
from torchtts.nn.modules.hifinet.discriminator import HiFiGANMultiPeriodDiscriminator
from torchtts.nn.modules.hifinet.discriminator import MultiPeriodDiscriminator
from torchtts.nn.modules.hifinet.alias_free_torch import Activation1d

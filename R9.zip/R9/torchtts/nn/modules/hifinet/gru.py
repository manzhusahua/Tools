import torch.nn as nn


class GRU(nn.Module):
    def __init__(self, in_size, out_size, num_layers=1, bidirectional=True, dropout=0.0):
        super().__init__()
        self.model = nn.GRU(
            in_size,
            out_size // 2 if bidirectional else out_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=bidirectional,
            dropout=dropout,
        )

    def forward(self, x):
        predict = x.transpose(1, 2)
        predict, _ = self.model(predict)
        predict = predict.transpose(1, 2)
        return predict

import torch
import torch.nn as nn


class ResnetBlock(nn.Module):
    def __init__(self, dim, dilation=1, kernel_size=3, causal=False):
        super().__init__()

        if kernel_size == 3:
            pad_dilation = dilation
        elif kernel_size == 5:
            pad_dilation = 2 * dilation
        elif kernel_size == 7:
            pad_dilation = 3 * dilation

        if causal is True:
            pad_dilation = (2 * pad_dilation, 0)

        self.block = nn.Sequential(
            nn.LeakyReLU(0.2),
            nn.ReflectionPad1d(pad_dilation),
            nn.Conv1d(dim, dim, kernel_size=kernel_size, dilation=dilation),
            nn.LeakyReLU(0.2),
            nn.Conv1d(dim, dim, kernel_size=1),
        )

        self.shortcut = nn.Conv1d(dim, dim, kernel_size=1)
        self.alpha = nn.Parameter(torch.Tensor(dim, 1))
        with torch.no_grad():
            self.alpha.fill_(0)

    def forward(self, x):
        return self.shortcut(x) + self.block(x) * self.alpha

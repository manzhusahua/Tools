import torch.nn as nn


class AcousticEncoder(nn.Module):
    def __init__(self, in_size, hidden_size, out_size, encoder):
        super().__init__()
        # Input projection to fit encoder dim
        self.in_proj = nn.Linear(in_size, hidden_size)

        # Frame-level encoder
        self.encoder = encoder

        # Output projection
        self.out_proj = nn.Linear(hidden_size, out_size)

    def forward(self, latents, latents_mask=None, local_conditions=None):
        if latents_mask is not None:
            latents_mask = latents_mask.unsqueeze(1)
        if local_conditions is not None:
            local_conditions = local_conditions.permute(0, 2, 1)

        outputs = self.in_proj(latents)
        outputs = self.encoder(outputs.permute(0, 2, 1), latents_mask, c=local_conditions)
        outputs = outputs.permute(0, 2, 1)

        outputs = self.out_proj(outputs)

        if latents_mask is not None:
            outputs *= latents_mask.permute(0, 2, 1)

        return outputs

import numpy as np
import torch
import torch.nn as nn

from torchtts.nn.modules.hifinet.gru import GRU
from torchtts.nn.modules.hifinet.resnet_block import ResnetBlock


class Decoder(nn.Module):
    def __init__(self,
                 in_channels=80,
                 ngf=32,
                 n_residual_layers=(3, 3, 3, 3),
                 dropout=0.1,
                 use_rnn=True,
                 rnn_bidirectional=False,
                 rnn_num_layers=1,
                 rnn_dropout=0.,
                 up_ratios=(3, 4, 5, 5),
                 n_skip_connections=3,
                 use_weight_norm=True):
        super().__init__()
        self.hop_length = np.prod(up_ratios)
        self.ngf = ngf
        self.up_ratios = up_ratios
        self.skip_start = len(up_ratios) - n_skip_connections
        mul = int(2 ** len(up_ratios))

        pre_layer = [
            nn.ReflectionPad1d(3),
            nn.Conv1d(in_channels, mul * ngf, kernel_size=7),
            nn.LeakyReLU(0.2),
        ]

        if use_rnn:
            pre_layer += [
                nn.Dropout(dropout),
                GRU(in_size=mul * ngf,
                    out_size=mul * ngf,
                    num_layers=rnn_num_layers,
                    bidirectional=rnn_bidirectional,
                    dropout=rnn_dropout)
            ]

        self.pre_layer = nn.Sequential(*pre_layer)

        self.upsample_layers = nn.ModuleList()
        self.skip_upsample_layers = nn.ModuleList()

        # Upsample to raw audio scale
        for i, r in enumerate(up_ratios):
            upsample_layer = [
                nn.ConvTranspose1d(
                    in_channels=mul * ngf,
                    out_channels=mul * ngf // 2,
                    kernel_size=r * 2,
                    stride=r,
                    padding=r // 2 + r % 2,
                    output_padding=r % 2,
                ),
            ]

            for j in range(n_residual_layers[i]):
                upsample_layer += [ResnetBlock(mul * ngf // 2, dilation=3 ** j)]

            upsample_layer += [nn.LeakyReLU(0.2)]

            self.upsample_layers.append(nn.Sequential(*upsample_layer))

            # Skip connection upsample layers
            if i >= self.skip_start:
                skip_upsample_layer = [
                    nn.Upsample(scale_factor=r, mode='nearest'),
                    nn.Conv1d(in_channels=mul * ngf,
                              out_channels=mul * ngf // 2,
                              kernel_size=1)
                ]
                self.skip_upsample_layers.append(nn.Sequential(*skip_upsample_layer))

            mul //= 2

        self.post_layer = nn.Sequential(
            nn.ReflectionPad1d(3),
            nn.Conv1d(ngf, 1, kernel_size=7),
            nn.Tanh(),
        )

        if use_weight_norm:
            self.apply_weight_norm()
        self.reset_parameters()

    def forward(self, x):
        x = self.pre_layer(x)

        output = None
        for i in range(len(self.upsample_layers)):
            new_x = self.upsample_layers[i](x)

            if i >= self.skip_start:
                skip_upsample_input = x if output is None else output
                output = self.skip_upsample_layers[i - self.skip_start](skip_upsample_input)
                output += new_x

            x = new_x

        return self.post_layer(output)

    def remove_weight_norm(self):
        """Remove weight normalization module from all of the layers."""

        def _remove_weight_norm(m):
            try:
                torch.nn.utils.remove_weight_norm(m)
            except ValueError:  # this module didn't have weight norm
                return

        self.apply(_remove_weight_norm)

    def apply_weight_norm(self):
        """Apply weight normalization module from all of the layers."""

        def _apply_weight_norm(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                torch.nn.utils.weight_norm(m)

        self.apply(_apply_weight_norm)

    def reset_parameters(self):
        def _reset_parameters(m):
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                m.weight.data.normal_(0.0, 0.02)
        self.apply(_reset_parameters)

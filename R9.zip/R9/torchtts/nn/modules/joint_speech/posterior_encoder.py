import torch.nn as nn
from torch.distributions import Normal

from torchtts.nn.modules.common import LayerNorm


class ConvPosteriorEncoder(nn.Module):

    def __init__(self,
                 in_size,
                 hidden_size,
                 out_size,
                 conv_num_layers=3,
                 conv_kernel_size=3,
                 conv_dropout_rate=0.1):
        super().__init__()

        self.layers = nn.ModuleList()
        for i in range(conv_num_layers):
            self.layers += [
                nn.Conv1d(
                    in_channels=in_size if i == 0 else hidden_size,
                    out_channels=hidden_size,
                    kernel_size=conv_kernel_size,
                    padding=conv_kernel_size // 2
                ),
                nn.ReLU(),
                LayerNorm(hidden_size, dim=1),
                nn.Dropout(conv_dropout_rate)
            ]

        self.rnn = nn.GRU(hidden_size, hidden_size, bidirectional=True, batch_first=True)
        self.out_linear = nn.Linear(hidden_size * 2, out_size)

    def forward(self, x, mask=None):
        x = x.permute(0, 2, 1)
        for layer in self.layers:
            x = layer(x)
        x = x.permute(0, 2, 1)

        if mask is not None:
            x = x * mask.unsqueeze(-1)

        x, _ = self.rnn(x)
        x = self.out_linear(x)

        if mask is not None:
            x = x * mask.unsqueeze(-1)

        return x


class PosteriorEncoder(nn.Module):
    def __init__(self, in_size, hidden_size, out_size, frame_encoder, downsampler, phone_encoder, mean_only=False):
        super().__init__()
        # Input project to fit encoder dim
        self.in_proj = nn.Linear(in_size, hidden_size)

        # Frame-level encoder
        self.frame_encoder = frame_encoder

        # Downsampler to convert frame-level to phone-level features
        self.downsampler = downsampler

        # Phone-level encoder
        self.phone_encoder = phone_encoder

        self.mean_only = mean_only

        # Output projection for VAE
        self.mu_proj = nn.Linear(hidden_size, out_size)
        if not self.mean_only:
            self.scale_proj = nn.Linear(hidden_size, out_size)

    def forward(
        self, feats, feats_mask, durations=None, durations_mask=None, local_conditions=None, global_conditions=None
    ):
        feats_mask = feats_mask.unsqueeze(-1)
        if local_conditions is not None:
            local_conditions = local_conditions.permute(0, 2, 1)
        if global_conditions is not None:
            global_conditions = global_conditions.unsqueeze(-1)

        outputs = self.in_proj(feats) * feats_mask
        outputs = self.frame_encoder(
            outputs.permute(0, 2, 1), feats_mask.permute(0, 2, 1), c=local_conditions, g=global_conditions
        )
        outputs = outputs.permute(0, 2, 1)

        if self.downsampler is not None:
            outputs, _ = self.downsampler(outputs, durations)
            outputs *= durations_mask.unsqueeze(-1)

            if self.phone_encoder is not None:
                if local_conditions is not None:
                    phone_local_conditions, _ = self.downsampler(local_conditions.permute(0, 2, 1), durations)
                    phone_local_conditions *= durations_mask.unsqueeze(-1)
                    phone_local_conditions = phone_local_conditions.permute(0, 2, 1)

                outputs = self.phone_encoder(
                    outputs.permute(0, 2, 1),
                    durations_mask.unsqueeze(1),
                    c=phone_local_conditions,
                    g=global_conditions,
                )
                outputs = outputs.permute(0, 2, 1)

        if self.mean_only:
            return self.mu_proj(outputs)
        else:
            means = self.mu_proj(outputs)
            log_scales = self.scale_proj(outputs)
            return Normal(means, log_scales.exp())

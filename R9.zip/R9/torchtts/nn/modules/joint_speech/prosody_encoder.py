import torch.nn as nn
from torch.distributions import Normal


class ProsodyEncoder(nn.Module):
    def __init__(self, in_size, hidden_size, out_size, encoder):
        super().__init__()
        # Input project to fit encoder dim
        self.in_proj = nn.Linear(in_size, hidden_size)

        # Phone-level encoder
        self.encoder = encoder

        # Output projection for VAE
        self.mu_proj = nn.Linear(hidden_size, out_size)
        self.scale_proj = nn.Linear(hidden_size, out_size)

    def forward(self, feats, feats_mask=None, global_conditions=None):
        if feats_mask is not None:
            feats_mask = feats_mask.to(feats.dtype).unsqueeze(1)
        if global_conditions is not None:
            global_conditions = global_conditions.unsqueeze(-1)

        outputs = self.in_proj(feats)
        if feats_mask is not None:
            outputs *= feats_mask.permute(0, 2, 1)

        outputs = self.encoder(outputs.permute(0, 2, 1), feats_mask, g=global_conditions)
        outputs = outputs.permute(0, 2, 1)

        means = self.mu_proj(outputs)
        log_scales = self.scale_proj(outputs)

        return Normal(means, log_scales.exp())

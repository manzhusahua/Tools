import torch.nn as nn


class TextEncoder(nn.Module):
    def __init__(
        self,
        model_dim,
        phone_embedding,
        pos_encoding,
        encoder,
    ):
        super().__init__()
        self.model_dim = model_dim

        self.phone_embedding = phone_embedding
        self.pos_encoding = pos_encoding

        self.encoder = encoder

        self.reset_parameters()

    def forward(self, phone_ids, phone_mask=None, locale_embedding=None):
        # Phoneme or character embedding
        phone_embedding = self.phone_embedding(phone_ids)
        phone_embedding *= self.model_dim**0.5

        # Add position encoding to embedding
        encoder_input = self.pos_encoding(phone_embedding)

        padding_mask = ~phone_mask if phone_mask is not None else None
        encoder_output = self.encoder(
            encoder_input, src_key_padding_mask=padding_mask, layer_norm_condition=locale_embedding
        )

        return encoder_output

    def reset_parameters(self):
        # Note: parameter initialization is an important part in transformer based models
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
            if p.dim() == 1:
                nn.init.zeros_(p)

        for m in self.modules():
            if isinstance(m, nn.LayerNorm):
                m.reset_parameters()

        nn.init.normal_(self.phone_embedding.weight, 0, self.model_dim**-0.5)

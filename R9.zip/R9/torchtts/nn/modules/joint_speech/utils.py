def fuse_conditions(conditions):
    if all(c is None for c in conditions):
        return None

    fused_feats = 0
    for condition in conditions:
        if condition is not None:
            fused_feats = fused_feats + condition

    return fused_feats

import torch.nn as nn
import torch.nn.functional as F


class LocaleEmbedding(nn.Module):
    def __init__(self, locale_table_size, embedding_dim, activation='softplus'):
        super(LocaleEmbedding, self).__init__()
        self.embedding = nn.Embedding(locale_table_size, embedding_dim)
        self.linear = nn.Linear(embedding_dim, embedding_dim)
        self.activation = activation

    def forward(self, locale_id):
        embedding = self.embedding(locale_id)
        embedding = getattr(F, self.activation)(self.linear(embedding))
        return embedding

import torch.nn as nn
import torch.nn.functional as F


class SpeakerEmbedding(nn.Module):
    def __init__(self, speaker_table_size, embedding_dim, activation='softplus'):
        super(SpeakerEmbedding, self).__init__()
        self.embedding = nn.Embedding(speaker_table_size, embedding_dim)
        self.linear = nn.Linear(embedding_dim, embedding_dim)
        self.activation = activation

    def forward(self, speaker_id):
        embedding = self.embedding(speaker_id)
        embedding = getattr(F, self.activation)(self.linear(embedding))
        return embedding

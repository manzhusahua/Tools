from torchtts.nn.modules.style_encoders.style_embedding import StyleEmbedding
from torchtts.nn.modules.style_encoders.style_embedding import StyleEmbeddingV2

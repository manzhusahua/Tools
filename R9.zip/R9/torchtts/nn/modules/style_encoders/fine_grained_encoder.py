import torch
import torch.nn as nn

from torchtts.nn.modules.attention import MultiheadAttention
from torchtts.nn.modules.common import LayerNorm
from torchtts.nn.modules.transformer import PositionalEncoding


class FineGrainedEncoder(nn.Module):
    def __init__(
        self,
        in_dim,
        model_dim=384,
        pos_encoding_dim=32,
        speaker_embedding_dim=128,
        locale_embedding_dim=128,
        num_conv_layers=3,
        conv_kernel=5,
        conv_dropout=0.3,
        attn_num_heads=2,
        attn_dropout=0.1,
        attn_kv_dim=48,
        out_dim=None,
    ):
        super(FineGrainedEncoder, self).__init__()
        self.positional_encoding = PositionalEncoding(pos_encoding_dim, mode="concat", dropout=0.0)
        self.layers = nn.ModuleList()
        for i in range(num_conv_layers):
            self.layers.append(
                nn.Conv1d(
                    in_dim + pos_encoding_dim + speaker_embedding_dim if i == 0 else model_dim,
                    model_dim,
                    kernel_size=conv_kernel,
                    padding=(conv_kernel - 1) // 2,
                )
            )
            self.layers.append(nn.ReLU())
            self.layers.append(LayerNorm(model_dim, dim=1))
            self.layers.append(nn.Dropout(conv_dropout))

        # Self attention to encode reference
        self.self_attn = MultiheadAttention(model_dim, attn_num_heads, dropout=attn_dropout, bias=False)

        # Attention used to align reference with phone encoder output
        q_in_dim = model_dim + speaker_embedding_dim + locale_embedding_dim
        self.align_attn = MultiheadAttention(
            model_dim,
            attn_num_heads,
            dropout=attn_dropout,
            bias=False,
            k_dim=attn_kv_dim,
            v_dim=attn_kv_dim,
            q_in_dim=q_in_dim,
            out_dim=out_dim if out_dim is not None else model_dim,
        )

    def forward(
        self,
        style_input,
        reference,
        speaker_embedding=None,
        locale_embedding=None,
        style_input_padding_mask=None,
        reference_padding_mask=None,
    ):
        # Process style input
        input_length = style_input.size(1)
        embeddings = [style_input]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, input_length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, input_length, -1))
        style_input = torch.cat(embeddings, dim=-1)

        # Process reference
        ref_length = reference.size(1)
        reference = self.positional_encoding(reference)
        # Only concat speaker embedding to align with t2t
        if speaker_embedding is not None:
            reference = torch.cat([reference, speaker_embedding.expand(-1, ref_length, -1)], dim=-1)
        # Stack of convolution layers
        reference = reference.permute(0, 2, 1)
        for layer in self.layers:
            reference = layer(reference)
        reference = reference.permute(0, 2, 1)
        # Self attention layer
        encoded_reference, _ = self.self_attn(reference, reference, reference, key_padding_mask=reference_padding_mask)
        # Align phone encoder output to reference to extract style info
        style_embedding, _ = self.align_attn(
            style_input, encoded_reference, encoded_reference, key_padding_mask=reference_padding_mask
        )

        if style_input_padding_mask is not None:
            mask = (~style_input_padding_mask).to(style_embedding.dtype)
            style_embedding = style_embedding * mask.unsqueeze(-1)

        return style_embedding


class StyleEmbeddingPredictor(nn.Module):
    def __init__(
        self, in_dim, out_dim, speaker_embedding_dim=128, locale_embedding_dim=128, gru_layers=2, gru_size=128
    ):
        super(StyleEmbeddingPredictor, self).__init__()
        self.rnn = nn.GRU(
            input_size=in_dim + speaker_embedding_dim + locale_embedding_dim,
            hidden_size=gru_size,
            num_layers=gru_layers,
            batch_first=True,
        )
        self.out_proj = nn.Linear(gru_size, out_dim)

    def forward(self, style_input, speaker_embedding=None, locale_embedding=None, mask=None):
        input_length = style_input.size(1)
        embeddings = [style_input]
        if speaker_embedding is not None:
            embeddings.append(speaker_embedding.expand(-1, input_length, -1))
        if locale_embedding is not None:
            embeddings.append(locale_embedding.expand(-1, input_length, -1))
        style_input = torch.cat(embeddings, dim=-1)

        style_embedding = self.out_proj(self.rnn(style_input)[0])

        if mask is not None:
            style_embedding = style_embedding * mask.to(style_embedding.dtype).unsqueeze(-1)

        return style_embedding


class FineGrainedLatentEncoder(nn.Module):
    def __init__(
        self,
        in_dim,
        model_dim=384,
        pos_encoding_dim=32,
        num_conv_layers=3,
        conv_kernel=5,
        conv_dropout=0.3,
        attn_num_heads=2,
        attn_dropout=0.1,
        attn_kv_dim=48,
        out_dim=None,
    ):
        super(FineGrainedLatentEncoder, self).__init__()
        self.positional_encoding = PositionalEncoding(pos_encoding_dim, mode="concat", dropout=0.0)
        self.layers = nn.ModuleList()
        for i in range(num_conv_layers):
            self.layers.append(
                nn.Conv1d(
                    in_dim if i == 0 else model_dim, model_dim, kernel_size=conv_kernel, padding=(conv_kernel - 1) // 2
                )
            )
            self.layers.append(nn.ReLU())
            self.layers.append(LayerNorm(model_dim, dim=1))
            self.layers.append(nn.Dropout(conv_dropout))

        # Self attention to encode reference
        self.self_attn = MultiheadAttention(model_dim, attn_num_heads, dropout=attn_dropout, bias=False)

        # Attention used to align reference with phone encoder output
        self.align_attn = MultiheadAttention(
            model_dim,
            attn_num_heads,
            dropout=attn_dropout,
            bias=False,
            k_dim=attn_kv_dim,
            v_dim=attn_kv_dim,
            q_in_dim=model_dim,
            out_dim=out_dim if out_dim is not None else model_dim,
        )

    def forward(self, inputs, reference, inputs_padding_mask=None, reference_padding_mask=None):
        # Stack of convolution layers
        reference = reference.permute(0, 2, 1)
        for layer in self.layers:
            reference = layer(reference)
        reference = reference.permute(0, 2, 1)
        # Self attention layer
        encoded_reference, _ = self.self_attn(reference, reference, reference, key_padding_mask=reference_padding_mask)

        # Align phone encoder output to reference to extract style info
        latents, _ = self.align_attn(
            inputs, encoded_reference, encoded_reference, key_padding_mask=reference_padding_mask
        )

        if inputs_padding_mask is not None:
            mask = (~inputs_padding_mask).to(latents.dtype)
            latents = latents * mask.unsqueeze(-1)

        return latents


class FineGrainedLatentPredictor(nn.Module):
    def __init__(self, in_dim, out_dim, gru_layers=2, gru_size=128):
        super(FineGrainedLatentPredictor, self).__init__()
        self.rnn = nn.GRU(input_size=in_dim, hidden_size=gru_size, num_layers=gru_layers, batch_first=True)
        self.out_proj = nn.Linear(gru_size, out_dim)

    def forward(self, x, mask=None):
        latents = self.out_proj(self.rnn(x)[0])

        if mask is not None:
            latents = latents * mask.to(latents.dtype).unsqueeze(-1)

        return latents

import torch.nn as nn
import torch.nn.functional as F


class StyleEmbedding(nn.Module):
    def __init__(self, style_table_size, embedding_dim):
        super(StyleEmbedding, self).__init__()
        self.embedding = nn.Embedding(style_table_size, embedding_dim)

    def forward(self, speaker_id):
        embedding = self.embedding(speaker_id)
        return embedding


class StyleEmbeddingV2(nn.Module):
    def __init__(self, style_table_size, embedding_dim, activation='softplus'):
        super().__init__()
        self.embedding = nn.Embedding(style_table_size, embedding_dim)
        self.linear = nn.Linear(embedding_dim, embedding_dim)
        self.activation = activation

    def forward(self, speaker_id):
        embedding = self.embedding(speaker_id)
        embedding = getattr(F, self.activation)(self.linear(embedding))
        return embedding

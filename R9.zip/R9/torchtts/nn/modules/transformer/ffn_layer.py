import torch.nn as nn
import torch.nn.functional as F

from torchtts.nn.modules.common import tpu_conv1d


def _get_activation_fn(activation):
    if activation == "relu":
        return F.relu
    elif activation == "gelu":
        return F.gelu

    raise RuntimeError("activation should be relu/gelu, not {}".format(activation))


class PositionWiseFeedForward(nn.Module):
    """Position-wise feed-forward networks

    Args:
         model_dim: the number of expected features in the input (required).
         ffn_dims: the dimension of the feedforward network model (list or .
         ffn_kernels: the kernel size of first conv1d.
         dropout: the dropout value (default=0.1).
         activation: the activation function of intermediate layer, relu or gelu (default=relu).
         t2t_compatible: whether to use tpu_conv1d to be compatible with t2t
    """

    def __init__(
        self, model_dim, ffn_dims, ffn_kernels, ffn_dilations=None, dropout=0.1, activation="relu", t2t_compatible=True
    ):
        super(PositionWiseFeedForward, self).__init__()

        if isinstance(ffn_dims, int):
            ffn_dims = [ffn_dims]

        if isinstance(ffn_kernels, int):
            ffn_kernels = [ffn_kernels]

        assert len(ffn_dims) == len(ffn_kernels), f"{len(ffn_dims)} != {len(ffn_kernels)}"

        if ffn_dilations is None:
            ffn_dilations = [1 for _ in range(len(ffn_dims))]

        assert len(ffn_dims) == len(ffn_dilations), f"{len(ffn_dims)} != {len(ffn_dilations)}"

        self.ffn_kernels = ffn_kernels

        self.layers = nn.ModuleList()
        for i in range(len(ffn_dims)):
            in_dim = model_dim if i == 0 else ffn_dims[i - 1]
            if t2t_compatible:
                self.layers.append(
                    tpu_conv1d.Conv1d(in_dim, ffn_dims[i], kernel_size=ffn_kernels[i], dilation=ffn_dilations[i])
                )
            else:
                kernel_size, dilation = ffn_kernels[i], ffn_dilations[i]
                padding = (kernel_size + (kernel_size - 1) * (dilation - 1) - 1) // 2
                self.layers.append(
                    nn.Conv1d(in_dim, ffn_dims[i], kernel_size=kernel_size, padding=padding, dilation=dilation)
                )

        self.dropout = nn.Dropout(dropout)
        self.activation = _get_activation_fn(activation)
        self.t2t_compatible = t2t_compatible

    def __setstate__(self, state):
        if "activation" not in state:
            state["activation"] = F.relu
        super(PositionWiseFeedForward, self).__setstate__(state)

    def forward(self, src, padding_mask=None):
        """Pass the input through the ffn layer.

        Args:
            src: the sequence to the encoder layer (required).
            padding_mask: mask used to ignore paddings.
        """
        if padding_mask is not None:
            src = src * (~padding_mask).unsqueeze(-1)

        if not self.t2t_compatible:
            src = src.transpose(1, 2)

        for i, layer in enumerate(self.layers):
            if i != 0:
                src = self.dropout(self.activation(src))
            src = layer(src)
            src = src * self.ffn_kernels[i] ** -0.5

        if not self.t2t_compatible:
            src = src.transpose(1, 2)

        if padding_mask is not None:
            src *= (~padding_mask).to(src.dtype).unsqueeze(-1)
        return src


class LinearPositionwiseFeedForward(nn.Module):
    """Linear Position-wise feed forward layer."""

    def __init__(self, idim, hidden_units, dropout):
        """Construct an PositionwiseFeedForward object."""
        super(LinearPositionwiseFeedForward, self).__init__()
        self.w_1 = nn.Linear(idim, hidden_units)
        self.w_2 = nn.Linear(hidden_units, idim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, src, padding_mask=None):
        """Forward function."""

        if padding_mask is not None:
            src *= (~padding_mask).to(src.dtype).unsqueeze(-1)

        src = self.w_2(self.dropout(F.relu(self.w_1(src))))

        if padding_mask is not None:
            src *= (~padding_mask).to(src.dtype).unsqueeze(-1)

        return src

import torch
import torch.nn as nn
import torch.nn.functional as F


def encoder_init(m):
    """Initialize encoder parameters."""
    if isinstance(m, torch.nn.Conv1d):
        torch.nn.init.xavier_uniform_(m.weight, torch.nn.init.calculate_gain("relu"))


class EncoderPrenet(nn.Module):
    def __init__(
        self,
        embed_dim=512,
        econv_layers=3,
        econv_chans=512,
        econv_filts=5,
        use_residual=False,
        use_layer_norm=False,
        dropout_rate=0.5,
    ):
        """Initialize Tacotron2 encoder module.

        Args:
            idim (int) Dimension of the inputs.
            embed_dim (int, optional) Dimension of character embedding.
            econv_layers (int, optional) The number of encoder conv layers.
            econv_filts (int, optional) The number of encoder conv filter size.
            econv_chans (int, optional) The number of encoder conv filter channels.
            use_residual (bool, optional) Whether to use residual connection.
            dropout_rate (float, optional) Dropout rate.

        """
        super(EncoderPrenet, self).__init__()
        self.use_residual = use_residual
        self.use_layer_norm = use_layer_norm

        # define network layer modules
        if econv_layers > 0:
            self.convs_enc_prenet = nn.ModuleList()
            if use_layer_norm:
                self.norms_enc_prenet = nn.ModuleList()
            self.relu_dropout_enc_prenet = nn.ModuleList()
            for layer in range(econv_layers):
                ichans = embed_dim if layer == 0 else econv_chans
                self.convs_enc_prenet += [
                    nn.Conv1d(ichans, econv_chans, econv_filts, stride=1, padding=(econv_filts - 1) // 2, bias=True)
                ]
                if use_layer_norm:
                    self.norms_enc_prenet += [nn.LayerNorm(econv_chans)]
                self.relu_dropout_enc_prenet += [nn.Sequential(nn.ReLU(), nn.Dropout(dropout_rate))]
        else:
            self.convs_enc_prenet = None

        self.linear_enc_prenet = nn.Linear(econv_chans, econv_chans)
        # special initialize
        self.apply(encoder_init)

    def forward(self, xs):
        """Calculate forward propagation.

        Args:
            xs (Tensor): Batch of the padded sequence of character ids (B, Tmax, embed_dim). Padded value should be 0.
            ilens (LongTensor): Batch of lengths of each input batch (B,).

        Returns:
            Tensor: Batch of the sequences of encoder states(B, Tmax, eunits).
            LongTensor: Batch of lengths of each sequence (B,)

        """
        if not self.use_layer_norm:
            xs = xs.transpose(1, 2)
        if self.convs_enc_prenet is not None:
            for i in range(len(self.convs_enc_prenet)):
                if self.use_residual:
                    if self.use_layer_norm:
                        xs += self.relu_dropout_enc_prenet[i](
                            self.norms_enc_prenet[i](self.convs_enc_prenet[i](xs.transpose(1, 2)).transpose(1, 2))
                        )
                    else:
                        xs += self.relu_dropout_enc_prenet[i](self.convs_enc_prenet[i](xs))
                else:
                    if self.use_layer_norm:
                        xs = self.relu_dropout_enc_prenet[i](
                            self.norms_enc_prenet[i](self.convs_enc_prenet[i](xs.transpose(1, 2)).transpose(1, 2))
                        )
                    else:
                        xs = self.relu_dropout_enc_prenet[i](self.convs_enc_prenet[i](xs))
        return self.linear_enc_prenet(xs) if self.use_residual else self.linear_enc_prenet(xs.transpose(1, 2))


class DecoderPrenet(nn.Module):
    def __init__(self, idim, n_layers=2, model_dim=256, dropout_rate=0.5):
        """Initialize prenet module.

        Args:
            idim (int): Dimension of the inputs.
            odim (int): Dimension of the outputs.
            n_layers (int, optional): The number of prenet layers.
            model_dim (int, optional): The number of prenet units.

        """
        super(DecoderPrenet, self).__init__()
        self.dropout_rate = dropout_rate
        self.prenet = nn.ModuleList()
        for layer in range(n_layers):
            n_inputs = idim if layer == 0 else model_dim
            self.prenet += [nn.Sequential(nn.Linear(n_inputs, model_dim), nn.ReLU())]
        self.linear_dec_prenet = nn.Linear(model_dim, model_dim)

    def forward(self, x):
        """Calculate forward propagation.

        Args:
            x (Tensor): Batch of input tensors (B, ..., idim).

        Returns:
            Tensor: Batch of output tensors (B, ..., odim).

        """
        for i in range(len(self.prenet)):
            x = F.dropout(self.prenet[i](x), self.dropout_rate)
        return self.linear_dec_prenet(x)


class Postnet(nn.Module):
    """Postnet module for Spectrogram prediction network.

    This is a module of Postnet in Spectrogram prediction network, which described in `Natural TTS Synthesis by
    Conditioning WaveNet on Mel Spectrogram Predictions`_. The Postnet predicts refines the predicted
    Mel-filterbank of the decoder, which helps to compensate the detail sturcture of spectrogram.

    .. _`Natural TTS Synthesis by Conditioning WaveNet on Mel Spectrogram Predictions`:
       https://arxiv.org/abs/1712.05884

    """

    def __init__(self, idim, odim, n_layers=5, n_chans=512, n_filts=5, dropout_rate=0.5, use_batch_norm=True):
        """Initialize postnet module.

        Args:
            idim (int): Dimension of the inputs.
            odim (int): Dimension of the outputs.
            n_layers (int, optional): The number of layers.
            n_filts (int, optional): The number of filter size.
            n_units (int, optional): The number of filter channels.
            use_batch_norm (bool, optional): Whether to use batch normalization..
            dropout_rate (float, optional): Dropout rate..

        """
        super(Postnet, self).__init__()
        self.postnet = nn.ModuleList()
        for layer in range(n_layers - 1):
            ichans = odim if layer == 0 else n_chans
            ochans = odim if layer == n_layers - 1 else n_chans
            if use_batch_norm:
                self.postnet += [
                    nn.Sequential(
                        nn.Conv1d(ichans, ochans, n_filts, stride=1, padding=(n_filts - 1) // 2, bias=False),
                        nn.BatchNorm1d(ochans),
                        nn.Tanh(),
                        nn.Dropout(dropout_rate),
                    )
                ]
            else:
                self.postnet += [
                    nn.Sequential(
                        nn.Conv1d(ichans, ochans, n_filts, stride=1, padding=(n_filts - 1) // 2, bias=False),
                        nn.Tanh(),
                        nn.Dropout(dropout_rate),
                    )
                ]
        ichans = n_chans if n_layers != 1 else odim
        if use_batch_norm:
            self.postnet += [
                nn.Sequential(
                    nn.Conv1d(ichans, odim, n_filts, stride=1, padding=(n_filts - 1) // 2, bias=False),
                    nn.BatchNorm1d(odim),
                    nn.Dropout(dropout_rate),
                )
            ]
        else:
            self.postnet += [
                nn.Sequential(
                    nn.Conv1d(ichans, odim, n_filts, stride=1, padding=(n_filts - 1) // 2, bias=False),
                    nn.Dropout(dropout_rate),
                )
            ]

    def forward(self, xs):
        """Calculate forward propagation.

        Args:
            xs (Tensor): Batch of the sequences of padded input tensors (B, idim, Tmax).

        Returns:
            Tensor: Batch of padded output tensor. (B, odim, Tmax).

        """
        for i in range(len(self.postnet)):
            xs = self.postnet[i](xs)
        return xs

import copy
from typing import Optional

import torch
import torch.nn as nn
from torch import Tensor

from torchtts.nn.modules.attention import MultiheadAttention
from torchtts.nn.modules.transformer.ffn_layer import PositionWiseFeedForward


class TransformerDecoderLayer(nn.Module):
    """TransformerDecoderLayer is made up of self-attn and feedforward network.

    Args:
        model_dim: the number of expected features in the input (required).
        num_heads: the number of heads in the multiheadattention models (required).
        ffn_dims: the dimension of the feedforward network model (default=2048).
        ffn_kernels: the kernel size of conv1d in feedforward network model.
        dropout: the dropout value (default=0.1).
        activation: the activation function of intermediate layer, relu or gelu (default=relu)

    Note:
        This version use Pre-LN implementation.
    """

    def __init__(
        self,
        model_dim,
        num_heads,
        ffn_dims,
        ffn_kernels,
        ffn_dilations=None,
        t2t_compatible=True,
        dropout=0.1,
        activation="relu",
    ):
        super(TransformerDecoderLayer, self).__init__()
        self.norm1 = nn.LayerNorm(model_dim)
        self.self_attn = MultiheadAttention(model_dim, num_heads, dropout=dropout, bias=False)
        self.cross_attn = MultiheadAttention(model_dim, num_heads, dropout=dropout, bias=False)
        self.dropout1 = nn.Dropout(dropout)

        self.norm2 = nn.LayerNorm(model_dim)

        self.ffn = PositionWiseFeedForward(
            model_dim,
            ffn_dims=ffn_dims,
            ffn_kernels=ffn_kernels,
            ffn_dilations=ffn_dilations,
            dropout=dropout,
            activation=activation,
            t2t_compatible=t2t_compatible,
        )

        self.dropout2 = nn.Dropout(dropout)
        self.norm3 = nn.LayerNorm(model_dim)
        self.dropout3 = nn.Dropout(dropout)
        self.model_dim = model_dim

    def forward(
        self,
        src,
        mels,
        attn_mask=None,
        src_key_padding_mask=None,
        mel_tril_mask=None,
        mel_mask=None,
        cache=None,
        attention_constrain=False,
    ):
        """Pass the input through the encoder layer.

        Args:
            src: the sequence to the decoder (required).
            attn_mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).
            mel_tril_mask: the mask for the autoregressive casuality (required).
            mel_mask: the mask for the target sequence (optional).
            cache: cache value for the infenece (required).
            attention_constrain: attention constrain for the inference (optional).
        """
        residual = mels
        mels_norm1 = self.norm1(mels)

        if cache is None:
            mels_q_norm1 = mels_norm1
            mels_q_mask = mel_tril_mask
        else:
            # compute only the last frame query keeping dim: max_time_out -> 1
            assert cache.shape == (
                mels.shape[0],
                mels.shape[1] - 1,
                self.model_dim,
            ), f"{cache.shape} == {(mels.shape[0], mels.shape[1] - 1, self.model_dim)}"
            mels_q_norm1 = mels_norm1[:, -1:, :]
            residual = residual[:, -1:, :]
            mels_q_mask = None
            if mel_tril_mask is not None:
                mels_q_mask = mel_tril_mask[:, -1:, :]

        mels_self, _ = self.self_attn(
            mels_q_norm1, mels_norm1, mels_norm1, attn_mask=mels_q_mask, key_padding_mask=None
        )
        mels_self = residual + self.dropout1(mels_self)

        residual = mels_self
        mels_norm2 = self.norm2(mels_self)
        mels_cross, attn_cross = self.cross_attn(
            mels_norm2,
            src,
            src,
            attn_mask=attn_mask,
            key_padding_mask=src_key_padding_mask,
            attention_constrain=attention_constrain,
        )
        mels_cross = residual + self.dropout2(mels_cross)

        residual = mels_cross
        mels_norm3 = self.norm3(mels_cross)

        mels_ffn = self.ffn(mels_norm3, padding_mask=mel_mask)
        mels_ffn = residual + self.dropout3(mels_ffn)

        if cache is not None:
            mels_ffn = torch.cat([cache, mels_ffn], dim=1)

        return mels_ffn, attn_cross


class TransformerDecoder(nn.Module):
    r"""TransformerDecoder is a stack of N decoder layers

    Args:
        decoder_layer: an instance of the TransformerDecoderLayer() class (required).
        num_layers: the number of sub-decoder-layers in the decoder (required).
        norm: the layer normalization component (optional).
    """

    def __init__(self, decoder_layer, num_layers, norm=None):
        super(TransformerDecoder, self).__init__()
        self.layers = _get_clones(decoder_layer, num_layers)
        self.num_layers = num_layers
        self.norm = norm

    def forward(
        self,
        src: Tensor,
        mels: Tensor,
        attn_mask: Optional[Tensor] = None,
        src_key_padding_mask: Optional[Tensor] = None,
        mel_tril_mask: Optional[Tensor] = None,
        mel_mask: Optional[Tensor] = None,
    ) -> Tensor:
        r"""Pass the input through the decoder layers in turn.

        Args:
            src: the sequence to the decoder (required).
            attn_mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).
            mel_tril_mask: the mask for the autoregressive casuality (required).
            mel_mask: the mask for the target sequence (optional).

        Shape:
            see the docs in Transformer class.
        """
        output = mels
        attn_cross_list = []

        for mod in self.layers:
            output, attn_cross = mod(
                src,
                output,
                attn_mask=attn_mask,
                src_key_padding_mask=src_key_padding_mask,
                mel_tril_mask=mel_tril_mask,
                mel_mask=mel_mask,
            )
            attn_cross_list.append(attn_cross)  # [(B, H, T_out, T_in),...]

        if self.norm is not None:
            output = self.norm(output)

        return output, attn_cross_list

    def inference(
        self,
        src: Tensor,
        mels: Tensor,
        attn_mask: Optional[Tensor] = None,
        src_key_padding_mask: Optional[Tensor] = None,
        mel_tril_mask: Optional[Tensor] = None,
        mel_mask: Optional[Tensor] = None,
        cache: Optional[Tensor] = None,
        attention_constrain: Optional[bool] = False,
    ) -> Tensor:
        """Forward one step."""
        output = mels

        if cache is None:
            cache = self.init_state()
        new_cache = []

        for c, mod in zip(cache, self.layers):
            output, _ = mod(
                src,
                output,
                attn_mask=attn_mask,
                src_key_padding_mask=src_key_padding_mask,
                mel_tril_mask=mel_tril_mask,
                mel_mask=mel_mask,
                cache=c,
                attention_constrain=attention_constrain,
            )
            new_cache.append(output)

        if self.norm is not None:
            y = self.norm(output)[:, -1]
        else:
            y = output[:, -1]
        return y, new_cache

    def init_state(self):
        """Get an initial state for decoding."""
        return [None for i in range(len(self.layers))]  # [None,None,None,None,None,None]


def _get_clones(module, n):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(n)])

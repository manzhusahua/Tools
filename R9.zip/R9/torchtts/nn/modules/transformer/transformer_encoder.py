import copy
from typing import Optional

import torch.nn as nn
from torch import Tensor

from torchtts.nn.modules.attention import MultiheadAttention
from torchtts.nn.modules.common import LayerNorm
from torchtts.nn.modules.transformer.ffn_layer import PositionWiseFeedForward
from torchtts.utils.import_utils import _FMOE_AVAILABLE

if _FMOE_AVAILABLE:
    from fmoe.transformer import FMoETransformerMLP


class TransformerEncoderLayer(nn.Module):
    """TransformerEncoderLayer is made up of self-attn and feedforward network.

    Args:
        model_dim: the number of expected features in the input (required).
        num_heads: the number of heads in the multiheadattention models (required).
        ffn_dims: the dimension of the feedforward network model (default=2048).
        ffn_kernels: the kernel size of conv1d in feedforward network model.
        t2t_compatible: whether to use tpu_conv1d in ffn to be compatible with t2t.
        dropout: the dropout value (default=0.1).
        activation: the activation function of intermediate layer, relu or gelu (default=relu)

    Note:
        This version use Pre-LN implementation.
    """

    def __init__(
        self,
        model_dim,
        num_heads,
        ffn_dims,
        ffn_kernels,
        ffn_dilations=None,
        t2t_compatible=True,
        dropout=0.1,
        activation="relu",
        layer_norm_condition_dim=-1,
        enable_fmoe=False,
        fmoe_num_expert=64,
        fmoe_hidden_dim=1024,
        fmoe_top_k=2,
    ):
        super(TransformerEncoderLayer, self).__init__()
        self.norm1 = LayerNorm(model_dim, condition_dim=layer_norm_condition_dim)
        self.self_attn = MultiheadAttention(model_dim, num_heads, dropout=dropout, bias=False)
        self.dropout1 = nn.Dropout(dropout)

        self.norm2 = LayerNorm(model_dim, condition_dim=layer_norm_condition_dim)
        self.enable_fmoe = enable_fmoe

        if not enable_fmoe:
            self.ffn = PositionWiseFeedForward(
                model_dim,
                ffn_dims=ffn_dims,
                ffn_kernels=ffn_kernels,
                ffn_dilations=ffn_dilations,
                dropout=dropout,
                activation=activation,
                t2t_compatible=t2t_compatible,
            )
        else:
            self.ffn = FMoETransformerMLP(
                num_expert=fmoe_num_expert,
                d_model=model_dim,
                d_hidden=fmoe_hidden_dim,
                top_k=fmoe_top_k,
                dropout=dropout,
            )

        self.dropout2 = nn.Dropout(dropout)

    def forward(self, src, layer_norm_condition=None, attn_mask=None, src_key_padding_mask=None, gating_features=None):
        """Pass the input through the encoder layer.

        Args:
            src: the sequence to the encoder layer (required).
            layer_norm_condition: the condition to predict weight and bias of layer norm (optional).
            attn_mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).
        """
        residual = src
        src_norm1 = self.norm1(src, condition=layer_norm_condition)
        src_self, _ = self.self_attn(
            src_norm1, src_norm1, src_norm1, attn_mask=attn_mask, key_padding_mask=src_key_padding_mask
        )
        src_self = residual + self.dropout1(src_self)

        residual = src_self
        src_norm2 = self.norm2(src_self, condition=layer_norm_condition)

        if not self.enable_fmoe:
            src_ffn = self.ffn(src_norm2, padding_mask=src_key_padding_mask)
        else:
            src_ffn = self.ffn(src_norm2, gating_features)
        src_ffn = residual + self.dropout2(src_ffn)
        return src_ffn


class TransformerEncoder(nn.Module):
    r"""TransformerEncoder is a stack of N encoder layers

    Args:
        encoder_layer: an instance of the TransformerEncoderLayer() class (required).
        num_layers: the number of sub-encoder-layers in the encoder (required).
        norm: the layer normalization component (optional).
    """

    def __init__(self, encoder_layer, num_layers, norm=None):
        super(TransformerEncoder, self).__init__()
        self.layers = _get_clones(encoder_layer, num_layers)
        self.num_layers = num_layers
        self.norm = norm

    def forward(
        self,
        src: Tensor,
        layer_norm_condition: Tensor = None,
        attn_mask: Optional[Tensor] = None,
        src_key_padding_mask: Optional[Tensor] = None,
        gating_features: Optional[Tensor] = None,
    ) -> Tensor:
        r"""Pass the input through the encoder layers in turn.

        Args:
            src: the sequence to the encoder (required).
            layer_norm_condition: the condition to predict weight and bias of layer norm (optional).
            attn_mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).

        Shape:
            see the docs in Transformer class.
        """
        output = src

        for mod in self.layers:
            output = mod(
                output,
                layer_norm_condition=layer_norm_condition,
                attn_mask=attn_mask,
                src_key_padding_mask=src_key_padding_mask,
                gating_features=gating_features,
            )

        if self.norm is not None:
            output = self.norm(output, condition=layer_norm_condition)

        return output


def _get_clones(module, n):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(n)])

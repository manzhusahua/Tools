import copy
from torch import Tensor
from typing import Optional
import torch.nn as nn

from torchtts.nn.modules.attention import MultiheadAttention
from torchtts.nn.modules.common import LayerNorm
from torchtts.nn.modules.transformer.ffn_layer import PositionWiseFeedForward
from torchtts.nn.modules.soft_dtw.learned_upsampling import SoftLengthRegulator


class TransformerSoftEncoderLayer(nn.Module):
    """TransformerEncoderLayer is made up of self-attn and feedforward network.

    Args:
        model_dim: the number of expected features in the input (required).
        num_heads: the number of heads in the multiheadattention models (required).
        ffn_dims: the dimension of the feedforward network model (default=2048).
        ffn_kernels: the kernel size of conv1d in feedforward network model.
        t2t_compatible: whether to use tpu_conv1d in ffn to be compatible with t2t.
        dropout: the dropout value (default=0.1).
        activation: the activation function of intermediate layer, relu or gelu (default=relu)

    Note:
        This version use Pre-LN implementation.
    """

    def __init__(
        self,
        model_dim,
        num_heads,
        ffn_dims,
        ffn_kernels,
        ffn_dilations=None,
        t2t_compatible=True,
        dropout=0.1,
        activation="relu",
        layer_norm_condition_dim=-1,
        enable_soft_dtw=False,
    ):
        super(TransformerSoftEncoderLayer, self).__init__()
        self.norm1 = LayerNorm(model_dim, condition_dim=layer_norm_condition_dim)
        self.self_attn = MultiheadAttention(model_dim, num_heads, dropout=dropout, bias=False)
        self.dropout1 = nn.Dropout(dropout)

        self.norm2 = LayerNorm(model_dim, condition_dim=layer_norm_condition_dim)

        self.ffn = PositionWiseFeedForward(
            model_dim,
            ffn_dims=ffn_dims,
            ffn_kernels=ffn_kernels,
            ffn_dilations=ffn_dilations,
            dropout=dropout,
            activation=activation,
            t2t_compatible=t2t_compatible,
        )

        self.dropout2 = nn.Dropout(dropout)

        if enable_soft_dtw:
            self.soft_lengthregulator = SoftLengthRegulator(
                in_dim=model_dim,
                num_heads=num_heads,
                ffn_dims=ffn_dims,
                enc_ffn_kernels=ffn_kernels,
                enc_ffn_dilations=ffn_dilations,
                t2t_compatible=t2t_compatible,
                dropout=dropout,
                cond_dim=layer_norm_condition_dim,
            )
            self.dropout3 = nn.Dropout(dropout)

        self.enable_soft_dtw = enable_soft_dtw

    def forward(
        self,
        src,
        encoder_output=None,
        layer_norm_condition=None,
        attn_mask=None,
        src_key_padding_mask=None,
        phs_mask=None,
        speaking_rate=None,
        tgt_length=None,
    ):
        """Pass the input through the encoder layer.

        Args:
            src: the sequence to the encoder layer (required).
            layer_norm_condition: the condition to predict weight and bias of layer norm (optional).
            attn_mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).
        """
        residual = src
        src_norm1 = self.norm1(src, condition=layer_norm_condition)
        src_self, _ = self.self_attn(
            src_norm1, src_norm1, src_norm1, attn_mask=attn_mask, key_padding_mask=src_key_padding_mask
        )
        src_self = residual + self.dropout1(src_self)

        if self.enable_soft_dtw:
            residual = src_self
            src_soft, pred_dur, cross_attention = self.soft_lengthregulator(
                encoder_output,
                phs_mask=phs_mask,
                speaking_rate=speaking_rate,
                layer_norm_condition=layer_norm_condition,
                total_duration_groundtruth=tgt_length,
            )
            src_soft = residual + self.dropout3(src_soft)
            residual = src_soft
            src_norm2 = self.norm2(src_soft, condition=layer_norm_condition)
        else:
            residual = src_self
            src_norm2 = self.norm2(src_self, condition=layer_norm_condition)

        src_ffn = self.ffn(src_norm2, padding_mask=src_key_padding_mask)
        src_ffn = residual + self.dropout2(src_ffn)

        if self.enable_soft_dtw:
            return src_ffn, pred_dur, cross_attention
        else:
            return src_ffn


class TransformerSoftEncoder(nn.Module):
    r"""TransformerEncoder is a stack of N encoder layers

    Args:
        encoder_layer: an instance of the TransformerEncoderLayer() class (required).
        num_layers: the number of sub-encoder-layers in the encoder (required).
        norm: the layer normalization component (optional).
    """

    def __init__(self, encoder_layer, num_layers, norm=None, enable_soft_dtw=False):
        super(TransformerSoftEncoder, self).__init__()
        self.layers = _get_clones(encoder_layer, num_layers)
        self.num_layers = num_layers
        self.norm = norm
        self.enable_soft_dtw = enable_soft_dtw

    def forward(
        self,
        src: Tensor,
        layer_norm_condition: Tensor = None,
        attn_mask: Optional[Tensor] = None,
        src_key_padding_mask: Optional[Tensor] = None,
        phs_mask: Optional[Tensor] = None,
        speaking_rate: Optional[Tensor] = None,
        tgt_length: Optional[Tensor] = None,
        encoder_output: Optional[Tensor] = None,
    ) -> Tensor:
        r"""Pass the input through the encoder layers in turn.

        Args:
            src: the sequence to the encoder (required).
            layer_norm_condition: the condition to predict weight and bias of layer norm (optional).
            attn_mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).

        Shape:
            see the docs in Transformer class.
        """
        pred_dur_list = []
        cross_attention_list = []
        output = src

        for mod in self.layers:
            if self.enable_soft_dtw:
                output, pred_dur, cross_attention = mod(
                    output,
                    layer_norm_condition=layer_norm_condition,
                    attn_mask=attn_mask,
                    src_key_padding_mask=src_key_padding_mask,
                    phs_mask=phs_mask,
                    speaking_rate=speaking_rate,
                    tgt_length=tgt_length,
                    encoder_output=encoder_output,
                )

                pred_dur_list.append(pred_dur)
                cross_attention_list.append(cross_attention)
            else:
                output = mod(
                    output,
                    layer_norm_condition=layer_norm_condition,
                    attn_mask=attn_mask,
                    src_key_padding_mask=src_key_padding_mask,
                )

        if self.norm is not None:
            output = self.norm(output, condition=layer_norm_condition)

        if self.enable_soft_dtw:
            return output, pred_dur_list, cross_attention_list
        else:
            return output


def _get_clones(module, n):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(n)])

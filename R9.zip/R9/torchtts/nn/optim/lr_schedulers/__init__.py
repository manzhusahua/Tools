from torchtts.nn.optim.lr_schedulers.exponitial_decay import ExponitialDecayLR
from torchtts.nn.optim.lr_schedulers.noam import TacotronNoamLR
from torchtts.nn.optim.lr_schedulers.noam import NoamLR
from torchtts.nn.optim.lr_schedulers.polynomial_decay import PolynomialDecayLR
from torchtts.nn.optim.lr_schedulers.power import PowerLR, TwoStepsLR

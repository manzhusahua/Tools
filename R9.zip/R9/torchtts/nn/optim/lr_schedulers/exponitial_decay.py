import warnings

from torch.optim.lr_scheduler import _LRScheduler


class ExponitialDecayLR(_LRScheduler):
    """Learning rate schedule.

    This corresponds to increasing the learning rate linearly for the first `warmup_steps`
    training steps, and decreasing it thereafter proportionally to the inverse square
    root of the step number, scaled by the inverse square root of the dimensionality of
    the model.
    """

    def __init__(
        self,
        optimizer,
        initial_lr=0.001,
        decay_rate=0.825,
        decay_steps=4000,
        last_epoch=-1,
        verbose=False,
        min_lr=0.00001,
    ):
        self.warmup_steps = decay_steps
        self.initial_lr = initial_lr
        self.decay_rate = decay_rate
        self.decay_steps = decay_steps
        self.min_lr = min_lr
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        if not self._get_lr_called_within_step:
            warnings.warn(
                "To get the last learning rate computed by the scheduler, " "please use `get_last_lr()`.", UserWarning
            )

        step = max(self.last_epoch, 1)

        if step <= self.warmup_steps:
            lr = self.initial_lr * step / self.warmup_steps
        else:
            decayed_learning_rate = self.initial_lr * self.decay_rate ** (step / self.decay_steps)
            lr = max(self.min_lr, decayed_learning_rate)

        return [lr for _ in self.optimizer.param_groups]

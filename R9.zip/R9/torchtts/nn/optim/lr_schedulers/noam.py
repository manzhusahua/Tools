import warnings

from torch.optim.lr_scheduler import _LRScheduler


class NoamLR(_LRScheduler):
    """Noam Learning rate schedule.

    This corresponds to increasing the learning rate linearly for the first `warmup_steps`
    training steps, and decreasing it thereafter proportionally to the inverse square
    root of the step number, scaled by the inverse square root of the dimensionality of
    the model.
    """

    def __init__(self, optimizer, model_size, warmup_steps, factor=1.0, last_epoch=-1, verbose=False):
        self.warmup_steps = warmup_steps
        self.factor = factor
        self.model_size = model_size
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        if not self._get_lr_called_within_step:
            warnings.warn(
                "To get the last learning rate computed by the scheduler, " "please use `get_last_lr()`.", UserWarning
            )

        step = max(self.last_epoch, 1)
        scale = self.factor * (self.model_size ** (-0.5) * min(step ** (-0.5), step * self.warmup_steps ** (-1.5)))
        return [scale for _ in self.optimizer.param_groups]


class TacotronNoamLR(_LRScheduler):
    """Noam Learning rate schedule
    Based on: https://github.com/keithito/tacotron/blob/d26c763342518d4e432e9c4036a1aff3b4fdaa1e/models/tacotron.py#L150

    The version of noam learning rate's highest value is constant.
    0 ~ warmup_steps, the lr will go to init_lr linearly,
    and after warmup_steps, lr will decay like norm noam lr decay.
    """

    def __init__(self, optimizer, warmup_steps, init_lr=2e-3, last_epoch=-1, verbose=False):
        self.init_lr = init_lr
        self.warmup_steps = warmup_steps
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        if not self._get_lr_called_within_step:
            warnings.warn(
                "To get the last learning rate computed by the scheduler, " "please use `get_last_lr()`.", UserWarning
            )

        step = max(self.last_epoch, 1)
        scale = self.init_lr * self.warmup_steps**0.5 * min(step ** (-0.5), step * self.warmup_steps ** (-1.5))

        return [scale for _ in self.optimizer.param_groups]

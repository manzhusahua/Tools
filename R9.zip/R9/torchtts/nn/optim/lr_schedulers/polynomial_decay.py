import warnings

from torch.optim.lr_scheduler import _LRScheduler


class PolynomialDecayLR(_LRScheduler):
    """Polynomial decay learning rate scheduler with warmup.

    Create a schedule with a learning rate that decreases as a polynomial decay from the initial lr set in the
    optimizer to end lr defined by `lr_end`, after a warmup period during which it increases linearly from 0 to the
    initial lr set in the optimizer.

    Note: `power` defaults to 1.0 which is based on the original BERT implementation
    """

    def __init__(
        self, optimizer, num_warmup_steps, num_training_steps, lr_end=1e-7, power=1.0, last_epoch=-1, verbose=False
    ):
        lr_init = optimizer.defaults["lr"]
        assert lr_init > lr_end, f"lr_end ({lr_end}) must be be smaller than initial lr ({lr_init})"

        self.num_warmup_steps = num_warmup_steps
        self.num_training_steps = num_training_steps
        self.lr_init = lr_init
        self.lr_end = lr_end
        self.power = power
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        if not self._get_lr_called_within_step:
            warnings.warn(
                "To get the last learning rate computed by the scheduler, " "please use `get_last_lr()`.", UserWarning
            )

        if self.last_epoch < self.num_warmup_steps:
            return [self.lr_init * self.last_epoch / max(1, self.num_warmup_steps) for _ in self.optimizer.param_groups]
        elif self.last_epoch > self.num_training_steps:
            return [self.lr_end for _ in self.optimizer.param_groups]
        else:
            lr_range = self.lr_init - self.lr_end
            decay_steps = self.num_training_steps - self.num_warmup_steps
            pct_remaining = 1 - (self.last_epoch - self.num_warmup_steps) / decay_steps
            decay = lr_range * pct_remaining**self.power + self.lr_end
            return [decay for _ in self.optimizer.param_groups]

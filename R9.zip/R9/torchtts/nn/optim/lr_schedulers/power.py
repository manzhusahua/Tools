import numpy as np
import warnings

from torch.optim.lr_scheduler import _LRScheduler


class PowerLR(_LRScheduler):
    def __init__(
            self, optimizer, start_step=0, decay_step=100000, gamma=0.5, min_lr=1e-6, last_epoch=-1, verbose=False
    ):
        self.start_step = start_step
        self.decay_step = decay_step
        self.gamma = gamma
        self.min_lr = min_lr

        self.base_lrs = list(map(lambda group: group["lr"], optimizer.param_groups))
        super().__init__(optimizer, last_epoch, verbose)

    def get_lr(self):
        if not self._get_lr_called_within_step:
            warnings.warn(
                "To get the last learning rate computed by the scheduler, " "please use `get_last_lr()`.", UserWarning
            )

        step = max(self.last_epoch, 1)

        if step < self.start_step:
            return self.base_lrs
        else:
            return [
                max(base_lr * np.power(self.gamma, (step - self.start_step) / self.decay_step), self.min_lr)
                for base_lr in self.base_lrs
            ]


class TwoStepsLR(_LRScheduler):

    def __init__(self, optimizer, start_step=0, gamma=0.5, decay_step=10000, min_lr=1e-6):
        self.optimizer = optimizer
        self.start_step = start_step
        self.decay_step = decay_step
        self.gamma = gamma
        self.scale = 0.1

        self.base_lrs = list(map(lambda group: group['lr'], optimizer.param_groups))
        # super().__init__(optimizer)

    def get_lr(self, cur_step):
        if cur_step < self.start_step:
            lr = []
            for base_lr in self.base_lrs:
                lr.append(base_lr)
            return lr
        else:
            return [base_lr * self.scale for base_lr in self.base_lrs]

    def step(self, cur_step):
        for param_group, lr in zip(self.optimizer.param_groups, self.get_lr(cur_step)):
            param_group['lr'] = lr

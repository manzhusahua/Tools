import logging
from abc import ABC
from abc import abstractmethod
from typing import Optional

import torch
from torch.utils.tensorboard import SummaryWriter

from torchtts import clusters
from torchtts import engines
from torchtts.hooks import CheckpointHook
from torchtts.hooks import ConsoleLogger
from torchtts.hooks import MetricResetHook
from torchtts.hooks import SetEpochForDataPipelineHook
from torchtts.hooks import StepCounterHook
from torchtts.hooks import StopAtStepOrEpochHook
from torchtts.hooks import TensorboardLogger
from torchtts.hooks import TimerHook
from torchtts.hooks import ValidationHook
from torchtts.nn.metrics import Mean
from torchtts.utils.hook_utils import check_hooks_type
from torchtts.utils.hook_utils import select_hooks_by_node
from torchtts.utils.hook_utils import sort_hooks_by_order
from torchtts.utils.torch_utils import recursive_detach

logger = logging.getLogger(__name__)


class Trainer(ABC):
    def __init__(
        self,
        device="cuda",
        use_amp=False,
        dist_config=None,
        save_path=None,
        save_interval=1000,
        log_interval=100,
        warm_start_from=None,
        reset_trainer=False,
        parameter_list=None,
        **kwargs,
    ):
        self.log_interval = log_interval
        self.save_path = save_path
        self.save_interval = save_interval
        self.warm_start_from = warm_start_from
        self.reset_trainer = reset_trainer
        self.parameter_list = parameter_list

        self.dataloader = None
        self.cv_dataloader = None
        self.model = None
        self.hooks = None

        self.criteria = None
        self.optimizers = None
        self.lr_schedulers = None

        self.metrics = None
        self.cv_metrics = None

        self.logs = None
        self.cv_logs = None

        self.tensorboard_writer = None

        # Extra storage reserved for internal usage
        self.extra_states = {}

        # Initial states of trainer
        self.global_steps = 0
        self.steps = 0
        self.epochs = 0
        self.should_stop = False

        self.exception = None
        self.should_raise_exception = True

        if dist_config is not None and dist_config["type"] != "none":
            self.cluster_env = self._choose_cluster(dist_config["cluster_type"])
            self.engine = engines.DistributedDeviceEngine(
                device=device,
                rank=self.cluster_env.rank,
                local_rank=self.cluster_env.local_rank,
                world_size=self.cluster_env.world_size,
                address=self.cluster_env.master_address,
                port=self.cluster_env.master_port,
                dist_config=dist_config,
                use_amp=use_amp,
                **kwargs,
            )
        else:
            self.engine = engines.DeviceEngine(device, use_amp, **kwargs)

        # Setup engine for training
        logger.info(f"Select engine: {self.engine}")
        self.engine.setup()

        self._config = kwargs

    def train(self, model, dataloader, cv_dataloader=None, max_steps=None, max_epochs=None, hooks=None):
        if max_steps is not None and max_epochs is not None:
            raise ValueError("Can not provide both max_steps and max_epochs.")
        if max_steps is not None and max_steps <= 0:
            raise ValueError("Must specify max_steps > 0, given: {}".format(max_steps))
        if max_epochs is not None and max_epochs <= 0:
            raise ValueError("Must specify max_epochs > 0, given: {}".format(max_epochs))

        # Save dataloader to trainer
        self.dataloader = dataloader
        self.cv_dataloader = cv_dataloader

        # Setup model
        self.model = self.engine.setup_model(model)

        # Setup optimizers
        self.optimizers = self.configure_optimizers()
        # Wrap optimizer with different distributed method
        self.model, self.optimizers = self.engine.setup_optimizer(self.model, self.optimizers)
        # Setup lr schedulers
        self.lr_schedulers = self.configure_lr_schedulers()

        # Setup training criteria
        self.criteria = self.engine.to_device(self.configure_criteria())

        # Setup metrics
        self.metrics = self.configure_metrics()
        self.cv_metrics = self.configure_cv_metrics()
        # We set the default metrics if user doesn't provide any.
        if self.metrics is None and self.criteria is not None:
            if isinstance(self.criteria, dict):
                self.metrics = {k: Mean() for k, v in self.criteria.items()}
                # Add metric for the loss item
                self.metrics["loss"] = Mean()
            else:
                self.metrics = Mean()
        self.engine.to_device(self.metrics)

        # Setup tensorboard writers used by hook and maybe trainers for visualization
        self.tensorboard_writer = SummaryWriter(".")

        # Setup training hooks
        self.hooks = check_hooks_type(hooks)

        default_hooks = [
            # Add a hook for stop training at max_steps or max_epochs
            *self._convert_steps_or_epochs_to_hooks(max_steps, max_epochs),
            # Add a hook for count steps and epochs
            StepCounterHook(),
            # Add a hook for setting epochs for data pipeline
            SetEpochForDataPipelineHook(),
            # Add a hook for validation
            ValidationHook(self.save_interval),
            # Add a hook for timing
            TimerHook(),
            # Add a hook for logging to console
            ConsoleLogger(self.log_interval, self.save_interval),
            # Add a hook for logging to tensorboard
            TensorboardLogger(self.log_interval, self.save_interval, self.tensorboard_writer),
            # Add a hook for metric resetting
            MetricResetHook(self.log_interval, self.save_interval, False),
            # Add a hook for checkpoint saving
            CheckpointHook(
                self.save_path, self.save_interval, self.warm_start_from, self.reset_trainer, self.parameter_list
            ),
        ]

        # Add default hooks.
        self.hooks.extend(default_hooks)
        # Add custom training hooks.
        self.hooks.extend(self.train_hooks())

        # Convert hooks to OrderedDict ordered by HookOrder
        self.hooks = sort_hooks_by_order(self.hooks)
        # Select hooks by node (rank)
        self.hooks = select_hooks_by_node(self.hooks)

        self._run_train()

    def _run_train(self):
        try:
            self._fire_event("on_start")
            while True:
                self._run_epoch()
                if self.should_stop:
                    self.should_stop = False
                    break
            self._fire_event("on_end")
        except (Exception, KeyboardInterrupt) as ex:
            self.exception = ex
            self._fire_event("on_exception")
            if self.should_raise_exception:
                logger.exception("Exception during training:")
                raise
        finally:
            self.engine.cleanup()

    def _run_epoch(self):
        self._fire_event("on_epoch_start")
        for batch in self.dataloader:
            self._run_step(batch)
            if self.should_stop:
                break
        self._fire_event("on_epoch_end")

    def _run_step(self, batch):
        self._fire_event("on_step_start")
        batch = self.engine.to_device(batch)
        logs = self.train_step(batch)
        self.logs = recursive_detach(logs)
        self._fire_event("on_step_end")

    @abstractmethod
    def train_step(self, batch) -> dict:
        raise NotImplementedError("Must be implemented in subclasses.")

    @torch.no_grad()
    def validate(self) -> Optional[dict]:
        """Optionally return the validation results"""
        pass

    def train_hooks(self):
        return []

    @abstractmethod
    def configure_optimizers(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    @abstractmethod
    def configure_lr_schedulers(self):
        raise NotImplementedError("Must be implemented in subclasses.")

    def configure_criteria(self) -> Optional[dict]:
        """Optionally return the required criteria needed by train_step"""
        pass

    def configure_metrics(self) -> Optional[dict]:
        """Optionally return the required metrics"""
        pass

    def configure_cv_metrics(self) -> Optional[dict]:
        """Optionally return the required metrics"""
        pass

    def _fire_event(self, event):
        for h in self.hooks.values():
            getattr(h, event)(self)

    @staticmethod
    def _convert_steps_or_epochs_to_hooks(max_steps, max_epochs):
        if max_steps is not None or max_epochs is not None:
            return [StopAtStepOrEpochHook(max_steps, max_epochs)]
        else:
            return []

    @staticmethod
    def _choose_cluster(cluster_type):
        if not isinstance(cluster_type, str):
            raise ValueError("Cluster type should be provided (local, philly or itp)")
        if cluster_type.lower() == "philly":
            cluster_env = clusters.PhillyEnvironment()
        elif cluster_type.lower() == "itp":
            cluster_env = clusters.ITPEnvironment()
        elif cluster_type.lower() == "local":
            cluster_env = clusters.LocalEnvironment()
        else:
            raise ValueError(f"Cluster type {cluster_type} is not supported")
        return cluster_env

import logging
import torch
from copy import deepcopy

from torchtts.nn import metrics
from torchtts.trainers.base_trainer import Trainer

logger = logging.getLogger(__name__)


class BasicCVTrainer(Trainer):
    def train_step(self, batch):
        with self.engine.context():
            prediction = self.model(batch["img"])
            loss = self.criteria(input=prediction, target=batch["label"])

        # Exits the context manager before optimize step
        self.engine.optimize_step(loss=loss, optimizer=self.optimizers)

        # Update metrics
        self.metrics["loss"].update_state(loss)
        self.metrics["accuracy"].update_state(prediction, batch["label"])

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def validate(self):
        with self.engine.context():
            for batch in self.cv_dataloader:
                batch = self.engine.to_device(batch)
                prediction = self.model(batch["img"])
                loss = self.criteria(input=prediction, target=batch["label"])

                # Update metrics
                self.cv_metrics["loss"].update_state(loss)
                self.cv_metrics["accuracy"].update_state(prediction, batch["label"])

        # The dict will be stored as validation logs.
        return {k: m.result() for k, m in self.cv_metrics.items()}

    def configure_optimizers(self):
        return torch.optim.Adam(self.model.parameters(), lr=1e-4)

    def configure_lr_schedulers(self):
        return None

    def configure_criteria(self):
        return torch.nn.CrossEntropyLoss()

    def configure_metrics(self):
        return {"loss": metrics.Mean(), "accuracy": metrics.SparseCategoricalAccuracy()}

    def configure_cv_metrics(self):
        return deepcopy(self.configure_metrics())

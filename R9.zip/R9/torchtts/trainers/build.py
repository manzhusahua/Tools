import hydra
import logging
from omegaconf import OmegaConf

logger = logging.getLogger(__name__)


def build_trainer(trainer_config):
    logger.info("Instantiating trainer with config: \n" f"{OmegaConf.to_yaml(trainer_config, sort_keys=True)}")
    trainer = hydra.utils.instantiate(trainer_config)
    return trainer

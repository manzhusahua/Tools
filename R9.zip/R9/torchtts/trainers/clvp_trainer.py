import torch

from torchtts.nn import criterions
from torchtts.nn.criterions import GANLoss
from torchtts.nn.criterions import MultiResolutionSTFTLoss
from torchtts.nn.metrics import Mean
from torchtts.nn.optim.lr_schedulers import ExponitialDecayLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.nn.criterions.duration_loss import DurationPredictorLoss

import logging

from torch.optim import AdamW

logger = logging.getLogger(__name__)


class CLVPTrainer(Trainer):
    def train_step(self, batch):
        if 'audio' not in batch:
            batch['audio'] = batch.get('speech', None)

        with self.engine.context():
            self.model['CodecEnc'] = self.model['CodecEnc'].eval()
            self.model['generator'] = self.model['generator'].eval()

            with torch.no_grad():
                vq_emb, _, _ = self.model['CodecEnc'](batch['audio'].unsqueeze(1))
                q = self.model['generator'](vq_emb, return_vqid=True)  # vq_idx [codebook_num, batch_size, time]
                vq_idx_det = q.detach()

                b, t = vq_idx_det[0].size()
                vq_idx_det = vq_idx_det[0:1, :, :].permute(1, 2, 0)

                text_inp = batch['phone_id']
                text_inp_length = batch['phone_id_length']

                vq_bos = torch.ones_like(vq_idx_det[:, 0:1, :]) * 3073
                vq_inp = torch.cat((vq_bos, vq_idx_det,
                                    torch.zeros_like(vq_idx_det[:, 0:1, :])), dim=1)
                r = torch.arange(1, vq_inp.size(1) + 1)[None, :].repeat(vq_inp.size(0), 1) \
                    .to(batch.get('wavs_length', None).device)
                vq_inp_length = batch.get('wavs_length', None) // 320 + 1
                a = torch.zeros_like(r)
                for idx, r_ in enumerate(r):
                    a[idx] = r_ <= vq_inp_length[idx]
                a = a[:, :, None].float()
                vq_inp = vq_inp * a + (1 - a) * 3074
                vq_inp = vq_inp.long()

                clvp_input = vq_inp[:, 1:-1]
                clvp_text_input = text_inp[:, 1:-1]

            loss = self.model['clvp'](text=clvp_text_input.long(), speech_tokens=clvp_input.squeeze(-1),
                                      text_ilens=text_inp_length, speech_ilens=vq_inp_length - 1, return_loss=True)
        self.metrics['loss'].update_state(loss)
        self.engine.optimize_step(loss=loss,
                                  optimizer=self.optimizers['clvp'],
                                  lr_scheduler=self.lr_schedulers['clvp'])
        return {k: m.result() for k, m in self.metrics.items()}

    def configure_optimizers(self):
        am_params = self.model['clvp'].parameters()
        return {'clvp': AdamW(am_params, **self._config["gen_optim_params"])}

    def configure_lr_schedulers(self):
        return {
            'clvp': ExponitialDecayLR(optimizer=self.optimizers['clvp'],
                                      initial_lr=self._config.get("initial_lr", 2.5e-4),
                                      decay_rate=self._config.get("decay_rate", 0.98),
                                      decay_steps=self._config.get("decay_steps", 7000),
                                      min_lr=self._config.get("min_lr", 0.00006)),
        }

    def configure_criteria(self):
        criteria = {
            'gan_loss': GANLoss(mode='lsgan'),
            'mel_loss': criterions.SequenceLoss('mse_loss', use_masking=True),
            'l1_loss': torch.nn.L1Loss(reduction='mean'),
            'l2_loss': torch.nn.MSELoss(reduction='mean'),
            'dur_loss': DurationPredictorLoss(reduction='mean'),
            'guided_attention_loss': criterions.GuidedMultiHeadAttentionLoss(sigma=0.4, alpha=1.0, reset_always=True)
        }
        if self._config['use_stft_loss']:
            criteria['stft_loss'] = MultiResolutionSTFTLoss(**self._config['stft_loss_params'])
        if self._config['use_feat_match_loss']:
            criteria['fm_loss'] = torch.nn.L1Loss()
        return criteria

    def configure_metrics(self):
        metrics = {
            'loss': Mean(),
        }

        return metrics

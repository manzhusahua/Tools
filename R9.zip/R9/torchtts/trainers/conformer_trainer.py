import logging
import os
import yaml
import copy
import random
from omegaconf.dictconfig import DictConfig

import torch
import torch.nn.functional as F
from torchtts import models
from torchtts.nn import metrics
from torchtts.nn.criterions.duration_loss import DurationPredictorLoss
from torchtts.nn.modules.common.functional import make_non_pad_mask
from torchtts.nn.modules.conformer.ssim import ssim, mask_ssim
from torchtts.nn.optim import Ranger
from torchtts.nn.optim.lr_schedulers import ExponitialDecayLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookNode
from torchtts.hooks.base_hook import HookOrder
from torchtts.utils.torch_utils import unwrap_ddp
from torchtts.data.core import writers
from torchtts.data.core import features
import numpy as np

logger = logging.getLogger(__name__)

fs_feature_dict = features.FeaturesDict(
    {
        "phone_id": features.Tensor(shape=(None,), dtype=np.int64),
        "phone_id_length": features.Tensor(shape=(), dtype=np.int64),
        "duration": features.Tensor(shape=(None,), dtype=np.int64),
        "mel": features.Tensor(shape=(None, 80), dtype=np.float32),
        "mel_length": features.Tensor(shape=(), dtype=np.int64),
    }
)


class ConformerTrainer(Trainer):
    def __init__(
        self,
        device="cuda",
        use_amp=False,
        dist_config=None,
        save_path=None,
        save_interval=1000,
        log_interval=100,
        warm_start_from=None,
        reset_trainer=False,
        parameter_list=None,
        **kwargs,
    ):
        super().__init__(
            device,
            use_amp,
            dist_config,
            save_path,
            save_interval,
            log_interval,
            warm_start_from,
            reset_trainer,
            parameter_list,
            **kwargs,
        )
        if self._config.get("dump_student_for_ls", False):
            self.total_dump = 0
            self.writer = writers.ShardWriter("./shards-%05d.tar", writer_cls=writers.TarWriter, max_count=10000)

    def train_step(self, batch):
        if self._config.get("mel2vec_pretrain", False):
            with self.engine.context():
                mel2vec_loss = self.model(
                    xs=None,
                    ilens=None,
                    ys=batch["mel"],
                    olens=batch.get("mel_length", None),
                    ds=None,
                    f0=None,
                    speaker_id=batch.get("speaker_id", None),
                    lang_id=batch.get("lang_id", None),
                    job="m2v",
                )
                loss = mel2vec_loss

            self.engine.optimize_step(loss=loss, optimizer=self.optimizers, lr_scheduler=self.lr_schedulers)
            self.metrics["loss"].update_state(mel2vec_loss)
            return {k: m.result() for k, m in self.metrics.items()}

        if self._config.get("phoneme_bert_pretrain", False):
            with self.engine.context():
                phoneme_masked_tokens = batch["phoneme_target"].ne(0)
                sample_size = phoneme_masked_tokens.int().sum().item()
                if sample_size == 0:
                    phoneme_masked_tokens = None
                logitps = self.model(
                    xs=batch["phoneme"],
                    ilens=batch["phone_id_length"],
                    masked_tokens=phoneme_masked_tokens,
                    ys=None,
                    olens=None,
                    ds=None,
                    job="phoneme_bert",
                )

                targets_p = batch["phoneme_target"].long()
                if sample_size != 0:
                    targets_p = targets_p[phoneme_masked_tokens]

                loss = F.nll_loss(
                    F.log_softmax(
                        logitps.view(-1, logitps.size(-1)),
                        dim=-1,
                        dtype=torch.float32,
                    ),
                    targets_p.view(-1),
                    reduction="sum",
                    ignore_index=0,
                )

            self.engine.optimize_step(loss=loss, optimizer=self.optimizers, lr_scheduler=self.lr_schedulers)
            self.metrics["loss"].update_state(loss)
            return {k: m.result() for k, m in self.metrics.items()}

        if self._config.get("enable_singing_vc", False):
            with self.engine.context():
                model_out = self.model(
                    xs=batch["phone_id"],
                    ilens=batch["phone_id_length"],
                    ys=batch["mel"],
                    olens=batch.get("mel_length", None),
                    ds=batch["duration"],
                    f0=batch.get("f0", None),
                    speaker_id=batch.get("speaker_id", None),
                    lang_id=batch.get("locale_id", None),
                    style_id=batch.get("style_id", None),
                    uv=batch.get("uv", None),
                    power=batch.get("power", None),
                    tilt=batch.get("tilt", None)
                )
            loss = self.calc_loss(batch, model_out)
            self.engine.optimize_step(loss=loss,
                                      optimizer=self.optimizers,
                                      lr_scheduler=self.lr_schedulers)
            self.metrics["loss"].update_state(loss)
            return {k: m.result() for k, m in self.metrics.items()}

        with self.engine.context():
            ref_prosody, ph_hs, window_frame = None, None, None
            # for full model distil, evaluate teacher model here
            if self.distil.startswith("full"):
                batch, teacher_out, ref_prosody, ph_hs = self.teacher_inference(batch)
                if self._config.get("dump_student_for_ls", False):
                    for i in range(batch["phone_id"].shape[0]):
                        ph_id_len = batch["phone_id_length"][i].cpu()
                        ph_id = batch["phone_id"][i][:ph_id_len].cpu()
                        dur = batch["duration"][i][:ph_id_len].cpu()
                        mel_len = batch["mel_length"][i].cpu()
                        mel = batch["mel"][i][:mel_len].cpu()
                        encoded_example = fs_feature_dict.encode_example(
                            {
                                "phone_id": ph_id,
                                "phone_id_length": ph_id_len,
                                "duration": dur,
                                "mel": mel,
                                "mel_length": mel_len,
                            }
                        )

                        self.writer.write({"__key__": f"{self.total_dump:010}", **encoded_example})
                        self.total_dump += 1

            # only for adversarial training
            if self._config.get("enable_adversarial_loss", False):
                self.optimizers.zero_grad()
                for name, module in unwrap_ddp(self.model).named_modules():
                    if "model_disc" in name:
                        for param in module.parameters():
                            param.requires_grad_(True)
                    else:
                        for param in module.parameters():
                            param.requires_grad_(False)
                disc_real, window_frame = self.model(
                    xs=batch["phone_id"],
                    ilens=batch["phone_id_length"],
                    ys=batch["mel"],
                    olens=batch.get("mel_length", None),
                    ds=batch["duration"],
                    gan_step="disc_real",
                )
                disc_real = -disc_real.mean()
                disc_real.backward()
                (disc_fake, gan_interp) = self.model(
                    xs=batch["phone_id"],
                    ilens=batch["phone_id_length"],
                    ys=batch["mel"],
                    olens=batch.get("mel_length", None),
                    ds=batch["duration"],
                    f0=batch.get("phone_f0", None),
                    speaker_id=batch.get("speaker_id", None),
                    lang_id=batch.get("locale_id", None),
                    style_id=batch.get("style_id", None),
                    energy=batch.get("phone_energy", None),
                    ref_prosody=ref_prosody,
                    ph_hs=ph_hs,
                    context_phone=batch.get("context_phone_emb", None),
                    context_seq=batch.get("context_seq_emb", None),
                    spembsinput=batch.get("pretrain_speaker_embedding", None),
                    global_zero_cross_rate=batch.get("global_zero_cross_rate", None),
                    global_f0=batch.get("global_f0", None),
                    global_energy=batch.get("global_energy", None),
                    attributes=batch.get("attributes", None),
                    spk_rate_level=batch.get("spk_rate", None),
                    pitch_level=batch.get("pitch_level", None),
                    energy_level=batch.get("energy_level", None),
                    with_attri_label=batch.get('with_attri_label', None),
                    sp_tgtxseqs=batch.get("tgtxseq", None),
                    sp_tgtyseqs=batch.get("tgtyseq", None),
                    sp_reflens=batch.get("ref_olen", None),
                    sp_ref=batch.get("ref", None),
                    note_duration=batch.get("note_duration", None),
                    note_pitch=batch.get("note_pitch", None),
                    syllable_duration=batch.get("syllable_duration", None),
                    gan_step="disc_fake",
                    gan_reltaed=window_frame,
                )
                disc_fake = disc_fake.mean()
                disc_fake.backward()
                gradient_penalty = self.model(
                    xs=batch["phone_id"],
                    ilens=batch["phone_id_length"],
                    ys=batch["mel"],
                    olens=batch.get("mel_length", None),
                    ds=batch["duration"],
                    gan_interp=gan_interp,
                    gan_step="gradient_penalty",
                    gan_reltaed=window_frame,
                )
                gradient_penalty.backward()
                current_lr = self.lr_schedulers.get_lr()[0]
                for group in self.optimizers.param_groups:
                    group["lr"] = 0.1 * current_lr
                    torch.nn.utils.clip_grad_norm_(group["params"], 1.0)
                self.optimizers.step()
                for group in self.optimizers.param_groups:
                    group["lr"] = current_lr
                wasserstein_dist = -disc_real - disc_fake
                self.metrics["wasserstein_dist"].update_state(wasserstein_dist)
                self.optimizers.zero_grad()
                for name, module in unwrap_ddp(self.model).named_modules():
                    if "model_disc" in name:
                        for param in module.parameters():
                            param.requires_grad_(False)
                    else:
                        for param in module.parameters():
                            param.requires_grad_(True)

            model_out = self.model(
                xs=batch["phone_id"],
                ilens=batch["phone_id_length"],
                ys=batch["mel"],
                olens=batch.get("mel_length", None),
                ds=batch["duration"],
                f0=batch.get("phone_f0", None),
                speaker_id=batch.get("speaker_id", None),
                lang_id=batch.get("locale_id", None),
                style_id=batch.get("style_id", None),
                energy=batch.get("phone_energy", None),
                ref_prosody=ref_prosody,
                ph_hs=ph_hs,
                context_phone=batch.get("context_phone_emb", None),
                context_seq=batch.get("context_seq_emb", None),
                spembsinput=batch.get("pretrain_speaker_embedding", None),
                global_zero_cross_rate=batch.get("global_zero_cross_rate", None),
                global_f0=batch.get("global_f0", None),
                global_energy=batch.get("global_energy", None),
                attributes=batch.get("attributes", None),
                spk_rate_level=batch.get("spk_rate", None),
                pitch_level=batch.get("pitch_level", None),
                energy_level=batch.get("energy_level", None),
                with_attri_label=batch.get('with_attri_label', None),
                sp_tgtxseqs=batch.get("tgtxseq", None),
                sp_tgtyseqs=batch.get("tgtyseq", None),
                sp_reflens=batch.get("ref_olen", None),
                sp_ref=batch.get("ref", None),
                note_duration=batch.get("note_duration", None),
                note_pitch=batch.get("note_pitch", None),
                syllable_duration=batch.get("syllable_duration", None),
                interp_pitch=batch.get("f0", None),
                quantized_pitch=batch.get("quantized_f0", None),
                uv=batch.get("uv", None),
                power=batch.get("phone_power", None),
                tilt=batch.get("phone_tilt", None),
                mel_shuffle=batch.get("mel_shuffle", None),
                emt_tau=self.cal_temp()
            )

            if self.distil.startswith("full"):
                loss = self.calc_soft_loss(batch, teacher_out, model_out)
                if self._config.get("enable_hard_loss", False):
                    hard_loss = self.calc_loss(batch, model_out)

                    self.metrics["loss_hard"].update_state(hard_loss)
                    self.metrics["loss_soft"].update_state(loss)

                    self.hardw = self._config.get("hardw", 0.1)
                    self.softw = self._config.get("softw", 0.9)

                    loss = hard_loss * self.hardw + loss * self.softw
            else:
                loss = self.calc_loss(batch, model_out)

        self.engine.optimize_step(loss=loss, optimizer=self.optimizers, lr_scheduler=self.lr_schedulers)

        self.metrics["loss"].update_state(loss)

        return {k: m.result() for k, m in self.metrics.items()}

    def cal_temp(self):
        return np.maximum(self._config.get('temperature', 1.0)
                          * np.exp(-self._config.get('anneal_rate', 1e-6)
                          * self.global_steps),
                          self._config.get('temp_min', 0.5))

    def calc_loss(self, batch, model_out, tag="hard"):
        assert tag in ["hard", "soft"], "tag should be hard or soft"
        if self._config.get("enable_zeroshot", False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
                pred_global_f0,
                global_f0,
            ) = model_out
        elif self._config.get("new_voice_generation", False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
                spk_emb,
                spk_emb_encdec,
                spk_emb_cycle,
                attri_gt,
                attri_relate,
                log_like
            ) = model_out
        elif self._config.get('enable_cross_lingual_spk_loss', False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
                spk_emb_gt,
                cross_spk_emb,
            ) = model_out
        elif self._config.get("enable_adversarial_loss", False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
                kl_tuple_style_vae,
                loss_adv,
            ) = model_out
        elif self._config.get("enable_frame_pitch_loss", False):
            if self._config.get("enable_quant2cont_pitch_loss", False):
                (
                    pred_mel,
                    pred_dur,
                    pred_prosody,
                    ref_prosody,
                    p_ref,
                    p_pred,
                    ph_emb,
                    ph_emb_pred,
                    kl_tuple,
                    es,
                    eouts,
                    spred_mel,
                    ds,
                    _,
                    frame_quantpitch_pred,
                    frame_contpitch_pred,
                    pitch_norm,
                ) = model_out
            else:
                (
                    pred_mel,
                    pred_dur,
                    pred_prosody,
                    ref_prosody,
                    p_ref,
                    p_pred,
                    ph_emb,
                    ph_emb_pred,
                    kl_tuple,
                    es,
                    eouts,
                    spred_mel,
                    ds,
                    _,
                    frame_quantpitch_pred,
                ) = model_out
        elif self._config.get("enable_ar_prosody", False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
                p_ref1,
                p_pred1,
                ds1,
                pred_dur1,
            ) = model_out
        elif self._config.get("enable_diff_prosody", False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
                diffp_ref,
                diffp_pred,
            ) = model_out
        elif self._config.get("enable_emotion_encoder", False):
            (pred_mel, pred_dur, pred_prosody, ref_prosody, p_ref, p_pred, ph_emb,
             ph_emb_pred, kl_tuple, es, eouts, spred_mel, ds, _,
             emt_logits, spk_logits, locale_logits) = model_out
        elif self._config.get('enable_singing_loss', False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
                power_s,
                power_outs,
                tilt_s,
                tilt_outs) = model_out
        else:
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                spred_mel,
                ds,
                _,
            ) = model_out

        m = mask_ssim(pred_mel[-1].shape, batch["mel_length"], dim=1).float().to(pred_mel[-1].device)
        if tag == "soft":
            pred_mel_ss, ys_ss = pred_mel[-1] * m, batch["mel"][-1] * m
        else:
            pred_mel_ss, ys_ss = pred_mel[-1] * m, batch["mel"] * m
        ssim_loss = 1 - ssim(pred_mel_ss.unsqueeze(1), ys_ss.unsqueeze(1))

        duration_masks = make_non_pad_mask(batch["phone_id_length"]).to(batch["phone_id"].device)
        d_outs = pred_dur.masked_select(duration_masks)
        ds = batch["duration"].masked_select(duration_masks)
        if tag == "soft":
            duration_loss = self.criteria["l2_loss"](d_outs, ds) * self._config.get("duration_loss_weight", 0.1)
        else:
            duration_loss = self.criteria["dur_loss"](d_outs, ds) * self._config.get("duration_loss_weight", 0.1)

        out_masks = make_non_pad_mask(batch["mel_length"]).unsqueeze(-1).to(batch["phone_id"].device)
        masked_pred_mel = [mel_.masked_select(out_masks) for mel_ in pred_mel]
        if tag == "soft":
            masked_ys = [mel_.masked_select(out_masks) for mel_ in batch["mel"]]
            slayer_id = self.get_slayer_id(len(masked_ys), len(masked_pred_mel))
            ys_losses = [
                self.criteria["l1_loss"](mel_, mel0_.detach())
                for mel_, mel0_ in zip(masked_pred_mel, [masked_ys[i] for i in slayer_id])
            ]
        else:
            masked_ys = batch["mel"].masked_select(out_masks)
            ys_losses = [self.criteria["l1_loss"](mel_, masked_ys) for mel_ in masked_pred_mel]
        ys_loss = sum(ys_losses)

        loss = ssim_loss + duration_loss + ys_loss

        if p_ref is not None:
            pitch_mask = duration_masks.unsqueeze(-1)
            p_pred = p_pred.masked_select(pitch_mask)
            p_ref = p_ref.masked_select(pitch_mask)
            pitch_loss = self.criteria["l2_loss"](p_pred, p_ref)
            self.metrics["pitch_loss"].update_state(pitch_loss)
            loss += pitch_loss

        if self._config.get("enable_singing_loss", False) and power_s is not None:
            power_mask = duration_masks.unsqueeze(-1)
            power_outs = power_outs.masked_select(power_mask)
            power_s = power_s.masked_select(power_mask)
            power_loss = self.criteria["l2_loss"](power_outs, power_s)
            self.metrics["power_loss"].update_state(power_loss)
            loss += power_loss

        if self._config.get("enable_singing_loss", False) and tilt_s is not None:
            tilt_mask = duration_masks.unsqueeze(-1)
            tilt_outs = tilt_outs.masked_select(tilt_mask)
            tilt_s = tilt_s.masked_select(tilt_mask)
            tilt_loss = self.criteria["l2_loss"](tilt_outs, tilt_s)
            self.metrics["tilt_loss"].update_state(tilt_loss)
            loss += tilt_loss

        if es is not None:
            energy_mask = duration_masks.unsqueeze(-1)
            eouts = eouts.masked_select(energy_mask)
            es = es.masked_select(energy_mask)
            energy_loss = self.criteria["l2_loss"](eouts, es)
            self.metrics["energy_loss"].update_state(energy_loss)
            loss += energy_loss

        if pred_prosody is not None:
            gst_loss = self.criteria["l1_loss"](pred_prosody, ref_prosody.detach())
            self.metrics["gst_loss"].update_state(gst_loss)
            loss += gst_loss

        if ph_emb is not None and ph_emb_pred is not None:
            ph_emb_mask = duration_masks.unsqueeze(-1)
            ph_emb = ph_emb.masked_select(ph_emb_mask)
            ph_emb_pred = ph_emb_pred.masked_select(ph_emb_mask)
            ph_emb_loss = self.criteria["l1_loss"](ph_emb_pred, ph_emb.detach())
            self.metrics["ph_emb_loss"].update_state(ph_emb_loss)
            loss += ph_emb_loss

        if self._config.get("enable_zeroshot", False) and global_f0 is not None and pred_global_f0 is not None:
            global_f0_loss = self.criteria["l1_loss"](pred_global_f0, global_f0 / 100.0)
            self.metrics["global_f0_loss"].update_state(global_f0_loss)
            loss += global_f0_loss

        if kl_tuple is not None:
            ph_kl_mask = duration_masks.unsqueeze(-1)
            z_mu, z_log_sigma2 = kl_tuple
            masked_z_mu = z_mu.masked_select(ph_kl_mask)
            masked_z_log_sigma2 = z_log_sigma2.masked_select(ph_kl_mask)  # [BT, D]

            ph_kl_loss = torch.mean(
                torch.sum(-0.5 * (1 + masked_z_log_sigma2 - masked_z_mu**2 - torch.exp(masked_z_log_sigma2)), dim=-1)
            ) * self._config.get("ph_kl_loss_weight", 1e-4)
            self.metrics["ph_kl_loss"].update_state(ph_kl_loss)
            loss += ph_kl_loss

        if self._config.get("enable_style_vae_kl_loss", False):
            qz_mu, qz_log_sigma2, pz_mu, pz_log_sigma2 = kl_tuple_style_vae
            end_weight = self._config.get("style_vae_kl_loss_weight", 1e-4)
            final_weight = end_weight

            style_vae_kl_loss = (
                torch.mean(
                    torch.sum(
                        -0.5
                        * (
                            1
                            + qz_log_sigma2
                            - pz_log_sigma2
                            - (pz_mu - qz_mu) ** 2 / torch.exp(pz_log_sigma2)
                            - torch.exp(qz_log_sigma2) / torch.exp(pz_log_sigma2)
                        ),
                        dim=-1,
                    )
                )
                * final_weight
            )

            self.metrics["style_vae_kl_loss"].update_state(style_vae_kl_loss)
            loss += style_vae_kl_loss

        if spred_mel is not None and self._config.get("enable_retrain_phnpred", False) and isinstance(spred_mel, tuple):
            spred_mel, sp_pred, spred_dur, sph_emb_pred = spred_mel

        if spred_mel is not None:
            # calculate loss for online decoder distillation
            # hard loss
            m = mask_ssim(spred_mel[-1].shape, batch["mel_length"], dim=1).float().to(spred_mel[-1].device)
            spred_mel_ss = spred_mel[-1] * m
            ssim_sloss = 1 - ssim(spred_mel_ss.unsqueeze(1), ys_ss.unsqueeze(1))
            masked_spred_mel = [mel_.masked_select(out_masks) for mel_ in spred_mel]
            ys_slosses = [self.criteria["l1_loss"](mel_, masked_ys) for mel_ in masked_spred_mel]
            ys_sloss = sum(ys_slosses)
            sloss = ssim_sloss + ys_sloss

            # soft loss
            sloss_soft = 1 - ssim(spred_mel_ss.unsqueeze(1), pred_mel_ss.detach().unsqueeze(1))
            slayer_id = self.get_slayer_id(len(masked_pred_mel), len(masked_spred_mel))
            ys_slosses_soft = [
                self.criteria["l1_loss"](mel_, mel0_.detach())
                for mel_, mel0_ in zip(masked_spred_mel, [masked_pred_mel[i] for i in slayer_id])
            ]
            ys_sloss_soft = sum(ys_slosses_soft)
            sloss_soft = sloss_soft + ys_sloss_soft

            self.metrics["sloss_hard"].update_state(sloss)
            self.metrics["sloss_soft"].update_state(sloss_soft)

            if self.distil == "online_decoder":
                loss = loss + self.ssoftw * sloss_soft + self.shardw * sloss
            elif self.distil == "offline_decoder":
                # for offline_decoder, just update sdecoder parameters
                loss = self.ssoftw * sloss_soft + self.shardw * sloss
            else:
                raise NotImplementedError

        if self._config.get("enable_retrain_phnpred", False):
            duration_masks = make_non_pad_mask(batch["phone_id_length"]).to(batch["phone_id"].device)
            sd_outs = spred_dur.masked_select(duration_masks)
            ds = batch["duration"].masked_select(duration_masks)
            sduration_loss = self.criteria["dur_loss"](sd_outs, ds) * self._config.get("duration_loss_weight", 0.1)
            self.metrics["sdur_loss"].update_state(sduration_loss)
            pitch_mask = duration_masks.unsqueeze(-1)
            sp_pred = sp_pred.masked_select(pitch_mask)
            spitch_loss = self.criteria["l2_loss"](sp_pred, p_ref)
            self.metrics["spitch_loss"].update_state(spitch_loss)

            ph_emb_mask = duration_masks.unsqueeze(-1)
            sph_emb_pred = sph_emb_pred.masked_select(ph_emb_mask)
            sph_emb_loss = self.criteria["l1_loss"](sph_emb_pred, ph_emb.detach())
            self.metrics["sph_emb_loss"].update_state(sph_emb_loss)

            loss = loss + spitch_loss + sduration_loss + sph_emb_loss

        if self._config.get("new_voice_generation", False):
            spk_encdec_loss = self.criteria["l2_loss"](spk_emb_encdec, spk_emb) * 100
            spk_cycle_loss = self.criteria["l2_loss"](spk_emb_cycle, spk_emb) * 100
            self.metrics["spk_encdec_loss"].update_state(spk_encdec_loss)
            self.metrics["spk_cycle_loss"].update_state(spk_cycle_loss)
            # attributes loss
            attri_weight = self._config.get("attri_weight", 2.0)
            attri_loss = self.criteria["l2_loss"](attri_relate, attri_gt) * attri_weight
            self.metrics["attri_loss"].update_state(attri_loss)
            # gender loss
            gender_weight = self._config.get("gender_weight", 5.0)
            gender_loss = self.criteria["l2_loss"](attri_relate[:, 0], attri_gt[:, 0]) * gender_weight
            self.metrics["gender_loss"].update_state(gender_loss)
            # age loss
            age_weight = self._config.get("age_weight", 5.0)
            age_loss = self.criteria["l2_loss"](attri_relate[:, 1], attri_gt[:, 1]) * age_weight
            self.metrics["age_loss"].update_state(age_loss)
            # log-likelihood
            if self._config.get('model_attri_distribution', False):
                log_like_loss = -torch.mean(log_like)
                self.metrics['log_like_loss'].update_state(log_like_loss)
                loss = loss + log_like_loss

            loss = loss + spk_encdec_loss + spk_cycle_loss + attri_loss + gender_loss + age_loss

        if self._config.get('enable_cross_lingual_spk_loss', False):
            cross_spk_loss = self.criteria['l2_loss'](cross_spk_emb, spk_emb_gt) * self._config.get('cross_lingual_loss_weight', 100.0)
            self.metrics['cross_spk_loss'].update_state(cross_spk_loss)
            # be effective when step > 10000
            if self.global_steps > self._config.get('cross_spk_loss_effective_step', 10000):
                loss = loss + cross_spk_loss

        if self._config.get("enable_adversarial_loss", False):
            loss_gener = F.relu(-loss_adv.mean())
            loss_gener = loss_gener * self._config.get("adversarial_loss_weight", 0.001)
            self.metrics["adversarial_loss"].update_state(loss_gener)
            loss = loss + loss_gener

        if self._config.get("enable_frame_pitch_loss", False):
            if self._config.get("enable_quant_pitch_loss", False):
                bce_loss_quantized_f0 = self.criteria["bce_loss"](
                    frame_quantpitch_pred.masked_select(out_masks), batch["quantized_f0"].masked_select(out_masks)
                )
                bce_loss_quantized_f0 = bce_loss_quantized_f0 * self._config.get("bce_loss_quantized_f0_weight", 1.0)
                self.metrics["bce_loss_quantized_f0"].update_state(bce_loss_quantized_f0)
                loss = loss + bce_loss_quantized_f0
                frame_level_accuracy = torch.eq(
                    torch.argmax(frame_quantpitch_pred, dim=-1), torch.argmax(batch["quantized_f0"], dim=-1)
                )
                frame_level_accuracy = frame_level_accuracy.masked_select(out_masks.squeeze(-1)).float().mean()
                self.metrics["frame_level_accuracy"].update_state(frame_level_accuracy)
                if self._config.get("enable_quant2cont_pitch_loss", False):
                    out_masks = out_masks.squeeze(-1)
                    target_pitch = pitch_norm.masked_select(out_masks)
                    l1l2_loss_frame_pitch = self.criteria["l1_loss"](
                        frame_contpitch_pred.masked_select(out_masks), target_pitch
                    )
                    l1l2_loss_frame_pitch += self.criteria["l2_loss"](
                        frame_contpitch_pred.masked_select(out_masks), target_pitch
                    )
                    l1l2_loss_frame_pitch *= self._config.get("l1l2_loss_frame_pitch_weight", 1.0)
                    self.metrics["l1l2_loss_frame_pitch"].update_state(l1l2_loss_frame_pitch)
                    loss = loss + l1l2_loss_frame_pitch

        if self._config.get("enable_ar_prosody", False):
            duration_masks1 = duration_masks.long()

            p_ref1 = p_ref1 * duration_masks1 + (duration_masks1 - 1)
            p_ref1 = p_ref1.contiguous().view(-1)
            p_pred1 = p_pred1.contiguous().view(-1, p_pred1.shape[-1])
            pitch_loss1 = self.criteria['ce_loss'](p_pred1, p_ref1)
            loss += pitch_loss1

            ds1 = ds1 * duration_masks1 + (duration_masks1 - 1)
            ds1 = ds1.contiguous().view(-1)
            pred_dur1 = pred_dur1.contiguous().view(-1, pred_dur1.shape[-1])
            duration_loss1 = self.criteria['ce_loss'](pred_dur1, ds1)
            loss += duration_loss1

        if self._config.get("enable_diff_prosody", False):
            duration_masks1 = duration_masks.unsqueeze(-1)
            diffp_ref = diffp_ref.masked_select(duration_masks1)
            diffp_pred = diffp_pred.masked_select(duration_masks1)
            diffp_loss = self.criteria['l2_loss'](diffp_pred, diffp_ref)
            loss += diffp_loss

        if self._config.get("enable_emotion_encoder", False):

            emotion_loss = self.criteria["cross_entropy_loss"](emt_logits, batch["style_id"])
            spk_loss = self.criteria["cross_entropy_loss"](spk_logits, batch["speaker_id"])
            locale_loss = self.criteria["cross_entropy_loss"](locale_logits, batch["locale_id"])

            self.metrics["emt_loss"].update_state(emotion_loss)
            self.metrics["spk_loss"].update_state(spk_loss)
            self.metrics["locale_loss"].update_state(locale_loss)

            loss += emotion_loss + self._config.get("grl_loss_weight", 0.1) * spk_loss + \
                self._config.get("grl_loss_weight", 0.1) * locale_loss

        self.metrics["dur_loss"].update_state(duration_loss)
        self.metrics["ssim_loss"].update_state(ssim_loss)
        self.metrics["mel_loss"].update_state(ys_losses[-1])

        return loss

    def calc_soft_loss(self, batch, teacher_out, student_out):
        if self._config.get("enable_adversarial_loss", False) and self._config.get("enable_style_vae_kl_loss", False):
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                _,
                ds,
                t_encoder_hidden_tuple,
                t_kl_tuple_style_vae,
                t_loss_adv,
            ) = teacher_out
            (
                s_pred_mel,
                s_pred_dur,
                s_pred_prosody,
                s_ref_prosody,
                s_p_ref,
                s_p_pred,
                s_ph_emb,
                s_ph_emb_pred,
                s_kl_tuple,
                s_es,
                s_eouts,
                _,
                s_ds,
                s_encoder_hidden_tuple,
                s_kl_tuple_style_vae,
                s_loss_adv,
            ) = student_out
        else:
            (
                pred_mel,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb,
                ph_emb_pred,
                kl_tuple,
                es,
                eouts,
                _,
                ds,
                t_encoder_hidden_tuple,
            ) = teacher_out
            (
                s_pred_mel,
                s_pred_dur,
                s_pred_prosody,
                s_ref_prosody,
                s_p_ref,
                s_p_pred,
                s_ph_emb,
                s_ph_emb_pred,
                s_kl_tuple,
                s_es,
                s_eouts,
                _,
                s_ds,
                s_encoder_hidden_tuple,
            ) = student_out
        sbatch = copy.deepcopy(batch)
        if not self.enable_distil_t2t:
            sbatch["mel"] = [mel_.detach() for mel_ in pred_mel]
            sbatch["duration"] = pred_dur.detach()

        s_ref_prosody = pred_prosody.detach() if pred_prosody is not None else None
        s_p_ref = p_pred.detach() if p_pred is not None else None
        s_ph_emb = ph_emb_pred.detach() if ph_emb_pred is not None else None
        s_es = eouts.detach() if eouts is not None else None
        if self._config.get("enable_adversarial_loss", False) and self._config.get("enable_style_vae_kl_loss", False):
            smodel_out = (
                s_pred_mel,
                s_pred_dur,
                s_pred_prosody,
                s_ref_prosody,
                s_p_ref,
                s_p_pred,
                s_ph_emb,
                s_ph_emb_pred,
                s_kl_tuple,
                s_es,
                s_eouts,
                _,
                s_ds,
                _,
                s_kl_tuple_style_vae,
                s_loss_adv,
            )
        else:
            smodel_out = (
                s_pred_mel,
                s_pred_dur,
                s_pred_prosody,
                s_ref_prosody,
                s_p_ref,
                s_p_pred,
                s_ph_emb,
                s_ph_emb_pred,
                s_kl_tuple,
                s_es,
                s_eouts,
                _,
                s_ds,
                _,
            )

        if self.enable_distil_t2t:
            soft_loss = self.calc_loss(sbatch, smodel_out, tag="hard")
        else:
            soft_loss = self.calc_loss(sbatch, smodel_out, tag="soft")
        if not self.enable_distil_t2t:
            if len(t_encoder_hidden_tuple) != 0 and len(s_encoder_hidden_tuple) != 0:
                #  default: both return encoder hidden and enc/dec att.
                assert len(t_encoder_hidden_tuple) == len(s_encoder_hidden_tuple), (
                    "student constraint setting mismatch with teacher, "
                    "please check the teacher config file or student config command"
                )
                if len(t_encoder_hidden_tuple) == 3 and len(s_encoder_hidden_tuple) == 3:
                    t_encoder_hidden_tuple, t_encoder_att_matrix, t_decoder_att_matrix = t_encoder_hidden_tuple
                    s_encoder_hidden_tuple, s_encoder_att_matrix, s_decoder_att_matrix = s_encoder_hidden_tuple

                # only return att matrix
                elif len(t_encoder_hidden_tuple) == 2 and len(s_encoder_hidden_tuple) == 2:
                    t_encoder_att_matrix, t_decoder_att_matrix = t_encoder_hidden_tuple
                    s_encoder_att_matrix, s_decoder_att_matrix = s_encoder_hidden_tuple

                if self._config.get("att_constraint", False):
                    ilens, olens = batch["phone_id_length"], batch["mel_length"]
                    enc_att_mask = self._source_to_target_mask(ilens, ilens).unsqueeze(1).to(batch["phone_id"].device)
                    dec_att_mask = self._source_to_target_mask(olens, olens).unsqueeze(1).to(batch["phone_id"].device)
                    enc_slayer_id = self.get_slayer_id(len(t_encoder_att_matrix), len(s_encoder_att_matrix))
                    att_enc_losses = [
                        self.criteria["l2_loss"](
                            s_eh_.masked_select(enc_att_mask), t_eh_.detach().masked_select(enc_att_mask)
                        )
                        for s_eh_, t_eh_ in zip(s_encoder_att_matrix, [t_encoder_att_matrix[i] for i in enc_slayer_id])
                    ]

                    dec_slayer_id = self.get_slayer_id(len(t_decoder_att_matrix), len(s_decoder_att_matrix))
                    att_dec_losses = [
                        self.criteria["l2_loss"](
                            s_eh_.masked_select(dec_att_mask), t_eh_.detach().masked_select(dec_att_mask)
                        )
                        for s_eh_, t_eh_ in zip(s_decoder_att_matrix, [t_decoder_att_matrix[i] for i in dec_slayer_id])
                    ]

                    att_loss_weight = self._config.get("att_loss_weight", 0.2)
                    att_dec_loss = sum(att_dec_losses) * att_loss_weight
                    att_enc_loss = sum(att_enc_losses) * att_loss_weight
                    self.metrics["att_dec_loss"].update_state(att_dec_loss)
                    self.metrics["att_enc_loss"].update_state(att_enc_loss)
                    soft_loss += att_dec_loss + att_enc_loss

                # conformer hidden constraint
                if self._config.get("encoder_hidden_constraint", False):
                    duration_masks = make_non_pad_mask(sbatch["phone_id_length"]).to(sbatch["phone_id"].device)
                    encoder_hidden_loss_mask = duration_masks.unsqueeze(-1)

                    masked_encoder_hidden = [
                        eh.masked_select(encoder_hidden_loss_mask) for eh in t_encoder_hidden_tuple
                    ]
                    masked_encoder_hidden_pred = [
                        eh.masked_select(encoder_hidden_loss_mask) for eh in s_encoder_hidden_tuple
                    ]

                    slayer_id = self.get_slayer_id(len(masked_encoder_hidden), len(masked_encoder_hidden_pred))
                    encoder_hidden_losses = [
                        self.criteria["l2_loss"](s_eh_, t_eh_.detach())
                        for s_eh_, t_eh_ in zip(
                            masked_encoder_hidden_pred, [masked_encoder_hidden[i] for i in slayer_id]
                        )
                    ]

                    encoder_hidden_loss_weight = self._config.get("encoder_hidden_loss_weight", 0.1)
                    # -1 stands for the output the hidden is not constrained for better flexbility.
                    encoder_hidden_loss = (
                        sum(encoder_hidden_losses[:-1]) * encoder_hidden_loss_weight + encoder_hidden_losses[-1] * 0
                    )
                    self.metrics["encoder_hidden_loss"].update_state(encoder_hidden_loss)
                    soft_loss += encoder_hidden_loss

        return soft_loss

    def _source_to_target_mask(self, ilens, olens):
        x_masks = make_non_pad_mask(ilens)
        y_masks = make_non_pad_mask(olens)
        return x_masks.unsqueeze(-2) & y_masks.unsqueeze(-1)

    def configure_optimizers(self):
        if self._config.get("distil", "") == "offline_decoder":
            # for offline decoder distillation, params of teacher are not updated
            for name, child in unwrap_ddp(self.model).named_modules():
                if len(name) == 0:
                    # the first item name of model.named_modules is somehow empty
                    continue

                # trainable parameters updating rules:
                # 1. sdecoder distillation stage will only update sdecoder and soutput_layers,
                #    batchnorm mean/var of sdecoder will update, other batchnorm mean/var will fixed
                # 2. phone emb predictor retraining stage will only update spitch and sduration
                #    all batchnorm mean/var should be all fixed
                if self._config.get("enable_retrain_phnpred", False):
                    if "spitch_" in name or "sduration_" in name:
                        for param in child.parameters():
                            param.requires_grad_(True)
                    else:
                        for param in child.parameters():
                            param.requires_grad_(False)

                        if (
                            hasattr(child, "running_mean")
                            or isinstance(child, torch.nn.BatchNorm1d)
                            or isinstance(child, torch.nn.BatchNorm2d)
                        ):
                            child.track_running_stats = False
                            child.eval()
                else:
                    if "sdecoder" in name or "soutput_layers" in name:
                        for param in child.parameters():
                            param.requires_grad_(True)
                    else:
                        for param in child.parameters():
                            param.requires_grad_(False)

                        if (
                            hasattr(child, "running_mean")
                            or isinstance(child, torch.nn.BatchNorm1d)
                            or isinstance(child, torch.nn.BatchNorm2d)
                        ):
                            child.track_running_stats = False
                            child.eval()

        # this distill freeze option should only be effective when load same dimension of the model structure.
        elif self._config.get("distil", "") == "full":
            for name, child in unwrap_ddp(self.model).named_modules():
                if len(name) == 0:
                    # the first item name of model.named_modules is somehow empty
                    continue
                if 'decoder.encoder' in name or 'output_layers' in name or \
                        ((self._config.get('freeze_encoder', False) is False) and 'encoder.encoder' in name):
                    print("update {}".format(name))
                    for param in child.parameters():
                        param.requires_grad_(True)
                else:
                    print("freeze {}".format(name))
                    for param in child.parameters():
                        param.requires_grad_(False)

                    if (
                        isinstance(child, torch.nn.LayerNorm)
                        or isinstance(child, torch.nn.BatchNorm1d)
                        or isinstance(child, torch.nn.BatchNorm2d)
                    ):
                        child.track_running_stats = False
                        child.eval()

        if self._config.get("new_voice_generation", False):
            for name, child in unwrap_ddp(self.model).named_modules():
                if "spk_encoder.lstm" in name or "spk_encoder.linear" in name:
                    logger.info(f"freeze model parameters: {name}")
                    for param in child.parameters():
                        param.requires_grad_(False)
                if self._config.get('only_update_MDN', False):
                    if 'MDN' not in name:
                        logger.info(f'freeze model parameters: {name}')
                        for param in child.parameters():
                            param.requires_grad_(False)
                    else:
                        logger.info(f'Updating model parameters: {name}')
                        for param in child.parameters():
                            param.requires_grad_(True)

        if self._config.get('enable_cross_lingual_spk_loss', False):
            for name, child in (unwrap_ddp(self.model).named_modules()):
                if 'spk_encoder.lstm' in name or 'spk_encoder.linear' in name:
                    logger.info(f'freeze model parameters: {name}')
                    for param in child.parameters():
                        param.requires_grad_(False)

        return Ranger(
            filter(lambda p: p.requires_grad, self.model.parameters()),
            alpha=0.5,
            k=6,
            n_sma_threshold=5,
            betas=(0.95, 0.999),
            eps=1e-5,
            weight_decay=self._config.get("weight_decay", 1e-6),
        )

    def configure_lr_schedulers(self):
        return ExponitialDecayLR(
            optimizer=self.optimizers,
            initial_lr=self._config.get("initial_lr", 0.001),
            decay_rate=self._config.get("decay_rate", 0.825),
            decay_steps=self._config.get("decay_steps", 4000),
        )

    def configure_metrics(self):
        if self._config.get("phoneme_bert_pretrain", False):
            return {"loss": metrics.Mean()}
        else:
            metrics_dict = {
                "dur_loss": metrics.Mean(),
                "ssim_loss": metrics.Mean(),
                "mel_loss": metrics.Mean(),
                "loss": metrics.Mean()
            }

        if self._config.get("enable_gst_loss", False):
            metrics_dict.update({"gst_loss": metrics.Mean()})
        if self._config.get("enable_pitch_loss", False):
            metrics_dict.update({"pitch_loss": metrics.Mean()})
        if self._config.get("enable_energy_loss", False):
            metrics_dict.update({"energy_loss": metrics.Mean()})
        if self._config.get("enable_phone_emb_loss", False):
            metrics_dict.update({"ph_emb_loss": metrics.Mean()})
        if self._config.get("enable_global_f0_loss", False):
            metrics_dict.update({"global_f0_loss": metrics.Mean()})
        if self._config.get("enable_phone_kl_loss", False):
            metrics_dict.update({"ph_kl_loss": metrics.Mean()})
        if self._config.get("enable_style_vae_kl_loss", False):
            metrics_dict.update({"style_vae_kl_loss": metrics.Mean()})
        if self._config.get("enable_adversarial_loss", False):
            metrics_dict.update({"adversarial_loss": metrics.Mean()})
            metrics_dict.update({"wasserstein_dist": metrics.Mean()})
        if self._config.get("enable_singing_loss", False):
            metrics_dict.update({"power_loss": metrics.Mean()})
            metrics_dict.update({"tilt_loss": metrics.Mean()})
        if self._config.get("new_voice_generation", False):
            metrics_dict.update(
                {
                    "spk_encdec_loss": metrics.Mean(),
                    "spk_cycle_loss": metrics.Mean(),
                    "attri_loss": metrics.Mean(),
                    "gender_loss": metrics.Mean(),
                    "age_loss": metrics.Mean(),
                }
            )
            if self._config.get('model_attri_distribution', False):
                metrics_dict.update({'log_like_loss': metrics.Mean()})

        if self._config.get('enable_cross_lingual_spk_loss', False):
            metrics_dict.update({'cross_spk_loss': metrics.Mean()})

        self.distil = self._config.get("distil", "")
        if self.distil.startswith("full"):
            distil_tgt_spk = str(self._config.get("distil_tgt_spk", "")).strip()
            self.distil_tgt_spk = [int(i) for i in distil_tgt_spk.split("-") if len(i) > 0]
            distil_tgt_style = str(self._config.get("distil_tgt_style", "")).strip()
            self.distil_tgt_style = [int(i) for i in distil_tgt_style.split("-") if len(i) > 0]
            distil_tgt_locale = str(self._config.get("distil_tgt_locale", "")).strip()
            self.distil_tgt_locale = [int(i) for i in distil_tgt_locale.split("-") if len(i) > 0]
            self.enable_distil_t2t = self._config.get("enable_distil_t2t", False)
            self.enable_t2t_scale_mel = self._config.get("enable_t2t_scale_mel", False)

        if self.distil.endswith("_decoder"):
            if self.distil == "offline_decoder":
                assert os.path.exists(self.warm_start_from)

            self.shardw = self._config.get("shardw", 0.1)
            self.ssoftw = self._config.get("ssoftw", 1.0)

            metrics_dict.update({"sloss_hard": metrics.Mean()})
            metrics_dict.update({"sloss_soft": metrics.Mean()})

        if self._config.get("enable_retrain_phnpred", False):
            metrics_dict.update({"spitch_loss": metrics.Mean()})
            metrics_dict.update({"sdur_loss": metrics.Mean()})
            metrics_dict.update({"sph_emb_loss": metrics.Mean()})

        if self._config.get("enable_hard_loss", False):
            metrics_dict.update({"loss_hard": metrics.Mean()})
            metrics_dict.update({"loss_soft": metrics.Mean()})

        if self.distil.startswith("full"):
            if self._config.get("encoder_hidden_constraint", False):
                metrics_dict.update({"encoder_hidden_loss": metrics.Mean()})

            if self._config.get("att_constraint", False):
                metrics_dict.update({"att_dec_loss": metrics.Mean()})
                metrics_dict.update({"att_enc_loss": metrics.Mean()})

        if self._config.get("enable_frame_pitch_loss", False):
            metrics_dict.update({"bce_loss_quantized_f0": metrics.Mean()})
            metrics_dict.update({"frame_level_accuracy": metrics.Mean()})
            if self._config.get("enable_quant2cont_pitch_loss", False):
                metrics_dict.update({"l1l2_loss_frame_pitch": metrics.Mean()})

        if self._config.get("enable_emotion_encoder", False):
            metrics_dict.update({"emt_loss": metrics.Mean(),
                                 "spk_loss": metrics.Mean(),
                                 "locale_loss": metrics.Mean()})

        return metrics_dict

    def configure_criteria(self):
        criteria = {
            "l1_loss": torch.nn.L1Loss(reduction="mean"),
            "l2_loss": torch.nn.MSELoss(reduction="mean"),
            "dur_loss": DurationPredictorLoss(reduction="mean"),
            "style_vae_kl_loss": "self-defined",
            "adversarial_loss": "self-defined",
            "wasserstein_dist": "self-defined",
            'ce_loss': torch.nn.CrossEntropyLoss(ignore_index=-1),
            "cross_entropy_loss": torch.nn.CrossEntropyLoss(reduction="mean")
        }
        return criteria

    def train_hooks(self):
        hooks = []
        if self._config.get("distil", "").endswith("_decoder"):
            # initialize sdecoder params from pretrained model
            sdecoder_refine_from = self._config.get("sdecoder_refine_from", None)
            sdecoder_refine_id = self._config.get("sdecoder_refine_id", "")
            if sdecoder_refine_from is not None:
                hooks.append(SdecoderLoadHook(sdecoder_refine_from, sdecoder_refine_id))
        if self._config.get("distil", "").startswith("full"):
            # load teacher model for full model distil
            fd_refine_from = self._config.get("fd_refine_from", None)
            fd_refine_id = self._config.get("fd_refine_id", "")

            if fd_refine_from is not None:
                if self._config.get("distil", "") == "full_tiny":
                    hooks.append(FullDistilTinyLoadHook(fd_refine_from))
                else:
                    hooks.append(FullDistilLoadHook(fd_refine_from, fd_refine_id))

            if not self.enable_distil_t2t:
                teacher_config_file = self._config.get("teacher_config", None)
                teacher_model_path = self._config.get("teacher_model_path", None)
                enable_teacher_infer = self._config.get("enable_teacher_infer", False)
                hooks.append(TeacherLoadHook(teacher_model_path, teacher_config_file, enable_teacher_infer))
        return hooks

    def teacher_inference(self, batch):
        if len(self.distil_tgt_spk) > 0:
            # only use teacher data to distil a speaker w/o gt-mel
            if batch.get("speaker_id", None) is not None:
                for i in range(len(batch["speaker_id"])):
                    batch["speaker_id"][i] = random.sample(self.distil_tgt_spk, 1)[0]
        if len(self.distil_tgt_style) > 0:
            if batch.get("style_id", None) is not None:
                for i in range(len(batch["style_id"])):
                    batch["style_id"][i] = random.sample(self.distil_tgt_style, 1)[0]
        if len(self.distil_tgt_locale) > 0:
            if batch.get("locale_id", None) is not None:
                for i in range(len(batch["locale_id"])):
                    batch["locale_id"][i] = random.sample(self.distil_tgt_locale, 1)[0]
        if self.enable_distil_t2t:
            if self.enable_t2t_scale_mel:
                batch["mel"] = batch["mel"] * 8.0 - 4.0
            teacher_out = (
                batch["mel"],
                None,
                None,
                None,
                batch["phone_f0"].unsqueeze(-1),
                batch["phone_f0"].unsqueeze(-1),
                None,
                None,
                None,
                batch["phone_energy"].unsqueeze(-1),
                batch["phone_energy"].unsqueeze(-1),
                None,
                batch["duration"],
                None,
            )
            ref_prosody = None
            ph_hs = None
        else:
            with torch.no_grad():
                if not self._config.get("enable_teacher_infer", False):
                    teacher_out = self.teacher_model(
                        xs=batch["phone_id"],
                        ilens=batch["phone_id_length"],
                        ys=batch["mel"],
                        olens=batch.get("mel_length", None),
                        ds=batch["duration"],
                        f0=batch.get("phone_f0", None),
                        speaker_id=batch.get("speaker_id", None),
                        lang_id=batch.get("locale_id", None),
                        style_id=batch.get("style_id", None),
                        energy=batch.get("phone_energy", None),
                        mode="eval",
                    )
                else:
                    teacher_out = self.teacher_model(
                        phone_id=batch["phone_id"],
                        speaker_id=batch.get("speaker_id", None),
                        lang_id=batch.get("locale_id", None),
                        style_id=batch.get("style_id", None),
                        mode="infer",
                        ilens=batch["phone_id_length"],
                    )

                (
                    ys,
                    d_outs,
                    pred_prosody,
                    ref_prosody,
                    ps,
                    p_outs,
                    ph_hs,
                    ph_emb_pred,
                    kl_tuple,
                    es,
                    e_outs,
                    _,
                    ds,
                    t_encoder_hidden_tuple,
                ) = teacher_out
                ref_prosody = ref_prosody.unsqueeze(1).detach() if ref_prosody is not None else ref_prosody
                ph_hs = ph_hs.detach() if ph_hs is not None else ph_hs
                batch["mel"] = ys[-1]
                batch["mel_length"] = torch.sum(ds, dim=1)
                batch["duration"] = ds
                batch["phone_f0"] = ps.squeeze(-1) if ps is not None else ps
                batch["phone_energy"] = es.squeeze(-1) if es is not None else es
        return batch, teacher_out, ref_prosody, ph_hs

    @staticmethod
    def get_slayer_id(tnum, snum):
        # for distillation, get student-teacher layer id mapping to calculate soft loss
        # tnum: teacher layer num
        # snum: student layer num
        n = tnum / snum
        nlist = [n * (i + 1) for i in range(snum)]
        return [int(i) - 1 for i in nlist]


class TeacherLoadHook(Hook):
    def __init__(self, model_path, config_file, enable_teacher_infer):
        super().__init__(order=HookOrder.LOGGING + 1, node=HookNode.ALL)
        self.model_path = model_path
        if not os.path.exists(model_path):
            raise ValueError("teacher model doesn't exist: {}".format(model_path))
        self.config_file = config_file
        if not os.path.exists(config_file):
            raise ValueError("teacher config file not exist: {}".format(config_file))
        self.enable_teacher_infer = enable_teacher_infer

    def on_start(self, trainer):
        teacher_config = DictConfig(yaml.load(open(self.config_file, "r"), Loader=yaml.FullLoader))
        teacher_model = models.build_model(teacher_config)
        print("Loading teacher model from", self.model_path)
        checkpoint = torch.load(self.model_path, map_location=trainer.engine.device)["model"]
        teacher_model.load_state_dict(checkpoint)
        teacher_model = trainer.engine.setup_model(teacher_model)
        if self.enable_teacher_infer:
            trainer.teacher_model = teacher_model.module.inference_style_transfer
        else:
            trainer.teacher_model = teacher_model.eval()


class SdecoderLoadHook(Hook):
    def __init__(self, sdecoder_refine_from, sdecoder_refine_id):
        super().__init__(order=HookOrder.LOGGING + 1, node=HookNode.ALL)
        self.sdecoder_refine_from = sdecoder_refine_from
        self.sdecoder_refine_id = sdecoder_refine_id

    def on_start(self, trainer):
        checkpoint = torch.load(self.sdecoder_refine_from, map_location=trainer.engine.device)
        layer_id = str(self.sdecoder_refine_id).split("_")
        weight_name = ["decoder.encoders", "decoder_proj", "output_layers"]
        s_dict = {}
        for k, v in checkpoint["model"].items():
            for i, lid in enumerate(layer_id):
                for wn in weight_name:
                    if wn + "." + lid in k:
                        print(k + "->" "s" + k.replace("." + lid + ".", "." + str(i) + "."))
                        s_dict["s" + k.replace("." + lid + ".", "." + str(i) + ".")] = v

        trainer.engine._load_state_dict(trainer.model, s_dict, strict=False)


class FullDistilTinyLoadHook(Hook):
    def __init__(self, fd_refine_from):
        super().__init__(order=HookOrder.LOGGING + 1, node=HookNode.ALL)
        self.fd_refine_from = fd_refine_from

    def on_start(self, trainer):
        checkpoint = torch.load(self.fd_refine_from, map_location=trainer.engine.device)
        exclude_load_weight_name = [
            "gst.encoder",
            "gst.stl",
            "spec_enc",
            "ph_spec_att",
            "spec_encoder",
            "pitch_predictor",
            "duration_predictor",
        ]
        restore_weight_name = ["symbol_embedding"]
        s_dict = {}
        for k, v in checkpoint["model"].items():
            short_k = ".".join(k.split(".")[:2])
            short_k_2 = k.split(".")[0]
            if short_k in exclude_load_weight_name or short_k_2 in exclude_load_weight_name:
                print("exclude:", k)
                continue
            elif short_k in restore_weight_name or short_k_2 in restore_weight_name:
                print("load:", k)
                s_dict[k] = v
        trainer.engine._load_state_dict(trainer.model, s_dict, strict=False)


class FullDistilLoadHook(Hook):
    def __init__(self, fd_refine_from, fd_refine_id):
        super().__init__(order=HookOrder.LOGGING + 1, node=HookNode.ALL)
        self.fd_refine_from = fd_refine_from
        self.fd_refine_id = fd_refine_id

    def on_start(self, trainer):
        checkpoint = torch.load(self.fd_refine_from, map_location=trainer.engine.device)
        layer_id = str(self.fd_refine_id).split("_")
        weight_name = ["decoder.encoders", "decoder_proj", "output_layers"]
        exclude_load_weight_name = ["gst.encoder", "gst.stl", "spec_enc", "ph_spec_att", "spec_encoder"]
        s_dict = {}
        for k, v in checkpoint["model"].items():
            short_k = ".".join(k.split(".")[:2])
            short_k_2 = k.split(".")[0]
            if short_k in weight_name or short_k_2 in weight_name:
                for i, lid in enumerate(layer_id):
                    for wn in weight_name:
                        if wn + "." + lid in k:
                            print(k + "->" + k.replace("." + lid + ".", "." + str(i) + "."))
                            s_dict[k.replace("." + lid + ".", "." + str(i) + ".")] = v

            elif short_k in exclude_load_weight_name or short_k_2 in exclude_load_weight_name:
                print("exclude:", k)
                continue
            else:
                print("load:", k)
                s_dict[k] = v
        trainer.engine._load_state_dict(trainer.model, s_dict, strict=False)

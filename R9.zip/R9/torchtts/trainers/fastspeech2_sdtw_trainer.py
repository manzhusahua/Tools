import logging
import re
import torch

from torchtts.nn.criterions import GuidedMultiHeadAttentionLoss
from torchtts.nn.criterions import SequenceLoss
from torchtts.nn.criterions import SoftDynamicTimeWarping
from torchtts.nn.optim.lr_schedulers import NoamLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.utils.torch_utils import unwrap_ddp

logger = logging.getLogger(__name__)


class FastSpeech2SDTWTrainer(Trainer):
    def train_step(self, batch):
        with self.engine.context():
            if self._config.get("soft_refine", False):
                prob = self.global_steps / self._config.get("max_steps", 1000000)
                sample = torch.distributions.bernoulli.Bernoulli(prob).sample().bool()
            else:
                sample = False
            (
                pred_mel,
                pred_dur_list,
                cross_att_list,
                pred_style_embedding,
                style_embedding,
                src_mask,
                tgt_mask,
                kl_tuple,
            ) = self.model(
                phone_id=batch["phone_id"],
                speaker_id=batch.get("speaker_id", None),
                locale_id=batch.get("locale_id", None),
                src_length=batch["phone_id_length"],
                duration=None,
                tgt_length=batch["mel_length"],
                reference=batch["mel"],
                phone_f0=None,
                use_pred_style_embedding=sample,
            )

            mel_loss = self.criteria["soft_dtw_mel_loss"](
                x=pred_mel,
                y=batch["mel"],
                x_mask=tgt_mask,
                y_mask=tgt_mask,
                save_alignment_flag=self.engine.is_master_process,
                global_steps=self.global_steps,
                cross_attention=cross_att_list,
            )

            dur_loss_list = []
            guided_att_loss_list = []
            self.len_pred_dur_list = len(pred_dur_list)

            for i in range(self.len_pred_dur_list):
                dur_loss_list.append(
                    self.criteria["total_dur_loss_" + str(i)](
                        torch.sum(pred_dur_list[i], dim=-1), target_seq=batch["mel_length"].float()
                    )
                )
                guided_att_loss = self.criteria["guided_att_loss_" + str(i)](
                    att_ws=cross_att_list[i].unsqueeze(1),
                    ilens=batch["phone_id_length"],
                    olens=batch["mel_length"].long(),
                )
                guided_att_loss_list.append(guided_att_loss)

            dur_loss_weight = self._config.get("duration_loss_weight", 1)

            style_embed_loss = self.criteria["style_embed_loss"](
                input_seq=pred_style_embedding, target_seq=style_embedding, mask=src_mask.unsqueeze(-1)
            )
            sty_loss_weight = self._config.get("style_embedding_loss_weight", 0.1)
            style_embed_loss *= sty_loss_weight

            loss = mel_loss + style_embed_loss
            for i in range(self.len_pred_dur_list):
                loss += dur_loss_weight * dur_loss_list[i]
                loss += guided_att_loss_list[i]

            if self._config.get("enable_phone_kl_loss", False):
                ph_kl_mask = src_mask.unsqueeze(-1)
                z_mu, z_log_sigma2 = kl_tuple
                masked_z_mu = z_mu.masked_select(ph_kl_mask)
                masked_z_log_sigma2 = z_log_sigma2.masked_select(ph_kl_mask)  # [BT, D]
                start_weight = 0
                end_weight = self._config.get("ph_kl_loss_weight", 1e-4)
                linear_increasing_start = self._config.get("max_steps", 1000000) / 100
                linear_increasing_end = self._config.get("max_steps", 1000000) / 10
                if self.global_steps <= linear_increasing_start:
                    final_weight = 0
                elif linear_increasing_start < self.global_steps <= linear_increasing_end:
                    position = linear_increasing_end - self.global_steps
                    interval = linear_increasing_end - linear_increasing_start - 1
                    final_weight = end_weight - (end_weight - start_weight) * position / interval
                else:
                    final_weight = end_weight

                ph_kl_loss = (
                    torch.mean(
                        torch.sum(
                            -0.5 * (1 + masked_z_log_sigma2 - masked_z_mu**2 - torch.exp(masked_z_log_sigma2)),
                            dim=-1,
                        )
                    )
                    * final_weight
                )

                loss += ph_kl_loss

        # Exits the context manager before optimize step
        self.engine.optimize_step(loss=loss, optimizer=self.optimizers, lr_scheduler=self.lr_schedulers)

        # Update metrics
        self.metrics["soft_dtw_mel_loss"].update_state(mel_loss)
        for i in range(self.len_pred_dur_list):
            self.metrics["total_dur_loss_" + str(i)].update_state(dur_loss_list[i])
            self.metrics["guided_att_loss_" + str(i)].update_state(guided_att_loss_list[i])

        self.metrics["style_embed_loss"].update_state(style_embed_loss)
        if self._config.get("enable_phone_kl_loss", False):
            self.metrics["ph_kl_loss"].update_state(ph_kl_loss)
        self.metrics["loss"].update_state(loss)

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def configure_optimizers(self):
        if self._config.get("enable_partial_refine", False):
            pattern = re.compile("(^embedding|weight_proj|bias_proj)")
            partial_params = []
            for name, param in self.model.named_parameters():
                if re.search(pattern, name):
                    partial_params.append(param)
                else:
                    param.requires_grad_(False)
            parameters = partial_params
        else:
            parameters = self.model.parameters()

        optimizer = torch.optim.Adam(parameters, betas=(0.9, 0.997), eps=1e-9)
        return optimizer

    def configure_lr_schedulers(self):
        return NoamLR(
            optimizer=self.optimizers,
            model_size=384,
            warmup_steps=self._config.get("warmup_steps", 8000),
            factor=self._config.get("lr_factor", 2.0),
        )

    def configure_criteria(self):
        criteria = {
            "soft_dtw_mel_loss": SoftDynamicTimeWarping(
                penalty=self._config.get("soft_dtw_penalty", 1.0),
                gamma=self._config.get("soft_dtw_gamma", 0.01),
                bandwidth=self._config.get("soft_dtw_bandwidth", 120),
                dist_func=self._config.get("soft_dtw_dist_func", "manhattan"),
                average_alignment_save_path=self.save_path,
                device=self._config.get("device", "cuda"),
            )
        }

        dec_layers = unwrap_ddp(self.model).dec_layers if unwrap_ddp(self.model).enable_soft_decoder else 0
        criteria_total_dur_loss_list = {
            "total_dur_loss_" + str(i): SequenceLoss("l1_loss", use_masking=False) for i in range(dec_layers + 1)
        }

        criteria_guided_att_loss_list = {
            "guided_att_loss_" + str(i): GuidedMultiHeadAttentionLoss(sigma=0.4, alpha=1.0, reset_always=True)
            for i in range(dec_layers + 1)
        }

        criteria.update(criteria_total_dur_loss_list)
        criteria.update(criteria_guided_att_loss_list)
        criteria.update({"style_embed_loss": SequenceLoss("mse_loss", use_masking=True)})

        if self._config.get("enable_phone_kl_loss", False):
            criteria.update({"ph_kl_loss": "self-defined"})

        return criteria

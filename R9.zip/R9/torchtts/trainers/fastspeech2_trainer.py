import logging
import re
import torch

from torchtts.nn.criterions import SequenceLoss
from torchtts.nn.optim.lr_schedulers import NoamLR
from torchtts.trainers.base_trainer import Trainer

logger = logging.getLogger(__name__)


class FastSpeech2Trainer(Trainer):
    def train_step(self, batch):
        with self.engine.context():
            (
                pred_mel,
                pred_dur,
                pred_phone_f0,
                pred_style_embedding,
                style_embedding,
                src_mask,
                tgt_mask,
            ) = self.model(
                phone_id=batch["phone_id"],
                speaker_id=batch.get("speaker_id", None),
                locale_id=batch.get("locale_id", None),
                src_length=batch["phone_id_length"],
                duration=batch["duration"],
                tgt_length=batch["mel_length"],
                reference=batch["mel"],
                phone_f0=batch["phone_f0"],
            )

            # Use masked mse loss for mel
            mel_loss = self.criteria["mel_loss"](
                input_seq=pred_mel, target_seq=batch["mel"], mask=tgt_mask.unsqueeze(-1)
            )
            # Use masked mse loss for duration
            dur_loss = self.criteria["dur_loss"](
                input_seq=pred_dur, target_seq=torch.log1p(batch["duration"].float()), mask=src_mask
            )
            dur_loss_weight = self._config.get("duration_loss_weight", 0.1)
            dur_loss *= dur_loss_weight

            phone_f0_loss = self.criteria["phone_f0_loss"](
                input_seq=pred_phone_f0.squeeze(-1), target_seq=batch["phone_f0"], mask=src_mask
            )

            style_embed_loss = self.criteria["style_embed_loss"](
                input_seq=pred_style_embedding, target_seq=style_embedding, mask=src_mask.unsqueeze(-1)
            )
            style_embed_loss *= self._config.get("style_embedding_loss_weight", 0.1)

            loss = mel_loss + dur_loss + phone_f0_loss + style_embed_loss

        # Exits the context manager before optimize step
        self.engine.optimize_step(loss=loss, optimizer=self.optimizers, lr_scheduler=self.lr_schedulers)

        # Update metrics
        self.metrics["mel_loss"].update_state(mel_loss)
        self.metrics["dur_loss"].update_state(dur_loss)
        self.metrics["loss"].update_state(loss)
        self.metrics["phone_f0_loss"].update_state(phone_f0_loss)
        self.metrics["style_embed_loss"].update_state(style_embed_loss)

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def configure_optimizers(self):
        if self._config.get("enable_partial_refine", False):
            pattern = re.compile("(speaker_embedding|locale_embedding|weight_proj|bias_proj)")
            partial_params = []
            for name, param in self.model.named_parameters():
                if re.search(pattern, name):
                    partial_params.append(param)
                else:
                    param.requires_grad_(False)
            parameters = partial_params
        else:
            parameters = self.model.parameters()

        optimizer = torch.optim.Adam(parameters, betas=(0.9, 0.997), eps=1e-9)
        return optimizer

    def configure_lr_schedulers(self):
        return NoamLR(
            optimizer=self.optimizers,
            model_size=384,
            warmup_steps=self._config.get("warmup_steps", 8000),
            factor=self._config.get("lr_factor", 2.0),
        )

    def configure_criteria(self):
        criteria = {
            "mel_loss": SequenceLoss("mse_loss", use_masking=True),
            "dur_loss": SequenceLoss("mse_loss", use_masking=True),
            "phone_f0_loss": SequenceLoss("mse_loss", use_masking=True),
            "style_embed_loss": SequenceLoss("mse_loss", use_masking=True),
        }
        return criteria

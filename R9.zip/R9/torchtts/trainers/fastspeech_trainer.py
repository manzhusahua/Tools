import logging
import torch

from torchtts.nn.criterions import SequenceLoss
from torchtts.nn.optim.lr_schedulers import NoamLR
from torchtts.trainers.base_trainer import Trainer

logger = logging.getLogger(__name__)


class FastSpeechTrainer(Trainer):
    def train_step(self, batch):
        if self._config.get("enable_singing_vc", False):
            with self.engine.context():
                (pred_mel, tgt_mask) = self.model(
                    phone_id=batch["phone_id"],
                    job="singingvc",
                    speaker_id=batch.get("speaker_id", None),
                    locale_id=batch.get("locale_id", None),
                    style_id=batch.get("style_id", None),
                    src_length=batch["phone_id_length"],
                    duration=batch["duration"],
                    tgt_length=batch["mel_length"],
                    f0=batch.get("f0", None),
                    uv=batch.get("uv", None),
                )

                # Use masked mse loss for mel
                mel_loss = self.criteria["mel_loss"](
                    input_seq=pred_mel, target_seq=batch["mel"], mask=tgt_mask.unsqueeze(-1)
                )
                loss = mel_loss
            self.engine.optimize_step(
                loss=mel_loss, optimizer=self.optimizers["base"], lr_scheduler=self.lr_schedulers["base"]
            )
            self.metrics["mel_loss"].update_state(mel_loss)
            self.metrics["loss"].update_state(loss)
            return {k: m.result() for k, m in self.metrics.items()}
        else:
            with self.engine.context():
                if self._config.get("enable_pitch_loss", False):
                    if self._config.get("alternately_training", False):
                        alternately_step = self._config.get("alternately_step", 1000)
                        need_predict_pitch = self.global_steps // alternately_step % 2 != 0
                    else:
                        need_predict_pitch = True
                else:
                    need_predict_pitch = False

                (pred_mel, pred_dur, pred_f0, pred_uv, src_mask, tgt_mask) = self.model(
                    phone_id=batch["phone_id"],
                    speaker_id=batch.get("speaker_id", None),
                    locale_id=batch.get("locale_id", None),
                    style_id=batch.get("style_id", None),
                    src_length=batch["phone_id_length"],
                    duration=batch["duration"],
                    tgt_length=batch["mel_length"],
                    f0=batch.get("f0", None),
                    uv=batch.get("uv", None),
                    note_duration=batch.get("note_duration", None),
                    note_pitch=batch.get("note_pitch", None),
                    need_predict_pitch=need_predict_pitch,
                )

                # Use masked mse loss for mel
                mel_loss = self.criteria["mel_loss"](
                    input_seq=pred_mel, target_seq=batch["mel"], mask=tgt_mask.unsqueeze(-1)
                )
                # Use masked mse loss for duration
                dur_loss = self.criteria["dur_loss"](
                    input_seq=pred_dur, target_seq=torch.log1p(batch["duration"].float()), mask=src_mask
                )
                dur_loss_weight = self._config.get("duration_loss_weight", 0.1)
                dur_loss *= dur_loss_weight

                loss = mel_loss + dur_loss

                if need_predict_pitch:
                    f0_loss = self.criteria["f0_loss"](
                        input_seq=pred_f0.squeeze(-1), target_seq=batch["f0"], mask=tgt_mask
                    )
                    uv_loss = self.criteria["uv_loss"](
                        input_seq=pred_uv.squeeze(-1), target_seq=batch["uv"], mask=tgt_mask
                    )
                    pitch_loss_weight = self._config.get("pitch_loss_weight", 0.1)
                    f0_loss *= pitch_loss_weight
                    uv_loss *= pitch_loss_weight

                    loss += f0_loss + uv_loss

            # Exits the context manager before optimize step
            if need_predict_pitch:
                if self._config.get("alternately_training", False) or self._config.get("update_all_params", False):
                    self.engine.optimize_step(
                        loss=mel_loss + dur_loss + f0_loss + uv_loss,
                        optimizer=self.optimizers["base_and_pitch"],
                        lr_scheduler=self.lr_schedulers["base_and_pitch"],
                    )
                else:
                    self.engine.optimize_step(
                        loss=mel_loss + dur_loss + f0_loss + uv_loss,
                        optimizer=self.optimizers["pitch"],
                        lr_scheduler=self.lr_schedulers["pitch"],
                    )
            else:
                self.engine.optimize_step(
                    loss=mel_loss + dur_loss,
                    optimizer=self.optimizers["base"],
                    lr_scheduler=self.lr_schedulers["base"],
                )

            # Update metrics
            self.metrics["mel_loss"].update_state(mel_loss)
            self.metrics["dur_loss"].update_state(dur_loss)
            self.metrics["loss"].update_state(loss)

            if need_predict_pitch:
                self.metrics["f0_loss"].update_state(f0_loss)
                self.metrics["uv_loss"].update_state(uv_loss)

            # The return value will be stored as training logs.
            return {k: m.result() for k, m in self.metrics.items()}

    def configure_optimizers(self):
        base_params = []
        pitch_params = []
        for name, param in self.model.named_parameters():
            if "pitch" in name:
                pitch_params.append(param)
            else:
                base_params.append(param)

        if not self._config.get("enable_pitch_loss", False):
            optimizers = {"base": torch.optim.Adam(base_params, betas=(0.9, 0.997), eps=1e-9)}
        elif self._config.get("alternately_training", False):
            optimizers = {
                "base_and_pitch": torch.optim.Adam(base_params + pitch_params, betas=(0.9, 0.997), eps=1e-9),
                "base": torch.optim.Adam(base_params, betas=(0.9, 0.997), eps=1e-9),
            }
        elif self._config.get("update_all_params", False):
            optimizers = {"base_and_pitch": torch.optim.Adam(base_params + pitch_params, betas=(0.9, 0.997), eps=1e-9)}
        else:
            # Update only pitch contour related params
            for param in base_params:
                param.requires_grad_(False)
            optimizers = {"pitch": torch.optim.Adam(pitch_params, betas=(0.9, 0.997), eps=1e-9)}

        return optimizers

    def configure_lr_schedulers(self):
        if not self._config.get("enable_pitch_loss", False):
            return {"base": self.get_lr("base")}
        elif self._config.get("alternately_training", False):
            return {"base": self.get_lr("base"), "base_and_pitch": self.get_lr("base_and_pitch")}
        elif self._config.get("update_all_params", False):
            return {"base_and_pitch": self.get_lr("base_and_pitch")}
        else:
            return {"pitch": self.get_lr("pitch")}

    def get_lr(self, lr_name="base"):
        if lr_name not in {"base", "pitch", "base_and_pitch"}:
            raise ValueError("{} LR scheduler not supported".format(lr_name))
        return NoamLR(
            optimizer=self.optimizers[lr_name],
            model_size=384,
            warmup_steps=self._config.get("warmup_steps", 8000),
            factor=self._config.get("lr_factor", 2.0),
        )

    def configure_criteria(self):
        criteria = {
            "mel_loss": SequenceLoss("mse_loss", use_masking=True),
        }
        if not self._config.get("enable_singing_vc", False):
            criteria.update({"dur_loss": SequenceLoss("mse_loss", use_masking=True)})
        if self._config.get("enable_pitch_loss", False):
            criteria.update(
                {
                    "f0_loss": SequenceLoss("mse_loss", use_masking=True),
                    "uv_loss": SequenceLoss("mse_loss", use_masking=True),
                }
            )
        return criteria

import os
from itertools import chain
import logging

import librosa
import soundfile
import torch

from torchtts.nn.criterions import GANLoss
from torchtts.nn.criterions import MultiResolutionSTFTLoss
from torchtts.nn.criterions import mel_spectrogram_torch
from torchtts.nn.metrics import Mean
from torchtts.nn.modules.common.functional import make_non_pad_mask
from torchtts.nn.modules.conformer.ssim import ssim, mask_ssim
from torchtts.nn.optim.lr_schedulers import PowerLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.nn.optim import Ranger
from torchtts.nn.criterions.duration_loss import DurationPredictorLoss
from torchtts.nn.optim.lr_schedulers import ExponitialDecayLR
from torch.optim import Adam
from torch.optim import AdamW
from torchtts.utils.torch_utils import unwrap_ddp
from torchtts.hooks.moving_average import ExponentialMovingAverageHook
from torchtts.models.hifinet.pqmf import PQMF
from torchtts.models.hifinet.stft import TorchSTFT
import torch.nn.functional as F
from torchtts.nn.modules.codec.yin import pitch_estimater

logger = logging.getLogger(__name__)


class FoundationttsTrainer(Trainer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
        self.stft = TorchSTFT(filter_length=200, hop_length=100, win_length=200).to(self.device)
        self.pqmf_2 = PQMF(n_subband=2, taps=32, cutoff_ratio=0.283000000, beta=9.0).to(self.device)

    def de_accurancy(self, mel):
        """
        down sampling and up sampling to simulate the noise
        Args:
            mel:

        Returns:

        """
        ratio_time = 0.7
        ratio_fre = 0.7
        mel = mel.unsqueeze(0)
        org_shape = mel.shape
        mel = F.interpolate(mel, scale_factor=(ratio_fre, ratio_time), mode='bilinear', align_corners=True,
                            recompute_scale_factor=True)
        mel = F.interpolate(mel, size=(org_shape[2], org_shape[3]), mode='bilinear', align_corners=True)
        mel = mel.squeeze(0)
        return mel

    def train_step(self, batch):
        if "audio" not in batch:
            batch["audio"] = batch.get("speech", None)

        if self._config["training_stage"] == "codec":
            with self.engine.context():
                vq_emb, abs_loss, hid_in = self.model["codec_encoder"](
                    batch["audio"].unsqueeze(1),
                    abs_loss_func=self._config["abs_loss_func"],
                    range_func=self._config["range_func"],
                )

                y_, vq_loss = self.model["codec_decoder"](vq_emb, hid_in, self.global_steps, True, False)
                abs_loss = sum(abs_loss) if abs_loss is not None else None

                y = batch["audio"].unsqueeze(1)

            self.train_disc_step(y, y_)
            self.train_gen_step(y, y_, vq_loss, abs_loss)

        elif self._config["training_stage"] == "hifinet2":
            with self.engine.context():
                warmup_training = True
                wave_48k = batch['audio'].cpu().numpy()
                wave_24k = librosa.resample(wave_48k, orig_sr=48000, target_sr=24000,
                                            res_type="soxr_hq")
                wave_24k = torch.from_numpy(wave_24k).to(self.device)
                vq_emb, abs_loss, hid_in = self.model['codec_encoder'](wave_24k.unsqueeze(1))

                # introduce noise every even step
                if self.global_steps % 2 == 0:
                    vq_emb = vq_emb.to('cpu')
                    vq_emb_de = self.de_accurancy(vq_emb)
                    vq_emb = vq_emb_de

                if (warmup_training or self._config["use_sampling"]) and max(batch['mel_length']).item() > 30:

                    vq_seg, pred_vq_seg, y_seg = self.rand_slice_frame_wav_segments(batch, [vq_emb.transpose(1, 2)],
                                                                                    None,
                                                                                    batch['audio'], length=600)
                    y = y_seg.unsqueeze(1)
                else:
                    pred_vq_seg = vq_emb
                    y = batch['audio'].unsqueeze(1)
                y_24k, y_ = self.model['multibands_generator'](pred_vq_seg.detach())
                y = y.detach()

            self.train_disc_step(y, y_)
            self.train_hifinet2_step(y, y_)

            if self.global_steps % 10000 == 0:
                with torch.no_grad():
                    self.model["multibands_generator"].eval()
                    for i in range(min(5, pred_vq_seg.size()[0])):
                        pred_vq_seg = [vq_emb.transpose(1, 2)][-1].transpose(1, 2)
                        y_24k, y_test = self.model['multibands_generator'](pred_vq_seg.detach()[i].unsqueeze(0))
                        y_test_gt = batch['audio'][i].unsqueeze(0).unsqueeze(1)
                        save_dir = os.path.join(self.save_path, 'waves', str(self.global_steps))

                        os.makedirs(save_dir, exist_ok=True)

                        save_path = os.path.join(save_dir, '{}.wav'.format(i))
                        save_path_real = os.path.join(save_dir, '{}_real.wav'.format(i))
                        soundfile.write(save_path, y_test.squeeze().cpu().detach().numpy().T, samplerate=48000)
                        soundfile.write(save_path_real, y_test_gt.squeeze().cpu().detach().numpy().T, samplerate=48000)
                        i += 1
                    self.model["multibands_generator"].train()

        elif self._config["training_stage"] == "e2e":
            with self.engine.context():
                self.model["codec_encoder"] = self.model["codec_encoder"].eval()
                with torch.no_grad():
                    vq_emb, _, _ = self.model["codec_encoder"](
                        batch["audio"].unsqueeze(1),
                        abs_loss_func=self._config["abs_loss_func"],
                        range_func=self._config["range_func"],
                    )
                    post_vq_emb = self.model["codec_decoder"](vq_emb, return_after_vq=True, vq=True)
                post_vq_emb = post_vq_emb.detach()

                am_mode = "train-e2e"
                pred_vq, pred_dur, pred_prosody, ref_prosody, p_ref, p_pred, ph_emb, ph_emb_pred = self.run_am_step(
                    batch, am_mode
                )

                if self.global_steps < self._config["e2e_warmup_step"]:
                    am_loss = self.cal_am_loss(
                        batch, pred_dur, p_ref, p_pred, pred_prosody, ref_prosody, ph_emb, ph_emb_pred, pred_vq, post_vq_emb
                    )
                    self.engine.optimize_step(
                        loss=am_loss,
                        optimizer=self.optimizers["am"],
                        lr_scheduler=self.lr_schedulers["am"],
                    )
                    return {k: m.result() for k, m in self.metrics.items()}
                if self._config["use_sampling"] and max(batch["mel_length"]).item() > 40:
                    post_vq_emb_, pred_vq_seg, y_seg = self.rand_slice_frame_wav_segments(
                        batch, pred_vq, post_vq_emb, batch["audio"]
                    )
                    y = y_seg.unsqueeze(1)
                else:
                    pred_vq_seg = pred_vq[-1].transpose(1, 2)
                    y = batch["audio"].unsqueeze(1)
                    post_vq_emb_ = post_vq_emb

                y_ = self.model["codec_decoder"](pred_vq_seg, vq=False)
                if self._config["use_gt_audio"]:
                    y = y.detach()
                else:
                    y = self.model["codec_decoder"](post_vq_emb_, vq=False).detach()

            self.train_disc_step(y, y_)
            self.train_am_step(
                y,
                y_,
                batch,
                pred_dur,
                p_ref,
                p_pred,
                pred_prosody,
                ref_prosody,
                ph_emb,
                ph_emb_pred,
                pred_vq,
                post_vq_emb,
            )

        elif self._config["training_stage"] == "48k":
            with self.engine.context():
                self.model["codec_encoder"] = self.model["codec_encoder"].eval()
                self.model["codec_decoder"].module.quantizer = self.model["codec_decoder"].module.quantizer.eval()
                with torch.no_grad():
                    vq_emb, _, _ = self.model["codec_encoder"](
                        batch["audio"].unsqueeze(1),
                        abs_loss_func=self._config["abs_loss_func"],
                        range_func=self._config["range_func"],
                    )
                    x_frame, q_frame, frame_commit_loss = self.model["codec_decoder"].module.quantizer(vq_emb)
                    batch["audio8k_emb"] = x_frame.permute(0, 2, 1).detach()

                am_mode = "train-e2e"
                pred_vq, pred_dur, pred_prosody, ref_prosody, p_ref, p_pred, ph_emb, ph_emb_pred = self.run_am_step(
                    batch, mode=am_mode
                )
                x_frame_seg, pred_vq_seg, y_seg = self.rand_slice_frame_wav_segments(
                    batch, pred_vq, x_frame, batch["audio"], length=600
                )
                y_48k = y_seg.unsqueeze(1)
                pqmf = PQMF(n_subband=2, taps=32, cutoff_ratio=0.2829)
                bands = pqmf(y_48k.to("cpu"))
                y = bands[:, 1:2, :]
                y = y.to("cuda")
                y_seg = y.detach()
                y_24k, y_pred_seg = self.model["fullband_generator_tiny"](pred_vq_seg.detach())

                self.train_48k_step(y_seg, y_pred_seg)
                self.train_disc_step(y_seg, y_pred_seg)

        elif self._config["training_stage"] == "distill":
            stage_mode = self._config["stage_mode"]
            with self.engine.context():
                if self._config["semi_training"]:
                    batch["speaker_id"] = torch.ones_like(batch["phone_id_length"]) * self._config["target_spk_id"]
                if stage_mode == "full_distill":
                    t_pred_vq, t_dur_outs, ds, pred_vq, pred_dur, p_pred = self.run_am_step(batch, mode=stage_mode)
                    batch["mel_length"] = torch.sum(ds.detach(), dim=1)
                    soutputs = pred_vq
                    pred_vq = t_pred_vq
                    t_pitch_outs = batch.get("phone_f0", None).unsqueeze(-1)
                    vq_seg, pred_vq_seg, _ = self.rand_slice_frame_wav_segments(
                        batch, soutputs, pred_vq.transpose(1, 2)
                    )
                    y_ = self.model["codec_decoder"](pred_vq_seg, vq=False)
                    y = self.model["codec_decoder"](vq_seg, vq=False).detach()
                    self.train_disc_step(y, y_)
                    self.train_distill_step(batch, y, y_, pred_vq, soutputs, t_pitch_outs, p_pred, t_dur_outs, pred_dur)
                elif stage_mode == "distill":
                    pred_vq, soutputs, ds = self.run_am_step(batch, mode=stage_mode)
                    batch["mel_length"] = torch.sum(ds.detach(), dim=1)
                    self.train_distill_step(batch, t_out=pred_vq, s_out=soutputs)
                elif stage_mode == "voc_distill":
                    t_pred_vq, ds = self.run_am_step(batch, mode=stage_mode)
                    batch["mel_length"] = torch.sum(ds.detach(), dim=1)
                    soutputs = None
                    pred_vq = [t_pred_vq]
                    vq_seg, pred_vq_seg, _ = self.rand_slice_frame_wav_segments(batch, pred_vq, soutputs)
                    y_ = self.model["codec_decoder_student"](pred_vq_seg, vq=False)
                    y = self.model["codec_decoder"](pred_vq_seg, vq=False).detach()
                    self.train_disc_step(y, y_)
                    self.train_distill_step(batch, y, y_, mode=stage_mode)
        elif self._config["training_stage"] == "postprocess":
            if self._config["stage_mode"] == "pitch_tuning":
                pred_vq, spred_vq, pred_dur, spred_dur, p_pred, sp_pred, ph_emb_pred, sph_emb_pred = self.run_am_step(
                    batch, mode="train"
                )

                vq_seg, pred_vq_seg, _ = self.rand_slice_frame_wav_segments(batch, spred_vq, pred_vq.transpose(1, 2))
                y_ = self.model["codec_decoder"](pred_vq_seg, vq=False)
                y = self.model["codec_decoder"](vq_seg, vq=False).detach()
                self.train_disc_step(y, y_)
                self.train_pitch_tuning_step(
                    batch, y, y_, pred_vq, spred_vq, p_pred, sp_pred, pred_dur, spred_dur, ph_emb_pred, sph_emb_pred
                )
        else:
            logging.info("Unsupported recipe of foundationTTS!")

        return {k: m.result() for k, m in self.metrics.items()}

    def train_pitch_tuning_step(
            self,
            batch,
            y=None,
            y_=None,
            t_out=None,
            s_out=None,
            t_pitch=None,
            s_pitch=None,
            t_dur=None,
            s_dur=None,
            t_phem=None,
            s_phem=None,
            mode="distill",
    ):
        gen_loss = self.cal_gen_loss(y, y_)

        duration_masks = make_non_pad_mask(batch["phone_id_length"]).to(batch["phone_id"].device)
        d_outs = s_dur.masked_select(duration_masks)
        ds = t_dur.masked_select(duration_masks)
        duration_loss = self.criteria["l2_loss"](d_outs, ds) * self._config.get("duration_loss_weight", 0.1)
        self.metrics["dur_loss"].update_state(duration_loss)

        pitch_mask = duration_masks.unsqueeze(-1)
        p_pred = s_pitch.masked_select(pitch_mask)
        p_ref = t_pitch.masked_select(pitch_mask)
        pitch_loss = self.criteria["l2_loss"](p_pred, p_ref)
        self.metrics["pitch_loss"].update_state(pitch_loss)

        ph_emb_mask = duration_masks.unsqueeze(-1)
        ph_emb = t_phem.masked_select(ph_emb_mask)
        ph_emb_pred = s_phem.masked_select(ph_emb_mask)
        ph_emb_loss = self.criteria["l1_loss"](ph_emb_pred, ph_emb.detach())
        self.metrics["ph_emb_loss"].update_state(ph_emb_loss)

        out_masks = make_non_pad_mask(batch["mel_length"]).unsqueeze(-1).to(batch["phone_id"].device)
        masked_pred = [spec_.masked_select(out_masks) for spec_ in s_out]
        masked_ys = t_out.masked_select(out_masks)
        ys_losses = [self.criteria["l1_loss"](spec_, masked_ys) for spec_ in masked_pred]
        ys_loss = sum(ys_losses)
        self.metrics["vq_pred_loss"].update_state(ys_losses[-1])

        gen_loss = ys_loss + duration_loss + pitch_loss + ph_emb_loss + self._config["gen_loss_factor"] * gen_loss

        self.engine.optimize_step(
            loss=gen_loss, optimizer=self.optimizers["postprocess"], lr_scheduler=self.lr_schedulers["postprocess"]
        )

    def train_distill_step(
            self,
            batch,
            y=None,
            y_=None,
            t_out=None,
            s_out=None,
            t_pitch=None,
            s_pitch=None,
            t_dur=None,
            s_dur=None,
            mode="distill",
    ):
        gen_loss = 0.0
        if y is not None:
            gen_loss += self.cal_gen_loss(y, y_)
        if t_out is not None:
            duration_loss = 0.0
            pitch_loss = 0.0
            if t_dur is not None:
                duration_masks = make_non_pad_mask(batch["phone_id_length"]).to(batch["phone_id"].device)
                d_outs = s_dur.masked_select(duration_masks)
                ds = t_dur.masked_select(duration_masks)
                duration_loss = self.criteria["l2_loss"](d_outs, ds) * self._config.get("duration_loss_weight", 0.1)
                self.metrics["dur_loss"].update_state(duration_loss)

                pitch_mask = duration_masks.unsqueeze(-1)
                p_pred = s_pitch.masked_select(pitch_mask)
                p_ref = t_pitch.masked_select(pitch_mask)
                pitch_loss = self.criteria["l2_loss"](p_pred, p_ref)
                self.metrics["pitch_loss"].update_state(pitch_loss)

            out_masks = make_non_pad_mask(batch["mel_length"]).unsqueeze(-1).to(batch["phone_id"].device)
            masked_pred = [spec_.masked_select(out_masks) for spec_ in s_out]
            masked_ys = t_out.masked_select(out_masks)

            ys_losses = [self.criteria["l1_loss"](spec_, masked_ys) for spec_ in masked_pred]
            ys_loss = sum(ys_losses)
            self.metrics["vq_pred_loss"].update_state(ys_losses[-1])

            gen_loss = ys_loss + duration_loss + pitch_loss + self._config["gen_loss_factor"] * gen_loss

        if mode == "voc_distill":
            self.engine.optimize_step(loss=gen_loss, optimizer=self.optimizers["distill"])
        else:
            self.engine.optimize_step(
                loss=gen_loss, optimizer=self.optimizers["distill"], lr_scheduler=self.lr_schedulers["distill"]
            )

    def rand_slice_frame_wav_segments(self, batch, pred_vq, post_vq_emb, y=None, length=300):
        olens = batch.get("mel_length", None)
        rand_len = min(int(self._config["frame_num_scale_factor"] * min(olens)), self._config["joint_frame_len"])
        rand_ = torch.rand([pred_vq[-1].size(0)]).to(olens.device)
        rand_bos = (rand_ * (olens - rand_len)).int()

        vq_seg = None
        if post_vq_emb is not None:
            vq_seg = torch.zeros_like(post_vq_emb[:, :, :rand_len])
        pred_vq_seg = torch.zeros_like(pred_vq[-1].transpose(1, 2)[:, :, :rand_len])
        y_seg = None
        if y is not None:
            y_seg = torch.zeros_like(y[:, : rand_len * length])

        for i in range(pred_vq[-1].size(0)):
            if post_vq_emb is not None:
                vq_seg[i] = post_vq_emb[i, :, rand_bos[i]: rand_bos[i] + rand_len]
            pred_vq_seg[i] = pred_vq[-1].transpose(1, 2)[i, :, rand_bos[i]: rand_bos[i] + rand_len]
            if y is not None:
                y_seg[i] = y[i, rand_bos[i] * length: (rand_bos[i] + rand_len) * length]

        return vq_seg, pred_vq_seg, y_seg

    def cal_am_loss(
            self, batch, pred_dur, p_ref, p_pred, pred_prosody, ref_prosody, ph_emb, ph_emb_pred, pred_vq, vq_emb
    ):
        am_loss = 0.0
        duration_masks = make_non_pad_mask(batch["phone_id_length"]).to(batch["phone_id"].device)
        d_outs = pred_dur.masked_select(duration_masks)
        ds = batch["duration"].masked_select(duration_masks)
        duration_loss = self.criteria["dur_loss"](d_outs, ds) * self._config.get("duration_loss_weight", 0.1)
        self.metrics["dur_loss"].update_state(duration_loss)

        if self._config["use_wave_pitch_std_loss"] is True:
            pitch_std = -1. * self._config["pitch_std_factor"] * torch.mean(torch.std(p_pred.squeeze(-1), -1))
            am_loss += pitch_std
            self.metrics["pitch_std"].update_state(pitch_std)

        pitch_loss = 0.0
        if p_ref is not None:
            pitch_mask = duration_masks.unsqueeze(-1)
            p_pred = p_pred.masked_select(pitch_mask)
            p_ref = p_ref.masked_select(pitch_mask)
            pitch_loss = self.criteria["l2_loss"](p_pred, p_ref)
            self.metrics["pitch_loss"].update_state(pitch_loss)

        gst_loss = 0.0
        if pred_prosody is not None:
            gst_loss = self.criteria["l1_loss"](pred_prosody, ref_prosody.detach())
            self.metrics["gst_loss"].update_state(gst_loss)

        ph_emb_loss = 0.0
        if ph_emb is not None:
            ph_emb_mask = duration_masks.unsqueeze(-1)
            ph_emb = ph_emb.masked_select(ph_emb_mask)
            ph_emb_pred = ph_emb_pred.masked_select(ph_emb_mask)
            ph_emb_loss = self.criteria["l1_loss"](ph_emb_pred, ph_emb.detach())
            self.metrics["ph_emb_loss"].update_state(ph_emb_loss)

        mel_loss = 0.0
        if self._config["predict_mel"]:
            mel_layer = self._config["predict_mel_layer"]
            out_masks = make_non_pad_mask(batch["mel_length"]).unsqueeze(-1).to(batch["phone_id"].device)
            masked_pred_vq = [None] * mel_layer
            masked_pred_vq = masked_pred_vq + [vq_.masked_select(out_masks) for vq_ in pred_vq[mel_layer:]]
            masked_ys = vq_emb.permute(0, 2, 1).masked_select(out_masks)
            ys_losses = [self.criteria["l1_loss"](vq_, masked_ys) for vq_ in masked_pred_vq[mel_layer + 1:]]
            vq_pred_loss = sum(ys_losses)
            self.metrics["vq_pred_loss"].update_state(ys_losses[-1])

            masked_mel = batch["mel"].masked_select(out_masks)
            mel_losses = [self.criteria["l1_loss"](vq_, masked_mel) for vq_ in masked_pred_vq[mel_layer:mel_layer + 1]]
            mel_loss = sum(mel_losses)
            self.metrics["mel_loss"].update_state(mel_losses[-1])
        else:
            out_masks = make_non_pad_mask(batch["mel_length"]).unsqueeze(-1).to(batch["phone_id"].device)
            masked_pred_vq = [vq_.masked_select(out_masks) for vq_ in pred_vq]
            masked_ys = vq_emb.permute(0, 2, 1).masked_select(out_masks)
            ys_losses = [self.criteria["l1_loss"](vq_, masked_ys) for vq_ in masked_pred_vq]
            vq_pred_loss = sum(ys_losses)
            self.metrics["vq_pred_loss"].update_state(ys_losses[-1])

        m = mask_ssim(pred_vq[-1].shape, batch["mel_length"], dim=1).float().to(pred_vq[-1].device)
        pred_vq_ss, ys_ss = pred_vq[-1] * m, vq_emb.permute(0, 2, 1) * m
        ssim_loss = 1 - ssim(pred_vq_ss.unsqueeze(1), ys_ss.unsqueeze(1))
        self.metrics["ssim_loss"].update_state(ssim_loss)

        am_loss += vq_pred_loss + ssim_loss + duration_loss + pitch_loss + gst_loss + ph_emb_loss + mel_loss
        self.metrics["am_loss"].update_state(am_loss)

        return am_loss

    def cal_gen_loss(self, y, y_, vq_loss=None):
        gen_loss = 0.0

        if self._config["use_stft_loss"] and self.global_steps < self._config["stft_loss_steps"]:
            with self.engine.context():
                if self._config["use_wave_mel_loss"]:
                    y_mel = mel_spectrogram_torch(y.squeeze(1), 1200, 100, 24000, 300, 1200, 0.0, None)
                    y_hat_mel = mel_spectrogram_torch(y_.squeeze(1), 1200, 100, 24000, 300, 1200, 0.0, None)
                    loss_mel = F.l1_loss(y_mel, y_hat_mel)
                    gen_loss += loss_mel
                    self.metrics["wavemel_loss"].update_state(loss_mel)

                    f0_gt = pitch_estimater(y.squeeze(), sample_rate=24000, pitch_min=100, pitch_max=400)
                    f0_pred = pitch_estimater(y_.squeeze(), sample_rate=24000, pitch_min=100, pitch_max=400)
                    loss_f0 = F.l1_loss(f0_gt, f0_pred)
                    gen_loss += loss_f0
                    self.metrics["wavef0_loss"].update_state(loss_f0)
                else:
                    sc_loss, mag_loss = self.criteria["stft_loss"](y_.squeeze(1), y.squeeze(1))
                    gen_loss += sc_loss + mag_loss
                    self.metrics["sc_loss"].update_state(sc_loss)
                    self.metrics["mag_loss"].update_state(mag_loss)

        if self.global_steps >= self._config["disc_train_start_steps"]:
            with self.engine.context():
                adv_loss_list = []
                if "discriminator" in self.model:
                    p_ = self.model["discriminator"](y_)
                    for i in range(len(p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(p_[i][-1]))

                if "spec_discriminator" in self.model:
                    sd_p_ = self.model["spec_discriminator"](y_)
                    for i in range(len(sd_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(sd_p_[i][-1]))
                if "MPD_spec_discriminator" in self.model:
                    mpd_sd_p_ = self.model["MPD_spec_discriminator"](y_)
                    for i in range(len(mpd_sd_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(mpd_sd_p_[i][-1]))
                if "MSSTFT_discriminator" in self.model:
                    msstft_sd_p_, fmap_fake = self.model["MSSTFT_discriminator"](y_, ret_logits=True, ret_fmaps=True)
                    for i in range(len(msstft_sd_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(msstft_sd_p_[i]))

                adv_loss = sum(adv_loss_list) / len(adv_loss_list)
                gen_loss += adv_loss * self._config["lambda_adv"]

                self.metrics["adv_loss"].update_state(adv_loss)

            if self._config["use_feat_match_loss"]:
                with self.engine.context():
                    if "discriminator" in self.model:
                        fm_loss = 0.0
                        with torch.no_grad():
                            p = self.model["discriminator"](y)
                        for i in range(len(p_)):
                            for j in range(len(p_[i]) - 1):
                                fm_loss += self.criteria["fm_loss"](p_[i][j], p[i][j].detach())
                        fm_loss /= (i + 1) * (j + 1)
                        self.metrics["fm_loss"].update_state(fm_loss)
                        gen_loss += fm_loss * self._config["lambda_feat_match_loss"]

                    if "spec_discriminator" in self.model:
                        spec_fm_loss = 0.0
                        with torch.no_grad():
                            sd_p = self.model["spec_discriminator"](y)
                        for i in range(len(sd_p_)):
                            for j in range(len(sd_p_[i]) - 1):
                                spec_fm_loss += self.criteria["fm_loss"](sd_p_[i][j], sd_p[i][j].detach())
                        spec_fm_loss /= (i + 1) * (j + 1)

                        self.metrics["spec_fm_loss"].update_state(spec_fm_loss)
                        gen_loss += spec_fm_loss * self._config["lambda_feat_match_loss"]
                    if "MPD_spec_discriminator" in self.model:
                        mpd_spec_fm_loss = 0.0
                        with torch.no_grad():
                            mpd_sd_p = self.model["MPD_spec_discriminator"](y)
                        for i in range(len(mpd_sd_p_)):
                            for j in range(len(mpd_sd_p_[i]) - 1):
                                mpd_spec_fm_loss += self.criteria["fm_loss"](mpd_sd_p_[i][j], mpd_sd_p[i][j].detach())
                        mpd_spec_fm_loss /= (i + 1) * (j + 1)

                        self.metrics["mpd_spec_fm_loss"].update_state(mpd_spec_fm_loss)
                        gen_loss += mpd_spec_fm_loss * self._config["lambda_feat_match_loss"]
                    if "MSSTFT_discriminator" in self.model:
                        msstft_fm_loss = 0.
                        with torch.no_grad():
                            _, fmap_real = self.model["MSSTFT_discriminator"](y, ret_logits=False, ret_fmaps=True)
                        for i in range(len(fmap_real)):
                            for j in range(len(fmap_real[i])):
                                msstft_fm_loss += self.criteria["fm_loss"](fmap_fake[i][j], fmap_real[i][j].detach())
                        msstft_fm_loss /= (i + 1) * (j + 1)

                        self.metrics["msstft_fm_loss"].update_state(msstft_fm_loss)
                        gen_loss += msstft_fm_loss * self._config["lambda_feat_match_loss"]

        if vq_loss is not None:
            gen_loss += sum(vq_loss)
            self.metrics["vq_loss"].update_state(sum(vq_loss))
        self.metrics["gen_loss"].update_state(gen_loss)

        return gen_loss

    def run_am_step(self, batch, mode="train-e2e"):
        model_output = self.model["acoustic_model"](
            xs=batch["phone_id"],
            ilens=batch["phone_id_length"],
            ys=batch["mel"],
            olens=batch.get("mel_length", None),
            ds=batch["duration"],
            f0=batch.get("phone_f0", None),
            speaker_id=batch.get("speaker_id", None),
            lang_id=batch.get("locale_id", None),
            style_id=batch.get("style_id", None),
            energy=batch.get("phone_energy", None),
            mode=mode,
        )

        if mode == "eval-e2e":
            pred_vq, olens = model_output
            return pred_vq, olens
        elif mode == "distill":
            pred_vq, soutputs, ds = model_output
            return pred_vq, soutputs, ds
        elif mode == "full_distill":
            t_pred_vq, t_dur_outs, ds = model_output
            student_model_output = self.model["acoustic_model_student"](
                xs=batch["phone_id"],
                ilens=batch["phone_id_length"],
                ys=None,
                olens=torch.sum(ds.detach(), dim=1),
                ds=ds.detach(),
                f0=None,
                speaker_id=batch.get("speaker_id", None),
                lang_id=batch.get("locale_id", None),
                style_id=batch.get("style_id", None),
                energy=batch.get("phone_energy", None),
                mode="semi",
            )
            (pred_vq, pred_dur, _, _, _, p_pred, _, _) = student_model_output

            return t_pred_vq, t_dur_outs, ds, pred_vq, pred_dur, p_pred
        elif mode == "voc_distill":
            t_pred_vq, ds = model_output
            return t_pred_vq, ds
        elif mode == "semi":
            (pred_vq, pred_dur, pred_prosody, ref_prosody, p_ref, p_pred, ph_emb, ph_emb_pred) = model_output
            return pred_vq, pred_dur, pred_prosody, ref_prosody, p_ref, p_pred, ph_emb, ph_emb_pred
        elif mode == "train-e2e":
            (pred_vq, pred_dur, pred_prosody, ref_prosody, p_ref, p_pred, ph_emb, ph_emb_pred) = model_output
            return pred_vq, pred_dur, pred_prosody, ref_prosody, p_ref, p_pred, ph_emb, ph_emb_pred
        elif mode == "train":
            (
                pred_vq,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb_hs,
                ph_emb_pred,
                kl_tuple,
                es,
                e_outs,
                soutputs,
                ds,
                encoder_hidden_tuple,
            ) = model_output
            if self._config["stage_mode"] == "pitch_tuning":
                spred_mel, sp_pred, spred_dur, sph_emb_pred = soutputs
                return pred_vq[-1], spred_mel, pred_dur, spred_dur, p_pred, sp_pred, ph_emb_pred, sph_emb_pred
            return (
                pred_vq,
                pred_dur,
                pred_prosody,
                ref_prosody,
                p_ref,
                p_pred,
                ph_emb_hs,
                ph_emb_pred,
                kl_tuple,
                es,
                e_outs,
                soutputs,
                ds,
            )
        else:
            logging.info("Unsupported AM running mode!")

    def train_semi_step(self, batch):
        if self.global_steps >= self._config["semi_train_start_steps"]:
            with self.engine.context():
                batch["speaker_id"] = torch.ones_like(batch["phone_id_length"]) * self._config["target_spk_id"]
                pred_vq, olens = self.run_am_step(batch, mode="eval-e2e")

                rand_len = min(
                    int(self._config["frame_num_scale_factor"] * min(olens)), self._config["joint_frame_len"]
                )
                rand_ = torch.rand([pred_vq.size(0)]).to(olens.device)
                rand_bos = (rand_ * (olens - rand_len)).int()

                pred_vq_seg = torch.zeros_like(pred_vq.transpose(1, 2)[:, :, :rand_len])

                for i in range(pred_vq.size(0)):
                    pred_vq_seg[i] = pred_vq.transpose(1, 2)[i, :, rand_bos[i]: rand_bos[i] + rand_len]

                y_ = self.model["codec_decoder"](pred_vq_seg, None, 10000, vq=False)

            with self.engine.context():
                p_ = self.model["discriminator"](y_.detach())

                fake_loss_list = []
                for i in range(len(p_)):
                    fake_loss_list.append(self.criteria["gan_loss"].disc_fake_loss(p_[i][-1]))

                if "spec_discriminator" in self.model:
                    sd_p_ = self.model["spec_discriminator"](y_.detach())
                    for i in range(len(sd_p_)):
                        fake_loss_list.append(self.criteria["gan_loss"].disc_fake_loss(sd_p_[i][-1]))

                if "MPD_spec_discriminator" in self.model:
                    mpd_sd_p_ = self.model["MPD_spec_discriminator"](y_.detach())
                    for i in range(len(mpd_sd_p_)):
                        fake_loss_list.append(self.criteria["gan_loss"].disc_fake_loss(mpd_sd_p_[i][-1]))

                fake_loss = sum(fake_loss_list) / len(fake_loss_list)
            self.metrics["semi_fake_loss"].update_state(fake_loss)
            self.engine.optimize_step(loss=fake_loss, optimizer=self.optimizers["disc"])

            with self.engine.context():
                p_ = self.model["discriminator"](y_)

                adv_loss_list = []
                for i in range(len(p_)):
                    adv_loss_list.append(self.criteria["gan_loss"].gen_loss(p_[i][-1]))

                if "spec_discriminator" in self.model:
                    sd_p_ = self.model["spec_discriminator"](y_)
                    for i in range(len(sd_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(sd_p_[i][-1]))

                if "MPD_spec_discriminator" in self.model:
                    mpd_sd_p_ = self.model["MPD_spec_discriminator"](y_)
                    for i in range(len(mpd_sd_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(mpd_sd_p_[i][-1]))

                adv_loss = sum(adv_loss_list) / len(adv_loss_list)
                gen_loss = adv_loss * self._config["lambda_adv"]
            self.metrics["semi_gen_loss"].update_state(gen_loss)
            self.engine.optimize_step(
                loss=self._config["gen_loss_factor"] * gen_loss,
                optimizer=self.optimizers["e2e"],
                lr_scheduler=self.lr_schedulers["e2e"],
            )

    def train_e2e_step(
            self, y, y_, batch, pred_dur, p_ref, p_pred, pred_prosody, ref_prosody, ph_emb, ph_emb_pred, pred_vq, vq_emb
    ):
        gen_loss = self.cal_gen_loss(y, y_)
        am_loss = self.cal_am_loss(
            batch, pred_dur, p_ref, p_pred, pred_prosody, ref_prosody, ph_emb, ph_emb_pred, pred_vq, vq_emb
        )

        self.engine.optimize_step(
            loss=am_loss + self._config["gen_loss_factor"] * gen_loss,
            optimizer=self.optimizers["e2e"],
            lr_scheduler=self.lr_schedulers["e2e"],
        )

    def train_hifinet2_step(self, y, y_):
        gen_loss = self.cal_gen_loss(y, y_)

        self.engine.optimize_step(loss=self._config["gen_loss_factor"] * gen_loss,
                                  optimizer=self.optimizers['hifinet2'],
                                  lr_scheduler=self.lr_schedulers['hifinet2'])

    def train_48k_step(self, y, y_):
        gen_loss = self.cal_gen_loss(y, y_)

        self.engine.optimize_step(
            loss=self._config["gen_loss_factor"] * gen_loss,
            optimizer=self.optimizers["48k"],
            lr_scheduler=self.lr_schedulers["48k"],
        )

    def train_am_step(
            self, y, y_, batch, pred_dur, p_ref, p_pred, pred_prosody, ref_prosody, ph_emb, ph_emb_pred, pred_vq, vq_emb
    ):
        gen_loss = self.cal_gen_loss(y, y_)
        am_loss = self.cal_am_loss(
            batch, pred_dur, p_ref, p_pred, pred_prosody, ref_prosody, ph_emb, ph_emb_pred, pred_vq, vq_emb
        )

        self.engine.optimize_step(
            loss=am_loss + self._config["gen_loss_factor"] * gen_loss,
            optimizer=self.optimizers["am"],
            lr_scheduler=self.lr_schedulers["am"],
        )

    def train_disc_step(self, y, y_):
        if self.global_steps >= self._config["disc_train_start_steps"]:
            with self.engine.context():
                real_loss_list = []
                fake_loss_list = []
                if "discriminator" in self.model:
                    p = self.model["discriminator"](y)
                    p_ = self.model["discriminator"](y_.detach())

                    for i in range(len(p)):
                        real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(p[i][-1], p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)
                if "spec_discriminator" in self.model:
                    sd_p = self.model["spec_discriminator"](y)
                    sd_p_ = self.model["spec_discriminator"](y_.detach())

                    for i in range(len(sd_p)):
                        real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(sd_p[i][-1], sd_p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)
                if "MPD_spec_discriminator" in self.model:
                    mpd_sd_p = self.model["MPD_spec_discriminator"](y)
                    mpd_sd_p_ = self.model["MPD_spec_discriminator"](y_.detach())

                    for i in range(len(mpd_sd_p)):
                        real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(mpd_sd_p[i][-1], mpd_sd_p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)
                if "MSSTFT_discriminator" in self.model:
                    msstft_sd_p, _ = self.model["MSSTFT_discriminator"](y, ret_logits=True, ret_fmaps=False)
                    msstft_sd_p_, _ = self.model["MSSTFT_discriminator"](y_.detach(), ret_logits=True, ret_fmaps=False)

                    for i in range(len(msstft_sd_p)):
                        real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(msstft_sd_p[i], msstft_sd_p_[i])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)

                real_loss = sum(real_loss_list) / len(real_loss_list)
                fake_loss = sum(fake_loss_list) / len(fake_loss_list)

                disc_loss = real_loss + fake_loss

            self.metrics["real_loss"].update_state(real_loss)
            self.metrics["fake_loss"].update_state(fake_loss)
            self.metrics["disc_loss"].update_state(disc_loss)

            self.engine.optimize_step(loss=disc_loss, optimizer=self.optimizers["disc"])

    def train_gen_step(self, y, y_, vq_loss, abs_loss=None):
        gen_loss = self.cal_gen_loss(y, y_, vq_loss)

        if abs_loss is not None:
            gen_loss += abs_loss
            self.metrics["abs_loss"].update_state(abs_loss)

        self.engine.optimize_step(loss=gen_loss, optimizer=self.optimizers["gen"])

    def configure_optimizers(self):
        if self._config["training_stage"] == "codec":
            if "MSSTFT_discriminator" in self.model:
                disc_params = self.model["MSSTFT_discriminator"].parameters()
            if "discriminator" in self.model:
                disc_params = chain(disc_params, self.model["discriminator"].parameters())
            if "spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())

            gen_params = self.model["codec_decoder"].parameters()
            gen_params = chain(gen_params, self.model["codec_encoder"].parameters())
            return {
                "gen": AdamW(gen_params, **self._config["gen_optim_params"]),
                "disc": AdamW(disc_params, **self._config["disc_optim_params"]),
            }
        elif self._config["training_stage"] == "e2e":
            if "MSSTFT_discriminator" in self.model:
                disc_params = self.model["MSSTFT_discriminator"].parameters()
            if "discriminator" in self.model:
                disc_params = chain(disc_params, self.model["discriminator"].parameters())
            if "spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())
            if "MPD_spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["MPD_spec_discriminator"].parameters())

            for name, child in (unwrap_ddp(self.model["codec_decoder"]).named_modules()):
                if len(name) == 0:
                    continue
                if "quantizer" in name:
                    print("freeze {}".format(name))
                    for param in child.parameters():
                        param.requires_grad_(False)
                    if (isinstance(child, torch.nn.LayerNorm) or isinstance(child, torch.nn.BatchNorm1d)
                            or isinstance(child, torch.nn.BatchNorm2d)):
                        child.track_running_stats = False
                        child.eval()

            am_params = self.model["acoustic_model"].parameters()
            am_params = chain(am_params, self.model["codec_decoder"].parameters())
            return {
                "am": AdamW(filter(lambda p: p.requires_grad, am_params), **self._config["disc_optim_params"]),
                "disc": AdamW(disc_params, **self._config["disc_optim_params"])
            }
        elif self._config["training_stage"] == "48k":
            disc_params = self.model["discriminator"].parameters()
            if "spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())
            if "MPD_spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["MPD_spec_discriminator"].parameters())

            for name, child in unwrap_ddp(self.model["codec_decoder"]).named_modules():
                if len(name) == 0:
                    continue
                if "quantizer" in name:
                    print("freeze {}".format(name))
                    for param in child.parameters():
                        param.requires_grad_(False)
                    if (
                            isinstance(child, torch.nn.LayerNorm)
                            or isinstance(child, torch.nn.BatchNorm1d)
                            or isinstance(child, torch.nn.BatchNorm2d)
                    ):
                        child.track_running_stats = False
                        child.eval()
            joint_params = self.model["fullband_generator_tiny"].parameters()

            return {
                "48k": Ranger(
                    filter(lambda p: p.requires_grad, joint_params),
                    alpha=0.5,
                    k=6,
                    n_sma_threshold=5,
                    betas=(0.95, 0.999),
                    eps=1e-5,
                    weight_decay=self._config.get("weight_decay", 1e-6),
                ),
                "disc": Adam(disc_params, **self._config["disc_optim_params"]),
            }
        elif self._config["training_stage"] == "hifinet2":
            disc_params = self.model["discriminator"].parameters()
            if "spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())
            if "MPD_spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["MPD_spec_discriminator"].parameters())

            joint_params = self.model["multibands_generator"].parameters()

            return {
                "hifinet2": Ranger(
                    filter(lambda p: p.requires_grad, joint_params),
                    alpha=0.5,
                    k=6,
                    n_sma_threshold=5,
                    betas=(0.95, 0.999),
                    eps=1e-5,
                    weight_decay=self._config.get("weight_decay", 1e-6),
                ),
                "disc": Adam(disc_params, **self._config["disc_optim_params"]),
            }

        elif self._config["training_stage"] == "distill":
            opts = None
            if self._config["stage_mode"] == "distill":
                for name, child in unwrap_ddp(self.model["acoustic_model"]).named_modules():
                    if len(name) == 0:
                        continue

                    if "sdecoder" in name or "soutput_layers" in name:
                        for param in child.parameters():
                            param.requires_grad_(True)
                    else:
                        for param in child.parameters():
                            param.requires_grad_(False)

                        if (
                                hasattr(child, "running_mean")
                                or isinstance(child, torch.nn.BatchNorm1d)
                                or isinstance(child, torch.nn.BatchNorm2d)
                        ):
                            child.track_running_stats = False
                            child.eval()

                params = self.model["acoustic_model"].parameters()
                opts = {
                    "distill": Ranger(
                        filter(lambda p: p.requires_grad, params),
                        alpha=0.5,
                        k=6,
                        n_sma_threshold=5,
                        betas=(0.95, 0.999),
                        eps=1e-5,
                        weight_decay=self._config.get("weight_decay", 1e-6),
                    )
                }
            elif self._config["stage_mode"] == "full_distill":
                disc_params = self.model["discriminator"].parameters()
                if "spec_discriminator" in self.model:
                    disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())
                if "MPD_spec_discriminator" in self.model:
                    disc_params = chain(disc_params, self.model["MPD_spec_discriminator"].parameters())
                params = self.model["acoustic_model_student"].parameters()

                for name, child in unwrap_ddp(self.model["acoustic_model"]).named_modules():
                    if len(name) == 0:
                        continue
                    if (
                            hasattr(child, "running_mean")
                            or isinstance(child, torch.nn.BatchNorm1d)
                            or isinstance(child, torch.nn.BatchNorm2d)
                    ):
                        child.track_running_stats = False
                        child.eval()

                opts = {
                    "distill": Ranger(
                        filter(lambda p: p.requires_grad, params),
                        alpha=0.5,
                        k=6,
                        n_sma_threshold=5,
                        betas=(0.95, 0.999),
                        eps=1e-5,
                        weight_decay=self._config.get("weight_decay", 1e-6),
                    ),
                    "disc": Adam(disc_params, **self._config["disc_optim_params"]),
                }
            elif self._config["stage_mode"] == "voc_distill":
                disc_params = self.model["discriminator"].parameters()
                if "spec_discriminator" in self.model:
                    disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())
                if "MPD_spec_discriminator" in self.model:
                    disc_params = chain(disc_params, self.model["MPD_spec_discriminator"].parameters())
                params = self.model["codec_decoder_student"].parameters()

                for name, child in unwrap_ddp(self.model["acoustic_model"]).named_modules():
                    if len(name) == 0:
                        continue
                    if (
                            hasattr(child, "running_mean")
                            or isinstance(child, torch.nn.BatchNorm1d)
                            or isinstance(child, torch.nn.BatchNorm2d)
                    ):
                        child.track_running_stats = False
                        child.eval()

                opts = {
                    "distill": Adam(params, **self._config["gen_optim_params"]),
                    "disc": Adam(disc_params, **self._config["disc_optim_params"]),
                }

            return opts
        elif self._config["training_stage"] == "postprocess":
            disc_params = self.model["discriminator"].parameters()
            if "spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())
            if "MPD_spec_discriminator" in self.model:
                disc_params = chain(disc_params, self.model["MPD_spec_discriminator"].parameters())

            for name, child in unwrap_ddp(self.model["acoustic_model"]).named_modules():
                if len(name) == 0:
                    # the first item name of model.named_modules is somehow empty
                    continue

                if "spitch_" in name or "sduration_" in name:
                    for param in child.parameters():
                        param.requires_grad_(True)
                else:
                    for param in child.parameters():
                        param.requires_grad_(False)

                    if (
                            hasattr(child, "running_mean")
                            or isinstance(child, torch.nn.BatchNorm1d)
                            or isinstance(child, torch.nn.BatchNorm2d)
                    ):
                        child.track_running_stats = False
                        child.eval()

            params = self.model["acoustic_model"].parameters()

            opts = {
                "postprocess": Ranger(
                    filter(lambda p: p.requires_grad, params),
                    alpha=0.5,
                    k=6,
                    n_sma_threshold=5,
                    betas=(0.95, 0.999),
                    eps=1e-5,
                    weight_decay=self._config.get("weight_decay", 1e-6),
                ),
                "disc": Adam(disc_params, **self._config["disc_optim_params"]),
            }

            return opts

    def configure_lr_schedulers(self):
        if self._config["training_stage"] == "codec":
            return {
                "gen": PowerLR(self.optimizers["gen"], **self._config["gen_schedule_params"]),
                "disc": PowerLR(self.optimizers["disc"], **self._config["disc_schedule_params"]),
            }

        elif self._config["training_stage"] == "e2e":
            return {
                "am": ExponitialDecayLR(
                    optimizer=self.optimizers["am"],
                    initial_lr=self._config.get("initial_lr", 1e-4),
                    decay_rate=self._config.get("decay_rate", 0.98),
                    decay_steps=self._config.get("decay_steps", 4000),
                    min_lr=self._config.get("min_lr", 0.00005),
                )
            }
        elif self._config["training_stage"] == "48k":
            return {
                "48k": ExponitialDecayLR(
                    optimizer=self.optimizers["48k"],
                    initial_lr=self._config.get("initial_lr", 5e-4),
                    decay_rate=self._config.get("decay_rate", 0.98),
                    decay_steps=self._config.get("decay_steps", 4000),
                    min_lr=self._config.get("decay_steps", 0.00005),
                ),
                "disc": PowerLR(self.optimizers["disc"], **self._config["disc_schedule_params"]),
            }

        elif self._config["training_stage"] == "hifinet2":
            return {
                "hifinet2": ExponitialDecayLR(
                    optimizer=self.optimizers["hifinet2"],
                    initial_lr=self._config.get("initial_lr", 5e-4),
                    decay_rate=self._config.get("decay_rate", 0.98),
                    decay_steps=self._config.get("decay_steps", 4000),
                    min_lr=self._config.get("decay_steps", 0.00005),
                ),
                "disc": PowerLR(self.optimizers["disc"], **self._config["disc_schedule_params"]),
            }
        elif self._config["training_stage"] == "distill":
            if self._config["stage_mode"] == "voc_distill" or self._config["stage_mode"] == "full_distill":
                return {
                    "distill": PowerLR(self.optimizers["distill"], **self._config["gen_schedule_params"]),
                    "disc": PowerLR(self.optimizers["disc"], **self._config["disc_schedule_params"]),
                }
            else:
                return {
                    "distill": ExponitialDecayLR(
                        optimizer=self.optimizers["distill"],
                        initial_lr=self._config.get("initial_lr", 5e-4),
                        decay_rate=self._config.get("decay_rate", 0.97),
                        decay_steps=self._config.get("decay_steps", 4000),
                    )
                }
        elif self._config["training_stage"] == "postprocess":
            return {
                "postprocess": ExponitialDecayLR(
                    optimizer=self.optimizers["postprocess"],
                    initial_lr=self._config.get("initial_lr", 5e-4),
                    decay_rate=self._config.get("decay_rate", 0.97),
                    decay_steps=self._config.get("decay_steps", 4000),
                ),
                "disc": PowerLR(self.optimizers["disc"], **self._config["disc_schedule_params"]),
            }

    def configure_criteria(self):
        criteria = {
            "gan_loss": GANLoss(mode="lsgan"),
        }
        if self._config["use_stft_loss"]:
            criteria["stft_loss"] = MultiResolutionSTFTLoss(**self._config["stft_loss_params"])
        if self._config["use_feat_match_loss"]:
            criteria["fm_loss"] = torch.nn.L1Loss()

        criteria["dur_loss"] = DurationPredictorLoss(reduction="mean")
        criteria["l1_loss"] = torch.nn.L1Loss(reduction="mean")
        criteria["l2_loss"] = torch.nn.MSELoss(reduction="mean")
        return criteria

    def configure_metrics(self):
        if self._config["training_stage"] == "codec":
            metrics = {
                "real_loss": Mean(),
                "fake_loss": Mean(),
                "disc_loss": Mean(),
                "gen_loss": Mean(),
                "adv_loss": Mean(),
                "vq_loss": Mean(),
            }
            if self._config["use_wave_mel_loss"]:
                metrics["wavemel_loss"] = Mean()
                metrics["wavef0_loss"] = Mean()
            else:
                metrics["sc_loss"] = Mean()
                metrics["mag_loss"] = Mean()

            if self._config["abs_loss_func"] != "none":
                metrics["abs_loss"] = Mean()

            if self._config["use_feat_match_loss"]:
                if "discriminator" in self.model:
                    metrics["fm_loss"] = Mean()
                if "spec_discriminator" in self.model:
                    metrics["spec_fm_loss"] = Mean()
                if "MPD_spec_discriminator" in self.model:
                    metrics["mpd_spec_fm_loss"] = Mean()
                if "MSSTFT_discriminator" in self.model:
                    metrics["msstft_fm_loss"] = Mean()

            return metrics
        elif self._config["training_stage"] == "e2e":
            metrics = {
                "real_loss": Mean(),
                "fake_loss": Mean(),
                "disc_loss": Mean(),
                "gen_loss": Mean(),
                "adv_loss": Mean(),
                "dur_loss": Mean(),
                "pitch_loss": Mean(),
                "gst_loss": Mean(),
                "ph_emb_loss": Mean(),
                "ssim_loss": Mean(),
                "vq_pred_loss": Mean(),
                "am_loss": Mean(),
            }
            if self._config["use_wave_mel_loss"]:
                metrics["wavemel_loss"] = Mean()
                metrics["wavef0_loss"] = Mean()
            else:
                metrics["sc_loss"] = Mean()
                metrics["mag_loss"] = Mean()
            if self._config["use_wave_pitch_std_loss"]:
                metrics["pitch_std"] = Mean()

            if self._config["use_feat_match_loss"]:
                if "discriminator" in self.model:
                    metrics["fm_loss"] = Mean()
                if "spec_discriminator" in self.model:
                    metrics["spec_fm_loss"] = Mean()
                if "MPD_spec_discriminator" in self.model:
                    metrics["mpd_spec_fm_loss"] = Mean()
                if "MSSTFT_discriminator" in self.model:
                    metrics["msstft_fm_loss"] = Mean()

            if self._config["predict_mel"]:
                metrics["mel_loss"] = Mean()

            return metrics
        elif self._config["training_stage"] == "48k":
            metrics = {
                "real_loss": Mean(),
                "fake_loss": Mean(),
                "disc_loss": Mean(),
                "gen_loss": Mean(),
                "adv_loss": Mean(),
                "sc_loss": Mean(),
                "mag_loss": Mean(),
                "commit_loss": Mean(),
                "dur_loss": Mean(),
                "pitch_loss": Mean(),
                "gst_loss": Mean(),
                "ph_emb_loss": Mean(),
                "ssim_loss": Mean(),
                "vq_pred_loss": Mean(),
                "am_loss": Mean(),
            }
            if self._config["use_feat_match_loss"]:
                metrics["fm_loss"] = Mean()
                if "spec_discriminator" in self.model:
                    metrics["spec_fm_loss"] = Mean()
                if "MPD_spec_discriminator" in self.model:
                    metrics["mpd_spec_fm_loss"] = Mean()

            if self._config["semi_training"]:
                metrics["semi_fake_loss"] = Mean()
                metrics["semi_gen_loss"] = Mean()

            return metrics

        elif self._config["training_stage"] == "hifinet2":
            metrics = {
                "real_loss": Mean(),
                "fake_loss": Mean(),
                "disc_loss": Mean(),
                "gen_loss": Mean(),
                "adv_loss": Mean(),
                "sc_loss": Mean(),
                "mag_loss": Mean(),
                "commit_loss": Mean(),
                "dur_loss": Mean(),
                "pitch_loss": Mean(),
                "gst_loss": Mean(),
                "ph_emb_loss": Mean(),
                "ssim_loss": Mean(),
                "vq_pred_loss": Mean(),
                "am_loss": Mean(),
            }
            if self._config["use_feat_match_loss"]:
                metrics["fm_loss"] = Mean()
                if "spec_discriminator" in self.model:
                    metrics["spec_fm_loss"] = Mean()
                if "MPD_spec_discriminator" in self.model:
                    metrics["mpd_spec_fm_loss"] = Mean()

            if self._config["semi_training"]:
                metrics["semi_fake_loss"] = Mean()
                metrics["semi_gen_loss"] = Mean()

            return metrics

        elif self._config["training_stage"] == "distill":
            metrics = {
                "vq_pred_loss": Mean(),
                "dur_loss": Mean(),
                "pitch_loss": Mean(),
                "real_loss": Mean(),
                "fake_loss": Mean(),
                "adv_loss": Mean(),
                "disc_loss": Mean(),
                "sc_loss": Mean(),
                "mag_loss": Mean(),
                "gen_loss": Mean(),
            }
            return metrics
        elif self._config["training_stage"] == "postprocess":
            metrics = {
                "vq_pred_loss": Mean(),
                "dur_loss": Mean(),
                "pitch_loss": Mean(),
                "ph_emb_loss": Mean(),
                "real_loss": Mean(),
                "fake_loss": Mean(),
                "adv_loss": Mean(),
                "disc_loss": Mean(),
                "sc_loss": Mean(),
                "mag_loss": Mean(),
                "gen_loss": Mean(),
            }

            return metrics

    def train_hooks(self):
        if self._config["use_ema"]:
            if self._config["training_stage"] == "hifinet2":
                return [
                    ExponentialMovingAverageHook(
                        name="codec_decoder_ema",
                        model=self.model["multibands_generator"],
                        decay=self._config["ema_decay"],
                        update_interval=self._config["ema_update_interval"],
                        reset_interval=self._config["ema_reset_interval"],
                    )
                ]
            return [
                ExponentialMovingAverageHook(
                    name="codec_decoder_ema",
                    model=self.model["codec_decoder"],
                    decay=self._config["ema_decay"],
                    update_interval=self._config["ema_update_interval"],
                    reset_interval=self._config["ema_reset_interval"],
                )
            ]
        else:
            return []

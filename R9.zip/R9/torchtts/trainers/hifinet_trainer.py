from itertools import chain
import logging

import torch

from torchtts.nn.criterions import GANLoss
from torchtts.nn.criterions import MultiResolutionSTFTLoss
from torchtts.nn.metrics import Mean
from torchtts.nn.optim.lr_schedulers import PowerLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.hooks.moving_average import ExponentialMovingAverageHook
from torchtts.utils.import_utils import _APEX_AVAILABLE

if _APEX_AVAILABLE:
    from apex.optimizers import FusedAdam as Adam
else:
    from torch.optim import Adam

logger = logging.getLogger(__name__)


class HiFiNetTrainer(Trainer):
    def train_step(self, batch):
        with self.engine.context():
            y_ = self.model["generator"](batch["mel"])
            y = batch["audio"].unsqueeze(1)

        # Train discriminator
        self.global_steps = int(self.global_steps)
        if self.global_steps >= self._config["disc_train_start_steps"]:
            with self.engine.context():
                p = self.model["discriminator"](y)
                p_ = self.model["discriminator"](y_.detach())

                real_loss_list = []
                fake_loss_list = []
                for i in range(len(p)):
                    real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(p[i][-1], p_[i][-1])
                    real_loss_list.append(real_loss)
                    fake_loss_list.append(fake_loss)

                # spec discriminator
                if "spec_discriminator" in self.model:
                    sd_p = self.model["spec_discriminator"](y)
                    sd_p_ = self.model["spec_discriminator"](y_.detach())

                    for i in range(len(sd_p)):
                        real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(sd_p[i][-1], sd_p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)

                # multi-peroid discriminator
                if self._config["use_mpd_discriminator"] and "mpdiscriminator" in self.model:
                    md_p, md_p_, _, _ = self.model["mpdiscriminator"](y, y_.detach())

                    for i in range(len(md_p)):
                        real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(md_p[i][-1], md_p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)

                real_loss = sum(real_loss_list) / len(real_loss_list)
                fake_loss = sum(fake_loss_list) / len(fake_loss_list)

                disc_loss = real_loss + fake_loss

            self.metrics["real_loss"].update_state(real_loss)
            self.metrics["fake_loss"].update_state(fake_loss)
            self.metrics["disc_loss"].update_state(disc_loss)

            self.engine.optimize_step(
                loss=disc_loss, optimizer=self.optimizers["disc"], lr_scheduler=self.lr_schedulers["disc"]
            )

        # Train generator
        gen_loss = 0.0

        if self._config["use_stft_loss"] and self.global_steps < self._config["stft_loss_steps"]:
            with self.engine.context():
                sc_loss, mag_loss = self.criteria["stft_loss"](y_.squeeze(1), y.squeeze(1))
                gen_loss += sc_loss + mag_loss

            self.metrics["sc_loss"].update_state(sc_loss)
            self.metrics["mag_loss"].update_state(mag_loss)

        if self.global_steps >= self._config["disc_train_start_steps"]:
            with self.engine.context():
                p_ = self.model["discriminator"](y_)

                adv_loss_list = []
                for i in range(len(p_)):
                    adv_loss_list.append(self.criteria["gan_loss"].gen_loss(p_[i][-1]))

                if "spec_discriminator" in self.model:
                    sd_p_ = self.model["spec_discriminator"](y_)
                    for i in range(len(sd_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(sd_p_[i][-1]))

                # multi period discriminator
                if self._config["use_mpd_discriminator"] and "mpdiscriminator" in self.model:
                    md_p, md_p_, _, _ = self.model["mpdiscriminator"](y, y_)
                    for i in range(len(md_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(md_p_[i][-1]))

                adv_loss = sum(adv_loss_list) / len(adv_loss_list)
                gen_loss += adv_loss * self._config["lambda_adv"]

                self.metrics["adv_loss"].update_state(adv_loss)

            if self._config["use_feat_match_loss"]:
                fm_loss = 0.0
                with self.engine.context():
                    with torch.no_grad():
                        p = self.model["discriminator"](y)
                    for i in range(len(p_)):
                        for j in range(len(p_[i]) - 1):
                            fm_loss += self.criteria["fm_loss"](p_[i][j], p[i][j].detach())
                    fm_loss /= (i + 1) * (j + 1)

                    self.metrics["fm_loss"].update_state(fm_loss)
                    gen_loss += fm_loss * self._config["lambda_feat_match_loss"]

                    if "spec_discriminator" in self.model:
                        spec_fm_loss = 0.0
                        with torch.no_grad():
                            sd_p = self.model["spec_discriminator"](y)
                        for i in range(len(sd_p_)):
                            for j in range(len(sd_p_[i]) - 1):
                                spec_fm_loss += self.criteria["fm_loss"](sd_p_[i][j], sd_p[i][j].detach())
                        spec_fm_loss /= (i + 1) * (j + 1)

                        self.metrics["spec_fm_loss"].update_state(spec_fm_loss)
                        gen_loss += spec_fm_loss * self._config["lambda_feat_match_loss"]

                    if self._config["use_mpd_discriminator"] and "mpdiscriminator" in self.model:
                        period_fm_loss = 0.0
                        with torch.no_grad():
                            md_p, md_p_, fmap_p, fmap_p_ = self.model["mpdiscriminator"](y, y_)

                        period_fm_loss = self.criteria["gan_loss"].feature_loss(fmap_p, fmap_p_)

                        self.metrics["period_fm_loss"].update_state(period_fm_loss)
                        gen_loss += period_fm_loss * self._config["lambda_feat_match_loss"]

        self.metrics["gen_loss"].update_state(gen_loss)

        self.engine.optimize_step(
            loss=gen_loss, optimizer=self.optimizers["gen"], lr_scheduler=self.lr_schedulers["gen"]
        )

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def configure_optimizers(self):
        disc_params = self.model["discriminator"].parameters()
        if "spec_discriminator" in self.model:
            disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())

        if self._config["use_mpd_discriminator"] and "mpdiscriminator" in self.model:
            disc_params = chain(disc_params, self.model["mpdiscriminator"].parameters())

        return {
            "gen": Adam(self.model["generator"].parameters(), **self._config["gen_optim_params"]),
            "disc": Adam(disc_params, **self._config["disc_optim_params"]),
        }

    def configure_lr_schedulers(self):
        return {
            "gen": PowerLR(self.optimizers["gen"], **self._config["gen_schedule_params"]),
            "disc": PowerLR(self.optimizers["disc"], **self._config["disc_schedule_params"]),
        }

    def configure_criteria(self):
        criteria = {
            "gan_loss": GANLoss(mode="lsgan"),
        }
        if self._config["use_stft_loss"]:
            criteria["stft_loss"] = MultiResolutionSTFTLoss(**self._config["stft_loss_params"])
        if self._config["use_feat_match_loss"]:
            criteria["fm_loss"] = torch.nn.L1Loss()
        return criteria

    def configure_metrics(self):
        metrics = {
            "real_loss": Mean(),
            "fake_loss": Mean(),
            "disc_loss": Mean(),
            "gen_loss": Mean(),
            "adv_loss": Mean(),
            "sc_loss": Mean(),
            "mag_loss": Mean(),
        }
        if self._config["use_feat_match_loss"]:
            metrics["fm_loss"] = Mean()
            if "spec_discriminator" in self.model:
                metrics["spec_fm_loss"] = Mean()
            if "mpdiscriminator" in self.model:
                metrics["period_fm_loss"] = Mean()
        return metrics

    def train_hooks(self):
        return [
            ExponentialMovingAverageHook(
                name="generator_ema",
                model=self.model["generator"],
                decay=self._config["ema_decay"],
                update_interval=self._config["ema_update_interval"],
                reset_interval=self._config["ema_reset_interval"],
            )
        ]

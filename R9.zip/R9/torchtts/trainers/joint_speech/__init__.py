from torchtts.trainers.joint_speech.v1 import JointSpeechV1Trainer
from torchtts.trainers.joint_speech.v2 import JointSpeechV2Trainer

import logging
from itertools import chain

import torch
from torch.optim import Adam

from torchtts.nn.criterions import GANLoss
from torchtts.nn.criterions import MultiResolutionSTFTLoss
from torchtts.nn.criterions import SequenceLoss
from torchtts.nn.metrics import Mean
from torchtts.nn.optim.lr_schedulers import PowerLR
from torchtts.trainers.base_trainer import Trainer

logger = logging.getLogger(__name__)


class JointSpeechV1Trainer(Trainer):
    def train_step(self, batch):
        with self.engine.context():
            num_frames = max(batch["mel_length"])

            spec = self.model['transform'](batch["speech"])[..., :num_frames].transpose(1, 2)

            # Audio encoder (posterior encoder)
            z = self.model['posterior_encoder'](spec)

            # Text encoder (prior encoder)
            (pred_z, pred_dur, pred_phone_f0,
             pred_fine_grained_latent, fine_grained_latent,
             src_mask, tgt_mask) = self.model['prior_encoder'](
                phone_id=batch['phone_id'],
                speaker_id=batch.get('speaker_id', None),
                locale_id=batch.get('locale_id', None),
                style_id=batch.get('style_id', None),
                src_length=batch['phone_id_length'],
                duration=batch['duration'],
                tgt_length=batch['mel_length'],
                reference=z,
                phone_f0=batch['phone_f0'])

            # Random clip the latent
            z_slice, y = rand_slice_segments(z.transpose(1, 2), batch['speech'].unsqueeze(1),
                                             latent_lengths=batch['mel_length'],
                                             segment_size=self._config['segment_size'],
                                             num_segments=self._config['segment_batch_size'],
                                             hop_length=self._config['segment_hop_length'])
            y_ = self.model['decoder'](z_slice)

        self.train_disc_step(y, y_)
        self.train_joint_step(y, y_, pred_z=pred_z, target_z=z, pred_dur=pred_dur,
                              target_dur=torch.log1p(batch['duration'].float()),
                              pred_phone_f0=pred_phone_f0.squeeze(-1), target_phone_f0=batch['phone_f0'],
                              pred_fine_grained_latent=pred_fine_grained_latent,
                              target_fine_grained_latent=fine_grained_latent,
                              src_mask=src_mask, tgt_mask=tgt_mask)

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def train_disc_step(self, y, y_):
        with self.engine.context():
            p = self.model['discriminator'](y)
            p_ = self.model['discriminator'](y_.detach())

            real_loss_list = []
            fake_loss_list = []
            for i in range(len(p)):
                real_loss, fake_loss = self.criteria['gan_loss'].disc_loss(p[i][-1], p_[i][-1])
                real_loss_list.append(real_loss)
                fake_loss_list.append(fake_loss)

            # spec discriminator
            if 'spec_discriminator' in self.model:
                sd_p = self.model['spec_discriminator'](y)
                sd_p_ = self.model['spec_discriminator'](y_.detach())

                for i in range(len(sd_p)):
                    real_loss, fake_loss = self.criteria['gan_loss'].disc_loss(sd_p[i][-1], sd_p_[i][-1])
                    real_loss_list.append(real_loss)
                    fake_loss_list.append(fake_loss)

            real_loss = sum(real_loss_list) / len(real_loss_list)
            fake_loss = sum(fake_loss_list) / len(fake_loss_list)

            disc_loss = real_loss + fake_loss

            self.metrics['real_loss'].update_state(real_loss)
            self.metrics['fake_loss'].update_state(fake_loss)
            self.metrics['disc_loss'].update_state(disc_loss)

        self.engine.optimize_step(loss=disc_loss,
                                  optimizer=self.optimizers['disc'],
                                  lr_scheduler=self.lr_schedulers['disc'])

    def train_gen_step(self, y, y_):
        gen_loss = self.cal_gen_loss(y, y_)

        self.engine.optimize_step(loss=gen_loss,
                                  optimizer=self.optimizers['gen'],
                                  lr_scheduler=self.lr_schedulers['gen'])

    def cal_gen_loss(self, y, y_):
        with self.engine.context():
            gen_loss = 0

            if self._config["use_stft_loss"]:
                sc_loss, mag_loss = self.criteria['stft_loss'](y_.squeeze(1), y.squeeze(1))
                gen_loss += sc_loss + mag_loss

                self.metrics['sc_loss'].update_state(sc_loss)
                self.metrics['mag_loss'].update_state(mag_loss)

            p_ = self.model['discriminator'](y_)

            adv_loss_list = []
            for i in range(len(p_)):
                adv_loss_list.append(self.criteria['gan_loss'].gen_loss(p_[i][-1]))

            if 'spec_discriminator' in self.model:
                sd_p_ = self.model['spec_discriminator'](y_)
                for i in range(len(sd_p_)):
                    adv_loss_list.append(self.criteria['gan_loss'].gen_loss(sd_p_[i][-1]))

            adv_loss = sum(adv_loss_list) / len(adv_loss_list)
            gen_loss += adv_loss * self._config['lambda_adv']

            self.metrics['adv_loss'].update_state(adv_loss)

        self.metrics['gen_loss'].update_state(gen_loss)

        return gen_loss

    def train_joint_step(self, y, y_, pred_z, target_z, pred_dur, target_dur, pred_phone_f0, target_phone_f0,
                         pred_fine_grained_latent, target_fine_grained_latent, src_mask, tgt_mask):
        gen_loss = self.cal_gen_loss(y, y_)
        am_loss = self.cal_am_loss(pred_z=pred_z, target_z=target_z, pred_dur=pred_dur,
                                   target_dur=target_dur, pred_phone_f0=pred_phone_f0, target_phone_f0=target_phone_f0,
                                   pred_fine_grained_latent=pred_fine_grained_latent,
                                   target_fine_grained_latent=target_fine_grained_latent,
                                   src_mask=src_mask, tgt_mask=tgt_mask)

        am_loss_weight = self._config.get('am_loss_weight', 10)
        self.engine.optimize_step(loss=am_loss_weight * am_loss + gen_loss,
                                  optimizer=self.optimizers['joint'],
                                  lr_scheduler=self.lr_schedulers['joint'])

    def cal_am_loss(self, pred_z, target_z, pred_dur, target_dur, pred_phone_f0, target_phone_f0,
                    pred_fine_grained_latent, target_fine_grained_latent, src_mask, tgt_mask):
        z_loss = self.criteria['z_loss'](
            input_seq=pred_z, target_seq=target_z,
            mask=tgt_mask.unsqueeze(-1))

        dur_loss = self.criteria['dur_loss'](
            input_seq=pred_dur,
            target_seq=target_dur,
            mask=src_mask)
        dur_loss_weight = self._config.get('duration_loss_weight', 0.1)
        dur_loss *= dur_loss_weight

        # Phone pitch loss
        phone_f0_loss = self.criteria['phone_f0_loss'](
            input_seq=pred_phone_f0,
            target_seq=target_phone_f0,
            mask=src_mask)

        am_loss = z_loss + dur_loss + phone_f0_loss

        # Fine grained latent (ae/vae) loss
        if pred_fine_grained_latent is not None:
            f_vae_loss = self.criteria['f_vae_loss'](
                input_seq=pred_fine_grained_latent,
                target_seq=target_fine_grained_latent,
                mask=src_mask.unsqueeze(-1))
            am_loss += f_vae_loss
            self.metrics['f_vae_loss'].update_state(f_vae_loss)

        self.metrics['z_loss'].update_state(z_loss)
        self.metrics['dur_loss'].update_state(dur_loss)
        self.metrics['phone_f0_loss'].update_state(phone_f0_loss)
        self.metrics['am_loss'].update_state(am_loss)

        return am_loss

    def configure_optimizers(self):
        joint_params = chain(self.model['posterior_encoder'].parameters(),
                             self.model['prior_encoder'].parameters(),
                             self.model['decoder'].parameters())
        disc_params = self.model['discriminator'].parameters()
        if 'spec_discriminator' in self.model:
            disc_params = chain(disc_params, self.model['spec_discriminator'].parameters())

        return {
            'joint': Adam(joint_params, **self._config["joint_optim_params"]),
            'disc': Adam(disc_params, **self._config["disc_optim_params"])
        }

    def configure_lr_schedulers(self):
        return {
            'joint': PowerLR(self.optimizers['joint'],
                             **self._config["joint_schedule_params"]),
            'disc': PowerLR(self.optimizers['disc'],
                            **self._config["disc_schedule_params"]),
        }

    def configure_criteria(self):
        criteria = {
            'z_loss': SequenceLoss('l1_loss', use_masking=True),
            'dur_loss': SequenceLoss('mse_loss', use_masking=True),
            'gan_loss': GANLoss(mode='lsgan'),
            'phone_f0_loss': SequenceLoss('mse_loss', use_masking=True),
            'f_vae_loss': SequenceLoss('l1_loss', use_masking=True),
        }
        if self._config['use_stft_loss']:
            criteria['stft_loss'] = MultiResolutionSTFTLoss(**self._config['stft_loss_params'])
        return criteria

    def configure_metrics(self):
        metrics = {
            'z_loss': Mean(),
            'dur_loss': Mean(),
            'real_loss': Mean(),
            'fake_loss': Mean(),
            'disc_loss': Mean(),
            'am_loss': Mean(),
            'gen_loss': Mean(),
            'adv_loss': Mean(),
            'sc_loss': Mean(),
            'mag_loss': Mean(),
            'phone_f0_loss': Mean(),
            'f_vae_loss': Mean()
        }
        return metrics


def _slice_segments(x: torch.Tensor, ids_start, segment_size):
    ret = torch.zeros_like(x[:, :, :segment_size])
    for i in range(x.size(0)):
        idx_start = ids_start[i]
        idx_end = idx_start + segment_size
        ret[i] = x[i, :, idx_start: idx_end]
    return ret


def rand_slice_segments(latent, waveform, segment_size, hop_length, num_segments=None, latent_lengths=None):
    b, _, t = latent.size()
    if num_segments is None:
        num_segments = b
    # Random select batch lines to form new batch of size num_segments
    batch_idx = torch.randint(0, b, [num_segments]).to(device=latent.device)
    latent = torch.index_select(latent, 0, batch_idx)
    waveform = torch.index_select(waveform, 0, batch_idx)
    # Apply the same to x_lengths if given
    if latent_lengths is None:
        latent_lengths = t
    else:
        latent_lengths = torch.index_select(latent_lengths, 0, batch_idx)
        segment_size = min(segment_size, min(latent_lengths) * hop_length)
    # Random select fragments
    ids_start_max = latent_lengths - segment_size // hop_length + 1
    ids_start = (torch.rand([num_segments]).to(device=latent.device) * ids_start_max).to(dtype=torch.long)
    frame_seg = _slice_segments(latent, ids_start, segment_size // hop_length)
    wave_seg = _slice_segments(waveform, ids_start * hop_length, segment_size)

    return frame_seg, wave_seg

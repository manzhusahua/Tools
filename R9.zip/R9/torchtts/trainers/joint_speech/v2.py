import logging
from itertools import chain

import torch
from torch.distributions import Normal
from torch.distributions import kl_divergence
import torch.optim as optim

from torchtts.nn.criterions import GANLoss
from torchtts.nn.criterions import MultiResolutionSTFTLoss
from torchtts.nn.criterions import SequenceLoss
from torchtts.nn.metrics import Mean
from torchtts.nn.modules.common.functional import sequence_mask
from torchtts.nn.optim.lr_schedulers import PowerLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.nn.modules.conformer.ssim import ssim, mask_ssim

logger = logging.getLogger(__name__)


class JointSpeechV2Trainer(Trainer):
    def train_step(self, batch):
        with self.engine.context():
            num_frames = max(batch["num_frames"])

            # On-the-fly transformation
            spec = self.model["transform"](batch["speech"]).detach()
            spec = spec[..., :num_frames].transpose(1, 2)
            batch["acoustic_feats"] = spec

            # Generate random windows for GAN training
            batch_idx, frame_windows, sample_windows = self.random_select(
                batch["num_frames"],
                self._config["num_segments"],
                self._config["segment_size"],
                self._config["segment_hop_length"],
            )

            model_outputs = self.model["joint_model"](
                phone_ids=batch["phone_id"],
                phone_ids_lengths=batch["phone_id_length"],
                durations=batch["duration"],
                acoustic_feats=spec,
                acoustic_feats_lengths=batch["num_frames"],
                phone_pitch=batch["phone_f0"],
                speaker_id=batch.get("speaker_id", None),
                locale_id=batch.get("locale_id", None),
                style_id=batch.get("style_id", None),
                windows=(batch_idx, frame_windows),
            )

            # Batch with random select sample clips
            batch_speech = torch.index_select(batch["speech"], 0, batch_idx)
            y = torch.stack(
                [batch_speech[i, b:e] for i, (b, e) in enumerate(sample_windows)],
                dim=0,
            ).unsqueeze(1)
            y_ = model_outputs["audio"]

            self.train_disc_step(y, y_)
            self.train_joint_step(y, y_, batch, model_outputs)

            self.log_audio_to_tensorboard(y, y_)

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def train_disc_step(self, y, y_):
        if self.global_steps >= self._config["disc_train_start_steps"]:
            with self.engine.context():
                p = self.model["discriminator"](y)
                p_ = self.model["discriminator"](y_.detach())

                real_loss_list = []
                fake_loss_list = []
                for i in range(len(p)):
                    real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(p[i][-1], p_[i][-1])
                    real_loss_list.append(real_loss)
                    fake_loss_list.append(fake_loss)

                # spec discriminator
                if "spec_discriminator" in self.model:
                    sd_p = self.model["spec_discriminator"](y)
                    sd_p_ = self.model["spec_discriminator"](y_.detach())

                    for i in range(len(sd_p)):
                        real_loss, fake_loss = self.criteria["gan_loss"].disc_loss(sd_p[i][-1], sd_p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)

                real_loss = sum(real_loss_list) / len(real_loss_list)
                fake_loss = sum(fake_loss_list) / len(fake_loss_list)

                disc_loss = real_loss + fake_loss

                self.metrics["disc_loss"].update_state(disc_loss)

            self.engine.optimize_step(
                loss=disc_loss, optimizer=self.optimizers["disc"], lr_scheduler=self.lr_schedulers["disc"]
            )

    def train_joint_step(self, y, y_, batch, model_out):
        gen_loss = self.cal_gen_loss(y, y_)
        am_loss = self.cal_am_loss(batch, model_out)

        am_loss_weight = self._config.get("am_loss_weight", 10)
        self.engine.optimize_step(
            loss=am_loss_weight * am_loss + gen_loss,
            optimizer=self.optimizers["joint"],
            lr_scheduler=self.lr_schedulers["joint"],
        )

    def cal_gen_loss(self, y, y_):
        with self.engine.context():
            gen_loss = 0

            if self._config["use_stft_loss"]:
                sc_loss, mag_loss = self.criteria["stft_loss"](y_.squeeze(1), y.squeeze(1))
                gen_loss += sc_loss + mag_loss

                self.metrics["sc_loss"].update_state(sc_loss)
                self.metrics["mag_loss"].update_state(mag_loss)

            if self.global_steps >= self._config["disc_train_start_steps"]:
                p_ = self.model["discriminator"](y_)

                adv_loss_list = []
                for i in range(len(p_)):
                    adv_loss_list.append(self.criteria["gan_loss"].gen_loss(p_[i][-1]))

                if "spec_discriminator" in self.model:
                    sd_p_ = self.model["spec_discriminator"](y_)
                    for i in range(len(sd_p_)):
                        adv_loss_list.append(self.criteria["gan_loss"].gen_loss(sd_p_[i][-1]))

                adv_loss = sum(adv_loss_list) / len(adv_loss_list)
                gen_loss += adv_loss * self._config["lambda_adv"]

                self.metrics["adv_loss"].update_state(adv_loss)

        self.metrics["gen_loss"].update_state(gen_loss)

        return gen_loss

    def cal_am_loss(self, batch, model_out):
        phone_mask = sequence_mask(batch["phone_id_length"])
        frame_mask = sequence_mask(batch["num_frames"])

        loss = 0.0

        prosody_dist = model_out["prosody_dist"]
        pred_prosody_dist = model_out["pred_prosody_dist"]

        # Prosody predictor kl loss
        detached_prosody_dist = Normal(prosody_dist.loc.detach(), prosody_dist.scale.detach())
        prosody_kl_loss = kl_divergence(pred_prosody_dist, detached_prosody_dist)
        prosody_kl_loss = prosody_kl_loss.masked_select(phone_mask.unsqueeze(-1)).mean()
        prosody_kl_loss *= self._config.get("prosody_loss_weight", 1.0)
        self.metrics["prosody_loss"].update_state(prosody_kl_loss)
        loss += prosody_kl_loss

        # Normalizing flow kl loss (sampling)
        if model_out["pred_prior"] is not None:
            prior_kl_loss = -prosody_dist.stddev.log() - 0.5 + 0.5 * model_out["pred_prior"] ** 2
        else:
            prior_dist = Normal(torch.zeros_like(prosody_dist.loc), torch.ones_like(prosody_dist.scale))
            prior_kl_loss = kl_divergence(prosody_dist, prior_dist)

        prior_kl_loss = prior_kl_loss.masked_select(phone_mask.unsqueeze(-1)).mean()
        prior_kl_loss = torch.clamp(prior_kl_loss, min=0.0)
        prior_kl_loss *= min(self.global_steps / max(self._config["prior_kl_start_steps"], 1), 1.0)
        prior_kl_loss *= self._config.get("prior_loss_weight", 1.0)
        self.metrics["prior_loss"].update_state(prior_kl_loss)
        loss += prior_kl_loss

        # Duration loss
        dur_loss = self.criteria["dur_loss"](
            input_seq=model_out["pred_duration"],
            target_seq=torch.log1p(batch["duration"].float()),
            mask=phone_mask,
        )
        dur_loss *= self._config.get("duration_loss_weight", 1.0)
        self.metrics["dur_loss"].update_state(dur_loss)
        loss += dur_loss

        # Pitch loss
        pitch_loss = self.criteria["pitch_loss"](
            input_seq=model_out["pred_pitch"].squeeze(-1),
            target_seq=batch["phone_f0"],
            mask=phone_mask,
        )
        pitch_loss *= self._config.get("pitch_loss_weight", 1.0)
        self.metrics["pitch_loss"].update_state(pitch_loss)
        loss += pitch_loss

        # Acoustic feature reconstruction loss
        if self._config["use_recon_loss"]:
            recon_loss = self.criteria["recon_loss"](
                model_out["pred_acoustic_feats"], batch["acoustic_feats"], mask=frame_mask.unsqueeze(-1)
            )
            recon_loss *= self._config.get("recon_loss_weight", 0.5)
            self.metrics["recon_loss"].update_state(recon_loss)
            loss += recon_loss

            pred_feats = model_out["pred_acoustic_feats"]
            m = mask_ssim(pred_feats.shape, batch["num_frames"], dim=2).float().to(pred_feats.device)
            pred_feats_ss, ys_ss = pred_feats * m, batch["acoustic_feats"] * m
            ssim_loss = 1 - ssim(pred_feats_ss.unsqueeze(1), ys_ss.unsqueeze(1))
            ssim_loss *= self._config.get("ssim_loss_weight", 0.5)
            self.metrics["ssim_loss"].update_state(ssim_loss)
            loss += ssim_loss

        return loss

    def configure_optimizers(self):
        joint_params = chain(self.model["joint_model"].parameters())

        disc_params = self.model["discriminator"].parameters()
        if "spec_discriminator" in self.model:
            disc_params = chain(disc_params, self.model["spec_discriminator"].parameters())

        return {
            "joint": getattr(optim, self._config["joint_optim_type"])(
                joint_params, **self._config["joint_optim_params"]
            ),
            "disc": getattr(optim, self._config["disc_optim_type"])(disc_params, **self._config["disc_optim_params"]),
        }

    def configure_lr_schedulers(self):
        return {
            "joint": PowerLR(
                optimizer=self.optimizers["joint"],
                **self._config["joint_schedule_params"],
            ),
            "disc": PowerLR(
                optimizer=self.optimizers["disc"],
                **self._config["disc_schedule_params"],
            ),
        }

    def configure_criteria(self):
        criteria = {
            "dur_loss": SequenceLoss("mse_loss"),
            "pitch_loss": SequenceLoss("mse_loss"),
            "gan_loss": GANLoss("lsgan"),
        }
        if self._config["use_stft_loss"]:
            criteria["stft_loss"] = MultiResolutionSTFTLoss(**self._config["stft_loss_params"])
        if self._config["use_recon_loss"]:
            criteria["recon_loss"] = SequenceLoss("l1_loss")
        return criteria

    def configure_metrics(self):
        metrics = {
            "dur_loss": Mean(),
            "pitch_loss": Mean(),
            "prosody_loss": Mean(),
            "prior_loss": Mean(),
            "disc_loss": Mean(),
            "gen_loss": Mean(),
            "adv_loss": Mean(),
            "sc_loss": Mean(),
            "mag_loss": Mean(),
        }

        if self._config["use_recon_loss"]:
            metrics["recon_loss"] = Mean()
            metrics["ssim_loss"] = Mean()

        return metrics

    def log_audio_to_tensorboard(self, y, y_):
        if self.engine.is_master_process and self.global_steps % self.log_interval == 0:
            self.tensorboard_writer.add_audio(
                "pred_audio", y_[0], global_step=self.global_steps, sample_rate=self._config["sample_rate"]
            )
            self.tensorboard_writer.add_audio(
                "true_audio", y[0], global_step=self.global_steps, sample_rate=self._config["sample_rate"]
            )

    @staticmethod
    def random_select(frame_lengths, num_segments, segment_size, hop_length):
        device = frame_lengths.device
        # Random select batch lines to form new batch of size num_segments
        batch = len(frame_lengths)
        batch_idx = torch.randint(0, batch, [num_segments]).to(device=device)
        frame_lengths = torch.index_select(frame_lengths, 0, batch_idx)
        segment_size = min(segment_size, min(frame_lengths) * hop_length)
        # Random select fragments
        ids_start_max = frame_lengths - segment_size // hop_length + 1
        ids_start = (torch.rand([num_segments]).to(device=device) * ids_start_max).to(dtype=torch.long)
        sample_ids_start = ids_start * hop_length
        frame_windows = torch.stack((ids_start, ids_start + segment_size // hop_length), dim=1)
        sample_windows = torch.stack((sample_ids_start, sample_ids_start + segment_size), dim=1)

        return batch_idx, frame_windows, sample_windows

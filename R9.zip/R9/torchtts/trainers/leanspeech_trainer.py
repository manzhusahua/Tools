import logging
import torch

from torchtts.nn import criterions
from torchtts.nn.optim.lr_schedulers import TacotronNoamLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.nn import metrics

import json
from torchtts.data.core import writers
from torchtts.data.core import features
import numpy as np

logger = logging.getLogger(__name__)

fs_feature_dict = features.FeaturesDict(
    {
        "phone_id": features.Tensor(shape=(None,), dtype=np.int64),
        "phone_id_length": features.Tensor(shape=(), dtype=np.int64),
        "duration": features.Tensor(shape=(None,), dtype=np.int64),
        "mel": features.Tensor(shape=(None, 80), dtype=np.float32),
        "mel_length": features.Tensor(shape=(), dtype=np.int64),
    }
)


class LeanSpeechTrainer(Trainer):
    def __init__(
        self,
        device="cuda",
        use_amp=False,
        dist_config=None,
        save_path=None,
        save_interval=1000,
        log_interval=100,
        warm_start_from=None,
        reset_trainer=False,
        parameter_list=None,
        **kwargs,
    ):
        super().__init__(
            device,
            use_amp,
            dist_config,
            save_path,
            save_interval,
            log_interval,
            warm_start_from,
            reset_trainer,
            parameter_list,
            **kwargs,
        )

        if self._config.get("prune_phoneset", False):
            self.map_oldID_ph = {0: "<pad>", 1: "~"}
            self.ph_idx = 2
            phs = json.load(open(self._config.get("phoneset_src", "")))
            for ph in phs:
                self.map_oldID_ph[self.ph_idx] = ph
                self.ph_idx += 1

            print(self.map_oldID_ph)
            self.map_ph_newID = {self.map_oldID_ph[0]: 0, self.map_oldID_ph[1]: 1}
            self.ph_idx = 2

            self.total_dump = 0

            self.writer = writers.ShardWriter("./shards-%05d.tar", writer_cls=writers.TarWriter, max_count=10000)

    def train_step(self, batch):
        if self._config.get("prune_phoneset", False):
            if self.epochs > 0:
                with open("phone_tf.txt", "w", encoding="utf-8") as f:
                    for k, v in self.map_ph_newID.items():
                        f.write(f'"{k}":{v}\n')

            for i in range(batch["phone_id"].shape[0]):
                ph_id_len = batch["phone_id_length"][i].cpu()
                ph_id = batch["phone_id"][i][:ph_id_len].cpu()
                dur = batch["duration"][i][:ph_id_len].cpu()
                mel_len = batch["mel_length"][i].cpu()
                mel = batch["mel"][i][:mel_len].cpu()
                for p in range(ph_id_len):
                    ph = self.map_oldID_ph[int(ph_id[p])]
                    if ph not in self.map_ph_newID:
                        self.map_ph_newID[ph] = self.ph_idx
                        self.ph_idx += 1
                    ph_id[p] = self.map_ph_newID[ph]

                encoded_example = fs_feature_dict.encode_example(
                    {
                        "phone_id": ph_id,
                        "phone_id_length": ph_id_len,
                        "duration": dur,
                        "mel": mel,
                        "mel_length": mel_len,
                    }
                )

                self.writer.write({"__key__": f"{self.total_dump:010}", **encoded_example})
                self.total_dump += 1

        with self.engine.context():
            pred_mel, pred_dur, pred_f0, pred_uv, src_mask, tgt_mask, enc_out_softmax = self.model(
                phone_id=batch["phone_id"],
                length=batch["phone_id_length"],
                duration=batch["duration"],
                style_id=batch.get("style_id", None),
                spk_id=batch.get("speaker_id", None),
                lang_id=batch.get("locale_id", None),
                f0=batch.get("f0", None),
                uv=batch.get("uv", None),
            )

            if enc_out_softmax is not None:
                with torch.no_grad():
                    enc_out_std_loss = torch.mean(torch.std(enc_out_softmax, dim=1))
                    enc_out_std_loss = 1 / enc_out_std_loss / 100
            # Use masked mse loss for mel
            mel_loss = self.criteria["mel_loss"](
                input_seq=pred_mel, target_seq=batch["mel"], mask=tgt_mask.unsqueeze(-1)
            )
            # Use masked mse loss for duration
            dur_loss = self.criteria["dur_loss"](
                input_seq=pred_dur, target_seq=torch.log1p(batch["duration"].float()), mask=src_mask
            )
            dur_loss_weight = self._config.get("duration_loss_weight", 0.1)
            dur_loss *= dur_loss_weight

            loss = mel_loss + dur_loss

            if self._config.get("enable_pitch_loss", False):
                f0_loss = self.criteria["f0_loss"](input_seq=pred_f0.squeeze(-1), target_seq=batch["f0"], mask=tgt_mask)
                uv_loss = self.criteria["uv_loss"](input_seq=pred_uv.squeeze(-1), target_seq=batch["uv"], mask=tgt_mask)
                pitch_loss_weight = self._config.get("pitch_loss_weight", 0.1)
                f0_loss *= pitch_loss_weight
                uv_loss *= pitch_loss_weight

                loss += f0_loss + uv_loss

            if self._config.get("enable_cfm_pitch_loss", False):
                pitch_mask = src_mask
                pred_f0 = pred_f0.squeeze(-1).masked_select(pitch_mask)
                p_ref = batch["f0"].masked_select(pitch_mask)
                f0_loss = self.criteria["f0_loss"](pred_f0, p_ref)
                self.metrics["f0_loss"].update_state(f0_loss)
                loss += f0_loss

        # Exits the context manager before optimize step
        self.engine.optimize_step(loss=loss, optimizer=self.optimizers, lr_scheduler=self.lr_schedulers)

        # Update metrics
        self.metrics["mel_loss"].update_state(mel_loss)
        self.metrics["dur_loss"].update_state(dur_loss)
        self.metrics["loss"].update_state(loss)
        if self._config.get("enable_pitch_loss", False):
            self.metrics["f0_loss"].update_state(f0_loss)
            self.metrics["uv_loss"].update_state(uv_loss)
        if self._config.get("enable_cfm_pitch_loss", False):
            self.metrics["f0_loss"].update_state(f0_loss)

        # The return value will be stored as training logs.
        logs = {k: m.result() for k, m in self.metrics.items()}
        if enc_out_softmax is not None:
            logs["std-value"] = enc_out_std_loss
        return logs

    def configure_optimizers(self):
        if self._config.get("enable_pitch_loss", False):
            # Update only pitch contour related params
            pitch_contour_params = []
            for name, param in self.model.named_parameters():
                if "pitch" in name:
                    pitch_contour_params.append(param)
                else:
                    param.requires_grad_(False)
            parameters = pitch_contour_params
        else:
            parameters = self.model.parameters()

        weight_decay = self._config.get("weight_decay", 0.0)
        optimizer = torch.optim.Adam(parameters, betas=(0.9, 0.999), weight_decay=weight_decay)
        return optimizer

    def configure_lr_schedulers(self):
        lr_scheduler = TacotronNoamLR(
            optimizer=self.optimizers,
            init_lr=self._config.get("init_lr", 2e-3),
            warmup_steps=self._config.get("warmup_steps", 4000),
        )
        return lr_scheduler

    def configure_criteria(self):
        criteria = {
            "mel_loss": criterions.SequenceLoss("mse_loss", use_masking=True),
            "dur_loss": criterions.SequenceLoss("mse_loss", use_masking=True),
        }
        if self._config.get("enable_pitch_loss", False):
            criteria.update(
                {
                    "f0_loss": criterions.SequenceLoss("mse_loss", use_masking=True),
                    "uv_loss": criterions.SequenceLoss("mse_loss", use_masking=True),
                }
            )
        if self._config.get("enable_cfm_pitch_loss", False):
            criteria.update({"f0_loss": torch.nn.MSELoss(reduction="mean")})
        return criteria

    def configure_metrics(self):
        return {
            # 'enc_out_std_loss': metrics.Mean(),
            "mel_loss": metrics.Mean(),
            "dur_loss": metrics.Mean(),
            "f0_loss": metrics.Mean(),
            "uv_loss": metrics.Mean(),
            "loss": metrics.Mean(),
        }

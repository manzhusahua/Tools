import logging

import matplotlib.pyplot as plt

import os
import torch

from torchtts.nn import criterions, metrics
from torchtts.nn.optim.lr_schedulers import NoamLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.hooks.base_hook import Hook
from torchtts.hooks.base_hook import HookNode
from torchtts.hooks.base_hook import HookOrder

plt.switch_backend("agg")

logger = logging.getLogger(__name__)


class TransformerTrainer(Trainer):
    def train_step(self, batch):
        with self.engine.context():
            pred_mel, pred_stop_token, tgt_stop_token, tgt_mask, attn_cross_list = self.model(
                phone_id=batch["phone_id"],
                mels=batch["mel"],
                length=batch["phone_id_length"],
                length_out=batch["mel_length"],
                duration=batch["duration"],
            )

            # Use masked mse loss for mel
            mel_loss = self.criteria["mel_loss"](
                input_seq=pred_mel, target_seq=batch["mel"], mask=tgt_mask.unsqueeze(-1)
            )

            bce_loss = self.criteria["bce_loss"](input_seq=pred_stop_token, target_seq=tgt_stop_token, mask=tgt_mask)

            guided_attention_loss = self.criteria["guided_attention_loss"](
                att_ws=torch.cat([attn_cross[:, :1] for attn_cross in attn_cross_list], dim=1),
                ilens=batch["phone_id_length"],
                olens=batch["mel_length"],
            )  # first head of each layer

            loss = mel_loss + bce_loss + guided_attention_loss

        # Exits the context manager before optimize step
        self.engine.optimize_step(loss=loss, optimizer=self.optimizers, lr_scheduler=self.lr_schedulers)

        # Update metrics
        self.metrics["mel_loss"].update_state(mel_loss)
        self.metrics["bce_loss"].update_state(bce_loss)
        self.metrics["guided_attention_loss"].update_state(guided_attention_loss)
        self.metrics["loss"].update_state(loss)

        # Data to be used in TransformerHook.
        self.attn_cross_list = attn_cross_list

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def configure_optimizers(self):
        return torch.optim.Adam(self.model.parameters(), betas=(0.9, 0.997), eps=1e-9)

    def configure_lr_schedulers(self):
        return NoamLR(
            optimizer=self.optimizers,
            model_size=384,
            warmup_steps=self._config.get("warmup_steps", 8000),
            factor=self._config.get("lr_factor", 0.5),
        )

    def configure_criteria(self):
        return {
            "mel_loss": criterions.SequenceLoss("mse_loss", use_masking=True),
            "bce_loss": criterions.SequenceLoss("bce_loss", use_masking=True),
            "guided_attention_loss": criterions.GuidedMultiHeadAttentionLoss(sigma=0.4, alpha=1.0, reset_always=True),
        }

    def configure_metrics(self):
        return {
            "mel_loss": metrics.Mean(),
            "bce_loss": metrics.Mean(),
            "guided_attention_loss": metrics.Mean(),
            "loss": metrics.Mean(),
        }

    def train_hooks(self):
        return [TransformerHook(self.save_path)]


class TransformerHook(Hook):
    def __init__(self, save_path):
        super().__init__(order=HookOrder.LOGGING + 1, node=HookNode.ALL)
        self.att_cross_dir = save_path + os.sep + "attention"
        os.makedirs(self.att_cross_dir, exist_ok=True)

    def on_step_end(self, trainer):
        if not trainer.engine.is_master_process:
            # Worker sync
            trainer.engine.barrier()
            return

        if trainer.global_steps % 1000 == 0:
            self.image_att_cross_path = os.path.join(
                self.att_cross_dir, "Steps_{}_CrossAttention.jpg".format(trainer.global_steps)
            )
            self._plot_and_save(
                torch.stack([attn_cross[-1].transpose(1, 2) for attn_cross in trainer.attn_cross_list], dim=0)
                .float()
                .data.cpu()
                .numpy(),
                self.image_att_cross_path,
                figsize=(4, 16),
                dpi=150,
            )  # store the cross-attention matrix picture
            logger.info(f"Saving cross-attention matrix picture to the {os.path.abspath(self.image_att_cross_path)}")

        if trainer.engine.is_master_process:
            # Master sync
            trainer.engine.barrier()

    # define function for plot prob and att_ws
    @staticmethod
    def _plot_and_save(array, figname, figsize=(6, 4), dpi=150):
        shape = array.shape
        if len(shape) == 1:
            # for eos probability
            plt.figure(figsize=figsize, dpi=dpi)
            plt.plot(array)
            plt.xlabel("Frame")
            plt.ylabel("Probability")
            plt.ylim([0, 1])
        elif len(shape) == 2:
            # for tacotron 2 attention weights, whose shape is (out_length, in_length)
            plt.figure(figsize=figsize, dpi=dpi)
            plt.imshow(array, aspect="auto", origin="lower", interpolation="none")
            plt.xlabel("Input")
            plt.ylabel("Output")
        elif len(shape) == 4:
            # for transformer attention weights, whose shape is (#leyers, #heads, out_length, in_length)
            plt.figure(figsize=(figsize[0] * shape[0], figsize[1] * shape[1]), dpi=dpi)
            for idx1, xs in enumerate(array):
                for idx2, x in enumerate(xs, start=1):
                    plt.subplot(shape[0], shape[1], idx1 * shape[1] + idx2)
                    plt.imshow(x, aspect="auto", origin="lower", interpolation="none")
                    plt.xlabel("Output (Decoder mel-frame)")
                    plt.ylabel("Input (Encoder phone)")
        else:
            raise NotImplementedError("Support only from 1D to 4D array.")
        plt.tight_layout()
        if not os.path.exists(os.path.dirname(figname)):
            # NOTE: exist_ok = True is needed for parallel process decoding
            os.makedirs(os.path.dirname(figname), exist_ok=True)
        plt.savefig(figname)
        plt.close()

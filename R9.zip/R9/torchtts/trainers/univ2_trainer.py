import os.path
from itertools import chain
import logging

import torch

from torchtts.nn.criterions import GANLoss
from torchtts.nn.criterions import MultiResolutionSTFTLoss
# from torchtts.nn.criterions import mel_spectrogram_torch
from torchtts.nn.metrics import Mean
from torchtts.nn.optim.lr_schedulers import PowerLR, TwoStepsLR
from torchtts.trainers.base_trainer import Trainer
from torchtts.hooks.moving_average import ExponentialMovingAverageHook
from torchtts.utils.import_utils import _APEX_AVAILABLE
from torchtts.utils.torch_utils import unwrap_ddp

import soundfile

if _APEX_AVAILABLE:
    from apex.optimizers import FusedAdam as Adam
else:
    from torch.optim import Adam

import torch.nn.functional as F

logger = logging.getLogger(__name__)


class Univ2Trainer(Trainer):
    def test_step(self):
        gen = self.model['generator']
        gen.eval()
        rank = 0
        if hasattr(self, 'cluster_env'):
            rank = self.cluster_env.rank

        real_dir = os.path.join(self.save_path, f'{"dev/real"}')
        real_exist = os.path.exists(real_dir)

        with torch.no_grad():
            i = 0
            for testb in self.cv_dataloader:
                testb = self.engine.to_device(testb)
                mels = testb['mel']
                wavs = gen(mels)
                wavs = wavs.squeeze().cpu().numpy()
                wav_path = os.path.join(self.save_path, f'dev/{self.global_steps + 1}/{rank}_{i}.wav')
                os.makedirs(os.path.dirname(wav_path), exist_ok=True)
                soundfile.write(wav_path, wavs, samplerate=24000)
                if not real_exist:
                    real_path = os.path.join(real_dir, f'{rank}_{i}.wav')
                    os.makedirs(os.path.dirname(real_path), exist_ok=True)
                    soundfile.write(real_path, testb['audio'].squeeze().cpu(), samplerate=24000)
                if i > 19:  # 20 samples per rank
                    break
                i += 1

        gen.train()

    def de_accurancy(self, mel):
        """
        down sampling and up sampling to simulate the noise
        Args:
            mel:

        Returns:

        """
        ratio_time = 0.7
        ratio_fre = 0.7
        mel = mel.unsqueeze(0)
        org_shape = mel.shape
        mel = F.interpolate(mel, scale_factor=(ratio_fre, ratio_time), mode='bilinear', align_corners=True,
                            recompute_scale_factor=True)
        mel = F.interpolate(mel, size=(org_shape[2], org_shape[3]), mode='bilinear', align_corners=True)
        mel = mel.squeeze(0)
        return mel

    def train_step(self, batch):
        with self.engine.context():
            mel = batch['mel']
            if self.global_steps % 2 == 0:
                x = batch['mel'].to('cpu')
                mel = self.de_accurancy(x).to('cuda')
            y_ = self.model['generator'](mel)
            y = batch['audio'].unsqueeze(1)

        # Train discriminator
        # print(self.global_steps)
        self.global_steps = int(self.global_steps)
        if self.global_steps >= self._config["disc_train_start_steps"]:
            with self.engine.context():
                p = self.model['discriminator'](y)
                p_ = self.model['discriminator'](y_.detach())

                real_loss_list = []
                fake_loss_list = []
                for i in range(len(p)):
                    real_loss, fake_loss = self.criteria['gan_loss'].disc_loss(p[i][-1], p_[i][-1])
                    real_loss_list.append(real_loss)
                    fake_loss_list.append(fake_loss)

                # spec discriminator
                if 'spec_discriminator' in self.model:
                    sd_p = self.model['spec_discriminator'](y)
                    sd_p_ = self.model['spec_discriminator'](y_.detach())

                    for i in range(len(sd_p)):
                        real_loss, fake_loss = self.criteria['gan_loss'].disc_loss(sd_p[i][-1], sd_p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)

                # multi-peroid discriminator
                if self._config['use_mpd_discriminator'] and 'mpdiscriminator' in self.model:
                    md_p, md_p_, _, _ = self.model['mpdiscriminator'](y, y_.detach())

                    for i in range(len(md_p)):
                        real_loss, fake_loss = self.criteria['gan_loss'].disc_loss(md_p[i][-1], md_p_[i][-1])
                        real_loss_list.append(real_loss)
                        fake_loss_list.append(fake_loss)

                real_loss = sum(real_loss_list) / len(real_loss_list)
                fake_loss = sum(fake_loss_list) / len(fake_loss_list)

                disc_loss = real_loss + fake_loss + torch.abs(real_loss - fake_loss)

            self.metrics['real_loss'].update_state(real_loss)
            self.metrics['fake_loss'].update_state(fake_loss)
            self.metrics['disc_loss'].update_state(disc_loss)

            self.engine.optimize_step(loss=disc_loss,
                                      optimizer=self.optimizers['disc'],
                                      lr_scheduler=self.lr_schedulers['disc'])

        # Train generator
        gen_loss = 0.
        unwrap_ddp(self.model['discriminator']).requires_grad_(False)
        if 'spec_discriminator' in self.model:
            unwrap_ddp(self.model['spec_discriminator']).requires_grad_(False)

        # if self._config["use_mel_loss"]:
        #     with self.engine.context():
        #         y_mel = mel_spectrogram_torch(y.squeeze(1), 1200, 128, 24000, 300, 1200, 0.0, None)
        #         y_hat_mel = mel_spectrogram_torch(y_.squeeze(1), 1200, 128, 24000, 300, 1200, 0.0, None)
        #         mel_loss = self.criteria['mel_loss'](y_mel, y_hat_mel)
        #         gen_loss += mel_loss
        #
        #     self.metrics['mel_loss'].update_state(mel_loss)

        if self._config["use_stft_loss"] and self.global_steps < self._config["stft_loss_steps"]:
            with self.engine.context():
                sc_loss, mag_loss = self.criteria['stft_loss'](y_.squeeze(1), y.squeeze(1))
                gen_loss += sc_loss + mag_loss

            self.metrics['sc_loss'].update_state(sc_loss)
            self.metrics['mag_loss'].update_state(mag_loss)

        if self.global_steps >= self._config["disc_train_start_steps"]:
            with self.engine.context():
                p_ = self.model['discriminator'](y_)

                adv_loss_list = []
                for i in range(len(p_)):
                    adv_loss_list.append(self.criteria['gan_loss'].gen_loss(p_[i][-1]))

                if 'spec_discriminator' in self.model:
                    sd_p_ = self.model['spec_discriminator'](y_)
                    for i in range(len(sd_p_)):
                        adv_loss_list.append(self.criteria['gan_loss'].gen_loss(sd_p_[i][-1]))

                # multi period discriminator
                if self._config['use_mpd_discriminator'] and 'mpdiscriminator' in self.model:
                    md_p, md_p_, _, _ = self.model['mpdiscriminator'](y, y_)
                    for i in range(len(md_p_)):
                        adv_loss_list.append(self.criteria['gan_loss'].gen_loss(md_p_[i][-1]))

                adv_loss = sum(adv_loss_list) / len(adv_loss_list)
                gen_loss += adv_loss * self._config['lambda_adv']

                self.metrics['adv_loss'].update_state(adv_loss)

            if self._config['use_feat_match_loss']:
                fm_loss = 0.
                with self.engine.context():
                    with torch.no_grad():
                        p = self.model['discriminator'](y)
                    for i in range(len(p_)):
                        for j in range(len(p_[i]) - 1):
                            fm_loss += self.criteria['fm_loss'](p_[i][j], p[i][j].detach())
                    fm_loss /= (i + 1) * (j + 1)

                    self.metrics['fm_loss'].update_state(fm_loss)
                    gen_loss += fm_loss * self._config["lambda_feat_match_loss"]

                    if 'spec_discriminator' in self.model:
                        spec_fm_loss = 0.
                        with torch.no_grad():
                            sd_p = self.model['spec_discriminator'](y)
                        for i in range(len(sd_p_)):
                            for j in range(len(sd_p_[i]) - 1):
                                spec_fm_loss += self.criteria['fm_loss'](sd_p_[i][j], sd_p[i][j].detach())
                        spec_fm_loss /= (i + 1) * (j + 1)

                        self.metrics['spec_fm_loss'].update_state(spec_fm_loss)
                        gen_loss += spec_fm_loss * self._config['lambda_feat_match_loss']

                    if self._config['use_mpd_discriminator'] and 'mpdiscriminator' in self.model:
                        period_fm_loss = 0.
                        with torch.no_grad():
                            md_p, md_p_, fmap_p, fmap_p_ = self.model['mpdiscriminator'](y, y_)

                        period_fm_loss = self.criteria['gan_loss'].feature_loss(fmap_p, fmap_p_)

                        self.metrics['period_fm_loss'].update_state(period_fm_loss)
                        gen_loss += period_fm_loss * self._config['lambda_feat_match_loss']

        self.metrics['gen_loss'].update_state(gen_loss)

        self.engine.optimize_step(loss=gen_loss,
                                  optimizer=self.optimizers['gen'],
                                  lr_scheduler=self.lr_schedulers['gen'])

        unwrap_ddp(self.model['discriminator']).requires_grad_(True)
        if 'spec_discriminator' in self.model:
            unwrap_ddp(self.model['spec_discriminator']).requires_grad_(True)

        if (self.global_steps + 1) % self.save_interval == 0:
            self.test_step()

        # The return value will be stored as training logs.
        return {k: m.result() for k, m in self.metrics.items()}

    def configure_optimizers(self):
        disc_params = self.model['discriminator'].parameters()
        if 'spec_discriminator' in self.model:
            disc_params = chain(disc_params, self.model['spec_discriminator'].parameters())

        if self._config['use_mpd_discriminator'] and 'mpdiscriminator' in self.model:
            disc_params = chain(disc_params, self.model['mpdiscriminator'].parameters())

        return {
            'gen': Adam(self.model['generator'].parameters(),
                        **self._config["gen_optim_params"]),
            'disc': Adam(disc_params,
                         **self._config["disc_optim_params"])
        }

    def configure_lr_schedulers(self):
        return {
            'gen': PowerLR(self.optimizers['gen'],
                           **self._config["gen_schedule_params"]),
            'disc': TwoStepsLR(self.optimizers['disc'],
                               **self._config["disc_schedule_params"]),
        }

    def configure_criteria(self):
        criteria = {
            'gan_loss': GANLoss(mode='lsgan'),
        }
        if self._config['use_stft_loss']:
            criteria['stft_loss'] = MultiResolutionSTFTLoss(**self._config['stft_loss_params'])
        if self._config['use_feat_match_loss']:
            criteria['fm_loss'] = torch.nn.L1Loss()
        if self._config['use_mel_loss']:
            criteria['mel_loss'] = torch.nn.L1Loss()
        return criteria

    def configure_metrics(self):
        metrics = {
            'real_loss': Mean(),
            'fake_loss': Mean(),
            'disc_loss': Mean(),
            'gen_loss': Mean(),
            'adv_loss': Mean(),
            'sc_loss': Mean(),
            'mag_loss': Mean(),
            'mel_loss': Mean(),
        }
        if self._config['use_feat_match_loss']:
            metrics['fm_loss'] = Mean()
            if 'spec_discriminator' in self.model:
                metrics['spec_fm_loss'] = Mean()
            if 'mpdiscriminator' in self.model:
                metrics['period_fm_loss'] = Mean()
        return metrics

    def train_hooks(self):
        return [ExponentialMovingAverageHook(name='generator_ema',
                                             model=self.model['generator'],
                                             decay=self._config['ema_decay'],
                                             update_interval=self._config['ema_update_interval'],
                                             reset_interval=self._config['ema_reset_interval'])]

"""
use check FastTranscription result time
"""

import json
import os,sys

# def read_json(jsonfile):
#     # 打开 JSON 文件
#     with open(jsonfile, "r",encoding='utf8') as file:
#         data = json.load(file)
#     Durations = 0.0
#     if 'Duration' in data:
#     # durations = [int(line["duration"]) for line in data["fileInfo"]]
#         if '小时' in data["Duration"] and "min" not in data["Duration"]:
#             Durations=int(data["Duration"].split(' ')[0]).replace('小时','')
#         if '小时 ' in data["Duration"] and "min" in data["Duration"]:
#             Durations=float(data["Duration"].split(' ')[0].replace('小时',''))+int(data["Duration"].split(' ')[2].replace('min',''))/60
#         if '小时' not in data["Duration"] and "min" in data["Duration"]:
#             Durations=int(data["Duration"].split(' ')[0].replace('min',''))/60
#     else:
#         print("No Duration in %s" % jsonfile)
#     return Durations

def check_fasttranscription_result(input_file):
    sum_yime = 0
    for line in os.listdir(input_file):
        if ".json" in line:
            with open(os.path.join(input_file,line),'r',encoding='utf8') as f:
                data = json.load(f)
            print(os.path.basename(line)+'\t'+str(data["fasttranscription_result"]["durationMilliseconds"]))
            sum_yime += int(data["fasttranscription_result"]["durationMilliseconds"])
            # print(data["fasttranscription_result"]["durationMilliseconds"])
            # for segment in data["fasttranscription_result"]["phrases"]:
            #     print(segment["offsetMilliseconds"]+)
    print("Total duration in milliseconds: %s hours" % str(round(sum_yime/3600000, 5)))

def log_chek(log_file):
    with open(log_file, 'r', encoding='utf8') as f,open(log_file.replace('.txt', '_check1.txt'), 'w', encoding='utf8') as s:
        for line in f.readlines():
            name = line.replace('\n','')
            size_bytes = os.path.getsize(name.replace('.json','.mp3'))
            size_mb = size_bytes / (1024 * 1024)
            
            with open(name, 'r', encoding='utf8') as f1:
                data = json.load(f1)
                if "Duration" in data:
                    s.write(name + '\t' + data["Duration"] + '\t' + f"{size_mb:.2f} MB" +'\n')
                else:
                    print("No Duration in %s" % name)
                    
if __name__ == "__main__":

    log_chek(sys.argv[1])
    # fasttranscription_ratio(sys.argv[1], sys.argv[2])
    # fasttranscription_ratio(r"C:\Users\v-zhazhai\Downloads\1.txt", r"C:\Users\v-zhazhai\Downloads\1")
    # line = r"C:\Users\v-zhazhai\Downloads\zhcn\id1629435270_lphy39ClMqSAkO4ASyOvlqH33tZl00031.mp3"
    
    # size_bytes = os.path.getsize(line)
    # size_mb = size_bytes / (1024 * 1024)
    # print(f"File size: {size_mb:.2f} MB")

#!/bin/bash


# workspace_name="zetta-amprod-ws01-scus"
# compute_target="ZettA-AML-D64v4"

workspace_name="zetta-prod-ws02-eus2"
#compute_target="ZettA-AML-Target"
compute_target="ZettA-AML-Data"

inputdir="/datablob/v-litfen/apple/tier1/zhcn/podcast/accent_fine_data/speaker_statistic.txt"
# command="python ./V3_stats_set_output.py "$inputdir
command="pip install wave; pip install tinytag; python check_sppech_length.py "$inputdir

# experiment_name="V3_stats_set_output"
# display_name="zhCN_batch08_ttschunk_audio_text_segment"

experiment_name="check_FastTranscription"
display_name="Audio_conversion_zhcn_try1"

"C:\Users\v-zhazhai\Toosl\miniconda3\envs\use\python.exe" -u utils/zetta_submit.py \
  --workspace_name "${workspace_name}" \
  --compute_target "${compute_target}" \
  --experiment_name "${experiment_name}" \
  --display_name "${display_name}" \
  --key_vault_name "exawatt-philly-ipgsp" \
  --docker_address "azurespeechdockers.azurecr.io" \
  --docker_name "torchttsdataprocessing:release_20240920_124804" \
  --local_code_dir "$(pwd)" \
  --cmd "${command}"\
  --docker_username "default-pull"



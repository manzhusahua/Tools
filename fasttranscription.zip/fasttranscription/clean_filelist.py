import os
import json
import glob

"""
用于将filelist中的音频清除ratio小于.5的音频文件
"""
def check_ratio(jsondir,wavenaeme):
    for jsonfile in glob.glob(os.path.join(jsondir, "**", "*.json"), recursive=True):
        with open(jsonfile, "r") as file:
            data = json.load(file)
        print(data)
        # for line in data:
        #     if wavenaeme.replace('.wav', '.mp3') in line:
        #         print(line)
        #         print(data[n+3])
        #         ratio = float(data[n+4].replace('        "ratio": "', '').split('\"')[0])
        #         return ratio
        #     n+=1




def clean_filelist(filelist_path, output_path):
    with open(filelist_path, "r", encoding='UTF-8') as f:
        for line in f.readlines():
            wavenaeme = line.replace('\n', '')
            filename = check_ratio(output_path,wavenaeme)
            print(filename)
    


if __name__ == "__main__":
    # ratio = check_ratio(r"C:\Users\v-zhazhai\Downloads\filelist","00000000.wav")
    # print(ratio)
    # clean_filelist(r"C:\Users\v-zhazhai\Downloads\test1.txt", r"C:\Users\v-zhazhai\Downloads\filelist")
    ratio = check_ratio(r"C:\Users\v-zhazhai\Downloads\11111","00000001.wav")
    print(ratio)
import json,sys,os,shutil


def Result_viewing(jsonfile):
    with open(jsonfile, "r") as file:
        data = json.load(file)
    duration = data["fasttranscription_result"]["durationMilliseconds"]
    offset = data["fasttranscription_result"]["phrases"][0]["offsetMilliseconds"]
    for line in data["fasttranscription_result"]["phrases"]:
        offset+=line["durationMilliseconds"]
    ratio =  str(round(offset/duration, 3))
    return ratio

def read(jsonfile,savedir):
    with open(savedir+".txt", 'a') as s1:
        with open(jsonfile, "r") as file:
            data = json.load(file)
        # print(data["fasttranscription_result"]['combinedPhrases'][0]['text'])
        name =  os.path.basename(jsonfile)
        # print(name)
        save_file = os.path.join(savedir,name.replace(".json",".txt"))
        try:
            with open(save_file,'w',encoding='utf8') as s:
                s.writelines(data["fasttranscription_result"]['combinedPhrases'][0]['text']+'\n')
            ratio = Result_viewing(jsonfile)
            if float(ratio) > 0.6:
                s1.writelines(os.path.basename(jsonfile).replace(".json",".wav")+"\n")
            
        except Exception as e:
            print(f"Error writing to file {save_file}: {e}")
    # shutil.copyfile(jsonfile,os.path.join(savedir,name))

if __name__ == "__main__":
    inputdir = sys.argv[1]
    savedir = sys.argv[2]
    # inputdir = r"C:\Users\v-zhazhai\Downloads\v3_input_json"
    # savedir = r"C:\Users\v-zhazhai\Downloads\test"
    for line in os.listdir(inputdir):
        if ".json" in line:
            read(os.path.join(inputdir,line),savedir)
#!/bin/bash

set -euo pipefail

workspace_name="zetta-prod-ws02-eus2"
#compute_target="ZettA-AML-Target"
compute_target="ZettA-AML-Data"

#workspace_name="zetta-prod-ws01-wus2"
#compute_target="ZettA-AML-D16v3"


input="/datablob/v-litfen/customer/sheng/podcast/podcast20250605/rawdata/podcast/renames/pt-PT/accent_fine_data/v3_input_json/"
savedir="/datablob/v-litfen/apple/tier1/dede/podcast/accent_fine_data/v3_input_json/"

command="python get_trans.py "$input" "$input

experiment_name="fasttranscription_ptpt"
display_name="get_trans_try1"

"C:\Users\v-zhazhai\Toosl\miniconda3\envs\use\python.exe" -u utils/zetta_submit.py \
  --workspace_name "${workspace_name}" \
  --compute_target "${compute_target}" \
  --experiment_name "${experiment_name}" \
  --display_name "${display_name}" \
  --key_vault_name "exawatt-philly-ipgsp" \
  --docker_address "azurespeechdockers.azurecr.io" \
  --docker_name "torchttsdataprocessing:release_20240920_124804" \
  --local_code_dir "$(pwd)" \
  --cmd "${command}"\
  --docker_username "default-pull"



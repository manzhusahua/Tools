import matplotlib.pyplot as plt
import json

def load_json(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

def save_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

data = load_json(r"C:\Users\v-zhazhai\Downloads\speaker_statistic.json")
# Sample data

values = []
print(data['totalduration'])
for key, cases in data['items'].items():
    #print(type(cases))
    duration = int(cases['average_duration']) / 1000
    if duration <= 50:
        values.append(int(cases['average_duration']) / 1000)
#print(values)
# Create histogram
print(values[0:10])
print(len(values))
plt.hist(values, bins=200, edgecolor='black')

# Add title and labels
plt.title('Histogram of average_duration')
plt.xlabel('average_duration')
plt.ylabel('Frequency')

# Show plot
plt.show()
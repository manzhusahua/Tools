import os
import tarfile
import json
import shutil

def Result_viewing(jsonfile):
    with open(jsonfile, "r") as file:
        data = json.load(file)
    duration = data["fasttranscription_result"]["durationMilliseconds"]
    offset = data["fasttranscription_result"]["phrases"][0]["offsetMilliseconds"]
    for line in data["fasttranscription_result"]["phrases"]:
        offset+=line["durationMilliseconds"]
    ratio =  str(round(offset/duration, 3))
    return ratio

def un_tar(tar_path, extract_path):
    # 打开 tar 文件
    ratio_arvger = []
    with tarfile.open(tar_path, 'r') as tar:
        tar.extractall(path=extract_path)
    for line in os.listdir(extract_path):
        json_path = os.path.join(extract_path, line,"additional_info")
        ratio = Result_viewing(json_path)
        ratio_arvger.append(float(ratio))
    ratio = str(round(sum(ratio_arvger) / len(ratio_arvger), 3))
    return ratio

def clean_data(file_path,save_path):
    """"
    用于clean Apple Data 中 FastTranscription ratio 较低的数据
    """
    with open(save_path+".txt",'w',encoding='utf-8') as s:
        for line in os.listdir(file_path):
            shutil.copyfile(os.path.join(file_path,line),os.path.join(save_path,line+".tar"))
            ratio = un_tar(os.path.join(save_path,line+".tar"),os.path.join(save_path,line))
            s.write(line+"\t"+ratio+"\n")
    shutil.rmtree(save_path, ignore_errors=True)
if __name__ == "__main__":
    clean_data(r"C:\Users\v-zhazhai\debug\inputdir",r"C:\Users\v-zhazhai\debug\outputdir")
    # un_tar(r"C:\Users\v-zhazhai\debug\outputdir\chunk_063bdcba132a985bc4a8feba63192c99_0.info.tar", r"C:\Users\v-zhazhai\debug\outputdir\chunk_063bdcba132a985bc4a8feba63192c99_0")
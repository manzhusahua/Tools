#!/bin/bash

set -euo pipefail

# workspace_name="zetta-prod-ws02-eus2"
# compute_target="ZettA-AML-Target"


workspace_name="zetta-prod-ws01-wus2"
compute_target="ZettA-AML-D16v3"

inputdir="/datablob/realisticttsdataset_v3/train/chunks/tier1/en-au/applepodcast/average_duration_35-50/"
save_path="/datablob/v-zhazhai/realisticttsdataset_v3/datacheck/20250612/tier1/en-au/applepodcast/average_duration_35-50"

command="python info_clean.py "$inputdir" "$save_path

experiment_name="info_clean_applepodcast"
display_name="enau_35-50"

"C:\Users\v-zhazhai\Toosl\miniconda3\envs\use\python.exe" -u utils/zetta_submit.py \
  --workspace_name "${workspace_name}" \
  --compute_target "${compute_target}" \
  --experiment_name "${experiment_name}" \
  --display_name "${display_name}" \
  --key_vault_name "exawatt-philly-ipgsp" \
  --docker_address "azurespeechdockers.azurecr.io" \
  --docker_name "torchttsdataprocessing:release_20240920_124804" \
  --local_code_dir "$(pwd)" \
  --cmd "${command}"\
  --docker_username "default-pull"



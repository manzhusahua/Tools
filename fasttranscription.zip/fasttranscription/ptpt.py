import os, json, sys
import shutil
from pathlib import Path
from pydub import AudioSegment
import time
import librosa


# batch_txt_name = "00000.txt"
# batch_json_name = "00000.json"
batch_txt_name = str(sys.argv[1]).zfill(5) + ".txt"
batch_json_name = str(sys.argv[1]).zfill(5) + ".json"

filelist_dir = r"/datablob/v-litfen/customer/sheng/podcast/podcast20250605/rawdata/podcast/renames/pt-PT/accent_fine_data/filelist/"
output_dir = r"/datablob/v-litfen/customer/sheng/podcast/podcast20250605/rawdata/podcast/renames/pt-PT/accent_fine_data/v3_input_json/"
log_dir = r"/datablob/v-litfen/customer/sheng/podcast/podcast20250605/rawdata/podcast/renames/pt-PT/accent_fine_data/log/"

# filelist_dir = r"/mnt/c/Users/v-zhazhai/Downloads/test/"
# output_dir = r"/mnt/c/Users/v-zhazhai/Downloads/test/v3_input_json/"
# log_dir = r"/mnt/c/Users/v-zhazhai/Downloads/test/log/"

os.makedirs(output_dir, exist_ok=True)
os.makedirs(log_dir, exist_ok=True)

input_filelist = filelist_dir + batch_txt_name
outputlog = log_dir + batch_json_name

filelist = Path(input_filelist)
logfile = Path(outputlog)
temp_path = Path(output_dir)
log_path = Path(log_dir)

if not temp_path.exists():
    temp_path.mkdir(exist_ok=True)
if not log_path.exists():
    log_path.mkdir(exist_ok=True)
with open(filelist, "r", encoding='UTF-8') as fin:
    lines = fin.readlines()
badcase = {}

def Result_viewing(jsonfile):
    with open(jsonfile, "r") as file:
        data = json.load(file)
    duration = data["fasttranscription_result"]["durationMilliseconds"]
    offset = data["fasttranscription_result"]["phrases"][0]["offsetMilliseconds"]
    for line in data["fasttranscription_result"]["phrases"]:
        offset+=line["durationMilliseconds"]
    ratio =  str(round(offset/duration, 3))
    return str(round(duration/1000, 3)),str(round(offset/1000, 3)),ratio

for line in lines:
    line = line.strip()
    folder_name = os.path.basename(os.path.dirname(line))
    json_filename = os.path.basename(line).replace('wav', 'json').replace('mp3', 'json')
    # json_filename = folder_name + '_' + json_filename
    result_json = os.path.join(output_dir, json_filename)
    if os.path.exists(result_json):
        print("result exist, skip file: " + line)
        continue
    else:
        temp_txt_filename = result_json.replace('.json', '_temp.txt')
        temp_mp3_filename = result_json.replace('.json', '.mp3')
        if os.path.exists(temp_txt_filename):
            os.remove(temp_txt_filename)
        if os.path.exists(temp_mp3_filename):
            os.remove(temp_mp3_filename)
    wave_file = Path(line)
    if not wave_file.exists():
        if line not in badcase:
            badcase[line] = f"audio {wave_file} not exist"
        continue
    filename = json_filename.split('.')[0]
    if wave_file.suffix == '.wav' or wave_file.suffix == '.m4a':
        audio_data = AudioSegment.from_file(wave_file)
        audio_duration = len(audio_data) / 1000 / 3600
        if audio_duration > 2:
            print(f"audio {wave_file} duration is {audio_duration} hours longer than 2 hours, skip it")
            if line not in badcase:
                badcase[line] = f"audio {wave_file} duration is {audio_duration} hours longer than 2 hours, skip it"
            continue
        del audio_data

        temp_mp3_file = temp_path / f"{filename}.mp3"

        convert_command = f"ffmpeg -i {wave_file} -b:a 96k {temp_mp3_file}"
        print(convert_command)
        if temp_mp3_file.exists():
            os.remove(temp_mp3_file)

        os.system(convert_command)
        if not temp_mp3_file.exists():
            print(f"convert {wave_file.stem} failed")
            if line not in badcase:
                badcase[line] = f"convert {wave_file.stem} failed"
            continue

        if temp_mp3_file.stat().st_size > 200 * 1024 * 1024:
            print(f"{temp_mp3_file.stem} is larger than 200M, skiped")
            if line not in badcase:
                badcase[line] = f"{temp_mp3_file.stem} is larger than 200M, skiped"
            if temp_mp3_file.exists():
                os.remove(temp_mp3_file)
            continue  

        if temp_mp3_file.stat().st_size > 1 * 1024 * 1024:
            print(f"{temp_mp3_file.stem}  is less than 1M, skiped")
            if line not in badcase:
                badcase[line] = f"{temp_mp3_file.stem} is less than 1M, skiped"
            if temp_mp3_file.exists():
                os.remove(temp_mp3_file)
            continue             

    elif wave_file.suffix == '.mp3':
        if wave_file.stat().st_size > 200 * 1024 * 1024:
            print(f"{wave_file} is larger than 200M, skiped")
            if line not in badcase:
                badcase[line] = f"{wave_file} is larger than 200M, skiped"
            continue   

        temp_mp3_file = temp_path / f"{filename}.mp3"

        """
        It is used to determine whether the audio exceeds two hours
        """
        try:
            time_count = librosa.get_duration(filename=wave_file)
            if time_count/3600 > 2:
                badcase[line] = f"audio {wave_file} duration is {time_count/3600} hours longer than 2 hours, skip it"
                continue
        except Exception as e:
            badcase[line] = f"audio {wave_file} is there are problems, skip it"
            continue

        shutil.copy(wave_file, temp_mp3_file)

        if not temp_mp3_file.exists():
            print(f"copy {wave_file.stem} failed")
            if line not in badcase:
                badcase[line] = f"copy {wave_file} failed"
            continue
    else:
        if line not in badcase:
            badcase[line] = f"input is not mp3 or wav file"
            continue  

    temp_mp3_file = str(temp_mp3_file)
    temp_result_file = str(temp_path / f"{filename}_temp.txt")
    result_file = str(temp_path / f"{filename}.json")
    if not os.path.exists(temp_mp3_file):
        print(f"mp3 file not exist:" + temp_mp3_file)
        continue
    for i in range(2):
        if os.path.exists(temp_result_file):
            os.remove(temp_result_file)
            
        FTcommand = f'curl --location "https://southeastasia.api.cognitive.microsoft.com/speechtotext/transcriptions:transcribe?api-version=2024-11-15" --header "Content-Type: multipart/form-data" --header "Ocp-Apim-Subscription-Key:e8e879b043f54e29824c63cdad2f93b1" --form audio="@{temp_mp3_file}" --form definition="{{\\"locales\\":[\\"pt-PT\\"], \\"diarization\\": {{\\"enabled\\": true}} }}" > {temp_result_file}'

        print(FTcommand)
        os.system(FTcommand)

        if not os.path.exists(temp_result_file):
            print(f"The {i}-th time: transcribe {wave_file.stem} failed")
            # Sleep for 1 second
            time.sleep(1)
            continue
        print("write result to json start")
        with open(temp_result_file, 'r') as file:
            try:
                data = json.load(file)
            except:
                print(f"load data failed for {temp_result_file}")
                # Sleep for 1 second
                time.sleep(1)
                continue
        if "durationMilliseconds" not in data:
            # Sleep for 1 second
            time.sleep(1)
            continue
        res_dict = {'fasttranscription_result': data}
        with open(result_file, "w", encoding="utf-8") as f:
            json.dump(res_dict, f, indent=4)
        print(f"finished dump: {wave_file}")
        try:
            duration,offset,ratio = Result_viewing(result_file)
        except Exception as e:
            if line not in badcase:
                badcase[line] = f"get sr result failed"
            continue  
        with open(input_filelist.replace('.txt','.json'),'a',encoding='utf8') as s:
            row_values = {
                f"{wave_file}": {
                    "duration": f"{str(duration)}",
                    "offset": f"{str(offset)}",
                    "ratio": f"{str(ratio)}",
                    },
            }
            json.dump(row_values, s, indent=4)
        if os.path.exists(temp_mp3_file):
            os.remove(temp_mp3_file)
        if os.path.exists(temp_result_file):
            os.remove(temp_result_file)
        break
    if not os.path.exists(result_file):
        if line not in badcase:
            badcase[line] = f"get sr result failed"
    
if badcase:
    with open(logfile, "w", encoding="utf-8") as f:
        json.dump(badcase, f, indent=4)
    
import os,sys

def rename_json(inputdir):
    for line in os.listdir(inputdir):
        os.rename(os.path.join(inputdir,line),os.path.join(inputdir,line.split('-')[-1]))


if __name__ == "__main__":
    rename_json(sys.argv[1])
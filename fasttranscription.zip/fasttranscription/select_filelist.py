import matplotlib.pyplot as plt
import json,os

def load_json(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

def save_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)


def average_duration(st,et):
    names = f"filelist_{st}-{et}.txt"
    data = load_json(r"C:\Users\v-zhazhai\Downloads\speaker_statistic.json")
    # Sample data
    values = []
    totalduration = 0
    if st!=50:
        for key, cases in data['items'].items():
            #print(type(cases))
            duration = int(cases['average_duration']) / 1000
            if duration >=st and duration <= et:
                values.append(key + '.wav')
                totalduration += float(cases['average_duration'])*(int(cases['switch_count']) + 1)
        with open(os.path.join(r"C:\Users\v-zhazhai\Downloads",names), "w") as file:
            for item in values:
                file.write(item + "\n")
        print(f"{st}-{et} totalduration:", totalduration/1000/3600)
    else:
        for key, cases in data['items'].items():
            #print(type(cases))
            duration = int(cases['average_duration']) / 1000
            if duration >=st:
                values.append(key + '.wav')
                totalduration += float(cases['average_duration'])*(int(cases['switch_count']) + 1)
        with open(os.path.join(r"C:\Users\v-zhazhai\Downloads","filelist_50.txt"), "w") as file:
            for item in values:
                file.write(item + "\n")
        print(f"{st} totalduration:", totalduration/1000/3600)

data = load_json(r"C:\Users\v-zhazhai\Downloads\speaker_statistic.json")
print(data['totalduration'])
average_duration(0,15)
average_duration(15,35)
average_duration(35,50)
average_duration(50,50)
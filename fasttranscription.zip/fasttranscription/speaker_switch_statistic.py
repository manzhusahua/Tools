import os,sys
import json
def load_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)
    return data
def save_json(data, file_path):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=4)

input = sys.argv[1]
output = sys.argv[2]
inputfiles = os.listdir(input)
result_dict = {}
casenum = 0
totalduration = 0
itemsdict = {}
for file in inputfiles:
    reference_speaker = '1'
    total_pharse = 0
    switch_count = 0
    speaker_count = 0
    speaker_infor = {} # speaker id: phrase count, total duration , average duration

    if not file.endswith('json'):
        continue
    try:
        file_without_extention = file.split('.')[0]
        file_path = os.path.join(input, file)
        try:
            data = load_json(file_path)
        except:
            print("failed to load json file: " + file)
            continue
        segements = data['fasttranscription_result']['phrases']
        casenum = casenum + 1
        totalduration = totalduration + data['fasttranscription_result']['durationMilliseconds']
        reference_speaker = segements[0]['speaker']
        segement_speaker_count = 0
        segement_speaker_duration = 0
        total_pharse = len(segements)
        for segement in segements:
            current_speaker = segement['speaker']
            duration = segement['durationMilliseconds']
            segement_speaker_duration = segement_speaker_duration + duration
            if current_speaker not in speaker_infor:
                speaker_infor[current_speaker] = [1, 0, 0]
                segement_speaker_count = segement_speaker_count + 1
            else:
                if current_speaker != reference_speaker:
                    speaker_infor[current_speaker][0] = speaker_infor[current_speaker][0] + 1
                    segement_speaker_count = segement_speaker_count + 1
            speaker_infor[current_speaker][1] = speaker_infor[current_speaker][1] + duration

            if current_speaker != reference_speaker:
                switch_count = switch_count + 1
                reference_speaker = current_speaker
        for key, value in speaker_infor.items():
            speaker_infor[key][2] = value[1] / value[0]
        speaker_count = len(speaker_infor)
        if segement_speaker_count > 0:
            average_duration = segement_speaker_duration / segement_speaker_count
        
        value_dict = {'pharse_count' : total_pharse,
                            'speaker_count': speaker_count,
                            'switch_count': switch_count,
                            'average_duration': average_duration,
                            'speaker_infor': speaker_infor
                            }
        itemsdict[file_without_extention] = value_dict
    except:
        print(f"error {file}")
        continue
result_dict["casenum"] = casenum
result_dict["totalduration"] = totalduration
result_dict['items'] = itemsdict
save_json(result_dict, output)

 
#!/bin/bash

for i in {00001..00024..1}
do
    ./submit_zetta.sh $i
done

#!/bin/bash

set -euo pipefail

workspace_name="zetta-prod-ws02-eus2"
compute_target="ZettA-AML-D8v3"
# compute_target="ZettA-AML-PRS"
#compute_target="ZettA-AML-E8v3"
#compute_target="ZettA-AML-Data"

#workspace_name="zetta-prod-ws01-wus2"
#compute_target="ZettA-AML-Target"
#workspace_name="zetta-prod-ws01-wus2"
#compute_target="ZettA-AML-Target"


each_part=$1

command="python zhhk.py "$each_part

experiment_name="fasttranscription_zhhk"
display_name="ft_zhhk_accent_"$each_part


"C:\Users\v-zhazhai\Toosl\miniconda3\envs\use\python.exe" -u utils/zetta_submit.py \
  --workspace_name "${workspace_name}" \
  --compute_target "${compute_target}" \
  --experiment_name "${experiment_name}" \
  --display_name "${display_name}" \
  --key_vault_name "exawatt-philly-ipgsp" \
  --docker_address "azurespeechdockers.azurecr.io" \
  --docker_name "torchttsdataprocessing:release_20240920_124804" \
  --local_code_dir "$(pwd)" \
  --cmd "${command}"\
  --docker_username "default-pull"



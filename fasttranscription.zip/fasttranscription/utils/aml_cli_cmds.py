"""Provide CLI commands for interacting with Azure ML in order to achieve parity with Amulet"""

import os
import sys
import argparse
import subprocess
import threading
import yaml
import click
from pathlib import Path

from aml_utils.aml_utils import (
    create_uuid,
    download_or_list_blob_files,
    download_blob_directory,
    get_job_model_output_path_storage_account,
    get_job_code_location_container_name_and_environment,
    get_number_of_files_in_dir,
    launch_tb,
    AMLCodeDiff,
    aml_job_list_wrapper,
    get_blob_service_client,
    upload_blob_directory,
)

from aml_utils.setup_aml import (
    install_package,
    check_az_account,
)

from aml_utils.skumanager import get_vc_sub_rg_workspace
from aml_utils.utils import cleanup


cleanup_list = []


def aml_monitor(
    job_names,
    job_vcs,
    port="6006",
    download_profiling_logs=False,
    download_all_profiling_logs=False,
    use_job_display_name=False,
    container_name="philly-ipgsp",
):
    """
    Mirrors aml monitor: downloads the TensorBoard logs from all the jobs in job_names and launches
    a TensorBoard process with them. Each job will be downloaded to a directory with that name,
    so the logs for each job will show up under its name in TensorBoard.

    Args:
        job_names (list[str]): A list of job names to download the logs from
        job_vcs (list[str]): A list of VCs corresponding to each respective job.
            If specified, must match the length of job_names.
        port (str): The port to launch TensorBoard on
        download_profiling_logs (bool): Whether to also download profiling logs.  This should only
            be true if the job was run with `use_profiler: True` in the trainer config.
        download_all_profiling_logs (bool): Whether to download all profiling logs.  If False, only
            one trace file will be downloaded.  If True, all trace files will be downloaded.  This
            is needed because the trace files can be very large and so downloading all of them can
            take a long time.
        use_job_display_name (bool): Whether to use the job's display name instead of its name on
            TensorBoard.
    """
    # All TB logs contain this pattern
    file_patterns = ["tfevents"]
    if download_profiling_logs:
        try:
            # flake8: noqa: F401
            # pylint: disable=unused-import
            # pylint: disable=import-outside-toplevel
            import torch_tb_profiler
        except ImportError:
            if not click.confirm(
                "In order to view profiling logs, the torch-tb-profiler extension will need to be "
                "installed.  Do you want to automatically install it now?",
                default=True,
            ):
                print("Exiting script...")
                sys.exit(1)
            install_package("torch-tb-profiler")
        if not download_all_profiling_logs:
            print(
                "II Note: you have specified `--download_profiling_logs`.  Because of the size of"
                " the trace files, only one trace file will be downloaded by default.  If you wish"
                " to download all trace files, please specify `--download_all_profiling_logs."
            )
        else:
            # All TB profiling logs contain this pattern
            # Note: by doing this, we assume that the user is both downloading profiling logs and
            # wants to download all of them.  The default cause, where only one is downloaded, is
            # handled below.
            print(
                "II Note: you have specified  `--download_all_profiling_logs.`  Due to the size of"
                " the profiling logs, this may take a while (up to 10 minutes)."
            )
            file_patterns.append("pt.trace.json")

    # Make a temporary directory to store all the logs
    tmp_output_directory_uuid = create_uuid()
    tmp_output_directory = os.path.join("/tmp/submitter_tmp_dir", tmp_output_directory_uuid, "logs")
    tmp_output_directory = os.path.normpath(tmp_output_directory)
    num_files_in_dir_before_download = get_number_of_files_in_dir(tmp_output_directory)

    assert len(job_names) == len(job_vcs), "Please ensure that the number of job names and job VCs are the same"
    assert len(job_names) > 0, "Please provide job names and job VCs"

    for job_name, job_vc in zip(job_names, job_vcs):
        (
            project_path_location,
            storage_account,
            job_display_name,
        ) = get_job_model_output_path_storage_account(job_name, job_vc=job_vc)
        logs_project_path_location = os.path.join(project_path_location, "logs")
        logs_project_path_location = os.path.normpath(logs_project_path_location).replace("\\", "/")
        # Save each job's logs in a separate sub-directory
        job_dir_name = job_display_name if use_job_display_name else job_name
        full_output_directory_path = os.path.join(tmp_output_directory, job_dir_name)
        full_output_directory_path = os.path.normpath(full_output_directory_path)
        os.makedirs(full_output_directory_path, exist_ok=True)
        download_or_list_blob_files(
            logs_project_path_location,
            storage_account,
            full_output_directory_path,
            file_patterns_to_match=file_patterns,
            container_name=container_name,
        )
        # In the case that the user wants to download profiling logs but only wants one of them,
        # we handle that here.  In the other case, where the user wants to download all of them,
        # we handle that above.
        if download_profiling_logs and not download_all_profiling_logs:
            download_or_list_blob_files(
                logs_project_path_location,
                storage_account,
                full_output_directory_path,
                file_patterns_to_match=["pt.trace.json"],
                container_name=container_name,
                download_one_file=True,
            )

    num_files_in_dir_after_download = get_number_of_files_in_dir(tmp_output_directory)
    if num_files_in_dir_before_download == num_files_in_dir_after_download:
        print(f"II Warning: no logs found for job(s): '{job_names}'")
    else:
        t = threading.Thread(target=launch_tb, args=([tmp_output_directory, port]), daemon=True)
        t.start()
        try:
            t.join()
        except KeyboardInterrupt:
            pass


def aml_logs(job_name, output_directory, job_vc, container_name):
    """
    Download the logs from an AML job to a local directory.  Effectively, just downloads the
    'logs' directory from the job's model output directory.

    Args:
        job_name (str): The name of the job to download the logs from
        output_directory (str): The local directory to download the logs to.
            Should be an absolute path.
        job_vc (str): The name of the VC the job is in
    """
    project_path_location, storage_account, _ = get_job_model_output_path_storage_account(job_name, job_vc)
    logs_project_path_location = f"{project_path_location}/logs"
    full_output_directory_path = os.path.abspath(os.path.expanduser(os.path.expandvars(output_directory)))
    download_blob_directory(
        logs_project_path_location,
        full_output_directory_path,
        storage_account,
        container_name,
    )


def aml_results(
    job_name,
    file_patterns_to_match,
    sub_directories_to_match,
    output_directory,
    job_vc,
    list_only,
    container_name,
):
    """
    Download the results from an AML job to a local directory.  If file_patterns_to_match is
    specified, then all files (directory preserved and recursively) that match any of the patterns
    will be downloaded. If sub_directories_to_match is specified, then all of the specified
    sub-directories will be downloaded (hierarchy preserved and recursively).

    Args:
        job_name (str): The name of the job to download the results from
        file_patterns_to_match (list[str]): A list of file patterns to match.  If specified,
            only files that match any of the patterns will be downloaded.
        sub_directories_to_match (str): A sub-directory of the project's output folder to download.
            This is relative to the root of the project's output folder (i.e. the directory that
            contains the 'models' and 'logs' directories).
        output_directory (str): The local directory to download the results to.  Should be an
            absolute path.
        job_vc (str): The name of the VC the job is in
        list_only (bool): Whether to list the files in the project's results instead of downloading.

    """
    # dir_to_download will take a relative path from the project root and download it
    project_path_location, storage_account, _ = get_job_model_output_path_storage_account(job_name, job_vc)

    # Handle the case where we want to list (not download) files
    if list_only:
        if sub_directories_to_match:
            for sub_directory in sub_directories_to_match:
                blob_location = os.path.join(project_path_location, sub_directory)
                download_or_list_blob_files(
                    blob_location,
                    storage_account,
                    full_output_directory_path=None,
                    file_patterns_to_match=file_patterns_to_match,
                    container_name=container_name,
                    preserve_folder_structure=True,
                    list_only=True,
                )
        else:
            download_or_list_blob_files(
                project_path_location,
                storage_account,
                full_output_directory_path=None,
                file_patterns_to_match=file_patterns_to_match,
                container_name=container_name,
                preserve_folder_structure=True,
                list_only=True,
            )
        return

    full_output_directory_path = os.path.abspath(os.path.expanduser(os.path.expandvars(output_directory)))

    # Download all files (recursively) in the project's output folder (models and logs) that match
    # any of the file_patterns_to_match
    if file_patterns_to_match:
        assert not sub_directories_to_match, "Cannot specify both file_patterns_to_match and sub_directories_to_match"
        download_or_list_blob_files(
            project_path_location,
            storage_account,
            full_output_directory_path,
            file_patterns_to_match=file_patterns_to_match,
            container_name=container_name,
            preserve_folder_structure=True,
        )
    # Download specific subdirectories of the project's output folder (models and logs)
    # e.g. models/checkpoint18 or models/
    else:
        blob_location = project_path_location
        if sub_directories_to_match:
            for sub_directory in sub_directories_to_match:
                blob_location = os.path.join(project_path_location, sub_directory)
                download_blob_directory(
                    blob_location,
                    full_output_directory_path,
                    storage_account,
                    container_name=container_name,
                )
        # If neither file_patterns_to_match nor sub_directories_to_match are specified, then
        # download the all of the project's outputs
        else:
            print(
                "II Neither file_patterns_to_match nor sub_directories_to_match were specified so"
                " downloading all of the project's outputs"
            )
            download_blob_directory(
                blob_location,
                full_output_directory_path,
                storage_account,
                container_name=container_name,
            )


def copy_blob_dir(
    src_storage_account,
    src_blob_dir,
    dest_storage_account,
    dest_blob_dir,
    src_container="models",
    dest_container="models",
):
    """
    Copy a directory of blobs from one storage account to another.  This will preserve the
    directory structure.

    Args:
        src_storage_account (str): The name of the storage account to copy the blobs from
        src_blob_dir (str): The directory of blobs to copy.  This is relative to the root of the
            container.
        dest_storage_account (str): The name of the storage account to copy the blobs to
        dest_blob_dir (str): The directory to copy the blobs to.  This is relative to the root of
            the container.
        src_container (str): The name of the container to copy the blobs from
        dest_container (str): The name of the container to copy the blobs to
    """
    source_blob_service_client = get_blob_service_client(src_storage_account)
    destination_blob_service_client = get_blob_service_client(dest_storage_account)

    source_container_client = source_blob_service_client.get_container_client(src_container)
    source_blobs = source_container_client.list_blobs(name_starts_with=src_blob_dir)

    print(
        f"II Copying all blobs (preserving directory structure) from '{src_blob_dir}' in"
        f" '{src_storage_account}' to '{dest_blob_dir}' in '{dest_storage_account}'"
    )
    has_copied_blobs = False
    for source_blob in source_blobs:
        new_name = source_blob.name.replace(src_blob_dir, dest_blob_dir)
        destination_blob = destination_blob_service_client.get_blob_client(dest_container, new_name)
        source_blob_client = source_blob_service_client.get_blob_client(src_container, source_blob.name)
        destination_blob.start_copy_from_url(source_url=source_blob_client.url)
        has_copied_blobs = True

    if not has_copied_blobs:
        print(
            f"II Warning: no blobs were copied from storage account '{src_storage_account}',"
            f" container '{src_container}', and directory '{src_blob_dir}'.  This is likely because"
            " that directory does not exist."
        )


def aml_rerun(job_name, job_vc):
    """
    Rerun an AML job.  This effectively downloads the old code folder, opens the old job config,
    updates the relevant fields (including the job name and output location), submits a new job
    using the updated yaml file, and then copies all of the outputs from the
    old job to the new job's output folder ("models" and "logs" folders).

    Args:
        job_name (str): The name of the job to rerun
        job_vc (str): The name of the VC the job is in
    """
    tmp_output_directory_uuid = create_uuid()
    # Download old code folder to tmp directory
    tmp_output_directory = os.path.join("/tmp/cascades_tmp_dir", tmp_output_directory_uuid)

    (
        old_job_code_container_name,
        old_job_code_location_in_container,
        old_code_storage_account,
        old_job_environment_uri,
    ) = get_job_code_location_container_name_and_environment(
        job_name,
        job_vc,
    )

    download_blob_directory(
        old_job_code_location_in_container,
        tmp_output_directory,
        old_code_storage_account,
        container_name=old_job_code_container_name,
    )

    tmp_code_directory = os.path.join(tmp_output_directory, old_job_code_location_in_container)
    tmp_cfg_file_path = os.path.join(tmp_code_directory, "aml_utils", "tmp_cfg_aml.yaml")

    new_job_name = create_uuid()

    # Open the old file and update the relevant fields
    with open(tmp_cfg_file_path, encoding="utf8") as fin:
        rerun_job_cfg = yaml.safe_load(fin)
        # Overwrite the job name to avoid name collision
        rerun_job_cfg["name"] = new_job_name
        # Update the description from old job name to new job name
        rerun_job_cfg["description"] = rerun_job_cfg["description"].replace(job_name, new_job_name)
        rerun_job_cfg["description"] += f"  \n\n This is a rerun of job: '{job_name}'"

        # Update the output from the old job name to thew new job name
        rerun_job_cfg["outputs"]["output"]["path"] = rerun_job_cfg["outputs"]["output"]["path"].replace(
            job_name, new_job_name
        )

        # Update code and environment path to point to old job
        rerun_job_cfg["code"] = tmp_code_directory
        rerun_job_cfg["environment"] = old_job_environment_uri
        for key in rerun_job_cfg["tags"]:
            rerun_job_cfg["tags"][key] = rerun_job_cfg["tags"][key].replace(job_name, new_job_name)
        # AML_OUTPUT_BLOB_PATH and AML_OUTPUT_DIRECTORY need to be updated as well
        for key in rerun_job_cfg["environment_variables"]:
            rerun_job_cfg["environment_variables"][key] = rerun_job_cfg["environment_variables"][key].replace(
                job_name, new_job_name
            )

    with open(tmp_cfg_file_path, "w", encoding="utf8") as fout:
        yaml.safe_dump(rerun_job_cfg, fout, sort_keys=False, indent=4)

    subscription_id, resource_group_name, workspace_name, _region = get_vc_sub_rg_workspace(vc=job_vc)
    print(f"II Submitting rerun job with new name: '{new_job_name}'")
    display_filter = (
        "{job_name:name, tags:tags, experiment_name:experiment_name, display_name:display_name,"
        " job_url: services.Studio.endpoint}"
    )
    job_creation_cmd = (
        f"az ml job create -f {tmp_cfg_file_path} --subscription {subscription_id} "
        f" --resource-group {resource_group_name} --workspace-name {workspace_name} --output yaml "
    )

    # Query doesn't work well on windows, so bypass it for now
    if sys.platform != "win32":
        job_creation_cmd += f" --query '{display_filter}'"

    subprocess.check_call(
        job_creation_cmd,
        shell=True,
    )

    old_job_path_location, old_job_storage_account, _ = get_job_model_output_path_storage_account(job_name, job_vc)

    new_job_path_location, new_job_storage_account, _ = get_job_model_output_path_storage_account(new_job_name, job_vc)

    # Copy from old blob to new blob, but only after the new job has been created so we don't do
    # this if the job creation fails
    copy_blob_dir(
        old_job_storage_account,
        old_job_path_location,
        new_job_storage_account,
        new_job_path_location,
    )


def aml_show(job_name, web, output, job_vc):
    """
    Show the details of an AML job.  Basically just a wrapper around the `az ml job show` command.

    Args:
        job_name (str): The name of the job to show
        web (bool): Whether to also open the job in AML Studio
        output (str): The output format to use: can be json, jsonc, table, tsv, yaml, or yamlc
        job_vc (str): The name of the VC the job is in
    """
    subscription_id, resource_group_name, job_workspace_name, _ = get_vc_sub_rg_workspace(job_vc)

    aml_command = (
        f"az ml job show -n {job_name} --resource-group {resource_group_name} --subscription"
        f"={subscription_id} --output {output} --workspace-name {job_workspace_name}"
    )

    if web:
        aml_command += " --web"
    subprocess.check_call(
        aml_command,
        shell=True,
    )


def aml_list(
    experiment_name,
    vcs,
):
    """
    List all AML jobs for the given VCs.

    Args:
        experiment_name (str): The name of the experiment to list jobs for.  If empty, list
            all jobs
        vcs (list[str]): A list of VCs to list jobs for.

    """
    for vc_name in vcs:
        (
            subscription_id,
            resource_group_name,
            job_workspace_name,
            _region,
        ) = get_vc_sub_rg_workspace(vc_name)
        aml_job_list_wrapper(
            subscription_id,
            resource_group_name,
            job_workspace_name,
            experiment_name,
        )


def aml_storage_upload(job_name, local_dir, remote_dir, job_vc, container_name="models"):
    """
    Upload a local directory (or file) to the remote_dir on the storage account associated with the
    job.  Remote_dir is relative to the project root (i.e., the folder that contains
    "logs" and "models").

    Args:
        job_name (str): The name of the job to upload the directory for
        local_dir (str): The local directory to upload.  Can be a file or a directory.
        remote_dir (str): The remote directory to upload to.  Relative to the project root. For
            example if you want to upload a sample log file to the logs directory,
            you would specify "logs"
        job_vc (str): The name of the VC the job is in
        container_name (str): The name of the Azure container to upload to.  Defaults to "models"
    """
    click.confirm(
        f"\nII The operation you are about to perform will modify the job '{job_name}' in VC"
        f" '{job_vc}' by uploading local dir '{local_dir}' to remote dir '{remote_dir}' please"
        " confirm that you wish to proceed: ",
        default=None,
        abort=True,
    )

    project_path_location, storage_account, _ = get_job_model_output_path_storage_account(job_name, job_vc)
    full_local_dir = os.path.abspath(os.path.expanduser(os.path.expandvars(local_dir)))
    full_remote_dir = os.path.join(project_path_location, remote_dir)
    is_local_dir_a_file = os.path.isfile(full_local_dir)
    # Handle local dir being a file: otherwise, the folder structure isn't preserved
    if is_local_dir_a_file:
        full_remote_dir = os.path.join(full_remote_dir, os.path.basename(full_local_dir))
    elif not os.path.isdir(full_local_dir):
        raise ValueError(f"Local directory '{full_local_dir}' does not exist")
    print(f"II Uploading '{full_local_dir}' to '{full_remote_dir}' on storage account" f" '{storage_account}'")

    upload_blob_directory(storage_account, local_dir, full_remote_dir, container_name)


def aml_diff(job_vc_1, job_name_1, job_vc_2, job_name_2):
    """
    Prints the diff between the code of the two AML jobs.

    Args:
        job_vc_1 (str): The name of the VC that the first job is in
        job_name_1 (str): The name of the first job
        job_vc_2 (str): The name of the VC that the second job is in
        job_name_2 (str): The name of the second job
    """
    print(
        AMLCodeDiff(job_vc_1, job_name_1, job_vc_2, job_name_2).get_diff_str(),
    )


def parse_args():
    """
    Create the CLI parser and parse the command line arguments.  Note: each subcommand has its own
    parser.

    Returns:
        parsed_args (argparse.Namespace): The parsed arguments
    """
    parser = argparse.ArgumentParser(
        description=(
            "This is a CLI script that mimics some of the important functionality of Amulet, since"
            " AML's CLI is quite limited.  Use the `-h` command to see all the available commands"
            " and their usage."
        )
    )
    subparsers = parser.add_subparsers(dest="command")
    default_vc_help_str = "Name of the VC that the job is in."

    # create the parser for the "monitor" command
    monitor_parser = subparsers.add_parser(
        "monitor",
        help=(
            "Functional equivalent to amulet monitor, which launches a TensorBoard instance for the" " specified jobs"
        ),
    )
    monitor_parser.add_argument(
        "--job_name_vc_list",
        action="store",
        type=str,
        nargs="+",
        required=True,
        help="Space-separated job names to fetch and corresponding VCs. " "e.g. --job_name_vc_list name1 vc1 name2 vc2",
    )
    monitor_parser.add_argument(
        "--port",
        action="store",
        type=str,
        default="6006",
        help="Port to use for TensorBoard",
    )
    monitor_parser.add_argument(
        "--download_profiling_logs",
        action="store_true",
        default=False,
        help=(
            "Whether to also download profiling logs.  This should only be true if you ran your"
            " job with `use_profiler: True` in the trainer config."
        ),
    )
    monitor_parser.add_argument(
        "--download_all_profiling_logs",
        action="store_true",
        default=False,
        help=(
            "Whether to download all profiling logs.  If not specified, only one trace file will be"
            " downloaded.  If True, all trace files will be downloaded.  This is needed because the"
            " trace files can be very large and so downloading all of them can take a long time."
        ),
    )
    monitor_parser.add_argument(
        "--use_job_display_name",
        action="store_true",
        default=False,
        help=("Whether to use the job's display name instead of its name on TensorBoard."),
    )
    monitor_parser.add_argument(
        "--container_name",
        type=str,
        default="philly-ipgsp",
        help="Azure Blob storage container name for job results (default: 'philly-ipgsp')",
    )

    # create the parser for the "logs" command
    logs_parser = subparsers.add_parser(
        "logs",
        help=("Functional equivalent to amulet logs, which downloads the logs for the specified jobs"),
    )
    logs_parser.add_argument("job_name", action="store", type=str, help="Job name to fetch")
    logs_parser.add_argument(
        "job_vc",
        action="store",
        type=str,
        help=default_vc_help_str,
    )
    logs_parser.add_argument(
        "output_dir",
        action="store",
        type=str,
        help="Directory to download logs to",
    )
    logs_parser.add_argument(
        "--container_name",
        type=str,
        default="philly-ipgsp",
        help="Azure Blob storage container name for job results (default: 'philly-ipgsp')",
    )

    # create the parser for the "results" command
    results_parser = subparsers.add_parser(
        "results",
        help=(
            "Functional equivalent to amulet results, which downloads the results for the specified"
            " job to the specified directory.  If 'file_patterns_to_match` is given, then  any file"
            " containing any of the given patterns will be downloaded with the blob directory"
            " structure preserved.  If 'sub_directories_to_match' is given, then only those"
            " subdirectories within the blob will  be downloaded (with blob directory structure"
            " preserved). If you want to download a checkpoint, the sub_directories_to_match should"
            " be 'models/<CHECKPOINTNAME>'.  If neither is given, all outputs will be downloaded"
        ),
    )
    results_parser.add_argument("job_name", action="store", type=str, help="Job name to fetch")
    results_parser.add_argument("job_vc", action="store", type=str, help=default_vc_help_str)
    results_parser.add_argument(
        "--container_name",
        type=str,
        default="philly-ipgsp",
        help="Azure Blob storage container name for job results (default: 'philly-ipgsp')",
    )
    results_parser.add_argument(
        "--output_dir",
        action="store",
        type=str,
        help="Directory to download results to",
    )
    results_parser.add_argument(
        "--file_patterns_to_match",
        action="store",
        type=str,
        nargs="*",
        help=(
            "List of space-separated file patterns/names to match (i.e. a file that matches any of"
            " the file patterns will be downloaded).  Note 1: the blob directory structure will be"
            " preserved.  Note 2: you do NOT need to add the wildcard character to match certain"
            " file types (e.g. use '.txt' instead of '*.txt')"
        ),
    )
    results_parser.add_argument(
        "--sub_directories_to_match",
        action="store",
        type=str,
        nargs="*",
        help=(
            "List of space-separated subdirectories to match, relative to the project root (i.e."
            " the directory that contains 'logs' and 'models')"
        ),
    )

    results_parser.add_argument(
        "--list",
        action="store_true",
        default=False,
        help=(
            "Whether to simply list all results (logs/outputs) from a job instead of downloading"
            "them.  This is equivalent to `amlt results list`"
        ),
    )

    # create the parser for the "reun" command
    rerun_parser = subparsers.add_parser(
        "rerun",
        help=(
            "Functional equivalent to amulet rerun, which reruns a job with the same parameters "
            " and code/environment as the original job and also copies over the original job's logs"
            " and results"
        ),
    )
    rerun_parser.add_argument("job_name", action="store", type=str, help="Job name to fetch")
    rerun_parser.add_argument("job_vc", action="store", type=str, help=default_vc_help_str)

    # create the parser for the "show" command
    show_parser = subparsers.add_parser(
        "show",
        help=(
            "Functional equivalent to amulet show, which shows the details of a job.  Note: you can"
            " add `| grep` to the end of the command to filter the output."
        ),
    )
    show_parser.add_argument("job_name", action="store", type=str, help="Job name to fetch")
    show_parser.add_argument("job_vc", action="store", type=str, help=default_vc_help_str)
    show_parser.add_argument(
        "--web",
        action="store_true",
        default=False,
        help="Whether to also open the job in AML Studio",
    )
    show_parser.add_argument(
        "--output",
        action="store",
        type=str,
        default="yaml",
        help="Output format.  Can be one of yaml, json, yamlc, jsonc, tsv, or table",
    )

    # create the parser for the "list" command
    list_parser = subparsers.add_parser(
        "list",
        help=(
            "Functional equivalent to amulet list, but, due to speed issues, only lists jobs for"
            " the specified VCs.  Note 1: jobs are listed newest to oldest.  Note 2: if"
            " experiment_name is not specified, all experiments will be searched in each VC, which"
            " may take up to 5 minutes.  "
        ),
    )
    list_parser.add_argument(
        "--experiment_name",
        action="store",
        type=str,
        help=(
            "Experiment name to filter on.  If not specified, all experiments will be returned. "
            " Note: this should be the FULL experiment name, which is the experiment name with"
            " '<ALIAS>_submitter-' preprended to it.  For example, if you're working in an experiment"
            " named 's2s_test', you'll notice on AML Studio that the full experiment name is"
            " actually `<ALIAS>_submitter-s2s_test`"
        ),
    )
    list_parser.add_argument(
        "--vcs",
        action="store",
        type=str,
        nargs="+",
        required=True,
        help="List of space-separated VCs.  If specified, will only search these VCs.",
    )

    # create the parser for the "storage_upload" command
    storage_parser = subparsers.add_parser(
        "storage_upload",
        help=(
            "Functional equivalent to amulet storage upload, which uploads a local directory to the"
            " remote_dir relative to the project root"
        ),
    )
    storage_parser.add_argument("job_name", action="store", type=str, help="Job name to fetch")
    storage_parser.add_argument("job_vc", action="store", type=str, help=default_vc_help_str)
    storage_parser.add_argument(
        "local_dir", action="store", type=str, help="Local directory to upload.  Can be a file."
    )
    storage_parser.add_argument(
        "remote_dir",
        action="store",
        type=str,
        help=(
            "Remote directory to upload to. Relative to the project root (i.e. the directory"
            " containing 'models' and 'logs')"
        ),
    )
    storage_parser.add_argument(
        "--container_name",
        type=str,
        default="philly-ipgsp",
        help="Azure Blob storage container name for job results (default: 'philly-ipgsp')",
    )

    # create the parser for the "diff" command
    diff_parser = subparsers.add_parser(
        "diff",
        help="Functional equivalent to amulet diff, which does a diff between the code of two jobs",
    )
    diff_parser.add_argument("job_name_1", action="store", type=str, help="First job to compare")

    diff_parser.add_argument(
        "job_vc_1",
        action="store",
        type=str,
        help="Name of the VC that contains the first job.",
    )
    diff_parser.add_argument("job_name_2", action="store", type=str, help="Second job to compare")

    diff_parser.add_argument(
        "job_vc_2",
        action="store",
        type=str,
        help="Name of the VC that contains the second job.",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    check_az_account()

    if args.command == "monitor":
        job_names_list = []
        job_vcs_list = []
        if args.job_name_vc_list:
            for name, vc in zip(args.job_name_vc_list[::2], args.job_name_vc_list[1::2]):
                job_names_list.append(name)
                job_vcs_list.append(vc)
        # pylint: disable=invalid-name
        formatted_job_names = ", ".join(job_names_list)
        # pylint: disable=invalid-name
        formatted_job_vcs = ", ".join(job_vcs_list)
        print(
            f"II Running aml monitor on port '{args.port}' for jobs '{formatted_job_names}' in"
            f" respective VCs '{formatted_job_vcs}'"
        )
        print(f"II container_name='{args.container_name}'")
        aml_monitor(
            job_names_list,
            job_vcs_list,
            args.port,
            args.download_profiling_logs,
            args.download_all_profiling_logs,
            args.use_job_display_name,
            args.container_name,
        )
    elif args.command == "logs":
        print(f"II Running aml logs for job '{args.job_name}' in VC '{args.job_vc}'")
        print(f"II container_name='{args.container_name}'")
        aml_logs(args.job_name, args.output_dir, args.job_vc, args.container_name)
    elif args.command == "results":
        print(f"II Running aml results for job '{args.job_name}' in VC '{args.job_vc}'")
        print(f"II container_name='{args.container_name}'")
        if args.file_patterns_to_match:
            # pylint: disable=invalid-name
            file_patterns_to_match_str = ", or ".join(args.file_patterns_to_match)
            print(f"II Including blob files matching: '{file_patterns_to_match_str}'")
        if args.sub_directories_to_match:
            print(f"II Including subdirectories: '{args.sub_directories_to_match}'")
        if not args.list and not args.output_dir:
            raise ValueError("II If list is not specified, then output_dir must be specified")
        if args.list and args.output_dir:
            raise ValueError("II Cannot specify both list and output_dir")
        aml_results(
            args.job_name,
            args.file_patterns_to_match,
            args.sub_directories_to_match,
            args.output_dir,
            args.job_vc,
            args.list,
            args.container_name,
        )
    elif args.command == "rerun":
        print(f"II Running aml rerun for job '{args.job_name}' in VC '{args.job_vc}'")
        aml_rerun(args.job_name, args.job_vc)
    elif args.command == "show":
        print(f"II Running aml show for job '{args.job_name}' in VC '{args.job_vc}'")
        aml_show(args.job_name, args.web, args.output, args.job_vc)
    elif args.command == "list":
        print(f"II Running aml list for vcs '{args.vcs}'.  Note: this may take a while!")
        aml_list(
            args.experiment_name,
            args.vcs,
        )
    elif args.command == "storage_upload":
        print(
            f"II Running aml storage_upload for local dir '{args.local_dir}' to remote dir"
            f" '{args.remote_dir}' for job '{args.job_name}' in VC '{args.job_vc}'"
        )
        print(f"II container_name='{args.container_name}'")
        aml_storage_upload(
            args.job_name,
            args.local_dir,
            args.remote_dir,
            args.job_vc,
            args.container_name,
        )
    elif args.command == "diff":
        print(
            f"II Running aml diff between '{args.job_name_1}' in VC '{args.job_vc_1}' and"
            f" '{args.job_name_2}' in VC '{args.job_vc_2}'"
        )
        aml_diff(args.job_vc_1, args.job_name_1, args.job_vc_2, args.job_name_2)
    else:
        raise ValueError("Please run the script with the `-h` flag to see the available commands and their usage.")

    cleanup(cleanup_list)

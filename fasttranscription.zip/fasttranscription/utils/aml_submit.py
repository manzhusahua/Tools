# pylint: disable=duplicate-code
"""AML SDK v2-based job submitter"""
import argparse
import atexit
import copy
import os
import shutil
import subprocess
import sys
import time
import yaml

from aml_utils.aml_environment_utils import get_azurecr_digest

from aml_utils.setup_aml import (
    check_setup_aml,
    check_az_account,
    check_or_create_workspace_connection_to_acr,
    check_and_warn_file_size,
)

from aml_utils.aml_utils import (
    create_uuid,
    create_aml_experiment_and_job_name,
    validate_aml_submit_args,
    get_datastore_url,
    get_uai_job_client_id,
)
from aml_utils.skumanager import (
    get_data_storage_accounts_by_cluster_name,
    get_model_storage_account_by_cluster_name,
    get_sku_detail_by_instance_type,
    get_instance_type_by_sku,
    get_vc_sub_rg_workspace,
    get_data_storage_region,
    get_model_registry_region,
)
from aml_utils.utils import cleanup
from misc.common import str_to_bool


# pylint: disable=too-many-branches
# pylint: disable=too-many-statements
AML_IGNORE_FILE_NAME = ".amlignore"
# registry name: [username, key_vault name]
DOCKER_REGISTRY_INFO = {
    "sramdevregistry": ["tts-itp-user", "exawatt-philly-ipgsp"],  # noqa: E241
    "azurespeechdockers": ["default-pull", "exawatt-philly-ipgsp"],  # noqa: E241
    "avenadev": ["avenadev-itp", "avenavault"],
}


def _add_for_singularity(aml_config, gpu, sku_count, is_ib, cmd):
    """This is only for Singularity jobs"""
    # AML now supports launch distributed job by pyTorch, instead of mpi
    # And Singularity+AML's support for mpi still have issues
    aml_config["command"] = cmd
    if gpu > 1:  # cross nodes
        use_ib = is_ib and sku_count > 1
        aml_config["environment_variables"].update(
            {
                "NCCL_ASYNC_ERROR_HANDLING": "1",
                "NCCL_IB_DISABLE": "0" if use_ib else "1",
                "NCCL_DEBUG": "INFO",
                "NCCL_DEBUG_SUBSYS": "INT,ENV,GRAPH,NET",
                # "NCCL_SOCKET_IFNAME": "eth0",
                "OMP_NUM_THREADS": "1",
                "JOB_EXECUTION_MODE": "Basic",
                "MKL_THREADING_LAYER": "GNU",
            }
        )
        aml_config["distribution"] = {
            "type": "pytorch",
            "process_count_per_instance": gpu // sku_count,
        }


def check_docker_registry_info(docker_registry, docker_username, docker_key_vault):
    docker_registry_name = docker_registry.split(".azurecr.io")[0]
    """Check if the docker registry and username are valid"""
    if docker_registry_name not in DOCKER_REGISTRY_INFO:
        print("\nWW The docker registry is not in the predefined set. Please make sure its infos are correct.")

    if DOCKER_REGISTRY_INFO[docker_registry_name][0] != docker_username:
        raise ValueError(
            f"Username {docker_username} does not match the expected username "
            f"{DOCKER_REGISTRY_INFO[docker_registry_name][0]} for registry {docker_registry}"
        )

    if DOCKER_REGISTRY_INFO[docker_registry_name][1] != docker_key_vault:
        raise ValueError(
            f"Key vault {docker_key_vault} does not match the expected key vault "
            f"{DOCKER_REGISTRY_INFO[docker_registry_name][1]} for registry {docker_registry}"
        )


def _create_sbom_generation_step_config(args, aml_config, sbom_aml_compute, sbom_output_path):
    """
    Creates an AML step config for generating SBOM files.
    """
    sbom_script_run_cmd = "python aml_utils/generate_sbom.py --output_path ${{outputs.sbom_output}}"
    resources = copy.deepcopy(aml_config["resources"])
    singularity_properties = resources.get("properties", {}).get("singularity", {})
    instance_type = get_instance_type_by_sku(args.sbom_cluster, 1, False)
    singularity_properties["instanceType"] = f"Singularity.{instance_type}"
    resources["instance_count"] = 1
    job_uuid = create_uuid()
    sbom_generation_step_config = {
        "name": job_uuid,
        "compute": sbom_aml_compute,
        "code": aml_config["code"],
        "tags": aml_config["tags"],
        "environment": copy.deepcopy(aml_config["environment"]),
        "outputs": {
            "sbom_output": {
                "mode": "rw_mount",
                "type": "uri_folder",
                "path": f"{sbom_output_path}",
            }
        },
        "command": sbom_script_run_cmd,
        "environment_variables": {"AZUREML_COMMON_RUNTIME_USE_SBOM_CAPABILITY": "true"},
        "resources": resources,
    }

    return sbom_generation_step_config


def _create_training_pipeline_config_with_sbom_support(args, aml_config, sbom_aml_compute, sbom_output_path):
    """Adds an SBOM generation step to AML config and returns a two-step pipeline config."""
    aml_pipeline_config = {}
    aml_pipeline_config["type"] = "pipeline"
    aml_pipeline_config["experiment_name"] = aml_config["experiment_name"]
    aml_pipeline_config["display_name"] = aml_config["display_name"]
    # Add the tags and description from the training job to the pipeline
    # so that they are visible in the AML Studio UI.  This is a workaround
    # since the tags/description are not being shown for each sub-job
    aml_pipeline_config["description"] = aml_config["description"]
    aml_pipeline_config["tags"] = aml_config["tags"]

    sbom_generation_step_config = _create_sbom_generation_step_config(
        args, aml_config, sbom_aml_compute, sbom_output_path
    )
    aml_config["inputs"]["sbom_input"] = {
        "mode": "ro_mount",
        "type": "uri_folder",
        "path": "${{parent.jobs.sbom_generation.outputs.sbom_output}}",
    }

    aml_pipeline_config["jobs"] = {
        "sbom_generation": sbom_generation_step_config,
        "training": aml_config,
    }

    return aml_pipeline_config


def escape_to_raw_value(value):
    # Keep the "=" at the end of the value
    value = value.strip("=")
    value = value.strip().strip("\"'") + "="
    if r"\-\-" in value:
        value = value.replace(r"\-\-", "--")
    return value


def submit_job(args: argparse.Namespace) -> str:
    """Submit a training job

    Args:
        args (parsed_args): Arguments parsed from command line.

    Returns:
        str: Experiment name.
    """
    # pylint: disable=too-many-locals
    validate_aml_submit_args(args)
    cleanup_list = []

    check_docker_registry_info(args.docker_registry, args.docker_username, args.docker_key_vault)

    # The default model output structure will be:
    # projects/<base_exp_name>/<sub_exp_folder_name>/aml-results/<job_uuid>,
    # to allow for a more intuitive and organized structure
    (
        experiment_name,
        sub_exp_folder_name,
        base_exp_name,
        job_name,
    ) = create_aml_experiment_and_job_name(args.aml_exp_name, args.aml_job_name)

    aml_cfg_file = os.path.join(args.local_code_dir, "tmp_cfg_aml.yaml")

    # If an .amlignore file does not exist, make a default one (and clean it up)
    aml_ignore_path = os.path.join(args.local_code_dir, AML_IGNORE_FILE_NAME)
    if not os.path.exists(aml_ignore_path):
        raise FileNotFoundError(
            f"EE: File {aml_ignore_path} not found. Please create it MANUALLY before submitting a job. "
            "This file will ignore unnecessary files for model training."
        )

    cleanup_list.append(aml_cfg_file)

    # loading AML config and overwriting necessary details
    amd_gpu_series = ["MI200", "MI100"]
    if "amd" in args.vc or any(list(x in args.cluster for x in amd_gpu_series)):
        aml_in_cfg_yaml_file = "aml_cli_cfg_amd.yaml"
    else:
        aml_in_cfg_yaml_file = "aml_cli_cfg.yaml"

    # Copying config to repository root
    aml_utils_dir = "aml_utils"
    submitter_root_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(submitter_root_dir, aml_utils_dir, aml_in_cfg_yaml_file), encoding="utf8") as fin:
        aml_config = yaml.safe_load(fin)
    dest_aml_utils_dir = os.path.join(args.local_code_dir, aml_utils_dir)
    if not args.cleanup_only:
        shutil.copytree(os.path.join(submitter_root_dir, aml_utils_dir), dest_aml_utils_dir)

    cleanup_list.append(dest_aml_utils_dir)
    # need to make sure we clean up all changed files if something fails
    if not args.prepare_only:
        atexit.register(cleanup, cleanup_list)
    if args.cleanup_only:
        cleanup(cleanup_list)
        sys.exit(0)

    # This will be both the job name and model blob storage identifier
    job_uuid = create_uuid()
    # We'll save the model outputs/logs to the given storage account with the following path:
    # projects/<base_exp_name>/<sub_exp_folder_name>/aml-results/<job_uuid> ,
    # where base_exp_name is the user's username + "_submitter" (e.g. wake_submitter) to allow for
    # a more intuitive and organized structure
    aml_model_dir = os.path.join("projects", base_exp_name, sub_exp_folder_name, "aml-results", job_uuid).replace(
        "\\", "/"
    )

    # In order for Singularity/AML to fetch the latest version of the docker tag, we must pass
    # the digest.  If we don't, the environment will be cached and we won't pull the latest
    # version of the image.
    docker_digest = get_azurecr_digest(
        args.docker_registry, args.docker_image_name, args.docker_tag, args.docker_username, args.docker_key_vault
    )
    aml_config["environment"]["image"] = f"{args.docker_registry}/{args.docker_image_name}@{docker_digest}"

    model_storage_account = get_model_storage_account_by_cluster_name(args.vc)
    aml_config["description"] = (
        f'Submit job in output directory "{aml_model_dir}" in storage account "{model_storage_account}" and '
        f'storage container "{args.model_container_name}"'
    )
    if hasattr(args, "custom_storage_yml") and args.custom_storage_yml:
        aml_config["description"] += " with custom storage configuration."
    else:
        aml_config["description"] += " with default storage configuration."

    aml_config["tags"] = {
        "base_exp_name": base_exp_name,
        "output_directory": aml_model_dir,
        "model_storage_account": model_storage_account,
        "model_storage_container": args.model_container_name,
        "model_path": f"{aml_model_dir}/models",
        "model_logs_path": f"{aml_model_dir}/logs",
        "sbom_path": f"{aml_model_dir}/azureml_sbom_sbom_output",
    }

    subscription_id, resource_group_name, workspace_name, vc_region = get_vc_sub_rg_workspace(vc=args.vc)
    print(
        f"\nII Setting default subscription as '{subscription_id}' and workspace as"
        f" '{workspace_name}' in '{vc_region}' for this job submission"
    )
    subprocess.check_call(
        f"az account set -s {subscription_id}",
        shell=True,
    )

    subprocess.check_call(
        f"az configure --defaults group={resource_group_name} workspace={workspace_name}",
        shell=True,
    )
    check_or_create_workspace_connection_to_acr(
        args.docker_registry, args.docker_username, submitter_root_dir, args.docker_key_vault
    )

    data_storage_account = get_data_storage_accounts_by_cluster_name(args.vc)
    model_storage_account = get_model_storage_account_by_cluster_name(args.vc)
    _, _, gpu_per_node, is_ib = get_sku_detail_by_instance_type(args.cluster)

    sku_count = (args.gpu - 1) // gpu_per_node + 1
    gpu_count = args.gpu if args.gpu < gpu_per_node else gpu_per_node
    ib_enabled = sku_count > 1 and is_ib

    aml_config_resources = aml_config.get("resources", {})

    singularity_properties = aml_config_resources.get("properties", {}).get("singularity", {})
    data_storage_region = get_data_storage_region(data_storage_account)

    ssh_public_key_path = os.path.expanduser(args.ssh_public_key_path)
    if os.path.exists(ssh_public_key_path):
        with open(ssh_public_key_path, encoding="utf8") as f:
            # Remove newline character
            ssh_public_key = f.read().rstrip()
            singularity_properties.update({"sshPublicKey": ssh_public_key})

    # Note: slaTier must have the first letter capitalized
    # Note: location ensures that the Singularity compute is in the same region as the VC
    singularity_properties.update(
        {
            "slaTier": args.sla_tier.lower().capitalize(),
            "instanceType": (f"Singularity.{get_instance_type_by_sku(args.cluster, gpu_count, ib_enabled)}"),
            "location": f'["{data_storage_region}"]',
        }
    )

    aml_config["resources"].update(
        {
            "instance_count": sku_count,
            "properties": {"singularity": singularity_properties},
        }
    )

    aml_config["compute"] = (
        f"/subscriptions/{subscription_id}"
        f"/resourceGroups/{resource_group_name}"
        "/providers/Microsoft.MachineLearningServices"
        f"/virtualClusters/{args.vc}"
    )

    if args.register_model:
        if args.sbom_cluster is None or args.sbom_vc is None:
            raise ValueError(
                "SBOM cluster or vc is not provided and it should in the same region with the parameter for '--vc'."
            )
        sbom_subscription_id, sbom_resource_group_name, _, sbom_vc_region = get_vc_sub_rg_workspace(vc=args.sbom_vc)
        if sbom_vc_region != vc_region:
            raise ValueError(f"SBOM vc should be in the '{vc_region}', but '{args.sbom_vc}' is in '{sbom_vc_region}'.")
        sbom_aml_compute = (
            f"/subscriptions/{sbom_subscription_id}"
            f"/resourceGroups/{sbom_resource_group_name}"
            "/providers/Microsoft.MachineLearningServices"
            f"/virtualClusters/{args.sbom_vc}"
        )

    if hasattr(args, "custom_storage_yml") and args.custom_storage_yml:
        _handle_custom_storage_yml(args.custom_storage_yml, aml_config)
    else:
        # Default specification of IO mounts
        aml_config["outputs"]["output"]["path"] = get_datastore_url(model_storage_account, args.model_container_name)
        aml_config["inputs"]["data_blob"]["path"] = get_datastore_url(data_storage_account, args.data_container_name)

    # Add the location of the user's job in mounted output blob
    # as well as the path in the blob
    user_assigned_identity_name = resource_group_name + "-uai"
    try:
        uai_client_id = get_uai_job_client_id(subscription_id, resource_group_name, user_assigned_identity_name)
    except Exception as e:
        print(f"EE Failed to get user-assigned managed identity (UAI) with error: {e}")
        sys.exit(1)
    aml_config["environment_variables"].update(
        {
            "AML_OUTPUT_BLOB_PATH": aml_model_dir,
            "AML_OUTPUT_DIRECTORY": f"/modelblob/{aml_model_dir}",
            # NOTE: this is needed due to Singularity's use of managed identities
            # to connect to our data stores in AML.  See below for more information:
            # https://dev.azure.com/AzSingularity/AzSingularity/_git/azureml-singularity-docs?path=
            # /singularity-wiki/src/guide-for-admin/use-managed-identity.md&_a=preview
            "_AZUREML_SINGULARITY_JOB_UAI": (
                f"/subscriptions/{subscription_id}"
                f"/resourceGroups/{resource_group_name}"
                "/providers/Microsoft.ManagedIdentity/userAssignedIdentities/"
                f"{user_assigned_identity_name}"
            ),
            "UAI_CLIENT_ID": uai_client_id,
        }
    )

    aml_config["name"] = job_uuid
    aml_config["code"] = args.local_code_dir
    aml_config["display_name"] = job_name
    aml_config["experiment_name"] = experiment_name

    aml_model_dir = "$AML_OUTPUT_DIRECTORY/models"
    aml_log_dir = "$AML_OUTPUT_DIRECTORY/logs"
    aml_config["command"] = ""  # clear the command in the template
    cmd = aml_config["command"]
    cmd = f"{args.run_cmd} {cmd} {args.extra_params}"
    # Default: "--model_dir" and ""--log_dir"
    # TorchTTS: "trainer.save_path" and "hydra.run.dir"
    # Hydra: "trainer.model_dir" and "trainer.log_dir"
    if not args.model_dir_argument.endswith("="):
        args.model_dir_argument += "="
    if not args.log_dir_argument.endswith("="):
        args.log_dir_argument += "="
    model_dir = f"{escape_to_raw_value(args.model_dir_argument)}{aml_model_dir}"
    log_dir = f"{escape_to_raw_value(args.log_dir_argument)}{aml_log_dir}"
    model_arg = None
    if args.set_model_dir:
        model_arg = args.model_dir_argument

    if model_arg and model_arg in args.extra_params:
        cmd += f" {log_dir}"
    else:
        cmd += f" {model_dir} {log_dir}"

    model_registry_region = get_model_registry_region(model_storage_account)
    if args.register_model:
        user_name = aml_config["experiment_name"].split("_")[0]
        model_registry_name = f"{user_name}_{aml_config['display_name']}".replace(".", "_").replace("-", "_")
        if not args.model_registry_region_argument.endswith("="):
            args.model_registry_region_argument += " "
        if not args.sbom_path_argument.endswith("="):
            args.sbom_path_argument += " "
        if not args.model_registry_name_argument.endswith("="):
            args.model_registry_name_argument += " "
        if model_registry_region is not None:
            cmd += f" {escape_to_raw_value(args.model_registry_region_argument)}{model_registry_region}"
        cmd += f" {escape_to_raw_value(args.sbom_path_argument)}" + "${{inputs.sbom_input}}"
        cmd += f" {escape_to_raw_value(args.model_registry_name_argument)}{model_registry_name}"

    _add_for_singularity(aml_config, args.gpu, sku_count, is_ib, cmd)

    setup_command_list = aml_config.get("properties", {}).pop("setup_commands", [])
    if hasattr(args, "custom_setup_commands") and args.custom_setup_commands:
        if args.register_model:
            print("\nEE Custom setup commands are not supported when model registration is enabled.")
            sys.exit(1)
        else:
            custom_setup_commands = args.custom_setup_commands.strip()
            if len(custom_setup_commands) > 0:
                setup_command_list.append(custom_setup_commands)

    setup_command_string = ""
    for cmd in setup_command_list:
        # pylint: disable=consider-using-join
        setup_command_string += f'"{cmd}" '

    cmds_to_run = []
    if setup_command_string:
        cmds_to_run = [
            f"python {aml_utils_dir}/run_setup.py --commands-to-run {setup_command_string}",
            f"{aml_config['command']}",
        ]

    # If cmds_to_run is a list of length 1, this will work (i.e. no && will be added)
    aml_config["command"] = " && ".join(cmds_to_run)

    # If model registration is enabled, add an SBOM generation step before training.
    if args.register_model:
        models_output_path = get_datastore_url(model_storage_account, args.model_container_name)
        sbom_output_path = f"{models_output_path}/{aml_model_dir}"

        aml_config = _create_training_pipeline_config_with_sbom_support(
            args, aml_config, sbom_aml_compute, sbom_output_path
        )

    # Writing AML config back on disk and launching the job
    with open(aml_cfg_file, "w", encoding="utf8") as fout:
        # This needs to be set because I was noticing that the yaml.dump was
        # outputting "*id001" for certain nested dicts (e.g. tags for "training" sub job)
        yaml.Dumper.ignore_aliases = lambda *args: True
        yaml.dump(aml_config, fout, sort_keys=False, indent=4)

    if not args.prepare_only:
        check_and_warn_file_size(args.local_code_dir, AML_IGNORE_FILE_NAME)

        job_creation_cmd = (
            f"az ml job create -f {aml_cfg_file} --subscription {subscription_id} "
            f"--resource-group {resource_group_name} --workspace-name {workspace_name} --output yaml "
        )

        # Query doesn't work well on windows, so bypass it for now
        if sys.platform != "win32":
            display_filter = (
                "{job_name:name, tags:tags, experiment_name:experiment_name, display_name:display_name,"
                " job_url: services.Studio.endpoint}"
            )
            job_creation_cmd += f" --query '{display_filter}'"

        try:
            subprocess.run(job_creation_cmd, check=True, shell=True)
        except subprocess.CalledProcessError:
            print(
                "\nEE Job submission failed, trying again with verbose logging enabled, so you can better "
                "understand the problem. One possible cause is that your experiment name is not alpha-numeric and/or "
                "is longer than 256 characters."
            )
            job_creation_cmd += " --debug"
            time.sleep(5)
            subprocess.run(job_creation_cmd, check=True, shell=True)
        cleanup(cleanup_list)
    return experiment_name


def _handle_custom_storage_yml(custom_storage_yml_path, aml_config):
    # pylint: disable=pointless-string-statement
    """
    Handles manual specification of IO mounts via auxillary yaml (that is,
    lets you use non-premium storage).  Note: aml_config is modified in place.

    Example of custom_storage_yml:

    - account: "stdstoragetts01wus3"
    container_to_mount: "philly-ipgsp"
    io_type: "inputs" # one of "inputs" or "outputs"
    io_name: "data_blob"
    mount_path_on_vm: "/datablob"
    mode: "ro_mount"
    type: "uri_folder"

    - account: "exawattaiprmbtts01wus3"
    container_to_mount: "philly-ipgsp"
    io_type: "outputs" # one of "inputs" or "outputs"
    io_name: "output"
    mount_path_on_vm: "/modelblob"
    mode: "rw_mount"
    type: "uri_folder"

    Args:
        custom_storage_yml_path (str): Path to the custom storage yml file.
        aml_config (dict): AML config dictionary.
    """
    with open(custom_storage_yml_path, encoding="utf8") as handle:
        custom_storage = yaml.safe_load(handle)

    # overwrite the default IO mounts
    aml_config["inputs"] = {}
    aml_config["outputs"] = {}
    for key in list(aml_config["properties"].keys()):
        if key.startswith("AZURE_ML_INPUT_") or key.startswith("AZURE_ML_OUTPUT_"):
            del aml_config["properties"][key]

    for item in custom_storage:
        io_type = item["io_type"]
        io_name = item["io_name"]
        mode = item["mode"]

        assert io_type in [
            "inputs",
            "outputs",
        ], f"Only 'inputs' or 'outputs' are allowed for `io_type`, not {io_type}!"

        if io_type == "inputs":
            assert mode == "ro_mount", "Only 'ro_mount' is allowed for 'inputs' mode!"
        elif io_type == "outputs":
            assert mode == "rw_mount", "Only 'rw_mount' is allowed for 'outputs' mode!"

        datastore_url = get_datastore_url(item["account"], item["container_to_mount"])

        aml_config[io_type][io_name] = {
            "path": datastore_url,
            "mode": mode,
            "type": item["type"],
        }

        # For some reason, the `s` is not used, so we use ':-1" to remove it
        aml_config["properties"][f"AZURE_ML_{item['io_type'].upper()[:-1]}_PathOnCompute_{item['io_name']}"] = item[
            "mount_path_on_vm"
        ]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=(
            "This is a job submission script that uses AML SDK v2 as backend. It will perform automatic setup on the "
            "first run."
        )
    )
    parser.add_argument(
        "--cluster",
        "-s",
        help="name of compute target in in Singularity, e.g. NCv3, NDv2, etc.",
        required=True,
    )
    parser.add_argument(
        "--vc",
        "-v",
        required=True,
        help="name of the VC, e.g., spch-sing-tts-sc, spch-sing-ttsprod-sc, etc.",
    )
    parser.add_argument(
        "--sbom_cluster",
        type=str,
        default=None,
        help="name of compute target in in Singularity for SBOM generation, e.g. NCv3, NDv2, etc.",
    )
    parser.add_argument(
        "--sbom_vc",
        type=str,
        default=None,
        help="name of the VC, e.g., spch-sing-tts-sc, spch-sing-ttsprod-sc, etc.",
    )
    parser.add_argument("--aml_exp_name", "-x", type=str, required=True, help="AML experiment name.")
    parser.add_argument("--aml_job_name", "-n", type=str, required=True, help="AML job display name.")
    parser.add_argument(
        "--sla_tier",
        default="premium",
        choices=["basic", "standard", "premium"],
        help="Singularity tier for the job: choose one of basic, standard, or premium.",
    )
    parser.add_argument("--gpu", "-g", type=int, help="Number of GPUs to use", default=1)
    parser.add_argument("--run_cmd", type=str, required=True, help="Command to run the job")
    parser.add_argument("--extra_params", type=str, default="", help="extra parameters for the job")
    parser.add_argument(
        "--data_container_name",
        type=str,
        default="philly-ipgsp",
        help="Azure Blob storage container name for data " "(default: 'philly-ipgsp')",
    )
    parser.add_argument(
        "--model_container_name",
        type=str,
        default="philly-ipgsp",
        help="Azure Blob storage container name for model " "(default: 'philly-ipgsp')",
    )
    parser.add_argument(
        "--docker_registry",
        type=str,
        default="sramdevregistry.azurecr.io",
        help="Docker registry in ACR (default: sramdevregistry.azurecr.io)",
    )
    parser.add_argument("--docker_username", type=str, required=True, help="Docker username")
    parser.add_argument(
        "--docker_image_name", type=str, default="submitter", help="Docker images name (default: submitter)"
    )
    parser.add_argument(
        "--docker_tag",
        type=str,
        default="pytorch222-py310-cuda118-ubuntu2004",
        help="Docker image tag (default: pytorch222-py310-cuda118-ubuntu2004)",
    )
    parser.add_argument(
        "--docker_key_vault", type=str, default="exawatt-philly-ipgsp", help="Key vault for docker registry password"
    )
    parser.add_argument(
        "--skip_setup",
        dest="skip_setup",
        action="store_true",
        help="If specified, will skip automatic setup and all setup checks.",
    )
    parser.add_argument(
        "--prepare_only",
        dest="prepare_only",
        action="store_true",
        help=(
            "If specified, will only prepare repository for job submission, but will not execute submit "
            "command. If you want to restore repository to its original state, run python aml_submit.py with "
            "--cleanup_only "
        ),
    )
    parser.add_argument(
        "--cleanup_only",
        dest="cleanup_only",
        action="store_true",
        help=(
            "If specified, will only clean up repository. Only has effect if you previously ran "
            "aml_submit.py with '--prepare_only' option."
        ),
    )
    parser.add_argument(
        "--ssh_public_key_path",
        default="~/.ssh/id_rsa.pub",
        help=(
            "Location of your public SSH key to be used for SSHing into jobs."
            " This should be an absolute path or relative to user (e.g. ~/.test-ssh/id_rsa.pub)"
        ),
    )
    parser.add_argument(
        "--register_model",
        action="store_true",
        help=(
            "Register model in AML registry."
            "This should be set to True if there is a chance the model will be sent to Production."
        ),
    )
    parser.add_argument(
        "--set_model_dir",
        type=str_to_bool,
        default="true",
        help="Set the model directory automatically (default: true).",
    )
    parser.add_argument("--custom_storage_yml", default=None, help="YML for custom storage.")
    parser.add_argument("--custom_setup_commands", default=None, help="Custom setup commands.")
    parser.add_argument("--local_code_dir", type=str, required=True, help="absolute path of local code")
    parser.add_argument(
        "--model_dir_argument", type=str, default="--model_dir", help="model dir name (default: --model_dir)"
    )
    parser.add_argument("--log_dir_argument", type=str, default="--log_dir", help="log dir name (default: --log_dir)")
    parser.add_argument(
        "--model_registry_region_argument",
        type=str,
        default="--model_registry_region",
        help="model registry region (default: --model_registry_region)",
    )
    parser.add_argument(
        "--sbom_path_argument",
        type=str,
        default="--sbom_path",
        help="sbom path (default: --sbom_path)",
    )
    parser.add_argument(
        "--model_registry_name_argument",
        type=str,
        default="--model_registry_name",
        help="sbom name (default: --model_registry_name)",
    )

    user_args, unknown_args = parser.parse_known_args()
    if unknown_args:
        print(f"WW Unknown arguments: {unknown_args}")

    if not user_args.skip_setup:
        check_setup_aml()

    check_az_account()
    submit_job(user_args)

"""Helpers for getting the digest for a given docker image, registry and tag combination.

Ported from Amulet (but heavily modified), thanks Hannes!
"""

from typing import Dict, Tuple

import logging
import re
import requests

from aml_utils.setup_aml import _get_secret_client

LOG = logging.getLogger(__name__)


def _request(
    method: str,
    url,
    headers=None,
    auth=None,
):
    """
    Makes a request to a given URL and method, and handles the errors it might raise.
    """
    session = requests.Session()
    if auth:
        auth = tuple(map(lambda x: "" if x is None else str(x), auth))

    response = session.request(
        method,
        url,
        headers=headers,
        auth=auth,
    )

    if method.upper() == "HEAD":
        return response.headers

    try:
        response = response.json()
    except ValueError:
        LOG.debug("Could not decode json response from %s", url)
        response = None
    return response


def _get_acr_token(registry: str, docker_uname: str, docker_pas: str):
    """
    Gets the ACR token for a given Docker registry, username and password.

    Args:
        registry (str): registry URL
        docker_uname (str): username
        docker_pas (str): password

    Returns:
        token (str): ACR token
    """
    url = f"https://{registry}/oauth2/token?service={registry}&scope=repository:*:pull,metadata_read"
    response = _request("GET", url, auth=(docker_uname, docker_pas))
    token = response["access_token"]
    return token


def _make_azurecr_api_call(
    url: str,
    method: str,
    image_kwargs: Dict[str, str],
    auth: Tuple[str, str],
):
    """
    Calls docker v2 REST API for a given URL and method, and handles the errors it might raise.

    Note: will raise amlt.exceptions.ConnectionException if the registry does not exist

    Args:
      url: request URL
      method: request method (eg. GET, HEAD)
      image_kwargs: specifications of the image, used to provide specific exception messages
      auth: tuple containing the username and the password used for authentication
      auth_with_bearer: if True, uses bearer token for authentication. Otherwise, use
        basic authentication
    """
    # pylint: disable=use-dict-literal
    headers = dict(Accept="application/vnd.docker.distribution.manifest.v2+json")
    token = _get_acr_token(image_kwargs["registry"], *auth)
    headers["Authorization"] = f"Bearer {token}"
    response = _request(method, url, headers=headers)
    return response


def get_azurecr_digest(
    docker_registry: str,
    docker_image_name: str = None,
    docker_tag: str = None,
    docker_username: str = None,
    docker_key_vault_name: str = None,
) -> str:
    """
    Gets the digest for a given docker image, registry and tag combination.

    Args:
        docker_registry (str): registry URL, must end in azurecr.io
        docker_image_name (str): image name (NOTE: this is `repository` in Cascades)
        docker_tag (str): tag

    Returns:
        digest (str): digest for the given image, registry and tag combination.
    """
    if not docker_registry.endswith(".azurecr.io"):
        raise NotImplementedError("Submitting jobs to AML only supports registries ending in azurecr.io")

    if not docker_tag:
        docker_tag = "latest"

    match = re.fullmatch(r"(https?://)?(?P<registry>[\w-]+).azurecr.io(.*)?", docker_registry)
    parsed_registry = match.group("registry")
    url = f"https://{parsed_registry}.azurecr.io/v2//{docker_image_name}/manifests/{docker_tag}"

    key_vault_url = f"https://{docker_key_vault_name}.vault.azure.net"
    secret_client = _get_secret_client(key_vault_url)

    username = docker_username
    secret_name = f"{docker_registry.rstrip('.azurecr.io')}-registry-pwd"
    password = str(secret_client.get_secret(f"{secret_name}").value)
    auth = (username, password) if username else (None, None)

    # pylint: disable=use-dict-literal
    response = _make_azurecr_api_call(
        url,
        "head",
        dict(registry=docker_registry, repository="", image_name=docker_image_name, tag=docker_tag),
        auth,
    )
    try:
        return response["Docker-Content-Digest"]
    except KeyError as e:
        raise ValueError(f"Could not find digest for {docker_registry}/{docker_image_name}:{docker_tag}") from e

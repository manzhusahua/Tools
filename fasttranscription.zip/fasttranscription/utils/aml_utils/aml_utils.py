"""AML SDK v2 utility functions."""

import json
import base64
import os
import getpass
import uuid
import re
import textwrap
import shutil
from pathlib import Path

from tqdm import tqdm

from azure.ai.ml import MLClient
from azure.ai.ml.entities._builders.command import Command

from azure.mgmt.resource import ResourceManagementClient
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError
from azureml.core import Experiment, Workspace

from git import Repo

# pylint: disable=import-self
from aml_utils.setup_aml import get_azure_credential
from aml_utils.skumanager import get_vc_sub_rg_workspace, get_vc_sub_rg_workspace_dict

AZUREML_DATASTORE_URL_FORMAT = "azureml://datastores/{}/paths/"
AZ_API_VERSION = "2023-04-01"
AZ_BLOB_URL_FORMAT = "https://{}.blob.core.windows.net/"
AZ_CREDENTIAL = get_azure_credential()


def get_datastore_url(storage_account: str, container_to_mount: str):
    """
    Return the datastore name for the given storage account and container.
    Args:
        storage_account (str): The storage account that the datastore should reference.
            Should be the name itself (e.g. `stdstoragetts01scus`) without any trailing URL.
        container_to_mount (str): The container on the storage account to reference.
    """
    datastore_name = f'az_ml_datastore_{storage_account}_{container_to_mount.replace("-", "_")}'
    return AZUREML_DATASTORE_URL_FORMAT.format(datastore_name)


def get_uai_job_client_id(subscription_id: str, resource_group_name: str, user_assigned_identity_name: str) -> str:
    """
    Get the client ID of the user-assigned identity (UAI) with the given name.
    Args:
        subscription_id (str): The subscription ID of the UAI.
        resource_group_name (str): The resource group name of the UAI.
        user_assigned_identity_name (str): The name of the UAI.
    Returns:
        str: The client ID of the UAI.
    """
    uai_resource_id = (
        f"/subscriptions/{subscription_id}/resourceGroups/{resource_group_name}"
        f"/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{user_assigned_identity_name}"
    )
    resource_client = ResourceManagementClient(AZ_CREDENTIAL, subscription_id)
    resource = resource_client.resources.get_by_id(uai_resource_id, api_version="2023-01-31")

    client_id = resource.properties.get("clientId") if resource.properties else None
    if not client_id:
        raise ValueError(f"Client ID not found for the UAI: {user_assigned_identity_name}")
    return client_id


def get_blob_service_client(storage_account):
    """
    Create blob client object

    Returns:
        The BlobServiceClient object.
    """
    connection_str = (
        "DefaultEndpointsProtocol=https;" f"AccountName={storage_account};" "EndpointSuffix=core.windows.net"
    )

    return BlobServiceClient.from_connection_string(connection_str, AZ_CREDENTIAL)


def generate_base_experiment_name():
    """
    Generate the base experiment name, which is the user's alias + "_submitter"

    Returns:
        base_experiment_name (str): The base experiment name
    """
    # We'll try and get the alias of the current signed-in user.  If that fails,
    # (e.g. the current user is a service principal), then we'll fall back to
    # getpass.getuser()
    alias = ""
    try:
        token = AZ_CREDENTIAL.get_token("https://management.azure.com/", scopes=["user.read"])
        base64_meta_data = token.token.split(".")[1].encode("utf-8") + b"=="
        json_bytes = base64.decodebytes(base64_meta_data)
        json_string = json_bytes.decode("utf-8")
        json_dict = json.loads(json_string)
        # Purposely do not use "get" so that a keyerror is thrown
        upn = json_dict["upn"]
        alias = upn.split("@")[0]
    # pylint: disable=broad-except
    except Exception:
        # Handle the case where the username for the base OS has an "@" sign in it
        alias = getpass.getuser().split("@")[0]
    return alias.replace("\\", "/") + "_submitter"


def generate_full_experiment_name(base_exp_name, sub_exp_folder_name):
    """
    Generate the full experiment name, which is the base experiment name + "_" +
    sub-experiment folder name.

    Args:
        base_exp_name (str): The base experiment name
        sub_exp_folder_name (str): The sub-experiment folder name

    Returns:
        full_experiment_name (str): The full experiment name
    """
    return base_exp_name + "-" + sub_exp_folder_name


def create_aml_experiment_and_job_name(args_exp_name, args_job_name):
    """
    Creates the job name, experiment name, sub-experiment folder name, and base experiment name.

    Args:
        args_exp_name (str): The name of the experiment specified by the user on the CLI
        args_job_name (str): The name of the job specified by the user on the CLI

    Returns:
        full_experiment_name (str): The full experiment name (e.g. wake_submitter-my-s2s-exp).
            By default, this is "<ALIAS>_submitter-<args_exp_name>"
        sub_exp_folder_name (str): The sub-experiment folder name, which is the same as
            "args_exp_name" if given, or "default" otherwise
        base_exp_name (str): The base experiment name, which is "<ALIAS>_csd" (e.g. jacobplatin_csd)
        job_name (str): The name of the job (e.g. csd-job-my-s2s-exp)
    """
    base_exp_name = generate_base_experiment_name()
    sub_exp_folder_name = args_exp_name if args_exp_name else "default"
    # If the user has specified an experiment name, then the full experiment
    # name will be base_exp_name + "_" + args_exp_name (e.g. wake_submitter-my-s2s_exp)
    # Otherwise, the default experiment name will be base_exp_name + "-default"
    # (e.g. wake_submitter-default)
    full_experiment_name = generate_full_experiment_name(base_exp_name, sub_exp_folder_name)
    sub_job_name = args_job_name if args_job_name else "default"
    job_name = "submitter-job-" + sub_job_name
    return full_experiment_name, sub_exp_folder_name, base_exp_name, job_name


def validate_aml_submit_args(args):
    """
    Validates the args passed to aml_submit.py

    Args:
        args (argparse.Namespace): The args passed to aml_submit.py
    """
    if hasattr(args, "display_name") and args.display_name:
        assert re.match(
            r"^[A-Za-z0-9_-]+$", args.display_name
        ), "Please ensure your display name only contains alphanumeric characters, underscores, and dashes"
    if hasattr(args, "aml_exp_name") and args.aml_exp_name:
        assert re.match(
            r"^[A-Za-z0-9_-]+$", args.aml_exp_name
        ), "Please ensure your experiment name only contains alphanumeric characters, underscores, and dashes"


def create_uuid() -> str:
    """
    Wrapper around uuid.uuid4

    Returns:
        str: UUID
    """
    return str(uuid.uuid4())


def get_number_of_files_in_dir(directory):
    """
    Get the number of files in a directory, rescursively.

    Args:
        dir (str): The directory to count the number of files in

    Returns:
        num_files (int): The number of files in the directory
    """
    return sum((len(files) for _, _, files in os.walk(directory)))


def _get_aml_job(job_name, job_vc=None):
    """
    Get the AML job associated with the job_name.  If VC isn't given, then
    search all workspaces for the job, which may take a while.

    IMPORTANT NOTE: job names are not unique across workspaces, so we will only return
    the first match if no VC is given.

    Args:
        job_name (str): The name of the job
    Returns:
        aml_job (azure.ai.ml.Job): The AML job associated with the job_name
    """
    aml_job = None
    if job_vc:
        try:
            subscription_id, resource_group, workspace_name, _ = get_vc_sub_rg_workspace(job_vc)
            ml_client = MLClient(AZ_CREDENTIAL, subscription_id, resource_group, workspace_name)
            aml_job = ml_client.jobs.get(job_name)
        except ResourceNotFoundError:
            # pylint: disable=raise-missing-from
            raise ValueError(f"II Could not find job '{job_name}' in the VC '{job_vc}'")
    else:
        print(f"II Searching for job '{job_name}' in all workspaces, this may take a while...")
        for subscription_id, resource_group, workspace_name, _ in list(get_vc_sub_rg_workspace_dict().values()):
            try:
                ml_client = MLClient(AZ_CREDENTIAL, subscription_id, resource_group, workspace_name)
                aml_job = ml_client.jobs.get(job_name)
                print(f"II Found job '{job_name}' in workspace '{workspace_name}'")
                break
            # pylint: disable=raise-missing-from
            except ResourceNotFoundError:
                pass
    if not aml_job:
        raise ValueError(f"II Could not find job '{job_name}' in any VC")
    return aml_job


def get_job_model_output_path_storage_account(job_name, job_vc=None):
    """
    Get the model output path (the one that has sub-directories "logs" and "models")
    and storage account for a given job.

    Args:
        job_name (str): The name of the job
        job_vc (str): The name of the VC the job is in

    Returns:
        project_path_location (str): The path to the model output directory
        storage_account (str): The storage account the model output directory is in
        display_name (str): The display name of the job
    """
    aml_job = _get_aml_job(job_name, job_vc)
    project_path_location = aml_job.tags["output_directory"]
    storage_account = aml_job.tags["storage_account"]
    display_name = aml_job.display_name
    return project_path_location, storage_account, display_name


def get_job_code_location_container_name_and_environment(job_name, job_vc):
    """
    Gets the location of the code, including the container name and relative path in the container,
    as wel as the environment for the given job in the given workspace.

    Args:
        job_name (str): The name of the job to get the code location for
        job_vc (str): The name of the VC the job is in

    Returns:
        container_name (str): The name of the container the code is in
        code_location_container_name (str): The name of the container the code is in
        code_storage_account (str): The storage account the code is in
        environment_uri (str): The Azure URI of the environemnt the job is using
    """
    aml_job = _get_aml_job(job_name, job_vc)
    if not isinstance(aml_job, Command):
        raise ValueError(
            "II Error: you are attempting to re-run a job that is not a command job.  This likely"
            " becuase you are trying to re-run a failed job in a Pipeline (e.g. if using"
            " `--register_model`).  If you are trying to re-run a failed pipeline, please read"
            " `AML_FAQ.md` for more information."
        )
    code_resource_id = aml_job.code
    subscription_id, resource_group_name, job_workspace_name, _region = get_vc_sub_rg_workspace(job_vc)
    resource_client = ResourceManagementClient(AZ_CREDENTIAL, subscription_id)
    code_location_uri = resource_client.resources.get_by_id(
        code_resource_id,
        AZ_API_VERSION,
    ).properties["codeUri"]
    ml_client = MLClient(AZ_CREDENTIAL, subscription_id, resource_group_name, job_workspace_name)
    code_storage_account = ml_client.workspaces.get(job_workspace_name).storage_account.partition(
        "Microsoft.Storage/storageAccounts/"
    )[-1]

    container_and_code_path = code_location_uri.partition(f"https://{code_storage_account}.blob.core.windows.net:443/")[
        -1
    ].split("/")
    container_name = container_and_code_path[0]
    code_location_in_container = container_and_code_path[1]
    # Add azureml: to make it a URI
    environment_uri = "azureml:" + aml_job.environment
    return container_name, code_location_in_container, code_storage_account, environment_uri


def upload_blob_directory(storage_account, local_dir, remote_dir, container_name="models"):
    """
    Upload a directory to an Azure blob container.

    Args:
        storage_account (str): The storage account to upload the directory to
        local_dir (str): The local directory to upload to the blob container.
        remote_dir (str): The directory in the blob container to upload to.
        container_name (str): The name of the blob container to upload to
    """
    blob_service_client = get_blob_service_client(storage_account)
    if os.path.isdir(local_dir):
        list_of_local_file_paths = [str(f) for f in Path(local_dir).glob("**/*") if f.is_file()]
    else:
        list_of_local_file_paths = [local_dir]

    for local_file_path in tqdm(list_of_local_file_paths):
        blob_file = os.path.join(remote_dir, local_file_path).replace("\\", "/").strip("/")
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_file)
        try:
            with open(local_file_path, "rb") as data:
                blob_client.upload_blob(data, overwrite=True, max_concurrency=5)
        except Exception as e:
            raise RuntimeError(f"Upload error. Error detail: {e}") from e


def download_blob_directory(
    blob_dir_to_download,
    output_directory,
    storage_account,
    container_name="models",
):
    """
    Download a directory from an Azure blob container to a local directory.

    NOTE: this will download the entire directory recursively with structure preserved.

    Args:
        blob_dir_to_download (str): The directory in the blob container to download (e.g., projects/wake_submitter)
        output_directory (str): The local directory to download the blob directory to
        storage_account (str): The storage account the blob directory is in, e.g., "exawattaiprmbtts01scus"
        container_name (str): The name of the blob container to download from
    """
    os.makedirs(output_directory, exist_ok=True)
    num_files_in_dir_before_download = get_number_of_files_in_dir(output_directory)
    blob_service_client = get_blob_service_client(storage_account)
    container_client = blob_service_client.get_container_client(container=container_name)
    blob_list = container_client.list_blobs(name_starts_with=blob_dir_to_download)
    print(f"II Downloading blob directory '{blob_dir_to_download}' to '{output_directory}'")
    for blob in blob_list:
        if blob.name == blob_dir_to_download:
            continue
        if blob.size == 0:
            continue
        output_file_path = os.path.join(output_directory, Path(blob.name))
        if not os.path.exists(os.path.dirname(output_file_path)):
            os.makedirs(os.path.dirname(output_file_path), exist_ok=True)
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob.name)
        try:
            with open(output_file_path, "wb") as data:
                blob_client.download_blob(max_concurrency=5).readinto(data)
        except Exception as e:
            raise ValueError(
                "II Warning: Downloading blob directory failed. Please check the above trace "
                "for more information but this is likely because you don't have access to the "
                f"default storage account '{storage_account}' associated with the workspace "
                "you are submitting to.\n\n NOTE: the 'MSI auth not yet supported.' error "
                "is NOT relevant and can be ignored!"
            ) from e
    num_files_in_dir_after_download = get_number_of_files_in_dir(output_directory)
    if num_files_in_dir_after_download == num_files_in_dir_before_download:
        print(
            f"II Warning: no files were downloaded from blob directory '{blob_dir_to_download}'. "
            " This is likely because that directory does not exist."
        )


def _download_or_list_blob_files_helper(
    container_client,
    project_path_location,
    full_output_directory_path,
    file_patterns_to_match,
    download_one_file,
    preserve_folder_structure,
    list_only=False,
):
    """
    Helper function for download_or_list_blob_files. Helps make the code a bit cleaner.

    Args:
        container_client (azure.storage.blob.ContainerClient): The container client to search in
        project_path_location (str): The directory in the blob container to download from
        full_output_directory_path (str): The local directory to download the blob directory to.
            Should be an absolute path.
        file_patterns_to_match (list): A list of strings to match in the file names.
            If empty, will download all files.
        download_one_file (bool): If True, will only download one file from the blob directory.
        preserve_folder_structure (bool): If True, will preserve the folder structure of the
            blob directory when downloading.
        list_only (bool): If True, will only list the files in the blob directory instead of
            downloading them.
    """
    # TODO (@jacobplatin): might want to add logging/a progress bar here, but
    # not entirely efficient/easy since list_blobs is an iterator

    # Move this condition to be above the for loop to avoid calling an if-statement in each
    # iteration
    if file_patterns_to_match:
        for blob in container_client.list_blobs(name_starts_with=project_path_location):
            blob_client = container_client.get_blob_client(blob)
            for pattern in file_patterns_to_match:
                # TODO (@jacobplatin): might want to support glob matching here as well
                blob_file_name = blob.name.split("/")[-1]
                if pattern in blob_file_name:
                    if list_only:
                        print(blob.name)
                        continue
                    download_path = (
                        os.path.join(full_output_directory_path, blob.name)
                        if preserve_folder_structure
                        else os.path.join(full_output_directory_path, blob.name.split("/")[-1])
                    )
                    os.makedirs(os.path.dirname(download_path), exist_ok=True)
                    with open(download_path, "wb") as download_file:
                        blob_client.download_blob(max_concurrency=5).readinto(download_file)
                    if download_one_file:
                        return
    else:
        for blob in container_client.list_blobs(name_starts_with=project_path_location):
            blob_client = container_client.get_blob_client(blob)
            if list_only:
                print(blob.name)
                continue
            download_path = (
                os.path.join(full_output_directory_path, blob.name)
                if preserve_folder_structure
                else os.path.join(full_output_directory_path, blob.name.split("/")[-1])
            )
            os.makedirs(os.path.dirname(download_path), exist_ok=True)
            with open(download_path, "wb") as download_file:
                blob_client.download_blob(max_concurrency=5).readinto(download_file)
            if download_one_file:
                return


# pylint: disable=dangerous-default-value
def download_or_list_blob_files(
    project_path_location,
    storage_account,
    full_output_directory_path,
    file_patterns_to_match=[],
    container_name="models",
    download_one_file=False,
    preserve_folder_structure=False,
    list_only=False,
):
    """
    Download files from an Azure blob container to a local directory.  Differs from
    `download_blob_directory` in that it will download individual files instead of a directory.
    If you want to download an entire directory, use `download_blob_directory` instead, since it
    is faster.

    Args:
        project_path_location (str): The directory in the blob container to download from
        storage_account (str): The storage account the blob directory is in
        full_output_directory_path (str): The local directory to download the blob directory to.
            Should be an absolute path.
        file_patterns_to_match (list): A list of strings to match in the file names.
            If empty, will download all files.
        container_name (str): The name of the blob container to download from
        download_one_file (bool): If True, will only download one file from the blob directory.
            This is currently only used for downloading profiling (trace) files, which are large
            and we typically only need one of.
        preserve_folder_structure (bool): If True, will preserve the folder structure of the
            blob directory when downloading.
        list_only (bool): If True, will only list the files in the blob directory instead of
            downloading them.
    """
    blob_service = get_blob_service_client(storage_account)
    container_client = blob_service.get_container_client(container_name)

    if list_only:
        if file_patterns_to_match:
            file_patterns_to_match_text_str = ", or ".join(file_patterns_to_match)
            print(
                f"\nII Listing blobs with file patterns '{file_patterns_to_match_text_str}' from"
                f" '{project_path_location}'\n"
            )
        else:
            print(f"II Listing all blobs from '{project_path_location}'\n")
        _download_or_list_blob_files_helper(
            container_client,
            project_path_location,
            full_output_directory_path,
            file_patterns_to_match,
            download_one_file,
            preserve_folder_structure,
            list_only=True,
        )
        return

    if not os.path.exists(full_output_directory_path):
        os.makedirs(full_output_directory_path, exist_ok=True)

    print(f"II Downloading blobs to: '{full_output_directory_path}'")
    num_files_in_dir_before_download = get_number_of_files_in_dir(full_output_directory_path)

    _download_or_list_blob_files_helper(
        container_client,
        project_path_location,
        full_output_directory_path,
        file_patterns_to_match,
        download_one_file,
        preserve_folder_structure,
    )

    num_files_in_dir_after_download = get_number_of_files_in_dir(full_output_directory_path)
    if num_files_in_dir_after_download == num_files_in_dir_before_download:
        print(
            f"II Warning: no files were downloaded from blob directory '{project_path_location}'. "
            " This is likely because that directory does or no files matched the provided"
            " pattern(s)."
        )


def launch_tb(log_dir, port="6006"):
    """
    Launch a TensorBoard process with the given log directory.

    Args:
        log_dir (str): The directory containing the TensorBoard logs
        port (str): The port to launch TensorBoard on
    """
    print(f"II Launching TensorBoard with log directory '{log_dir}'")
    os.system(f"tensorboard --logdir={log_dir} --port {port} --bind_all")


def _aml_job_list_helper(aml_workspace, experiment_name):
    """
    Helper function for aml_job_list_wrapper.  Prints out the jobs in the given experiment.

    Args:
        aml_workspace (azureml.core.Workspace): The AML workspace to list jobs for
        experiment_name (str): The name of the experiment to list jobs for
    """

    def _text_wrapper_helper(initial_indent, fill_var, width=100, subsequent_indent=" " * 25):
        """
        Helps print out the job information neatly, with proper indents.
        """
        if fill_var is None:
            fill_var = "N/A"
        return textwrap.TextWrapper(
            initial_indent=initial_indent, width=width, subsequent_indent=subsequent_indent
        ).fill(fill_var)

    list_of_jobs = []
    for job in Experiment(aml_workspace, experiment_name).get_runs():
        job_str = [
            _text_wrapper_helper("name: ", job.id),
            _text_wrapper_helper("\tdisplay_name:    ", job.display_name),
            _text_wrapper_helper("\tstatus:          ", job.status),
            _text_wrapper_helper("\tdescription:     ", job.description),
            _text_wrapper_helper("\texperiment_name: ", job.experiment.name),
            # pylint: disable=protected-access
            _text_wrapper_helper("\tstudio_url:      ", job._run_details_url),
            "\n",
        ]
        list_of_jobs.append("\n".join(job_str))
    # I am printing here instead of within the loop above since it's a bit faster
    # and formats nicer on the CMD line
    for job in list_of_jobs:
        print(job)
    print("\n\n")


def aml_job_list_wrapper(
    subscription_id,
    resource_group_name,
    job_workspace_name,
    experiment_name=None,
):
    """
    Faster/more versatile version of `az ml job list` hat customizes the command for our needs.

    Args:
        subscription_id (str): The Azure subscription ID of the workspace
        resource_group_name (str): The Azure resource group name of the workspace
        job_workspace_name (str): The Azure ML workspace name
        experiment_name (str): The name of the experiment to list jobs for.  If None, will look
            in all experiments.

    """
    # NOTE: all experiments are guaranteed to contain this prefix
    base_exp_name = generate_base_experiment_name()
    aml_workspace = Workspace(subscription_id, resource_group_name, job_workspace_name)
    if experiment_name:
        print(
            f"II Listing all jobs in workspace '{job_workspace_name}' whose experiment name is"
            f" '{experiment_name}'\n"
        )
        _aml_job_list_helper(aml_workspace, experiment_name)
    else:
        print(
            f"II Listing all jobs in workspace '{job_workspace_name}' whose experiment name"
            f" contains '{base_exp_name}'\n"
        )
        for experiment in Experiment.list(aml_workspace):
            if base_exp_name in experiment.name:
                print(f"II Listing all jobs in experiment '{experiment.name}'\n")
                _aml_job_list_helper(aml_workspace, experiment.name)


class AMLCodeDiff:
    """
    A class to handle code diffs between two AML jobs.  Most functionality is
    copied directly from
    https://maluuba.visualstudio.com/_git/philly-tools?path=/amlt/repo_snapshot.py&version=GBmain

    Args:
        job_vc_1 (str): The VC that the first job is in
        job_1 (str): The name of the first job to diff
        job_vc_2 (str): The VC that the second job is in
        job_2 (str): The name of the second job to diff
    """

    def __init__(self, job_vc_1, job_1, job_vc_2, job_2):
        self.job1, self.job2 = job_1, job_2
        self.job_vc_1 = job_vc_1
        self.job_vc_2 = job_vc_2
        git_cmd = shutil.which("git")
        if git_cmd is None:
            raise ValueError("Git not found: please install it!")

    def check_out(
        self,
        base_repo,
        job,
        job_vc,
        path,
        branchname_suffix,
    ):
        """
        Downloads the code from the given job, checkouts a new git branch, and commits the code.

        Args:
            base_repo (git.repo.base.Repo): The base repo to use for the diff
            job (str): The job to download the code from
            job_vc (str): The VC that the job is in
            path (str): The path to download the code to
            branchname_suffix (str): The suffix to append to the branch name

        Returns:
            branch_name (str): The name of the branch that was checked out with this job's code
        """
        code_loc = path

        branch_name = self.generate_branch_name(job, branchname_suffix)

        (
            old_job_code_container_name,
            old_job_code_location_in_container,
            old_job_code_storage_account,
            _,
        ) = get_job_code_location_container_name_and_environment(
            job,
            job_vc,
        )
        download_blob_directory(
            old_job_code_location_in_container,
            path,
            old_job_code_storage_account,
            container_name=old_job_code_container_name,
        )

        try:
            os.unlink(os.path.join(code_loc, "repo.diff"))
        # pylint: disable=broad-except
        except Exception:
            pass
        try:
            os.unlink(os.path.join(code_loc, "staged.diff"))
        # pylint: disable=broad-except
        except Exception:
            pass

        base_repo.git.checkout("-b", branch_name)
        base_repo.git.add(".")
        base_repo.git.commit(m="/".join(job))
        return branch_name

    @staticmethod
    def generate_branch_name(job_name, suffix):
        """
        Generates a branch name for the given job name and suffix.

        Args:
            job_name (str): The name of the job
            suffix (str): The suffix to append to the branch name

        Returns:
            branch_name (str): The name of the branch
        """
        return "ptdiff/" + re.sub(r"[^\w.-]", "_", job_name) + "/" + suffix

    def get_diff_str(self):
        """
        Gets the diff str for the code between the two jobs.
        """
        tmp_output_directory_uuid = create_uuid()
        tmp_dir = os.path.join("/tmp/cascades_tmp_dir", tmp_output_directory_uuid)
        try:
            with Repo.init(tmp_dir) as base_repo:
                base_repo.git.commit("--allow-empty", "-m", "initial")
                initial_commit = base_repo.head.commit.hexsha
                branch1 = self.check_out(base_repo, self.job1, self.job_vc_1, tmp_dir, "1")
                base_repo.git.checkout(initial_commit)
                branch2 = self.check_out(base_repo, self.job2, self.job_vc_2, tmp_dir, "2")
                diff = base_repo.git.diff(branch1, branch2)
                base_repo.close()
        finally:
            try:
                shutil.rmtree(tmp_dir)
            except PermissionError:
                # on windows, this seems to fail reliably, maybe due to dangling open files.
                # gc.collect() doesn't solve the issue, let's just ignore it.
                pass

        return diff

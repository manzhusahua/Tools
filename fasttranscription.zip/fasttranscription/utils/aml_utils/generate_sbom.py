"""
Module for generating Software Bill Of Materials (SBOM) for cascades training.
"""

import sys
import argparse
import logging

logging.basicConfig(level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

LOG = logging.getLogger("submitter.generate_sbom")

if __name__ == "__main__":
    LOG.info(sys.argv)

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output_path",
        "-o",
        type=str,
        required=True,
        help="The output path where the SBOM files will be stored.",
    )

    parsed_args, _ = parser.parse_known_args()

    if parsed_args.output_path is None:
        raise RuntimeError("SBOM output path is not specified.")

    LOG.info(f"Azure ML will generate and upload SBOM files to {parsed_args.output_path}")

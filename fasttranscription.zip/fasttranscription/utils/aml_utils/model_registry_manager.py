"""
Implementation of ModelRegistryManager for managing model registration in AML registry.
"""

import logging
import os
import shutil
import tempfile
from pathlib import Path

import backoff


logger = logging.getLogger(__name__)

try:
    from azure.core.exceptions import ResourceNotFoundError
    from azure.identity import ManagedIdentityCredential

    AZ_CREDENTIAL = ManagedIdentityCredential(client_id=os.environ.get("UAI_CLIENT_ID"))
except ImportError as e:
    logger.warning(f"Could not import azure libraries: {e}")

try:
    from zettasdk.registry.models import (
        get_model_info,
        add_or_update_model,
        UpdateMode,
    )
except ImportError:
    logger.debug("Zetta sdk is not installed, disable model registry support")


@backoff.on_exception(backoff.expo, Exception, max_tries=5)
def call_with_retry(function, *args, **kwargs):
    """Calls a given function with retry."""
    return function(*args, **kwargs)


class ModelRegistryManager:
    """Class for managing model registration in AML registry.

    Args:
        sbom_input_path (str | Path): The path where the SBOM files will be saved into registry.
        model_registration_region (str): The model registration region to use for storing models.
        model_registration_name (str): The model registration name to use for storing models.
    """

    def __init__(
        self,
        sbom_input_path: str | Path,
        model_registration_region: str,
        model_registration_name: str,
    ) -> None:
        self.sbom_input_path = sbom_input_path
        self.registration_name = model_registration_name
        self.region = model_registration_region

    def save(self, model_resources: list[str | Path], version: int) -> None:
        """Save SBOM and model resources into AML registry.

        Args:
            model_resources (list[str | Path]): List of resource files to be saved along with the model.
            version (int): The version number for the model which will be registered.
        """
        if os.path.exists(self.sbom_input_path) and model_resources:
            logger.info(f"Registering model from {self.sbom_input_path} and {model_resources} in AML registry")
            self.register_model_checkpoint(
                self.sbom_input_path, model_resources, self.registration_name, version=version
            )

    def register_model_checkpoint(
        self, sbom_path: str | Path, model_resources: list[str | Path], registration_name: str, version: int
    ) -> None:
        """Uploads the model to AML registry and registers them under a unique name.

        Args.
            sbom_path (str | Path): Local path where the model is saved.
            model_resources (list[str | Path]): List of resource files to be saved along with the model.
            registration_name (str): The name of AML model registry.
            version (int): The version number under which the model will be registered.
        """
        skip_registration = False
        with tempfile.TemporaryDirectory() as temp_dir:
            checkpoint_dest = os.path.join(temp_dir, registration_name)
            call_with_retry(os.makedirs, checkpoint_dest, exist_ok=True)

            # Skip registration if the model was already registered by a previous run retry.
            registered_model = call_with_retry(self._check_model_in_registry, registration_name, version)
            if registered_model is not None:
                logger.info(
                    f"Model {registration_name}, version {version} already available in registry. "
                    "Skipping registration..."
                )
                skip_registration = True

            if not skip_registration:
                if os.path.exists(sbom_path):
                    call_with_retry(
                        shutil.copytree,
                        sbom_path,
                        os.path.join(checkpoint_dest, "sbom"),
                    )

                resource_dest = os.path.join(checkpoint_dest, "asset")
                os.makedirs(resource_dest, exist_ok=True)

                for resource in model_resources:
                    if os.path.exists(resource):
                        if os.path.isfile(resource):
                            call_with_retry(
                                shutil.copy,
                                resource,
                                os.path.join(checkpoint_dest, "asset", os.path.basename(resource)),
                            )
                        else:
                            call_with_retry(
                                shutil.copytree,
                                resource,
                                os.path.join(checkpoint_dest, "asset"),
                            )

                try:
                    call_with_retry(
                        add_or_update_model,
                        credential=AZ_CREDENTIAL,
                        name=registration_name,
                        path=checkpoint_dest,
                        version=version,
                        region=self.region,
                        mode=UpdateMode.ADD_NEW if version == 1 else UpdateMode.ADD_NEXT_VERSION,
                    )
                except Exception:
                    logger.exception(
                        f"Could not register model {self.registry_name}, version {self.version} in AML registry"
                    )

    def _check_model_in_registry(self, registration_name: str, version: int) -> object:
        """Checks if a model is already registered in AML registry.

        Args:
            registration_name (str): The name of the model to check.
            version (int): The version of the model to check.
        """
        registered_model = None

        try:
            registered_model = get_model_info(
                registration_name,
                version=version,
                region=self.region,
                credential=AZ_CREDENTIAL,
            )
        except ResourceNotFoundError:
            logger.info(f"Did not find model {registration_name}, version {version} in AML registry.")
        except Exception:
            logger.exception("Could not get model info from AML registry")

        return registered_model


def run_register_model(sbom_input_path, model_resources, model_registration_name, model_registration_region, version):
    """To save SBOM and model resources into registry.

    Args:
    """
    if not os.path.exists(sbom_input_path):
        raise RuntimeError("SBOM input path is not existed.")
    if not model_resources:
        raise RuntimeError("Model resources are not provided.")
    model_registry_manager = ModelRegistryManager(sbom_input_path, model_registration_region, model_registration_name)
    model_registry_manager.save(model_resources, version=version)

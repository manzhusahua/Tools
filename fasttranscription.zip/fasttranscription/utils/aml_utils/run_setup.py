"""
AML job setup run script.
"""

import argparse
import logging
import os
from pathlib import Path
import subprocess
import sys
import time

MARKER = Path("/tmp/.aml_setup_done")

module_logger = logging.getLogger(__name__)


# pylint: disable=consider-using-with
def _run_command(
    commands,
    cwd=None,
    stderr=subprocess.STDOUT,
    shell=False,
    env=None,
    stream_stdout=True,
    throw_on_retcode=True,
    logger=None,
):
    if logger is None:
        logger = module_logger

    if cwd is None:
        cwd = os.getcwd()

    t_0 = time.perf_counter()
    try:
        logger.debug(f"Executing {commands} in {cwd}")
        out = ""
        sub_p = subprocess.Popen(commands, stdout=subprocess.PIPE, stderr=stderr, cwd=cwd, shell=shell, env=env)
        for line in sub_p.stdout:
            line = line.decode("utf-8").rstrip()
            if line and line.strip():
                logger.debug(line)
                if stream_stdout:
                    sys.stdout.write(line)
                    sys.stdout.write("\n")
                out += line
                out += "\n"
        sub_p.communicate()
        retcode = sub_p.poll()
        if throw_on_retcode:
            if retcode:
                raise subprocess.CalledProcessError(retcode, sub_p.args, output=out, stderr=sub_p.stderr)
        return retcode, out
    finally:
        t_1 = time.perf_counter()
        logger.debug(f"Execution took {(t_1 - t_0):.0f}s for {commands} in {cwd}")


def run_command(
    commands,
    cwd=None,
    stderr=subprocess.STDOUT,
    shell=False,
    stream_stdout=True,
    throw_on_retcode=True,
    logger=None,
):
    """run command"""
    _, out = _run_command(
        commands,
        cwd=cwd,
        stderr=stderr,
        shell=shell,
        stream_stdout=stream_stdout,
        throw_on_retcode=throw_on_retcode,
        logger=logger,
    )
    return out


if __name__ == "__main__":
    local_rank = int(os.getenv("LOCAL_RANK", "0"))
    print(f"Got {local_rank} as the local rank")
    print("Entering setup script...")

    parser = argparse.ArgumentParser()
    parser.add_argument("--commands-to-run", type=str, nargs="+")
    args = parser.parse_args()
    if local_rank is not None:
        if local_rank == 0:
            try:
                if args.commands_to_run:
                    for cmd in args.commands_to_run:
                        print(f"Running setup command: {cmd}")
                        run_command(
                            commands=cmd,
                            shell=True,
                        )
            finally:
                MARKER.touch()
        while not MARKER.exists():
            time.sleep(1)
    else:
        print("Local rank could not be found in your environment variables: not running setup steps")
    print("Exiting setup script")

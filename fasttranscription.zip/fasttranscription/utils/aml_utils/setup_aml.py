"""A helper script to setup environment to use AML job submission."""

import os
import subprocess
import sys
import pathspec


MB = 1024 * 1024
WARN_TOTAL_FILE_SIZE_MB = 20


def get_azure_credential(non_interactive: bool = False, return_token: bool = False):
    """Get Azure credentials for authentication.

    Default AzureCredential will use an EnvironmentCredential for service principal
    authentication if the AZURE_TENANT_ID, AZURE_CLIENT_ID,
    and AZURE_CLIENT_SECRET environment variables are set, otherwise it will use an
    appropriate user-identity credential such as AzureCliCredential.
    Args:
        non_interactive: bool
            If True, then interactive methods of authenticating will be disabled.
            When False, if non-interactive methods fail then interactive forms
            (using the browser or device code) will be attempted.
        return_token: bool
            If True, will call the method get_token() to return the token.
    """
    from azure.identity import DefaultAzureCredential, DeviceCodeCredential

    try:
        from azure.identity._constants import AZURE_CLI_CLIENT_ID
    except ImportError:
        from azure.identity._constants import (
            DEVELOPER_SIGN_ON_CLIENT_ID as AZURE_CLI_CLIENT_ID,
        )

    credential = DefaultAzureCredential(
        exclude_managed_identity_credential=True,
        exclude_shared_token_cache_credential=True,
        exclude_interactive_browser_credential=non_interactive,
    )

    if not non_interactive:
        dcc = DeviceCodeCredential(AZURE_CLI_CLIENT_ID)
        # Append the DCC to the end of the credentials list
        credential.credentials = credential.credentials + tuple([dcc])

    if return_token:
        token = credential.get_token("https://management.azure.com/", scopes=[".default"])
        return token

    return credential


def get_sp_authentication():
    """Get the Service Principal Authentication"""
    from azureml.core.authentication import ServicePrincipalAuthentication

    tenant_id = os.environ.get("AZURE_TENANT_ID")
    service_principal_id = os.environ.get("AZURE_CLIENT_ID")
    service_principal_password = os.environ.get("AZURE_CLIENT_SECRET")
    mode = "sp" if all([tenant_id, service_principal_id, service_principal_password]) else "device"
    if mode == "sp":
        auth = ServicePrincipalAuthentication(
            tenant_id=tenant_id,
            service_principal_id=service_principal_id,
            service_principal_password=service_principal_password,
        )
        return auth

    return None


def install_package(package, verbose=True):
    """Will call pip install with provided arguments."""
    verbose_option = ["-q"] if not verbose else []
    print(f"\n ********* Installing python package: {package} ********* \n")
    subprocess.check_call([sys.executable, "-m", "pip", "install"] + verbose_option + [package])


def _get_secret_client(url):
    from azure.keyvault.secrets import SecretClient

    return SecretClient(vault_url=url, credential=get_azure_credential())


def check_or_create_workspace_connection_to_acr(docker_registry, docker_username, root_dir, docker_key_vault_name):
    """
    Create workspace connection to Azure Container Registry.
    """
    docker_registry_name = f"{docker_registry.rstrip('.azurecr.io')}"
    acr_workspace_connection_name = f"az_ml_cr_submitter_{docker_registry_name}"
    try:
        subprocess.check_call(
            f"az ml connection show -n {acr_workspace_connection_name}",
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        print(f"Creating workspace connection to {docker_registry} with name {acr_workspace_connection_name}")
        key_vault_url = f"https://{docker_key_vault_name}.vault.azure.net"
        secret_client = _get_secret_client(key_vault_url)

        secret_name = f"{docker_registry_name}-registry-pwd"
        password = str(secret_client.get_secret(f"{secret_name}").value)
        config_path = os.path.join(root_dir, "aml_utils", "aml_workspace_connection_cfg.yaml")
        subprocess.check_call(
            (
                f"az ml connection create -f {config_path} -n {acr_workspace_connection_name} "
                f"--set target={docker_registry} --set credentials.username={docker_username} "
                f"--set credentials.password={str(password)}"
            ),
            shell=True,
        )


def _check_aml():
    """
    Check if AZ CLI, AZ ML, and AZ Storage extensions are properly setup.
    """
    subprocess.check_call(
        "az -h && az ml -h && az storage azcopy -h",
        shell=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


# pylint: disable=inconsistent-return-statements
def check_setup_aml():
    """Check if az ml extension is properly setup (if not, will run the setup process)."""

    try:
        return _check_aml()
    except subprocess.CalledProcessError:
        print(
            "Your machine has not been set up correct to use submission scripts. Please read the "
            "https://dev.azure.com/speechoutput/_git/Submitter to setup your machine."
        )
        exit(1)


def check_az_account():
    """Check if loged into the Azure CLI (if not, will run the login process)."""
    try:
        subprocess.check_call(
            "az account get-access-token",
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        if sys.platform != "win32":
            subprocess.check_call("az login --use-device-code", shell=True)
        else:
            subprocess.check_call("az login", shell=True)


def check_and_warn_file_size(code_dir, aml_ignore_file_anme):
    """
    Check the total file size of the code directory, respecting the ignore patterns in the
    .amltignore file and warns the user if the total file size is too large.
    """
    ignore_path = os.path.join(code_dir, aml_ignore_file_anme)
    assert os.path.exists(ignore_path)
    with open(ignore_path, encoding="utf8") as f:
        ignore_patterns = list(f.readlines())

    ignore_spec = pathspec.PathSpec.from_lines("gitwildmatch", ignore_patterns)

    root_dir = os.path.abspath(code_dir)
    total_file_size = 0
    # pylint: disable=redefined-builtin
    for dir, subdirs, files in os.walk(root_dir, topdown=True, followlinks=True):
        skip_subdir = set()
        for _, subdir in enumerate(subdirs):
            subdir_path = os.path.join(dir, subdir)
            rel_subdir_path = os.path.relpath(subdir_path, root_dir) + os.path.sep
            if ignore_spec.match_file(rel_subdir_path):
                skip_subdir.add(subdir)

        # skip subdirs
        subdirs[:] = [s for s in subdirs if s not in skip_subdir]

        for filename in files:
            file_path = os.path.join(dir, filename)
            rel_file_path = os.path.relpath(file_path, root_dir)
            if ignore_spec.match_file(rel_file_path):
                continue

            file_size = os.path.getsize(file_path) / MB
            total_file_size += file_size

    if total_file_size > WARN_TOTAL_FILE_SIZE_MB:
        if (
            not input(
                f"II WARNING: The total size of the code directory is {total_file_size:.2f}MB,  which is larger than "
                f"{WARN_TOTAL_FILE_SIZE_MB}MB. It is likely that you are copying unnecessary files, so please add any "
                f"unneeded files or directories to your `.amlignore` file \n\n"
                f"Please enter Y to continue with job submission or N to exit."
            )
            .lower()
            .startswith("y")
        ):
            print("II Exiting job submission...")
            sys.exit(1)

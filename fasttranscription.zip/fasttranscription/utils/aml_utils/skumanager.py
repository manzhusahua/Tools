# pylint: disable=duplicate-code
# pylint: disable=invalid-name
"""Defines functions that describe our training cluster workspaces."""

# pylint: disable=duplicate-code

VC_TO_SUB_RG_WS_DICT = {
    # (subscription id, resource group name, workspace name, region)
    "spch-sing-wu3": (
        "b73d8cb2-6e57-4dc7-8775-0e125652753a",
        "speech-sing",
        "speech-sing-ws01-westus3",
        "westus3",
    ),
    "cogs-sing-shared-wu2": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "cogsvc-sing",
        "cogsvc-sing-ws01-westus2",
        "westus2",
    ),
    "cogs-sing-shared-eu": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "cogsvc-sing",
        "cogsvc-sing-ws01-eastus",
        "eastus",
    ),
    "cogs-sing-shared-wu3": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "cogsvc-sing",
        "cogsvc-sing-ws01-westus3",
        "westus3",
    ),
    "cogs-sing-shared-sc": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "cogsvc-sing",
        "cogsvc-sing-ws01-scus",
        "southcentralus",
    ),
    "cogsvc-sing-amd-vc02": (
        "b73d8cb2-6e57-4dc7-8775-0e125652753a",
        "cogsvc-sing-amd-vc02",
        "cogsvc-sing-amd-vc02-ws-wu3",
        "westus3",
    ),
    # TTS clusters
    "spch-sing-tts-sc": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "speech-sing-tts",
        "speech-sing-tts-ws01-scus",
        "southcentralus",
    ),
    "spch-sing-ttsprod-sc": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "speech-sing-tts",
        "speech-sing-tts-prod-ws01-scus",
        "southcentralus",
    ),
    "spch-sing-tts-wu2": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "speech-sing-tts",
        "speech-sing-tts-ws01-westus2",
        "westus2",
    ),
    "spch-singttsprod-wu2": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "speech-sing-tts",
        "speech-sing-tts-prod-ws01-westus2",
        "westus2",
    ),
    # End of TTS clusters
    # CSR clusters
    "csr-sing-speech-sc": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "csr-sing-speech",
        "csr-sing-speech-ws01-scus",
        "southcentralus",
    ),
    "csr-sing-wu2": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "csr-sing",
        "csr-sing-ws01-westus2",
        "westus2",
    ),
    "csr-sing-speech-wu2": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "csr-sing-speech",
        "csr-sing-speech-ws01-westus2",
        "westus2",
    ),
    "csr-sing-nlk-sc": (
        "48b6cd5e-3ffe-4c2e-9e99-5760a42cd093",
        "csr-sing-nlk",
        "csr-sing-nlk-ws01-scus",
        "southcentralus",
    ),
    # End of CSR clusters
}


def get_data_storage_region(data_storage_account):
    """Get region for storage account."""
    region_dict = {
        "eus": "eastus",
        "eus2": "eastus2",
        "scus": "southcentralus",
        "wus2": "westus2",
        "wus3": "westus3",
    }

    # Assert the storage account name
    valid_storage_account_name = ["stdstoragetts", "sdrgstd", "sdrgstorage"]
    assert any(
        list(x in data_storage_account for x in valid_storage_account_name)
    ), f"Storage account name {data_storage_account} is not valid"

    # Get the region from the storage account name
    if "stdstoragetts" in data_storage_account:
        region = data_storage_account.split("stdstoragetts")[1]
    elif "sdrgstd" in data_storage_account:
        region = data_storage_account.split("sdrgstd")[1]
    elif "sdrgstorage" in data_storage_account:
        region = data_storage_account.split("sdrgstorage")[1]
    # drop number
    region = region[2:]
    # verify known region
    assert region in region_dict
    return region_dict[region]


def get_model_registry_region(model_storage_account):
    """Get region of AML model registry to be used."""
    region = None
    if "exawattaiprmbtts01" in model_storage_account:
        region = model_storage_account.split("exawattaiprmbtts01")[1]

    region_dict = {
        "eus": "eastus",
        "eus2": "eastus2",
        "scus": "southcentralus",
        "wus2": "westus2",
        "wus3": "westus3",
    }

    return region_dict[region] if region else None


def get_data_storage_accounts_by_cluster_name(cluster_name):
    """Get associated storage account for a cluster.

    Args:
        cluster_name (str): The name of the VC.
    """
    cluster_region = cluster_name.split("-")[-1]

    cluster_region_to_data_storage_accounts_dict = {
        "eu": "stdstoragetts01eus",
        "eu2": "stdstoragetts01eus2",
        "sc": "stdstoragetts01scus",
        "wu2": "stdstoragetts01wus2",
        "wu3": "stdstoragetts01wus3",
    }

    cluster_with_ambiguous_region_to_data_storage_accounts_dict = {
        "cogsvc-sing-amd-vc02": "stdstoragetts01wus3",
        "csr-sing-speech-sc": "sdrgstd01scus",
        "csr-sing-wu2": "sdrgstorage01wus2",
        "csr-sing-speech-wu2": "sdrgstorage01wus2",
        "csr-sing-nlk-sc": "sdrgstd01scus",
    }

    data_storage_accounts = cluster_with_ambiguous_region_to_data_storage_accounts_dict.get(cluster_name, [])
    # do the ambiguous check first in case it ends with an existing region
    if not data_storage_accounts:
        data_storage_accounts = cluster_region_to_data_storage_accounts_dict.get(cluster_region, [])
        if not data_storage_accounts:
            raise ValueError(f"Cannot find the data storage account for cluster {cluster_name}")

    return data_storage_accounts


def get_model_storage_account_by_cluster_name(cluster_name):
    """Get associated storage account for a cluster."""
    cluster_region = cluster_name.split("-")[-1]

    cluster_region_to_model_storage_account_dict = {
        "eu": "exawattaiprmbtts01eus",
        "eu2": "exawattaiprmbtts01eus2",
        "sc": "exawattaiprmbtts01scus",
        "wu2": "exawattaiprmbtts01wus2",
        "wu3": "exawattaiprmbtts01wus3",
    }

    cluster_with_ambiguous_region_to_model_storage_account_dict = {
        "cogsvc-sing-amd-vc02": "exawattaiprmbtts01wus3",
        "csr-sing-speech-sc": "sdrgprmblob01scus",
        "csr-sing-wu2": "sdrgprmblob01wus2",
        "csr-sing-speech-wu2": "sdrgprmblob01wus2",
        "csr-sing-nlk-sc": "sdrgprmblob01scus",
    }

    # do the ambiguous check first in case it ends with an existing region
    model_storage_account = cluster_with_ambiguous_region_to_model_storage_account_dict.get(cluster_name, [])

    if not model_storage_account:
        model_storage_account = cluster_region_to_model_storage_account_dict.get(cluster_region, [])
        if not model_storage_account:
            raise ValueError(f"Cannot find the data storage account for cluster {cluster_name}")

    return model_storage_account


# pylint: disable=invalid-name
def get_vc_sub_rg_workspace(vc: str = None) -> tuple:
    """Get associated subscription, resource group, and workspace for a given Singularity VC
    Args:
        vc (str): The name of the VC.  If None, return all VCs.
    Returns:
        tuple: (subscription id, resource group name, workspace name, region)
    """
    if vc in VC_TO_SUB_RG_WS_DICT:
        return VC_TO_SUB_RG_WS_DICT[vc]
    raise ValueError(f"Cannot find the workspace scope for cluster {vc}")


def get_vc_sub_rg_workspace_dict():
    """
    Returns the dict mapping from a VC to subscription, resource group, workspace, and region.
    Needed for `list` in `aml_cli_cmds.py`
    """
    return VC_TO_SUB_RG_WS_DICT


def get_sku_detail_by_instance_type(instance_type):
    """Get SKU details by Instance type (Series). This is only for singularity"""

    sku_detail_dict = {
        # (GPU, Memory, GPU/Node, IB)
        "NCv3": ("V100", 16, 4, True),
        "NDv2": ("V100", 32, 8, True),
        "NDMI200v4": ("MI200", 64, 16, True),
        "NDv2g1": ("V100", 16, 8, False),
    }

    if instance_type in sku_detail_dict:
        return sku_detail_dict[instance_type]
    raise ValueError(f"Cannot find sku_detail for instance {instance_type}")


def get_instance_type_by_sku(sku, gpu_count, is_ib):
    """Get instance type by SKU"""
    instance_type_by_sku_dict = {
        # (GPU, Memory, #GPU/Node, IB)
        "NCv3": {
            "NC6_v3": ("V100", 16, 1, False),
            "NC12_v3": ("V100", 16, 2, False),
            "NC24_v3": ("V100", 16, 4, False),
            "NC24r_v3": ("V100", 16, 4, True),
        },
        "NDv2g1": {
            "ND5_v2g1": ("V100", 16, 1, False),
            "ND10_v2g1": ("V100", 16, 2, False),
            "ND20_v2g1": ("V100", 16, 4, False),
            "ND40s_v2g1": ("V100", 16, 8, False),
        },
        "NDv2": {
            "ND5_v2": ("V100", 32, 1, False),
            "ND10_v2": ("V100", 32, 2, False),
            "ND20_v2": ("V100", 32, 4, False),
            "ND40r_v2": ("V100", 32, 8, True),
            "ND40rs_v2": ("V100", 32, 8, True),
        },
        "NDMI200v4": {
            "ND12as_MI200_v4": ("MI200", 64, 2, False),
            "ND24as_MI200_v4": ("MI200", 64, 4, False),
            "ND48as_MI200_v4": ("MI200", 64, 8, False),
            "ND96asr_MI200_v4": ("MI200", 64, 16, True),
            "ND96as_MI200_v4": ("MI200", 64, 16, False),
        },
    }

    sku_instance_types = instance_type_by_sku_dict[sku]
    for instance_type, instance_type_quotas in sku_instance_types.items():
        _, _, instance_gpu_count, ib_enabled = instance_type_quotas
        if instance_gpu_count >= gpu_count and is_ib and ib_enabled:
            return instance_type
        if instance_gpu_count >= gpu_count:
            return instance_type
    raise ValueError(f"Could not find specific instance type for sku {sku} with given constraints.")

"""A collection of useful utilities for working with AML."""

import os
import shutil
import sys
import time
from pathlib import Path

# pylint: disable=wrong-import-order
from azureml.core import Experiment
from zettasdk.util import load_workspace

sys.path.append(str(Path(__file__).parent.parent.resolve()))
# pylint: disable=import-outside-toplevel,wrong-import-position
from aml_utils.setup_aml import get_sp_authentication  # noqa: E402
from aml_utils.skumanager import get_vc_sub_rg_workspace  # noqa: E402


def get_aml_run(exp_name, vc_name="spch-sing-devtest-eu"):
    """Returns AML job run object."""
    auth = get_sp_authentication()

    subscription, _, workspace_name = get_vc_sub_rg_workspace(vc=vc_name)
    workspace, _, _ = load_workspace(workspace_name, auth=auth, subscription_id=subscription)
    exp = Experiment(workspace, exp_name)
    try:
        time.sleep(20)
        run = list(exp.get_runs())[0]
    except IndexError:
        print(f"Can not found the experiment: {exp_name}, please give a correct job name.")

    return run


def get_job_status(exp_name):
    """Returns job status for specified experiment.

    Args:
        exp_name (str): aml experiment name (assumed to contain a single job).

    Returns:
        str: aml job status.
    """
    run = get_aml_run(exp_name)
    return run.status


def get_job_link(exp_name):
    """Returns job link for specified experiment.

    Args:
        exp_name (str): aml experiment name (assumed to contain a single job).

    Returns:
        str: aml portal job link.
    """
    run = get_aml_run(exp_name)
    return run.get_portal_url()


def abort_job(exp_name):
    """Aborts specified AML job.

    Args:
        exp_name (str): aml experiment name (assumed to contain a single job).
    """
    run = get_aml_run(exp_name)
    run.cancel()
    run.wait_for_completion()


def cleanup(gen_files_folders):
    """Removes given files"""
    for item in gen_files_folders:
        if os.path.isfile(item):
            os.remove(item)
        elif os.path.isdir(item):
            shutil.rmtree(item)
